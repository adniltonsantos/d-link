#!/usr/bin/php
<?php 

 include '/var/ACS/secureFiles/models/modelWebTask.php';
 include '/var/ACS/secureFiles/models/device.php';

$obj_fb= new modelWebTask();
$report_obj= $obj_fb->getfeedback();
$obj_ar= new Device();
$report_addr=$obj_ar->getApiRepostAddr();

$report_arr = json_decode(json_encode($report_obj), True);

$report_addr =array_values( json_decode(json_encode($report_addr), True)[0]);
//print_r($report_addr);

if(strlen($report_addr[0])>3 && count($report_arr)>0 ){
	$obj_fb->updatefeedback($report_arr);

	$payload = json_encode($report_arr);
	// Prepare new cURL resource
	$ch = curl_init($report_addr[0]);
	//curl_setopt($ch, CURLINFO_HEADER_OUT, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
	 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	 $len= strlen($payload);
	// Set HTTP Header for POST request 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'Content-Type: application/json',
	    'Content-Length: ' .$len)
	);
	 
	// Submit the POST request
	$result = curl_exec($ch);

	// Close cURL session handle
	curl_close($ch);
}

?> 