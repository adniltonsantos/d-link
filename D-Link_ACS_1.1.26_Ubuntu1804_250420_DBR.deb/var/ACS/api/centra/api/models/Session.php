<?php

namespace Centra\Api\Models;

class Session
{

  /**
   * Возвращает $_SESSION
   * @param $key string
   * @return array|bool
   */
  public static function get($key = null)
  {
    if (!is_null($key) && isset($_SESSION[$key]))
      return $_SESSION[$key];
    return $_SESSION;
  }

  /**
   * Добавляет значение в сессию
   * @param $key
   * @param $value
   */
  public static function add($key, $value)
  {
    $_SESSION[$key] = $value;
  }

  /**
   * Очищает значение для ключа
   * @param $key
   */
  public static function clear($key)
  {
    unset($_SESSION[$key]);
  }

}
