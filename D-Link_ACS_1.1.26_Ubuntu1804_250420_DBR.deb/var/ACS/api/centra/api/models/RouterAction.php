<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 15:23
 */

namespace Centra\Api\Models;

use Centra\Api\Interfaces\RouterActionInterface;

class RouterAction implements RouterActionInterface
{

  public function run()
  {
    return [];
  }

}