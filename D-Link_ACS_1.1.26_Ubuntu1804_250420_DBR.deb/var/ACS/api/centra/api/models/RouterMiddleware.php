<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 17:54
 */

namespace Centra\Api\Models;

use Centra\Api\Interfaces\RouterMiddlewareInterface;
use \Centra\Database\Main\Model;

class RouterMiddleware extends Model implements RouterMiddlewareInterface
{

  public function run()
  {

  }
}