<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 22.05.18
 * Time: 11:13
 */

namespace Centra\Api\Middleware;


use Centra\Api\Models\RouterMiddleware;
use Centra\Main\Exceptions\ClassException;
use Centra\Main\Utils\Validator;
use Centra\Main\Exceptions\ValidException;

/**
 * Class CheckId
 * @package Centra\Portal\Api\Middleware
 * @property integer $id
 */
class CheckId extends RouterMiddleware
{

  public static function rules()
  {
    return [
      ['id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id указан неверно',
        'required' => true,
      ]]
    ];
  }

  /** Выполняет проверку
   * @throws ValidException
   * @throws ClassException
   */
  public function run()
  {
    if(!empty(\query("id")))
      $this->setId(\query("id"));
    $this->check();
    if($this->hasError())
      throw new ValidException(implode(";", $this->getErrors()));
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

}