<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 22.05.18
 * Time: 11:13
 */

namespace Centra\Api\Middleware;

use Centra\Http\Main\Response;
use Centra\Api\Models\RouterMiddleware;
use Centra\Log4p\Main\Log;
use Centra\Main\Utils\StringBuilder;

/**
 * Class LogResponse
 * @package Centra\Api\Middleware
 * @property mixed $result
 */
class LogResponse extends RouterMiddleware
{

  /**
   * Записывает в журнал базовый запрос
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    /** @var Response $response */
    $response = \store(Response::class);
    if($response->getStatus() == Response::SUCCESS){
      $result = $response->getResult();
      $message = "Ответ: " . json_encode($result, JSON_UNESCAPED_UNICODE);
      Log::info($message);
    }
    if($response->getStatus() == Response::FAILED){
      $result = $response->getResult();
      Log::info($result);
      /** @var StringBuilder $stringBuilder */
      $stringBuilder = \store(StringBuilder::class);
      Log::debug($stringBuilder->get());
      Log::debug($result);
    }
  }

}