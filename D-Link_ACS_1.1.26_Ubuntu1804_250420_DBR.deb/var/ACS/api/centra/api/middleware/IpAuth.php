<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 22.05.18
 * Time: 11:13
 */

namespace Centra\Api\Middleware;

use Centra\Http\Models\IpNetwork;
use Centra\Http\Main\Request;
use Centra\Api\Models\RouterMiddleware;
use Centra\Main\Exceptions\ClassException;
use Centra\Main\Utils\IpAddressUtils;
use Centra\Main\Utils\Validator;
use Centra\Main\Exceptions\ValidException;

/**
 * Class IpAuth
 * @package Centra\Portal\Api\Middleware
 * @property string $nets
 */
class IpAuth extends RouterMiddleware
{
  public function __construct(array $params = [])
  {
    $default = [
      '127.0.0.1/32',
//      '10.1.19.0/24',
//      '94.232.104.50/32',
//      '94.232.104.51/32',
//      '94.232.104.219/32',
//      '94.232.104.226/32',
    ];
    $params = array_merge($params, ['nets' => $default]);
    parent::__construct($params);
  }

  public static function rules()
  {
    return [
      ['nets' => [
        'regexp' => Validator::PATTERN_NET,
        'message' => 'Подсеть указана неверно',
        'required' => true,
      ]]
    ];
  }

  /** Выполняет проверку
   * @throws ValidException
   * @throws ClassException
   */
  public function run()
  {
    $ip = (\store(Request::class))->getUserIp();
    $valid = false;
    foreach ($this->getAttribute("nets") as $net){
      $network = IpNetwork::fromString($net);
      if(IpAddressUtils::isIpInNetwork($ip, $network))
        $valid = true;
    }
    if(!$valid)
      throw new ValidException("Доступ запрещен");
  }

  /**
   * @return string
   */
  public function getNets()
  {
    return $this->getAttribute("nets");
  }

  /**
   * @param string $nets
   * @return IpAuth $this;
   */
  public function setNets($nets)
  {
    $this->setAttribute("nets", $nets);
    return $this;
  }

}