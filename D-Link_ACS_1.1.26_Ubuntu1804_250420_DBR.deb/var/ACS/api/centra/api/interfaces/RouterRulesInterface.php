<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 15:23
 */

namespace Centra\Api\Interfaces;


interface RouterRulesInterface
{
  public function getRules();
  public function setRules(array $rules);
  public function getBeforeMiddleware();
  public function getAfterMiddleware();
}