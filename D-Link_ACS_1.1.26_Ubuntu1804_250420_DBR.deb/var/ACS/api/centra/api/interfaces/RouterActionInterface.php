<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 15:24
 */

namespace Centra\Api\Interfaces;

interface RouterActionInterface
{
  public function run();
}