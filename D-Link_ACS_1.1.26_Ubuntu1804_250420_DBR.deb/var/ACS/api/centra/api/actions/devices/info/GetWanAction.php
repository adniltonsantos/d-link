<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Devices\Info;

use Centra\Acs\Main\DeviceParamsReader;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;
use Centra\Configs\ApplicationConfig;

class GetWanAction extends RouterAction
{
  const SECTION_PATTERN = '/InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.([0-9]+)./';
  const IP_PATTERN = '/(ExternalIPAddress)$/';
  const MAC_PATTERN = '/(MACAddress)$/';
  const SUBNET_PATTERN = '/(SubnetMask)$/';
  const GATEWAY_PATTERN = '/(DefaultGateway)$/';
  const DNS_PATTERN = '/(DNSServers)$/';
  const BYTES_RECEIVED_PATTERN = '/Stats.(EthernetBytesReceived)$/';
  const BYTES_SEND_PATTERN = '/Stats.(EthernetBytesSent)$/';
  const ERROR_RECEIVED_PATTERN = '/Stats.(EthernetErrorsReceived)$/';
  const ERROR_SEND_PATTERN = '/Stats.(EthernetErrorsSent)$/';

  /**
   * @return array|null|static
   * @throws \Centra\Main\Exceptions\ValidException
   * @throws \Centra\Main\Exceptions\ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Devices $devices */
    $device = Devices::find()->byId($id);
    if(empty($device))
      throw new ValidException("Устройство по id:" . $id . ' не найдено');
    /** @var ApplicationConfig $config */
    $config = \store(ApplicationConfig::class);
    $serial = $device->getSerialNumber();
    $path = $config->getParamsPath() . $serial . "_value.xml";
    /** @var DeviceParamsReader $deviceParams */
    $deviceParams = \store(DeviceParamsReader::class, $path);
    $result = [
      'date' => $deviceParams->getDate(),
      'wans' => [],
    ];
    foreach ($deviceParams->grep(self::SECTION_PATTERN) as $key => $value){
      preg_match(self::SECTION_PATTERN, $key, $match);
      $itemKey = '';
      if(preg_match(self::IP_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::MAC_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::SUBNET_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::GATEWAY_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::DNS_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::BYTES_RECEIVED_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::BYTES_SEND_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::ERROR_RECEIVED_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::ERROR_SEND_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(!empty($itemKey) && !empty($match[1]))
        $result['wans'][$match[1]][$itemKey] = $value;
    }
    $result['wans'] = array_values($result['wans']);
    return $result;
  }
}