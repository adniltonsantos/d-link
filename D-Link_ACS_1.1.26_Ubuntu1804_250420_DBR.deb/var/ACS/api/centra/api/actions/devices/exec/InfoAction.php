<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Devices\Exec;

use Centra\Acs\Main\AcsWorker;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;
use Centra\Main\Utils\Validator;

class InfoAction extends RouterAction
{

  /**
   * Обновляет шаблон на устройстве
   * @return array|bool|mixed
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\HttpException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    $id = \query("id");
    Validator::isInteger($id);
    /** @var Devices $item */
    $item = Devices::find()->byId($id);
    if(empty($item))
      throw new ValidException("Устройство по id:" . $id . " не найден");
    /** @var AcsWorker $worker */
    $worker = \store(AcsWorker::class);
    $worker->getConfig()->setTimeout(0);
    $worker->getAllParams($item->getId());
    return $item;
  }
}