<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Devices\Info;

use Centra\Acs\Main\DeviceParamsReader;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;
use Centra\Configs\ApplicationConfig;

class GetBaseAction extends RouterAction
{
  const UPTIME_PATTERN = '/InternetGatewayDevice.DeviceInfo.UpTime/';
  const CPU_USAGE_PATTERN = '/InternetGatewayDevice.DeviceInfo.ProcessStatus.CPUUsage/';
  const MEMORY_FREE_PATTERN = '/InternetGatewayDevice.DeviceInfo.MemoryStatus.Free/';
  const SERIAL_NUMBER_PATTERN = '/InternetGatewayDevice.DeviceInfo.SerialNumber/';
  const MODEl_NAME_PATTERN = '/InternetGatewayDevice.DeviceInfo.ModelName/';
  const HARDWARE_REVISION_PATTERN = '/InternetGatewayDevice.DeviceInfo.HardwareVersion/';
  const SOFTWARE_REVISION_PATTERN = '/InternetGatewayDevice.DeviceInfo.SoftwareVersion/';
  /**
   * @return array|null|static
   * @throws \Centra\Main\Exceptions\ValidException
   * @throws \Centra\Main\Exceptions\ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Devices $devices */
    $device = Devices::find()->byId($id);
    if(empty($device))
      throw new ValidException("Устройство по id:" . $id . ' не найдено');
    /** @var ApplicationConfig $config */
    $config = \store(ApplicationConfig::class);
    $serial = $device->getSerialNumber();
    $path = $config->getParamsPath() . $serial . "_value.xml";
    /** @var DeviceParamsReader $deviceParams */
    $deviceParams = \store(DeviceParamsReader::class, $path);
    $result = [
      'date' => $deviceParams->getDate(),
      'uptime' => $deviceParams->get(self::UPTIME_PATTERN),
      'cpu_usage' => $deviceParams->get(self::CPU_USAGE_PATTERN),
      'memory_free' => $deviceParams->get(self::MEMORY_FREE_PATTERN),
      'serial_number' => $deviceParams->get(self::SERIAL_NUMBER_PATTERN),
      'model' => $deviceParams->get(self::MODEl_NAME_PATTERN),
      'hardware_revision' => $deviceParams->get(self::HARDWARE_REVISION_PATTERN),
      'software_revision' => $deviceParams->get(self::SOFTWARE_REVISION_PATTERN),
    ];
    return $result;
  }
}