<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Devices\Info;

use Centra\Acs\Main\DeviceParamsReader;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;
use Centra\Configs\ApplicationConfig;

class GetLanAction extends RouterAction
{
  const SECTION_PATTERN = '/InternetGatewayDevice.LANDevice.1.LANEthernetInterfaceConfig.([0-9]+)/';
  const NAME_PATTERN = '/(Name)$/';
  const ENABLE_PATTERN = '/(Enable)$/';
  const STATUS_PATTERN = '/(Status)$/';
  const MAX_BITRATE_PATTERN = '/(MaxBitRate)$/';
  const DUPLEX_PATTERN = '/(DuplexMode)$/';
  const CRC_ERROR_PATTERN = '/Stats.(X_DLINK_CRCErroredPackets)$/';
  const BYTES_RECEIVED_PATTERN = '/Stats.(BytesReceived)$/';
  const BYTES_SEND_PATTERN = '/Stats.(BytesSent)$/';


  /**
   * @return array|null|static
   * @throws \Centra\Main\Exceptions\ValidException
   * @throws \Centra\Main\Exceptions\ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Devices $devices */
    $device = Devices::find()->byId($id);
    if(empty($device))
      throw new ValidException("Устройство по id:" . $id . ' не найдено');
    /** @var ApplicationConfig $config */
    $config = \store(ApplicationConfig::class);
    $serial = $device->getSerialNumber();
    $path = $config->getParamsPath() . $serial . "_value.xml";
    /** @var DeviceParamsReader $deviceParams */
    $deviceParams = \store(DeviceParamsReader::class, $path);
    $result = [
      'date' => $deviceParams->getDate(),
      'lans' => [],
    ];
    foreach ($deviceParams->grep(self::SECTION_PATTERN) as $key => $value){
      preg_match(self::SECTION_PATTERN, $key, $match);
      $itemKey = '';
      if(preg_match(self::NAME_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::ENABLE_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::STATUS_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::MAX_BITRATE_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::DUPLEX_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::BYTES_RECEIVED_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::BYTES_SEND_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::CRC_ERROR_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(!empty($itemKey) && !empty($match[1]))
        $result['lans'][$match[1]][$itemKey] = $value;
    }
    $result['lans'] = array_values($result['lans']);
    return $result;
  }
}