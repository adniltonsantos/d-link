<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\UnregisteredDevices;



use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Clients;
use Centra\Database\Models\Templates;
use Centra\Database\Models\UnregisteredDevices;
use Centra\Main\Exceptions\ValidException;

class AddAction extends RouterAction
{
  /**
   * @return array|UnregisteredDevices
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var UnregisteredDevices $item */
    $item = new UnregisteredDevices();
    $item->setScenario(UnregisteredDevices::SCENARIO_CREATE)->load(\request());
    $item->check();
    if($item->hasError())
      throw new ValidException("Ошибка при создании незарегистрированного устройства", $item->getErrors());
    if(!empty($item->getClientId())){
      $client = Clients::find()->byId($item->getClientId());
      if(empty($client))
        throw new ValidException("Id клиента не существует в базе");
    }
    if(!empty($item->getTemplateId())){
      $template = Templates::find()->byId($item->getTemplateId());
      if(empty($template))
        throw new ValidException("Id шаблона не существует в базе");
    }
    $item->save();
    return $item;
  }
}