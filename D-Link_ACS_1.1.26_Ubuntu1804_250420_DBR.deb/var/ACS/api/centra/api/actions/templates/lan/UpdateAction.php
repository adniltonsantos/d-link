<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Templates\Lan;


use Centra\Acs\Templates\TemplateLanBlank;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Templates;
use Centra\Main\Exceptions\ValidException;
use Centra\Main\Store;
use Centra\Acs\Templates\TemplateFileConfig;

class UpdateAction extends RouterAction
{
  /**
   * @return array
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Templates $template */
    $template = Templates::find()->byId($id);
    if(empty($template))
      throw new ValidException("Шаблон по id:" . $id . ' не найден');
    /** @var TemplateFileConfig $config */
    $config = Store::init()->make(TemplateFileConfig::class, ['path' => $template->getPath()]);
    $params = \request("params");
    if(empty($params))
      throw new ValidException("Не указан обязательный параметр");
    $json = json_decode($params, true);
    if(empty($json))
      throw new ValidException("Ожидает конфигурация в формате json");
    foreach ($json as $key => $item){
      $lan = new TemplateLanBlank($item);
      $lan->check();
      if($lan->hasError())
        throw new ValidException("Ошибка при обновлении шаблона lan", $lan->getErrors());
      $config->setLan($lan, $key);
    }
    $config->save();
    return $json;
  }
}