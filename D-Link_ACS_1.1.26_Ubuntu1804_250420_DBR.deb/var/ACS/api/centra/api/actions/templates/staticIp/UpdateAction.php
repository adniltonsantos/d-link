<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Templates\StaticIp;

use Centra\Acs\Templates\TemplateStaticIpBlank;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Templates;
use Centra\Main\Exceptions\ValidException;
use Centra\Main\Store;
use Centra\Acs\Templates\TemplateFileConfig;

class UpdateAction extends RouterAction
{
  /**
   * @return array
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Templates $template */
    $template = Templates::find()->byId($id);
    if(empty($template))
      throw new ValidException("Шаблон по id:" . $id . ' не найден');
    /** @var TemplateFileConfig $config */
    $config = Store::init()->make(TemplateFileConfig::class, ['path' => $template->getPath()]);
    $params = \request("params");
    if(empty($params))
      throw new ValidException("Не указан обязательный параметр");
    $json = json_decode($params, true);
    if(empty($json))
      throw new ValidException("Ожидает конфигурация в формате json");
    foreach ($json as $key => $item){
      $static = new TemplateStaticIpBlank($item);
      $static->check();
      if($static->hasError())
        throw new ValidException("Ошибка при обновлении шаблона static ip", $static->getErrors());
      $config->setStaticIp($static, $key);
    }
    $config->save();
    return $json;
  }
}