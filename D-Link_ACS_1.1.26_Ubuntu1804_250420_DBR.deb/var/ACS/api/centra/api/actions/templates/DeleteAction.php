<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Templates;



use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Templates;
use Centra\Main\Exceptions\ValidException;

class DeleteAction extends RouterAction
{
  /**
   * @return array|Templates
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var Templates $item */
    $item = Templates::find()->byId(\query("id"));
    if(empty($item))
      throw new ValidException("Шаблон по id:" . \query("id") . " не найден");
    $item->delete();
    return ['id' => \query("id")];
  }
}