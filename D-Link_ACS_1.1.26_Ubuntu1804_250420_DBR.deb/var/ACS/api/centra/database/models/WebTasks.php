<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:16
 */

namespace Centra\Database\Models;

use Centra\Database\Main\ActiveRecord;
use Centra\Main\Utils\Validator;

/**
 * Class WebTask
 * @package Centra\Database\Models\Devices
 * @property integer id
 * @property integer operation_type_id
 * @property integer operation_status
 * @property integer device_id
 * @property integer property_id
 * @property string create_date
 * @property integer user_id
 */
class WebTasks extends ActiveRecord
{
  const SCENARIO_CREATE = 'create';
  const SCENARIO_UPDATE = 'update';

  public function table()
  {
    return 'web_task';
  }

  public static function rules()
  {
    return [
      ['id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id задачи указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['operation_type_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id типа задачи указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['operation_status' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Статус задачи указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['operation_status' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Статус задачи указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['device_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id устройства в задаче указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['property_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id свойства в задаче указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['create_date' => [
        'regexp' => Validator::PATTERN_DATETIME,
        'message' => 'Дата создания в задаче указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['user_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id пользователя задачи указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
    ];
  }

  /**
   * @return int
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function getOperationType()
  {
    return OperationTypes::find()->byId($this->getOperationTypeId());
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

  /**
   * @return int
   */
  public function getOperationTypeId()
  {
    return $this->getAttribute("operation_type_id");
  }

  /**
   * @param int $operation_type_id
   * @return $this
   */
  public function setOperationTypeId($operation_type_id)
  {
    $this->setAttribute("operation_type_id", $operation_type_id);
    return $this;
  }

  /**
   * @return int
   */
  public function getOperationStatus()
  {
    return $this->getAttribute("operation_status");
  }

  /**
   * @param int $operation_status
   * @return $this
   */
  public function setOperationStatus($operation_status)
  {
    $this->setAttribute("operation_status", $operation_status);
    return $this;
  }

  /**
   * @return int
   */
  public function getDeviceId()
  {
    return $this->getAttribute("device_id");
  }

  /**
   * @param int $device_id
   * @return $this
   */
  public function setDeviceId($device_id)
  {
    $this->setAttribute("device_id", $device_id);
    return $this;
  }

  /**
   * @return int
   */
  public function getPropertyId()
  {
    return $this->getAttribute("property_id");
  }

  /**
   * @param int $property_id
   * @return $this
   */
  public function setPropertyId($property_id)
  {
    $this->setAttribute("property_id", $property_id);
    return $this;
  }

  /**
   * @return string
   */
  public function getCreateDate()
  {
    return $this->getAttribute("create_date");
  }

  /**
   * @param string $create_date
   * @return $this
   */
  public function setCreateDate($create_date)
  {
    $this->setAttribute("create_date", $create_date);
    return $this;
  }

  /**
   * @return int
   */
  public function getUserId()
  {
    return $this->getAttribute("user_id");
  }

  /**
   * @param int $user_id
   * @return $this
   */
  public function setUserId($user_id)
  {
    $this->setAttribute("user_id", $user_id);
    return $this;
  }

}