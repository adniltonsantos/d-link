<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:16
 */

namespace Centra\Database\Models;

use Centra\Database\Main\ActiveRecord;
use Centra\Main\Utils\Validator;

/**
 * Class UnregisteredDevices
 * @package Centra\Database\Models\Devices
 * @property integer id
 * @property string serial_number
 * @property string mac
 * @property string hw_version
 * @property integer profile_id
 * @property integer client_id
 * @property string ip
 * @property string last_inform_time
 * @property integer count
 * @property integer group_id
 * @property integer template_id
 * @property integer port
 * @property string req_path
 */
class UnregisteredDevices extends ActiveRecord
{
  const SCENARIO_CREATE = 'create';
  const SCENARIO_UPDATE = 'update';

  public function table()
  {
    return 'unregister_devices';
  }

  public static function rules()
  {
    return [
      ['id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['serial_number' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Серийный номер устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['mac' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Мак адрес устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['hw_version' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Аппаратная ревизия устройства указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['profile_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id профиля устройства указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['client_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id клиента указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['ip' => [
        'regexp' => Validator::PATTERN_IP,
        'message' => 'Ip адрес указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['last_inform_time' => [
        'regexp' => Validator::PATTERN_DATETIME,
        'message' => 'Дата обновления указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['count' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Количество запросов указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['group_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id группы указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['template_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id шаблона указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['port' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Порт указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['req_path' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Путь запроса указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['id' => [
        'required' => true,
        'message' => 'Id устройства не указано',
        'on' => [self::SCENARIO_UPDATE]
      ]],
      ['serial_number' => [
        'required' => true,
        'message' => 'Серийный номер устройства не указан',
        'on' => [self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['ip' => [
        'required' => true,
        'message' => 'Ip адрес не указан',
        'on' => [self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['id' => [
        'required' => true,
        'message' => 'Id устройства не указано',
        'on' => [ self::SCENARIO_UPDATE]
      ]],
      ['serial_number' => [
        'required' => true,
        'message' => 'Серийный номер устройства не указан',
        'on' => [ self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['ip' => [
        'required' => true,
        'message' => 'Ip адрес устройства не указан',
        'on' => [ self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
    ];
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

  /**
   * @return string
   */
  public function getSerialNumber()
  {
    return $this->getAttribute("serial_number");
  }

  /**
   * @param string $serial_number
   * @return $this
   */
  public function setSerialNumber($serial_number)
  {
    $this->setAttribute("serial_number", $serial_number);
    return $this;
  }

  /**
   * @return string
   */
  public function getMac()
  {
    return $this->getAttribute("mac");
  }

  /**
   * @param string $mac
   * @return $this
   */
  public function setMac($mac)
  {
    $this->setAttribute("mac", $mac);
    return $this;
  }

  /**
   * @return string
   */
  public function getHwVersion()
  {
    return $this->getAttribute("hw_version");
  }

  /**
   * @param string $hw_version
   * @return $this
   */
  public function setHwVersion($hw_version)
  {
    $this->setAttribute("hw_version", $hw_version);
    return $this;
  }

  /**
   * @return int
   */
  public function getProfileId()
  {
    return $this->getAttribute("profile_id");
  }

  /**
   * @param int $profile_id
   * @return $this
   */
  public function setProfileId($profile_id)
  {
    $this->setAttribute("profile_id", $profile_id);
    return $this;
  }

  /**
   * @return int
   */
  public function getClientId()
  {
    return $this->getAttribute("client_id");
  }

  /**
   * @param int $client_id
   * @return $this
   */
  public function setClientId($client_id)
  {
    $this->setAttribute("client_id", $client_id);
    return $this;
  }

  /**
   * @return string
   */
  public function getIp()
  {
    return $this->getAttribute("ip");
  }

  /**
   * @param string $ip
   * @return $this
   */
  public function setIp($ip)
  {
    $this->setAttribute("ip", $ip);
    return $this;
  }

  /**
   * @return string
   */
  public function getLastInformTime()
  {
    return $this->getAttribute("last_inform_time");
  }

  /**
   * @param string $last_inform_time
   * @return $this
   */
  public function setLastInformTime($last_inform_time)
  {
    $this->setAttribute("last_inform_time", $last_inform_time);
    return $this;
  }

  /**
   * @return int
   */
  public function getCount()
  {
    return $this->getAttribute("count");
  }

  /**
   * @param int $count
   * @return $this
   */
  public function setCount($count)
  {
    $this->setAttribute("count", $count);
    return $this;
  }

  /**
   * @return int
   */
  public function getGroupId()
  {
    return $this->getAttribute("group_id");
  }

  /**
   * @param int $group_id
   * @return $this
   */
  public function setGroupId($group_id)
  {
    $this->setAttribute("group_id", $group_id);
    return $this;
  }

  /**
   * @return int
   */
  public function getTemplateId()
  {
    return $this->getAttribute("template_id");
  }

  /**
   * @param int $template_id
   * @return $this
   */
  public function setTemplateId($template_id)
  {
    $this->setAttribute("template_id", $template_id);
    return $this;
  }

  /**
   * @return int
   */
  public function getPort()
  {
    return $this->getAttribute("port");
  }

  /**
   * @param int $port
   * @return $this
   */
  public function setPort($port)
  {
    $this->setAttribute("port", $port);
    return $this;
  }

  /**
   * @return string
   */
  public function getReqPath()
  {
    return $this->getAttribute("req_path");
  }

  /**
   * @param string $req_path
   * @return $this
   */
  public function setReqPath($req_path)
  {
    $this->setAttribute("req_path", $req_path);
    return $this;
  }


}