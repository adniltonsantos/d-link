<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 15:55
 */

namespace Centra\Database\Main;

use Centra\Configs\DatabaseConfig;
use Centra\Main\Exceptions\ProcessException;
use Centra\Main\Store;
use Centra\Main\Utils\StringBuilder;
use Centra\Main\Utils\StringUtils;
use Centra\Main\Utils\Validator;

class QueryBuilder
{
  const FIRST_INDEX = 1;
  const THREE_PARAMS = 3;
  const TWO_PARAMS = 2;
  const PDO_ERROR_MESSAGE_INDEX = 2;
  protected $select = ' * ';
  protected $table = null;
  protected $join = null;
  protected $where = null;
  protected $group = null;
  protected $having = null;
  protected $order = null;
  protected $limit = null;
  private $connection = null;

  /**
   * QueryBuilder constructor.
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function __construct()
  {
    if(is_null($this->getConnection())){
      /** @var Connection $connection */
      $config = \store(DatabaseConfig::class);
      $connection = \store(Connection::class, $config);
      $this->setConnection($connection->get());
    }
  }

  /**
   * @return static
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public static function find()
  {
    $model = new static();
    return $model;
  }

  /**
   * @param $table
   * @return static
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public static function getInstance($table)
  {
    $model = new static();
    $model->setTable($table);
    return $model;
  }

  public function select($select = [])
  {
    if(is_array($select))
      $this->setSelect(implode(",", $select));
    if(is_string($select))
      $this->setSelect($select);
    return $this;
  }

  public function join($table, $relation)
  {
    $join = $this->getJoin();
    if(empty($join))
      $this->setJoin($table . ' ON ' . $relation);
    else
      $this->setJoin($join . ' JOIN ' . $table . ' ON  '. $relation);
    return $this;
  }

  /**
   * @param $params
   * @return $this
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function where($params)
  {
    if(is_array($params)){
      $where = $this->addWhere($params);
      $this->setWhere($where);
    }
    if(is_string($params))
      $this->setWhere($params);
    return $this;
  }

  /**
   * @param $params
   * @return string
   * @throws \Centra\Main\Exceptions\ClassException
   */
  private function addWhere($params)
  {
    $where = $this->getWhere();
    /** @var StringBuilder $stringBuilder */
    $stringBuilder = Store::init()->make(StringBuilder::class);
    $stringBuilder->clear()->add("(")->add($where);
    foreach ($params as $paramKey => $value){
      if(!empty($where))
        $stringBuilder->add(' AND ');
      if(is_array($value) && count($value) == self::THREE_PARAMS){
        list($key, $expression, $value) = $value;
        $this->whereItem($key, $expression, $value);
      } else if(is_array($value) && count($value) == self::TWO_PARAMS){
        list($key, $value) = $value;
        $this->whereItem($key, "=", $value);
      } else if(is_string($paramKey)){
        $this->whereItem($paramKey, "=", $value);
      } else if(is_integer($paramKey) && is_string($value)){
        $stringBuilder->add($value);
      }
      $where = $stringBuilder->get();
    }
    return $stringBuilder->add(")")->get();
  }

  /**
   * @param $key
   * @param $expression
   * @param $value
   * @throws \Centra\Main\Exceptions\ClassException
   */
  private function whereItem($key, $expression, $value)
  {
    /** @var StringBuilder $stringBuilder */
    $stringBuilder = Store::init()->make(StringBuilder::class);
    $stringBuilder->add($key)->add(' ');
    if(is_array($value)){
      $stringBuilder->add(' in ')->add('(')->add(implode(",", $value))->add(')');
    } else {
      if(preg_match(Validator::PATTERN_INTEGER, $value))
        $stringBuilder->add($expression)->add(' ')->add($value);
      else
        $stringBuilder->add($expression)->add(' ')->add(StringUtils::escape($value));
    }
  }

  /**
   * @param $params
   * @return $this
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function andWhere($params)
  {
    $where = $this->getWhere();
    if(is_array($params)){
      $where = $this->addWhere($params);
      $this->setWhere($where);
    }
    if(is_string($params))
      $this->setWhere($where . ' AND ' . $params);
    return $this;
  }

  /**
   * @param $params
   * @return $this
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function orWhere($params)
  {
    $where = $this->getWhere();
    if(is_array($params)){
      $where = $this->addWhere($params);
      $this->setWhere($where);
    }
    if(is_string($params))
      $this->setWhere($where . ' OR ' . $params);
    return $this;
  }

  public function group($params)
  {
    if(is_array($params))
      $this->setGroup(implode(",", $params));
    if(is_string($params))
      $this->setOrder($params);
  }

  public function having($params)
  {
    if(is_array($params))
      $this->setGroup(implode(",", $params));
    if(is_string($params))
      $this->setOrder($params);
  }

  public function order($params)
  {
    if(is_array($params))
      $this->setOrder(implode(",", $params));
    if(is_string($params))
      $this->setOrder($params);
  }

  public function limit($params)
  {
    if(is_array($params))
      $this->setLimit(implode(",", $params));
    if(is_string($params) || is_integer($params))
      $this->setLimit($params);
  }

  /**
   * @return array
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function all()
  {
    /** @var StringBuilder $query */
    $query = Store::init()->make(StringBuilder::class);
    $query->clear();
    $query->add("SELECT ")->add($this->getSelect())
      ->add(" FROM ")->add($this->getTable());
    if(!empty($this->getJoin()))
      $query->add(" JOIN ")->add($this->getJoin());
    if(!empty($this->getWhere()))
      $query->add(" WHERE ")->add($this->getWhere());
    if(!empty($this->getGroup()))
      $query->add(" GROUP ")->add($this->getGroup());
    if(!empty($this->getHaving()))
      $query->add(" HAVING ")->add($this->getHaving());
    if(!empty($this->getOrder()))
      $query->add(" ORDER BY ")->add($this->getOrder());
    if(!empty($this->getLimit()))
      $query->add(" LIMIT ")->add($this->getLimit());
    $statement = $this->getConnection()->query($query->get());
    if(!empty($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]))
      throw new ProcessException($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]);
    $items = $statement->fetchAll(\PDO::FETCH_ASSOC);
    return $items;
  }

  /**
   * Добавляет запись в БД
   * @param array $params
   * @return int
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function insert(array $params)
  {
    /** @var StringBuilder $query */
    $query = Store::init()->make(StringBuilder::class);
    $query->clear()->add("INSERT INTO ")->add($this->getTable())->add("(");
    $query->add(implode(",", array_keys($params)))->add(") VALUES (");
    $quotedParams = [];
    foreach ($params as $value){
      if(preg_match(Validator::PATTERN_INTEGER, $value))
        $quotedParams[] = $value;
      else
        $quotedParams[] = StringUtils::escape($value);
    }
    $query->add(implode(",", $quotedParams))->add(")");
    $statement = $this->getConnection()->exec($query->get());
    if(!empty($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]))
      throw new ProcessException($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]);
    return $statement;
  }

  /**
   * Обновляет запись
   * @param integer $id
   * @param array $params
   * @return int
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function update($id, array $params)
  {
    /** @var StringBuilder $query */
    $query = Store::init()->make(StringBuilder::class);
    $query->clear()->add("UPDATE ")->add($this->getTable())->add(" SET ");
    $count = 0;
    $paramCount = count($params);
    foreach ($params as $key => $value){
      $query->add(StringUtils::escape($key, "`"))->add("=");
      if(preg_match(Validator::PATTERN_INTEGER, $value))
        $query->add($value);
      else
        $query->add(StringUtils::escape($value));
      $count++;
      if($count < $paramCount)
        $query->add(",");
    }
    $query->add(" WHERE ")->add($this->table)->add(".id = ")->add($id);
    $statement = $this->getConnection()->exec($query->get());
    if(!empty($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]))
      throw new ProcessException($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]);
    return $statement;
  }

  /**
   * Удаляте запись из бд
   * @param  int
   * @return int
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function delete($id)
  {
    /** @var StringBuilder $query */
    $query = Store::init()->make(StringBuilder::class);
    $query->clear()->add("DELETE FROM ")->add($this->getTable())->add(" WHERE ")->add($this->table)->add(".id = ")->add($id);
    /** @var Connection $connection */
    $connection = \store(Connection::class);
    $statement = $this->getConnection()->exec($query->get());
    if(!empty($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]))
      throw new ProcessException($this->getConnection()->errorInfo()[self::PDO_ERROR_MESSAGE_INDEX]);
    return $statement;
  }

  /**
   * @return mixed|null
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function first()
  {
    $this->setLimit(1);
    $item = $this->all();
    if(empty($item))
      return null;
    return $item[0];
  }

  /**
   * @return mixed|null
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function last()
  {
    $this->setOrder(" id desc");
    $this->setLimit(1);
    $item = $this->all();
    if(empty($item))
      return null;
    return $item[0];
  }

  /**
   * @param $id
   * @return mixed|null
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function byId($id)
  {
    $this->where(" id = " . $id);
    return $this->first();
  }

  /**
   * @return null
   */
  public function getSelect()
  {
    return $this->select;
  }

  /**
   * @return null
   */
  public function getTable()
  {
    return $this->table;
  }

  /**
   * @param null $table
   * @return $this
   */
  public function setTable($table)
  {
    $this->table = $table;
    return $this;
  }

  /**
   * @return null
   */
  public function getJoin()
  {
    return $this->join;
  }

  /**
   * @param null $join
   * @return $this
   */
  public function setJoin($join)
  {
    $this->join = $join;
    return $this;
  }

  /**
   * @param null $select
   * @return $this
   */
  public function setSelect($select)
  {
    $this->select = $select;
    return $this;
  }

  /**
   * @return null
   */
  public function getWhere()
  {
    return $this->where;
  }

  /**
   * @param null $where
   * @return $this
   */
  public function setWhere($where)
  {
    $this->where = $where;
    return $this;
  }

  /**
   * @return null
   */
  public function getGroup()
  {
    return $this->group;
  }

  /**
   * @param null $group
   * @return $this
   */
  public function setGroup($group)
  {
    $this->group = $group;
    return $this;
  }

  /**
   * @return null
   */
  public function getHaving()
  {
    return $this->having;
  }

  /**
   * @param null $having
   * @return $this
   */
  public function setHaving($having)
  {
    $this->having = $having;
    return $this;
  }

  /**
   * @return null
   */
  public function getOrder()
  {
    return $this->order;
  }

  /**
   * @param null $order
   * @return $this
   */
  public function setOrder($order)
  {
    $this->order = $order;
    return $this;
  }

  /**
   * @return null
   */
  public function getLimit()
  {
    return $this->limit;
  }

  /**
   * @param null $limit
   * @return $this
   */
  public function setLimit($limit)
  {
    $this->limit = $limit;
    return $this;
  }

  /**
   * @return \Pdo null
   */
  public function getConnection()
  {
    return $this->connection;
  }

  /**
   * @param null $connection
   * @return QueryBuilder $this;
   */
  public function setConnection($connection)
  {
    $this->connection = $connection;
    return $this;
  }

}