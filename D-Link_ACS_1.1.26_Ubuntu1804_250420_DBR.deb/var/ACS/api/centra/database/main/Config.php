<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:01
 */

namespace Centra\Database\Main;

use Centra\Database\Interfaces\ConfigInterface;
use Centra\Main\Model;

class Config extends Model implements ConfigInterface
{
  public $host = "localhost";
  public $port = 3306;
  public $username = "root";
  public $password = "toor";
  public $database = "ACSServer";

  /**
   * @return null
   */
  public function getHost()
  {
    return $this->host;
  }

  /**
   * @param null $host
   * @return $this
   */
  public function setHost($host)
  {
    $this->host = $host;
    return $this;
  }

  /**
   * @return null
   */
  public function getPort()
  {
    return $this->port;
  }

  /**
   * @param null $port
   * @return $this
   */
  public function setPort($port)
  {
    $this->port = $port;
    return $this;
  }

  /**
   * @return null
   */
  public function getUsername()
  {
    return $this->username;
  }

  /**
   * @param null $username
   * @return $this
   */
  public function setUsername($username)
  {
    $this->username = $username;
    return $this;
  }

  /**
   * @return null
   */
  public function getPassword()
  {
    return $this->password;
  }

  /**
   * @param null $password
   * @return $this
   */
  public function setPassword($password)
  {
    $this->password = $password;
    return $this;
  }

  /**
   * @return null
   */
  public function getDatabase()
  {
    return $this->database;
  }

  /**
   * @param null $database
   * @return $this
   */
  public function setDatabase($database)
  {
    $this->database = $database;
    return $this;
  }

}