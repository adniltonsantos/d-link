<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 22.05.17
 * Time: 9:38
 * Описывает конфигурацию для внешних систем.
 */

namespace Centra\Database\Interfaces;

interface ConfigInterface
{
    public function getHost();
    public function getPort();
    public function getUsername();
    public function getPassword();
    public function getDatabase();
    public function setHost($host);
    public function setPort($port);
    public function setUsername($username);
    public function setPassword($password);
    public function setDatabase($database);
}