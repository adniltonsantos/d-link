<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 9:56
 */

namespace Centra\Log4p\Interfaces;

interface MessageInterface
{
  public function getType();
  public function getClass();
  public function getTrace();
  public function getMessage();
  public function getChannel();
  public function setType($type);
  public function setClass($class);
  public function setTrace(array $trace);
  public function setMessage($message);
  public function setChannel($channel);
}