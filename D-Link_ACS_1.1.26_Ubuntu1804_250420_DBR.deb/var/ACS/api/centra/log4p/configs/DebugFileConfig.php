<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 18.05.17
 * Time: 12:00
 * Обьект конфигурации для billingWorker
 */

namespace Centra\Log4p\Configs;

use Centra\Log4p\Interfaces\FilterInterface;
use Centra\Log4p\Interfaces\PrinterInterface;
use Centra\Log4p\Interfaces\WiperInterface;
use Centra\Main\Store;
use Centra\Log4p\Main\Log;

class DebugFileConfig extends Config
{
  /**
   * Конфигурация для общего файла логов
   * FileInfoConfig constructor.
   */
  public function __construct()
  {
    $printer = Store::init()->get(PrinterInterface::class, true, [
      'directory' => "/var/ACS/api/runtime/logs",
      'name'      => "debug.log",
      'trace'     => true,
      'timestamp' => true,
      'skipLength' => 1024,
    ]);
    $filter = Store::init()->get(FilterInterface::class, true, [
      'type'    => Log::TYPE_DEBUG,
      'channel' => ".",
    ]);
    $wiper = Store::init()->get(WiperInterface::class, true, [
      'max_size' => "10M",
      'max_parts' => 1
    ]);
    parent::__construct($printer, $filter, $wiper);
  }
}