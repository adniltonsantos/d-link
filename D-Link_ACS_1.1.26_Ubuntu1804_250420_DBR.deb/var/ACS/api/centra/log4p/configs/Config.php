<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 11:13
 */

namespace Centra\Log4p\Configs;

use Centra\Log4p\Interfaces\ConfigInterface;
use Centra\Log4p\Interfaces\FilterInterface;
use Centra\Log4p\Interfaces\PrinterInterface;
use Centra\Log4p\Interfaces\WiperInterface;

class Config implements ConfigInterface
{
  /** @var PrinterInterface */
  public $printer = null;
  /** @var FilterInterface */
  public $filter = null;
  /** @var WiperInterface */
  public $wiper = null;

  public function __construct(PrinterInterface $printer, FilterInterface $filter, WiperInterface $wiper = null)
  {
    $this->setPrinter($printer);
    $this->setFilter($filter);
    if(!is_null($wiper))
      $this->setWiper($wiper);
  }

  /**
   * @return PrinterInterface
   */
  public function getPrinter()
  {
    return $this->printer;
  }

  /**
   * @param PrinterInterface $printer
   * @return $this
   */
  public function setPrinter(PrinterInterface $printer)
  {
    $this->printer = $printer;
    return $this;
  }

  /**
   * @return FilterInterface
   */
  public function getFilter()
  {
    return $this->filter;
  }

  /**
   * @param FilterInterface $filter
   * @return $this
   */
  public function setFilter(FilterInterface $filter)
  {
    $this->filter = $filter;
    return $this;
  }

  /**
   * @return WiperInterface
   */
  public function getWiper()
  {
    return $this->wiper;
  }

  /**
   * @param WiperInterface $wiper
   * @return $this
   */
  public function setWiper(WiperInterface $wiper)
  {
    $this->wiper = $wiper;
    return $this;
  }

}