<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 28.08.18
 * Time: 9:55
 */

namespace Centra\Log4p\Main;

use Centra\Log4p\Interfaces\ConfigInterface;
use Centra\Log4p\Interfaces\WiperInterface;
use Centra\Configs\Log4pConfig;

class Agent
{
  public static function rotate()
  {
    \store(Log4pConfig::class);
    /** @var Parser $parser */
    $parser = \store(Parser::class);
    /** @var ConfigInterface $config */
    foreach ($parser->getConfigs() as $config){
      /** @var WiperInterface $wiper */
      $wiper = $config->getWiper();
      if(empty($wiper))
        continue;
      $printer = $config->getPrinter();
      $wiper->clean($printer);
    }
    return true;
  }
}