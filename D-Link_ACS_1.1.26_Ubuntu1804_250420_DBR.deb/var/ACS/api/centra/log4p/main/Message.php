<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 9:55
 */

namespace Centra\Log4p\Main;

use Centra\Log4p\Interfaces\MessageInterface;

class Message implements MessageInterface
{
  public $type = null;
  public $class = null;
  public $trace = [];
  public $message = null;
  public $channel = null;

  /**
   * @return null
   */
  public function getType()
  {
    return $this->type;
  }

  /**
   * @param null $type
   * @return $this
   */
  public function setType($type)
  {
    $this->type = $type;
    return $this;
  }

  /**
   * @return null
   */
  public function getClass()
  {
    return $this->class;
  }

  /**
   * @param null $class
   * @return $this
   */
  public function setClass($class)
  {
    $this->class = $class;
    return $this;
  }

  /**
   * @return array
   */
  public function getTrace()
  {
    return $this->trace;
  }

  /**
   * @param array $trace
   * @return $this
   */
  public function setTrace(array $trace)
  {
    $this->trace = $trace;
    return $this;
  }

  /**
   * @return string|array|object|null
   */
  public function getMessage()
  {
    return $this->message;
  }

  /**
   * @param string|array|object|null $message
   * @return $this
   */
  public function setMessage($message)
  {
    $this->message = $message;
    return $this;
  }

  /**
   * @return null
   */
  public function getChannel()
  {
    return $this->channel;
  }

  /**
   * @param null $channel
   * @return $this
   */
  public function setChannel($channel)
  {
    $this->channel = $channel;
    return $this;
  }

}