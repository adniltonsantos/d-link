<?php

namespace Centra\Main\Utils;

class StringUtils
{

  const START_ZERO = 0;
  const START_ONE = 1;
  const LENGTH_ONE = 1;
  const REPLACE_START_INDEX = 0;
  const REPLACE_COUNT = 7;
  const REPLACE_CHAR = '*';
  const CHUNK_STEP = 1;
  const THOUSANDS_LIMIT = 6;
  const MILLION_LIMIT = 9;
  const THOUSANDS_LENGTH = -3;
  const MILLION_LENGTH = -6;

  public static function firstToUpper($string)
  {
    $fc = mb_strtoupper(mb_substr($string, self::START_ZERO, self::LENGTH_ONE));
    return $fc . mb_substr($string, self::START_ONE);
  }

  /**
   * Формирование сообщения для логгера
   * @param $action - действие, например: "Запрос" или "Ответ"
   * @param $text - текст, например массив данных или строка текста
   * @return string
   */
  public static function makeLogMessage($action, $text)
  {
    if (is_array($text)):
      $text = json_encode($text, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    endif;

    return $action . ': ' . $text;
  }

  public static function trimClassName($string)
  {
    return preg_replace("/[a-z]+\\\.+::/", "", $string);
  }

  public static function getExceptionProperty($string)
  {
    preg_match("/::([a-z0-9_]+)/", $string, $match);
    return $match[1];
  }

  public static function implodeAssoc(array $params, $delimiter = '&')
  {
    $string = '';
    foreach ($params as $key => $value) {
      $string .= empty($string) ? ($key . "=" . $value) : ($delimiter . $key . "=" . $value);
    }
    return $string;
  }

  public static function makeHtmlMessage($message)
  {
    return str_replace("\n", "<br>", $message);
  }

  public static function replaceSubstring(
    $text,
    $replacedChar = self::REPLACE_CHAR,
    $startIndex = self::REPLACE_START_INDEX,
    $replaceCount = self::REPLACE_COUNT
  )
  {
    $replaceText = str_repeat($replacedChar, $replaceCount);
    $text = str_replace(substr($text, $startIndex, $replaceCount), $replaceText, $text);
    return $text;
  }

  /**
   * Удаляет пробелы, а так же решает косяк с E-mail'ом
   * @param $value
   * @return mixed
   */
  public static function trimMail($value)
  {
    $value = preg_replace('/</', '', $value);
    $value = preg_replace('/>\n/', '', $value);
    trim($value);

    return $value;
  }

  public static function trimIBlock(array $item)
  {
    foreach ($item as $entry => $value) {
      preg_match("/(~*PROPERTY_.+_(VALUE_ID|DESCRIPTION))/", $entry, $arMatch);
      if (isset($arMatch[1]))
        unset($item[$arMatch[1]]);
    }
    return $item;
  }

  /**
   * Возвращает название тарифа
   * @param $tariff
   * @return string
   */
  public static function getTariffName($tariff)
  {
    return 'Тариф ' .
      $tariff['plan_id'] . ' с ' .
      (new \Datetime($tariff['date_from']))->format('Y-m-d') .
      ($tariff['date_to'] ? ' по ' .
        (new \DateTime($tariff['date_to']))->format("Y-m-d") : '');
  }

  public static function makeTemplateFilename($type, $code)
  {
    return ucfirst(strtolower($type)) . '_' . $code . '.docx';
  }

  /**
   * Добавляет двоеточие и пробел между ключом и значением
   * @param $mac
   * @param string $delimiter
   * @return string
   */
  public static function parseLinealMacAddress($mac, $delimiter = ':')
  {
    preg_match("/([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/", $mac, $octets);
    array_shift($octets);
    return implode($delimiter, $octets);
  }

  /**
   * Удаляет пробелы из строки
   * @param string $string
   * @return string
   */
  public static function trimSpaces($string)
  {
    return preg_replace('/\s+/u', '', $string);
  }

  /**
   * Меняет разделители в строке
   * @param $string
   * @param string $from
   * @param string $to
   * @return null|string|string[]
   */
  public static function changeDelimiter($string, $from = '/', $to = '.')
  {
    $string = preg_replace("/^\/{1}/", "", $string);
    $string = preg_replace("/\/{1}$/", "", $string);
    return str_replace($from, $to, $string);
  }

  /**
   * Получает стоимость из тарифа
   * @param $tariffname
   * @return int
   */
  public static function getPriceFromTariffName($tariffname)
  {
    preg_match("/([0-9]+)руб/u", $tariffname, $match);
    list($tariffname, $price) = $match;
    return !empty($price) ? $price : 0;
  }

  public static function escape($value, $pattern = "'")
  {
    if(preg_match(Validator::PATTERN_UNSIGNED, $value))
      return $value;
    else
      return $pattern . $value . $pattern;
  }
}