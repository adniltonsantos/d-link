<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 25.04.18
 * Time: 15:17
 */

namespace Centra\Main\Utils;

use Centra\Main\Traits\Configurable;

class StringBuilder
{
  use Configurable;

  public $string = '';
  public $delimiter = "\n";

  public function add( $string )
  {
    $this->string .= $string;
    return $this;
  }

  public function next()
  {
    $this->string .= $this->delimiter;
    return $this;
  }

  public function get()
  {
    return $this->string;
  }

  public function clear()
  {
    $this->string = '';
    return $this;
  }

  public function setDelimiter( $delimiter )
  {
    $this->string = str_replace($this->delimiter, $delimiter, $this->string);
    $this->delimiter = $delimiter;
    return $this;
  }
}