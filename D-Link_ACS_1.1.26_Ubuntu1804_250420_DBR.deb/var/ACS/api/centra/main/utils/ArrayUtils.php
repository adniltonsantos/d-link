<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 16.05.17
 * Time: 11:51
 * Вспомогательный обработчик массивов
 */

namespace Centra\Main\Utils;

class ArrayUtils
{
  /** Упаковывает массив с указанным ключем.
   * @param $key - ключ в массиве котоырй будет ключем для нового массива.
   * @param array $array - массив значений из который будет извлечено значение ключа.
   * @return array - ассоциативный массив.
   */
  public static function getAssoc($key, array $array)
  {
    $hash = array();
    foreach ($array as $item) {
      if (is_object($item) && !empty($item->$key)) {
          $hash[$item->$key] = $item;
      }
      if(is_array($item) && !empty($item[$key])) {
          $hash[$item[$key]] = $item;
      }
    }
    return $hash;
  }

  /** Упаковывает массив с указанным ключем и выводит в виде списка с вложением.
   * @param $key - ключ в массиве котоырй будет ключем для нового массива.
   * @param array $array - массив значений из который будет извлечено значение ключа.
   * @return array - ассоциативный массив.
   */
  public static function getAssocMultiply($key, array $array)
  {
    $hash = array();
    foreach ($array as $item) {
      if (is_object($item) && !empty($item->$key)) {
        $hash[$item->$key][] = $item;
      }
      if(is_array($item) && !empty($item[$key])) {
        $hash[$item[$key]][] = $item;
      }
    }
    return $hash;
  }

  /** Создает обьект из массива
   * @param array $params - массив с данными
   * @return array|float|int|mixed|null|number|object|string
   */
  public static function getObject(array $params)
  {
    $string = json_encode($params);
    return json_decode($string);
  }

  public static function toArray( $params)
  {
    $string = json_encode($params);
    return json_decode($string, true);
  }

  /** Производит срез массива оставляя только нужные ключи
   * @param $array - Обрабатываемый массив
   * @param $keys - Перечень необходимых ключей
   * @return array - возвращаемый массив
   */
  public static function repack($array, $filter)
  {
    $resultArray = array();
    foreach ($array as $item) {
      $resultItem = self::filterItem($item, $filter);
      if (!empty($resultItem))
        $resultArray[] = $resultItem;
    }
    return $resultArray;
  }

  /** Собирает массив из пар ключ - значение
   * @param $array
   * @param $keyName
   * @param $valueName
   * @return array
   */
  public static function pairs($array, $keyName, $valueName)
  {
    $pairs = array();
    foreach ($array as $item) {
      if(is_object($item) && isset($item->$keyName) && isset($item->$valueName)){
        $key = $item->$keyName;
        $value = $item->$valueName;
        $pairs[$key] = $value;
      }
      if (is_array($item) && isset($item[$keyName]) && isset($item[$valueName])) {
        $key = $item[$keyName];
        $value = $item[$valueName];
        $pairs[$key] = $value;
      }
    }
    return $pairs;
  }

  /** Фильтруем массив по перечню ключей
   * @param $item - Массив
   * @param $filter - Перечень ключей
   * @return array - Фильртованный массив
   */
  private static function filterItem($item, $filter)
  {
    $resultItem = array();
    foreach ($filter as $key) {
      if (is_object($item)) {
        if (isset($item->$key))
          $resultItem[$key] = $item->$key;
      } else {
        if (isset($item[$key]))
          $resultItem[$key] = $item[$key];
      }
    }
    return $resultItem;
  }

  /** Удаляет из полученного элемента ИБ дублирующие записи
   * @param array $items - Массив свойств
   * @return array - Масив свойств
   */
  public static function trimIBProperty(array $items)
  {
    if (empty($items))
      return [];
    $newItems = [];
    foreach ($items as $key => $value) {
      if (preg_match("/PROPERTY_(.+)_VALUE/", $key, $match)) {
        $newItems[$match[1]] = $value;
      } elseif (preg_match("/PROPERTY_(.+)/", $key, $match))
        $newItems[$match[1]] = $value;
      else
        $newItems[$key] = $value;
    }
    return $newItems;
  }

  /** Удаляет из полученного ИБ записи с дубликатами
   * @param array $items - Массив элементов из ИБ
   * @return array - Масив элементов
   */
  public static function trimIBArray(array $array)
  {
    if (empty($array))
      return [];
    $newArray = [];
    foreach ($array as $key => $items) {
      $newArray[$key] = self::trimIBProperty($items);
    }
    return $newArray;
  }

  public static function itemToLowerCase($item)
  {
    $newItem = [];
    foreach ($item as $key => $value)
      $newItem[mb_strtolower($key)] = $value;
    return $newItem;
  }

  public static function makeHash(array $array)
  {
    $items = [];
    foreach ($array as $item)
      $items[$item] = null;
    return $items;
  }

  public static function slice(array $array, $pattern = 'ID')
  {
    $items = [];
    foreach ($array as $item){
      if(is_array($item))
        $items[] = $item[$pattern];
      if(is_object($item))
        $items[] = $item->$pattern;
    }
    return $items;
  }

  /**
   * Сортирует один массив по другому
   * @param array $order
   * @param array $items
   * @return array
   */
  public static function order(array $order, array $items)
  {
    $sortedItems = [];
    foreach ($order as $key)
      $sortedItems[] = $items[$key];
    return $sortedItems;
  }

  public static function filter(array $array, &$function, $useKey = false)
  {
      $items = [];
      foreach ($array as $key => $value){
        $param = $useKey ? $key : $value;
        if($function($param))
          $items[$key] = $value;
      }
      return $items;
  }
}