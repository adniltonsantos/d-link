<?php

namespace Centra\Main\Exceptions;

use Centra\Main\Interfaces\ExceptionInterface;

class ValidException extends \Exception implements ExceptionInterface
{
  private $errors;

  function __construct($message, $errors = [], $code = null)
  {
    if(is_null($code))
      parent::__construct($message);
    else
      parent::__construct($message, $code);
    $this->errors = $errors;

    return $this;
  }

  public function getErrors()
  {
    return $this->errors;
  }

  public function setErrors(array $errors)
  {
    $this->errors = $errors;
    return $this;
  }
}