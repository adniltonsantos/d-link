<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 19.04.18
 * Time: 11:30
 */

namespace Centra\Main;

class Model
{
  const SCENARIO_DEFAULT = 'default';
  const MARK_SCENARIO = 'on';
  const SYSTEM_ATTRIBUTES = ['_errors', '_attributes', '_scenario'];
  public $_errors = [];
  public $_oldAttributes = [];
  public $_attributes = [];
  public $_scenario = self::SCENARIO_DEFAULT;

  public static function rules()
  {
    return [];
  }

  public function __construct(array $params = [])
  {
    if(!empty($params))
      $this->load($params);
    else
      $this->makeDefault();
    $this->setOldAttributes($this->getAttributes());
  }

  public function load(array $params = [])
  {
    $items = [];
    foreach ($params as $key => $value)
      if($this->isSafeParameter($key))
        $items[$key] = $value;
    $this->setAttributes($items);
    return $this;
  }

  public function makeDefault()
  {
    $rules = static::rules();
    $items = [];
    foreach ($rules as $rule)
      foreach ($rule as $key => $ruleItems)
        $items[$key] = !empty($ruleItems['default']) ? $ruleItems['default'] : null;
    $this->setAttributes($items);
  }

  public function check()
  {
    $this->clearErrors();
    $rules = static::rules();
    $ruleKeys = $this->getRulesKeys();
    foreach ($ruleKeys as $paramKey){
      $value = $this->getAttribute($paramKey);
      foreach ($rules as $rule){
        if (!isset($rule[$paramKey]))
          continue;
        $ruleEntry = $rule[$paramKey];
        if(isset($ruleEntry['on']) && is_array($ruleEntry[self::MARK_SCENARIO]) && !in_array($this->getScenario(), $ruleEntry[self::MARK_SCENARIO]))
          continue;
        $this->checkParameter($paramKey, $value, $ruleEntry);
      }
    }
    return true;
  }

  protected function isSafeParameter($key)
  {
    $rulesId = [];
    foreach (static::rules() as $ruleItem){
      foreach ($ruleItem as $param => $rule)
        if(!isset($rule['on']) && $this->getScenario() == static::SCENARIO_DEFAULT)
          $rulesId[] = $param;
        else if(isset($rule['on']))
          if(is_array($rule['on']) && in_array($this->getScenario(), $rule['on']))
            $rulesId[] = $param;
    }
    return in_array($key, $rulesId);
  }

  protected function checkParameter($key, $value, $rule)
  {
    if (mb_strlen($value) == 0 && isset($rule['default']) && mb_strlen($rule['default']) != 0){
      $this->setAttribute($key, $rule['default']);
    } else if (!empty($rule['safe'])) {
      return true;
    } else if (mb_strlen($value) == 0 && !empty($rule['required'])) {
      $this->addError($key, $rule['message']);
    } else if (mb_strlen($value) != 0 && is_array($value)) {
      foreach ($value as $subKey => $subValue)
        if(!preg_match($rule['regexp'], $subValue))
          $this->addError($key, $rule['message']);
    } else if (mb_strlen($value) != 0 && !empty($rule['regexp']) && !preg_match($rule['regexp'], $value)){
      $this->addError($key, $rule['message']);
    } else if (mb_strlen($value) != 0 && !empty($rule['min']) && !empty($rule['max'])){
      if(mb_strlen($value) > (int) $rule['max'] || mb_strlen($value) < (int) $rule['min'] )
      $this->addError($key, $rule['message']);
    }
    return true;
  }

  public function getRulesKeys()
  {
    $items = [];
    foreach (static::rules() as $rule)
      foreach ($rule as $key => $item)
        $items[$key] = true;
    return array_keys($items);
  }

  public function getAttributes()
  {
    return $this->_attributes;
  }

  public function getAttribute($key)
  {
    return isset($this->getAttributes()[$key]) ? $this->getAttributes()[$key] : null;
  }

  public function getOldAttributes()
  {
    return $this->_oldAttributes;
  }

  public function setAttributes($attributes)
  {
    $this->_attributes = $attributes;
    return $this;
  }

  public function setAttribute($key, $value)
  {
    $this->_attributes[$key] = $value;
    return $this;
  }

  public function getOldAttribute($key)
  {
    return isset($this->getOldAttributes()[$key]) ? $this->getOldAttributes()[$key] : null;
  }

  public function setOldAttributes($attributes)
  {
    $this->_oldAttributes = $attributes;
    return $this;
  }

  public function setOldAttribute($key, $value)
  {
    $this->_oldAttributes[$key] = $value;
    return $this;
  }

  public function isChanges()
  {
    $diff = array_diff_assoc($this->getAttributes(), $this->getOldAttributes());
    return (bool) count($diff);
  }

  public function hasError()
  {
    return (boolean) count($this->getErrors());
  }

  public function getError($key)
  {
    return isset($this->_errors[$key]) ? $this->_errors[$key] : '';
  }

  public function getErrors()
  {
    return $this->_errors;
  }

  public function addError($key, $message)
  {
    $this->_errors[$key] = $message;
  }

  public function clearErrors()
  {
    $this->_errors = [];
  }

  public function getScenario()
  {
    return $this->_scenario;
  }

  public function setScenario($scenario)
  {
    $this->_scenario = $scenario;
    return $this;
  }

  public function toArray()
  {
    return get_object_vars($this);
  }

}