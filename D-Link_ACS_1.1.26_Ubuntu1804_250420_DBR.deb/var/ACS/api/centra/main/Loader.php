<?php

namespace Centra\Main;

class Loader
{
  const FILE_SEPARATOR = "/";
  /** @var self $instance */
  private static $instance = null;
  private $path = null;
  private $map = [];

  public static function collect($basePath = '')
  {
    if (is_null(self::$instance)) {
      $model = new self();
      $model->path = empty($basePath) ? $_SERVER['DOCUMENT_ROOT'] : $basePath;
      $model->getFilesRecursive($model->path);
      self::$instance = $model;
    }
    return self::$instance;
  }

  /**
   * Рекурсивный поиск по каталогу и подкаталогам. Ищет *.php и складывает в массив с деревом каталога в качестве namespace. PSR0
   * @param string $path - Каталог откуда надо искать класс.
   * @return bool - Признак выполенения.
   */
  private function getFilesRecursive($path = '')
  {
    $fp = opendir($path);
    while ($cv_file = readdir($fp)) {
      if (is_file($path . "/" . $cv_file)) {
        $arFilename = pathinfo($path . "/" . $cv_file);
        if($arFilename['extension'] != "php")
          continue;
        $sTrimmedName = str_replace($this->path . "/", '', $path);
        $classPath = explode("/", $sTrimmedName);
        $className = [];
        foreach ($classPath as $pathItem)
          $className[] = ucfirst($pathItem);
        $className[] = ucfirst($arFilename['filename']);
        $className = implode("\\", $className);
        $this->map[$className] = $path . "/" . $cv_file;
      } elseif ($cv_file != "." && $cv_file != ".." && is_dir($path . "/" . $cv_file)) {
        $this->getFilesRecursive($path . "/" . $cv_file);
      }
    }
    closedir($fp);
    return true;
  }

  /** Проверка на существование класса и его подгрузка из файла.
   * @param $sName
   * @return bool
   * @throws \Exception
   */
  public static function registerClass($classname)
  {
    $model = self::$instance;
    if (isset($model->map[$classname]) && file_exists($model->map[$classname]))
      include_once $model->map[$classname];
    if (class_exists($classname) || interface_exists($classname) || trait_exists($classname))
      return true;
    throw new \Exception("Класс " . $classname . " не найден.");
  }

  /**
   * @return array
   */
  public function getMap()
  {
    return $this->map;
  }

  /**
   * @param array $map
   * @return Loader $this;
   */
  public function setMap($map)
  {
    $this->map = $map;
    return $this;
  }

  /**
   * @return null
   */
  public function getPath()
  {
    return $this->path;
  }

  /**
   * @param null $path
   * @return Loader $this;
   */
  public function setPath($path)
  {
    $this->path = $path;
    return $this;
  }

  /**
   * @return Loader
   */
  public static function getInstance()
  {
    if (is_null(self::$instance)) {
      $model = new self();
      self::$instance = $model;
    }
    return self::$instance;
  }

}

spl_autoload_register('\Centra\Main\Loader::registerClass');
