<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 14.12.16
 * Time: 9:42
 * Класс запроса с обвязкой curl.
 */

namespace Centra\Http\Main;

use Centra\Main\Exceptions\HttpException;
use Centra\Api\Interfaces\ConfigInterface;

abstract class RequestAgent
{
  const RESPONSE_RETURN_DATA = 'return_data';
  const RETURN_DATA_YES = 1;
  const RETURN_DATA_NO = 0;
  const REQUEST_SSL_PASS = 'ssl_pass';
  const SSL_PASS_YES = true;
  const SSL_PASS_NO = false;
  const RESPONSE_THROW_EXCEPTION = 'throwException';
  const THROW_EXCEPTION_YES = true;
  const THROW_EXCEPTION_NO = false;
  const POST_CONTENT_TYPE = 'Content-Type: multipart/form-data';
  const POST_TYPE = true;
  const SUCCESS = 1;
  const FAILED = 0;
  protected $returnData = self::RETURN_DATA_YES;
  protected $sslPass = self::SSL_PASS_YES;
  protected $throwException = self::THROW_EXCEPTION_YES;
  protected $headers = [];
  protected $curl = null;
  protected $search_url = null;
  protected $data = null;
  protected $config = null;
  protected $exceptionMessage = "Сервер недоступен. Приносим свои извинения.";

  public function __construct(ConfigInterface $config)
  {
    $this->setConfig($config);
  }

  public function __destruct()
  {
    if(!is_null($this->getCurl()))
      curl_close($this->getCurl());
  }

  /**
   * @return bool|mixed
   * @throws \Centra\Main\Exceptions\HttpException
   */
  protected function request()
  {
    for ($num = 0; $num <= $this->getConfig()->getRetries(); $num++) {
      $response = curl_exec($this->getCurl());
      if (!empty($response))
        return $response;
      sleep($this->getConfig()->getTimeout());
    }
    if ($this->throwException)
      throw new HttpException($this->getExceptionMessage());
    else
      return false;
  }

  protected function setCommonParams()
  {
    curl_setopt($this->getCurl(), CURLOPT_URL, $this->getSearchUrl());
    if ($this->getReturnData() === self::RETURN_DATA_YES)
      curl_setopt($this->getCurl(), CURLOPT_RETURNTRANSFER, self::RETURN_DATA_YES);
    if ($this->sslPass === self::SSL_PASS_YES) {
      curl_setopt($this->getCurl(), CURLOPT_SSL_VERIFYHOST, self::SSL_PASS_NO);
      curl_setopt($this->getCurl(), CURLOPT_SSL_VERIFYPEER, self::SSL_PASS_NO);
    }
    curl_setopt($this->getCurl(), CURLOPT_TIMEOUT, $this->getConfig()->getTimeout());
  }

  protected function setPostParams()
  {
    curl_setopt($this->getCurl(), CURLOPT_POST, self:: POST_TYPE);
    curl_setopt($this->getCurl(), CURLOPT_POSTFIELDS, $this->getData());
  }

  /**
   * @param $url
   * @return bool|mixed
   * @throws HttpException
   */
  protected function get($url)
  {
    $this->setCurl(curl_init());
    $this->setSearchUrl($url);
    if (!empty($this->getHeaders()))
      curl_setopt($this->getCurl(), CURLOPT_HTTPHEADER, $this->getHeaders());
    $this->setCommonParams();
    return $this->request();
  }

  /**
   * @param $url
   * @param mixed $params
   * @return bool|mixed
   * @throws HttpException
   */
  protected function post($url, $params)
  {
    $this->setCurl(curl_init());
    $this->setSearchUrl($url);
    $this->setData($params);
    if (!empty($this->getHeaders())) {
      $this->headers[] = self::POST_CONTENT_TYPE;
      curl_setopt($this->getCurl(), CURLOPT_HTTPHEADER, $this->getHeaders());
    } else {
      curl_setopt($this->getCurl(), CURLOPT_HTTPHEADER, [self::POST_CONTENT_TYPE]);
    }
    $this->setCommonParams();
    $this->setPostParams();
    return $this->request();
  }


  /** Обработчик ответа.
   * @param $response - строка ответа.
   * @return array - Массив с данными.
   * @throws HttpException
   */
  protected function parseResponse($response)
  {
    if (empty($response))
      throw new HttpException("Ответ от системы не получен.");
    $arResponse = json_decode($response);
    if (is_null($arResponse))
      throw new HttpException("Ответ от системы не возможно обработать.");
    if (isset($arResponse->success) && $arResponse->success == self::FAILED)
      throw new HttpException("Запрос к системе завершен с ошибкой: " . $arResponse->message);
    $data = isset($arResponse->data) ? $arResponse->data : $arResponse;
    return $data;
  }

  /**
   * @return int
   */
  public function getReturnData()
  {
    return $this->returnData;
  }

  /**
   * @param int $returnData
   */
  public function setReturnData($returnData)
  {
    $this->returnData = $returnData;
  }

  /**
   * @return bool
   */
  public function isSslPass()
  {
    return $this->sslPass;
  }

  /**
   * @param bool $sslPass
   */
  public function setSslPass($sslPass)
  {
    $this->sslPass = $sslPass;
  }

  /**
   * @return bool
   */
  public function isThrowException()
  {
    return $this->throwException;
  }

  /**
   * @param bool $throwException
   */
  public function setThrowException($throwException)
  {
    $this->throwException = $throwException;
  }

  /**
   * @return array
   */
  public function getHeaders()
  {
    return $this->headers;
  }

  /**
   * @param array $headers
   */
  public function setHeaders($headers)
  {
    $this->headers = $headers;
  }

  /**
   * @return null
   */
  public function getData()
  {
    return $this->data;
  }

  /**
   * @param null $data
   */
  public function setData($data)
  {
    $this->data = $data;
  }

  /**
   * @return string
   */
  public function getExceptionMessage()
  {
    return $this->exceptionMessage;
  }

  /**
   * @param string $exceptionMessage
   */
  public function setExceptionMessage($exceptionMessage)
  {
    $this->exceptionMessage = $exceptionMessage;
  }

  /**
   * @return null
   */
  public function getSearchUrl()
  {
    return $this->search_url;
  }

  /**
   * @param null $search_url
   * @return $this
   */
  public function setSearchUrl($search_url)
  {
    $this->search_url = $search_url;
    return $this;
  }

  /**
   * @return null|resource
   */
  public function getCurl()
  {
    return $this->curl;
  }

  /**
   * @param null$curl
   * @return $this
   */
  public function setCurl($curl)
  {
    $this->curl = $curl;
    return $this;
  }

  /**
   * @return null|ConfigInterface
   */
  public function getConfig()
  {
    return $this->config;
  }

  /**
   * @param null|ConfigInterface $config
   * @return $this
   */
  public function setConfig($config)
  {
    $this->config = $config;
    return $this;
  }

}