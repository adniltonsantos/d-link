<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 06.07.18
 * Time: 9:50
 */

namespace Centra\Http\Models;

use Centra\Main\Exceptions\ValidException;
use Centra\Main\Utils\Validator;

class IpNetwork
{
  const MAX_NET_LENGTH = 32;
  const BYTE_LENGTH = 2;
  public $ip = null;
  public $mask = null;

  /**
   * Заполняет из строки адрес сети
   * @param $netString
   * @return $this
   * @throws ValidException
   */
  public static function fromString($netString)
  {
    list($ip, $mask) = explode("/", $netString);
    Validator::isIp($ip);
    Validator::isIpMask($mask);
    $model = new self();
    $model->setIp($ip);
    $model->setMask($mask);
    return $model;
  }

  /**
   * @return null
   */
  public function getIp()
  {
    return $this->ip;
  }

  /** Устанавливает ip адрес
   * @param $ip
   * @return $this
   * @throws ValidException
   */
  public function setIp($ip)
  {
    Validator::isIp($ip);
    $this->ip = $ip;
    return $this;
  }

  /**
   * @return null
   */
  public function getMask()
  {
    return $this->mask;
  }

  /** Устанавливает маску ip
   * @param $mask
   * @return $this
   * @throws ValidException
   */
  public function setMask($mask)
  {
    Validator::isIpMask($mask);
    $this->mask = $mask;
    return $this;
  }

  public function getLastIpAddress()
  {
    $netLength = pow(self::BYTE_LENGTH, self::MAX_NET_LENGTH - $this->getMask());
    return long2ip(ip2long($this->getIp()) + $netLength);
  }

  public function getIpLong()
  {
    return ip2long($this->getIp());
  }

  public function getLastIpLong()
  {
    return ip2long($this->getLastIpAddress());
  }

}