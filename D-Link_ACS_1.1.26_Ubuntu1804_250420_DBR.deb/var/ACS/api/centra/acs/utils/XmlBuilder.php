<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 15:25
 */

namespace Centra\Acs\Utils;

class XmlBuilder
{
  public static function get($command, $deviceId)
  {
    $dom = new \DOMDocument(1, 'utf-8');
    $root = $dom->createElement("SOAP-ENV:Envelope");
    $root->setAttribute("xmlns:SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/");
    $root->setAttribute("xmlns:SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/");
    $root->setAttribute("xmlns:SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
    $root->setAttribute("xmlns:cwmp", "urn:dslforum-org:cwmp-1-0");
    $root->setAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
    $root->setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
    $dom->appendChild($root);
    $header = $dom->createElement("SOAP-ENV:Header");
    $root->appendChild($header);
    $headerItem = $dom->createElement("cwmp:ID", 1);
    $headerItem->setAttribute("SOAP-ENV:mustUnderstand", 1);
    $header->appendChild($headerItem);
    $body = $dom->createElement("SOAP-ENV:Body");
    $root->appendChild($body);
    $inform = $dom->createElement("cwmp:Inform");
    $body->appendChild($inform);
    $paramsList = $dom->createElement("ParameterList");
    $inform->appendChild($paramsList);
    $paramsList->setAttribute("SOAP-ENC:arrayType", "cwmp:ParameterValueStruct[1]");
    $paramsList->setAttribute("xsi:type", "SOAP-ENC:Array");
    $count = $dom->createElement("Count", 1);
    $paramsList->appendChild($count);
    $paramStrict = $dom->createElement("ParameterValueStruct");
    $paramsList->appendChild($paramStrict);
    $name = $dom->createElement("Name", $command);
    $deviceId = $dom->createElement("DeviceId", $deviceId);
    $setId = $dom->createElement("SetID");
    $fwName = $dom->createElement("FWName", "NoName");
    $userId = $dom->createElement("UserID", 1);
    $paramStrict->appendChild($name);
    $paramStrict->appendChild($deviceId);
    $paramStrict->appendChild($setId);
    $paramStrict->appendChild($fwName);
    $paramStrict->appendChild($userId);
    return $dom->saveXML();
  }
}