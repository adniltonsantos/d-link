<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 16.10.18
 * Time: 14:37
 */

namespace Centra\Acs\Main;

use Centra\Main\Exceptions\ProcessException;

class DeviceParamsReader
{
  private $config = [];
  private $path = null;
  private $date = null;

  /**
   * DeviceParamsReader constructor.
   * @param $path
   * @throws ProcessException
   */
  public function __construct($path)
  {
    $this->setPath($path);
    $this->read();
  }

  /**
   * Считывает конфигуркцию параметров
   * @throws ProcessException
   */
  private function read()
  {
    if(!file_exists($this->getPath()))
      throw new ProcessException("Не удалось считать конфигурацию по пути: " . $this->getPath());
    $xmlString = file_get_contents($this->getPath());
    $fileStat = stat($this->getPath());
    $date = (new \DateTime())->setTimestamp($fileStat['mtime']);
    $this->setDate($date->format("Y-m-d H:i:s"));
    $xml = new \DOMDocument(1);
    $xml->loadXML($xmlString);
    $paramList = $xml->getElementsByTagName("ParameterValueStruct");
    $params = [];
    for($index = 0; $index < $paramList->length; $index++){
      $item = $paramList->item($index);
      $name = $item->getElementsByTagName("Name")->item(0)->textContent;
      $value = $item->getElementsByTagName("Value")->item(0)->textContent;
      $params[$name] = $value;
    }
    $this->setConfig($params);
  }

  public function grep($pattern = null)
  {
    if(is_null($pattern))
      return $this->getConfig();
    $match = [];
    foreach ($this->getConfig() as $key => $value)
      if(preg_match($pattern, $key))
        $match[$key] = $value;
    return $match;
  }

  public function get($pattern = null)
  {
    if(is_null($pattern))
      return $this->getConfig();
    foreach ($this->getConfig() as $key => $value)
      if(preg_match($pattern, $key))
        return $value;
    return null;
  }


  public function isEmpty()
  {
    return empty($this->getConfig());
  }

  /**
   * @return array
   */
  public function getConfig()
  {
    return $this->config;
  }

  /**
   * @param array $config
   * @return $this
   */
  public function setConfig($config)
  {
    $this->config = $config;
    return $this;
  }

  /**
   * @return null
   */
  public function getPath()
  {
    return $this->path;
  }

  /**
   * @param null $path
   * @return $this
   */
  public function setPath($path)
  {
    $this->path = $path;
    return $this;
  }

  /**
   * @return null
   */
  public function getDate()
  {
    return $this->date;
  }

  /**
   * @param null $date
   * @return $this
   */
  public function setDate($date)
  {
    $this->date = $date;
    return $this;
  }

}