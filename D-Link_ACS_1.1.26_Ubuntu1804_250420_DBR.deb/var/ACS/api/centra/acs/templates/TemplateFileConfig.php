<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 17:49
 */

namespace Centra\Acs\Templates;

use Centra\Main\Exceptions\ProcessException;

use Centra\Main\Exceptions\ValidException;
use Centra\Database\Main\Model;
use Centra\Main\Store;
use Centra\Main\Utils\StringBuilder;
use Centra\Main\Utils\StringUtils;

class TemplateFileConfig extends Model
{
  const LAN_SECTION = 'LAN';
  const WIFI_SECTION = 'WI-FI';
  const DYNAMIC_IP_SECTION = 'DYNAMIC-IP';
  const STATIC_IP_SECTION = 'STATIC-IP';
  const FREQUENCY_BAND_24_TITLE = '2.4GHz';
  const FREQUENCY_BAND_5_TITLE = '5GHz';
  const FREQUENCY_BAND_KEY = 'frequency_band';
  const SECTION_PATTERN = "/^\[([(A-z0-9\-]+)\]$/u";
  const SECTION_REPLACE_PATTERN = "/(\[|\])/";
  const BEACON_BASIC = 'Basic';
  const BEACON_KEY = 'beacon_type';

  public static function rules()
  {
    return [
      ['path' => ['safe' => true]]
    ];
  }

  /**
   * Собирает конфигурацию.
   * TemplateFileConfig constructor.
   * @param $params
   * @throws ProcessException
   * @throws ValidException
   */
  public function __construct($params)
  {
    if(empty($params['path']))
      throw new ValidException("Путь к файлу конфигурации не указан");
    parent::__construct($params);
    $configLines = $this->getFileItems();
    $this->parseConfig($configLines);
  }

  /**
   * Получает конфигурацию из файла
   * @return array
   * @throws ProcessException
   */
  private function getFileItems()
  {
    if(!file_exists($this->getPath()))
      return [];
    $lines = explode("\n", file_get_contents($this->getPath()));
    if(empty($lines))
      throw new ProcessException("Не удалось получить конфигураци из файла по пути:" . $this->getPath());
    return $lines;
  }

  /**
   * Разбивает конфигурацию на секции
   * @param array $configLines
   */
  private function parseConfig(array $configLines)
  {
    $sectionName = null;
    $item = [];
    $items = [];
    foreach ($configLines as $line){
      if(preg_match(self::SECTION_PATTERN, $line, $match)){
        if(!empty($sectionName))
          $items[$sectionName][] = $item;
        $item = [];
        $sectionName = preg_replace(self::SECTION_REPLACE_PATTERN, "", $match[0]);
      } else {
        $line = StringUtils::trimSpaces($line);
        if(empty($line))
          continue;
        list($key, $value) = explode("=", $line);
        $item[$key] = $value;
      }
    }
    if(!is_null($sectionName))
      $items[$sectionName][] = $item;
    $this->setConfig($items);
  }

  public function getLan()
  {
    $config = $this->getConfig();
    if(empty($config[self::LAN_SECTION]))
      return [];
    return $config[self::LAN_SECTION];
  }

  public function getWifi()
  {
    $config = $this->getConfig();
    if(empty($config[self::WIFI_SECTION]))
      return [];
    return $config[self::WIFI_SECTION];
  }

  public function getWifi24()
  {
    $config = $this->getConfig();
    if(empty($config[self::WIFI_SECTION]))
      return [];
    $filterSections = [];
    foreach ($config[self::WIFI_SECTION] as $sectionItem){
      if($sectionItem[self::FREQUENCY_BAND_KEY] == self::FREQUENCY_BAND_24_TITLE)
        $filterSections[] = $sectionItem;
    }
    return $filterSections;
  }

  public function getWifi5()
  {
    $config = $this->getConfig();
    if(empty($config[self::WIFI_SECTION]))
      return [];
    $filterSections = [];
    foreach ($config[self::WIFI_SECTION] as $sectionItem){
      if($sectionItem[self::FREQUENCY_BAND_KEY] == self::FREQUENCY_BAND_5_TITLE)
        $filterSections[] = $sectionItem;
    }
    return $filterSections;
  }

  public function getDynamicIp()
  {
    $config = $this->getConfig();
    if(empty($config[self::DYNAMIC_IP_SECTION]))
      return [];
    return $config[self::DYNAMIC_IP_SECTION];
  }

  public function getStaticIp()
  {
    $config = $this->getConfig();
    if(empty($config[self::STATIC_IP_SECTION]))
      return [];
    return $config[self::STATIC_IP_SECTION];
  }

  public function setLan(TemplateLanBlank $blank, $key = null)
  {
    $config = $this->getConfig();
    if(is_null($key))
      $config[self::LAN_SECTION][] = $blank->getAttributes();
    else
      $config[self::LAN_SECTION][$key] = $blank->getAttributes();
    return $this->setConfig($config);
  }

  public function setWifi(TemplateWifiBlank $blank, $key = null)
  {
    $config = $this->getConfig();
    if(is_null($key))
      $config[self::WIFI_SECTION][] = $blank->getAttributes();
    else
      $config[self::WIFI_SECTION][$key] = $blank->getAttributes();
    return $this->setConfig($config);
  }

  public function setDynamicIp(TemplateDynamicIpBlank $blank, $key = null)
  {
    $config = $this->getConfig();
    if(is_null($key))
      $config[self::DYNAMIC_IP_SECTION][] = $blank->getAttributes();
    else
      $config[self::DYNAMIC_IP_SECTION][$key] = $blank->getAttributes();
    return $this->setConfig($config);
  }

  public function setStaticIp(TemplateStaticIpBlank $blank, $key = null)
  {
    $config = $this->getConfig();
    if(is_null($key))
      $config[self::STATIC_IP_SECTION][] = $blank->getAttributes();
    else
      $config[self::STATIC_IP_SECTION][$key] = $blank->getAttributes();
    return $this->setConfig($config);
  }

  public function clearLan()
  {
    $config = $this->getConfig();
    unset($config[self::LAN_SECTION]);
    return $this->setConfig($config);
  }

  public function clearWifi()
  {
    $config = $this->getConfig();
    unset($config[self::WIFI_SECTION]);
    return $this->setConfig($config);
  }

  public function clearDynamicIp()
  {
    $config = $this->getConfig();
    unset($config[self::DYNAMIC_IP_SECTION]);
    return $this->setConfig($config);
  }

  public function clearStaticIp()
  {
    $config = $this->getConfig();
    unset($config[self::STATIC_IP_SECTION]);
    return $this->setConfig($config);
  }

  /**
   * Устанавливает все параметры из массива
   * @param array $params
   * @throws ValidException
   */
  public function setFromParams(array $params)
  {
    $this->setConfig([]);
    foreach ($params as $section => $items){
      foreach ($items as $key => $configItem){
        $template = null;
        if($section == TemplateFileConfig::LAN_SECTION)
          $template = new TemplateLanBlank($configItem);
        if($section == TemplateFileConfig::WIFI_SECTION){
          $template = new TemplateWifiBlank();
          $scenario = $configItem[self::BEACON_KEY] == self::BEACON_BASIC ? TemplateWifiBlank::SCENARIO_BASIC : TemplateWifiBlank::SCENARIO_11I;
          $template->setScenario($scenario)->load($configItem);
        }
        if($section == TemplateFileConfig::STATIC_IP_SECTION)
          $template = new TemplateStaticIpBlank($configItem);
        if($section == TemplateFileConfig::DYNAMIC_IP_SECTION)
          $template = new TemplateDynamicIpBlank($configItem);
        if(is_null($template))
          throw new ValidException("Секция " . $section . ' не найдена');
        $template->check();
        if($template->hasError())
          throw new ValidException("При сохранении параметров произошла ошибка", $template->getErrors());
        if($section == TemplateFileConfig::LAN_SECTION)
          $this->setLan($template, $key);
        if($section == TemplateFileConfig::WIFI_SECTION)
          $this->setWifi($template, $key);
        if($section == TemplateFileConfig::STATIC_IP_SECTION)
          $this->setStaticIp($template, $key);
        if($section == TemplateFileConfig::DYNAMIC_IP_SECTION)
          $this->setDynamicIp($template, $key);
      }
    }
  }

  /**
   * Сохраняет конфигурацию.
   * @throws ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function save()
  {
    /** @var StringBuilder $config */
    $config = Store::init()->make(StringBuilder::class);
    $config->clear();
    foreach ($this->getConfig() as $section => $configSection){
      foreach ($configSection as $items){
        $config->add("[")->add($section)->add("]")->next();
        foreach ($items as $key => $value){
          $config->add($key)->add(" = ")->add($value)->next();
        }
      }
    }
    $result = file_put_contents($this->getPath(), $config->get());
    if(!$result)
      throw new ProcessException("Не удалось сохранить конфигурацию по пути:" . $this->getPath());
  }

  /**
   * @return mixed
   */
  public function getConfig()
  {
    return $this->getAttribute("config");
  }

  /**
   * @param mixed $config
   * @return $this
   */
  public function setConfig($config)
  {
    $this->setAttribute("config", $config);
    return $this;
  }

  /**
   * @return mixed
   */
  public function getPath()
  {
    return $this->getAttribute("path");
  }

  /**
   * @param mixed $path
   * @return $this
   */
  public function setPath($path)
  {
    $this->setAttribute("path", $path);
    return $this;
  }



}