<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 9:55
 */

namespace Centra\Acs\Templates;

use Centra\Database\Main\Model;
use Centra\Main\Utils\Validator;

/**
 * Class TemplateStaticIpBlank
 * @package Centra\Acs\Templates
 * @property string name
 * @property string ext_ip_address
 * @property string subnet_mask
 * @property string mtu
 * @property string def_gateway
 * @property string dns
 * @property string nat
 * @property string enable
 * @property string def_connection
 */
class TemplateStaticIpBlank extends Model
{
  public static function rules()
  {
    return [
      ['name' => [
        'required' => true,
        'message'  => 'Имя соединения не указано'
      ]],
      ['ext_ip_address' => [
        'required' => true,
        'message'  => 'Ip адрес соединения не указано'
      ]],
      ['subnet_mask' => [
        'required' => true,
        'message'  => 'Маска сети соединения не указана'
      ]],
      ['mtu' => [
        'required' => true,
        'message'  => 'MTU соединения не указано'
      ]],
      ['def_gateway' => [
        'required' => true,
        'message'  => 'Шлюз по умолчанию соединения не указан'
      ]],
      ['dns' => [
        'required' => true,
        'message'  => 'Ip адрес DNS соединения не указан'
      ]],
      ['nat' => [
        'required' => true,
        'message'  => 'Маркер NAT соединения не указан'
      ]],
      ['enable' => [
        'required' => true,
        'message'  => 'Активность соединения не указана'
      ]],
      ['def_connection' => [
        'required' => true,
        'message'  => 'Маркер по умолчанию соединения не указан'
      ]],
      ['name' => [
        'regexp' => Validator::PATTERN_STRING,
        'message'  => 'Имя соединения указано неверно'
      ]],
      ['ext_ip_address' => [
        'regexp' => Validator::PATTERN_IP,
        'message'  => 'Ip адрес соединения указано неверно'
      ]],
      ['subnet_mask' => [
        'regexp' => Validator::PATTERN_IP,
        'message'  => 'Маска сети соединения указана неверно'
      ]],
      ['mtu' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message'  => 'MTU соединения указано неверно'
      ]],
      ['def_gateway' => [
        'regexp' => Validator::PATTERN_IP,
        'message'  => 'Шлюз по умолчанию соединения указан неверно'
      ]],
      ['dns' => [
        'regexp' => Validator::PATTERN_IP_LIST,
        'message'  => 'Ip адрес DNS соединения указан неверно'
      ]],
      ['nat' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Маркер NAT соединения указан неверно'
      ]],
      ['enable' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Активность соединения указан неверно'
      ]],
      ['def_connection' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Маркер по умолчанию соединения указан неверно'
      ]],
    ];
  }



  /**
   * @return string
   */
  public function getName()
  {
    return $this->getAttribute("name");
  }

  /**
   * @param string $name
   * @return $this
   */
  public function setName($name)
  {
    $this->setAttribute("name", $name);
    return $this;
  }

  /**
   * @return string
   */
  public function getExtIpAddress()
  {
    return $this->getAttribute("ext_ip_address");
  }

  /**
   * @param string $ext_ip_address
   * @return $this
   */
  public function setExtIpAddress($ext_ip_address)
  {
    $this->setAttribute("ext_ip_address", $ext_ip_address);
    return $this;
  }

  /**
   * @return string
   */
  public function getSubnetMask()
  {
    return $this->getAttribute("subnet_mask");
  }

  /**
   * @param string $subnet_mask
   * @return $this
   */
  public function setSubnetMask($subnet_mask)
  {
    $this->setAttribute("subnet_mask", $subnet_mask);
    return $this;
  }

  /**
   * @return string
   */
  public function getMtu()
  {
    return $this->getAttribute("mtu");
  }

  /**
   * @param string $mtu
   * @return $this
   */
  public function setMtu($mtu)
  {
    $this->setAttribute("mtu", $mtu);
    return $this;
  }

  /**
   * @return string
   */
  public function getDefGateway()
  {
    return $this->getAttribute("def_gateway");
  }

  /**
   * @param string $def_gateway
   * @return $this
   */
  public function setDefGateway($def_gateway)
  {
    $this->setAttribute("def_gateway", $def_gateway);
    return $this;
  }

  /**
   * @return string
   */
  public function getDns()
  {
    return $this->getAttribute("dns");
  }

  /**
   * @param string $dns
   * @return $this
   */
  public function setDns($dns)
  {
    $this->setAttribute("dns", $dns);
    return $this;
  }

  /**
   * @return string
   */
  public function getNat()
  {
    return $this->getAttribute("nat");
  }

  /**
   * @param string $nat
   * @return $this
   */
  public function setNat($nat)
  {
    $this->setAttribute("nat", $nat);
    return $this;
  }

  /**
   * @return string
   */
  public function getEnable()
  {
    return $this->getAttribute("enable");
  }

  /**
   * @param string $enable
   * @return $this
   */
  public function setEnable($enable)
  {
    $this->setAttribute("enable", $enable);
    return $this;
  }

  /**
   * @return string
   */
  public function getDefConnection()
  {
    return $this->getAttribute("def_connection");
  }

  /**
   * @param string $def_connection
   * @return $this
   */
  public function setDefConnection($def_connection)
  {
    $this->setAttribute("def_connection", $def_connection);
    return $this;
  }

}