<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 15:23
 */

namespace Centra\Configs;

use Centra\Api\Middleware\FormatResponse;
use Centra\Api\Middleware\IpAuth;
use Centra\Api\Middleware\LogRequest;
use Centra\Api\Middleware\LogResponse;
use Centra\Api\Middleware\RateLimit;
use Centra\Api\Models\RouterRule as Rule;
use Centra\Api\Interfaces\RouterRulesInterface;
use Centra\Api\Actions\Clients\GetAllAction as GetAllClients;
use Centra\Api\Actions\Clients\GetByIdAction as GetClientById;
use Centra\Api\Actions\Clients\GetByParams as GetClientsByParams;
use Centra\Api\Actions\Clients\AddAction as AddClient;
use Centra\Api\Actions\Clients\UpdateAction as UpdateClient;
use Centra\Api\Actions\Clients\DeleteAction as DeleteClient;

use Centra\Api\Actions\Templates\GetAllAction as GetAllTemplates;
use Centra\Api\Actions\Templates\GetByIdAction as GetTemplateById;
use Centra\Api\Actions\Templates\GetByParams as GetTemplatesByParams;
use Centra\Api\Actions\Templates\AddAction as AddTemplate;
use Centra\Api\Actions\Templates\UpdateAction as UpdateTemplate;
use Centra\Api\Actions\Templates\DeleteAction as DeleteTemplate;
use Centra\Api\Actions\Templates\Lan\GetAllAction as GetTemplateLan;
use Centra\Api\Actions\Templates\Lan\UpdateAction as UpdateTemplateLan;
use Centra\Api\Actions\Templates\Lan\DeleteAction as DeleteTemplateLan;
use Centra\Api\Actions\Templates\Wifi\GetAllAction as GetTemplateWifi;
use Centra\Api\Actions\Templates\Wifi\UpdateAction as UpdateTemplateWifi;
use Centra\Api\Actions\Templates\Wifi\DeleteAction as DeleteTemplateWifi;
use Centra\Api\Actions\Templates\StaticIp\GetAllAction as GetTemplateStaticIp;
use Centra\Api\Actions\Templates\StaticIp\UpdateAction as UpdateTemplateStaticIp;
use Centra\Api\Actions\Templates\StaticIp\DeleteAction as DeleteTemplateStaticIp;
use Centra\Api\Actions\Templates\DynamicIp\GetAllAction as GetTemplateDynamicIp;
use Centra\Api\Actions\Templates\DynamicIp\UpdateAction as UpdateTemplateDynamicIp;
use Centra\Api\Actions\Templates\DynamicIp\DeleteAction as DeleteTemplateDynamicIp;

use Centra\Api\Actions\UnregisteredDevices\GetAllAction as GetAllUnregisteredDevices;
use Centra\Api\Actions\UnregisteredDevices\GetByIdAction as GetUnregisteredDeviceById;
use Centra\Api\Actions\UnregisteredDevices\GetByParams as GetUnregisteredDevicesByParams;
use Centra\Api\Actions\UnregisteredDevices\AddAction as AddUnregisteredDevice;
use Centra\Api\Actions\UnregisteredDevices\UpdateAction as UpdateUnregisteredDevice;
use Centra\Api\Actions\UnregisteredDevices\DeleteAction as DeleteUnregisteredDevice;

use Centra\Api\Actions\Devices\GetAllAction as GetAllDevices;
use Centra\Api\Actions\Devices\GetByIdAction as GetDeviceById;
use Centra\Api\Actions\Devices\GetByParams as GetDevicesByParams;
use Centra\Api\Actions\Devices\AddAction as AddDevice;
use Centra\Api\Actions\Devices\UpdateAction as UpdateDevice;
use Centra\Api\Actions\Devices\DeleteAction as DeleteDevice;
use Centra\Api\Actions\Devices\Exec\RefreshConfigAction as RefreshTemplateDevice;
use Centra\Api\Actions\Devices\Exec\RebootAction as RebootDevice;
use Centra\Api\Actions\Devices\Exec\InfoAction as InfoDevice;
use Centra\Api\Actions\Devices\Info\GetBaseAction as BaseDeviceInfo;
use Centra\Api\Actions\Devices\Info\GetHostsAction as HostsDeviceInfo;
use Centra\Api\Actions\Devices\Info\GetWanAction as WanDeviceInfo;
use Centra\Api\Actions\Devices\Info\GetLanAction as LanDeviceInfo;
use Centra\Api\Actions\Devices\Info\GetWifiAction as WifiDeviceInfo;

use Centra\Api\Actions\Tasks\GetByParams as TasksByParams;
use Centra\Api\Actions\Tasks\GetByDeviceId as TasksByDeviceId;

use Centra\Api\Actions\Models\GetAllAction as GetAllModels;
use Centra\Api\Actions\Models\GetByIdAction as GetModelById;

use Centra\Api\Middleware\CheckId;

class RoutesConfig implements RouterRulesInterface
{
  public $rules = [];

  public function __construct()
  {
    $rules[] = Rule::get('v1/clients', GetAllClients::class);
    $rules[] = Rule::get('v1/clients/{id}', GetClientById::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/clients/search', GetClientsByParams::class);
    $rules[] = Rule::post('v1/clients', AddClient::class);
    $rules[] = Rule::patch('v1/clients/{id}', UpdateClient::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::delete('v1/clients/{id}', DeleteClient::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/templates', GetAllTemplates::class);
    $rules[] = Rule::get('v1/templates/{id}', GetTemplateById::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/templates/search', GetTemplatesByParams::class);
    $rules[] = Rule::post('v1/templates', AddTemplate::class);
    $rules[] = Rule::patch('v1/templates/{id}', UpdateTemplate::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::delete('v1/templates/{id}', DeleteTemplate::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/templates/{id}/lan', GetTemplateLan::class);
    $rules[] = Rule::post('v1/templates/{id}/lan', UpdateTemplateLan::class);
    $rules[] = Rule::patch('v1/templates/{id}/lan', UpdateTemplateLan::class);
    $rules[] = Rule::delete('v1/templates/{id}/lan', DeleteTemplateLan::class);
    $rules[] = Rule::get('v1/templates/{id}/wifi', GetTemplateWifi::class);
    $rules[] = Rule::post('v1/templates/{id}/wifi', UpdateTemplateWifi::class);
    $rules[] = Rule::patch('v1/templates/{id}/wifi', UpdateTemplateWifi::class);
    $rules[] = Rule::delete('v1/templates/{id}/wifi', DeleteTemplateWifi::class);
    $rules[] = Rule::get('v1/templates/{id}/static-ip', GetTemplateStaticIp::class);
    $rules[] = Rule::post('v1/templates/{id}/static-ip', UpdateTemplateStaticIp::class);
    $rules[] = Rule::patch('v1/templates/{id}/static-ip', UpdateTemplateStaticIp::class);
    $rules[] = Rule::delete('v1/templates/{id}/static-ip', DeleteTemplateStaticIp::class);
    $rules[] = Rule::get('v1/templates/{id}/dynamic-ip', GetTemplateDynamicIp::class);
    $rules[] = Rule::post('v1/templates/{id}/dynamic-ip', UpdateTemplateDynamicIp::class);
    $rules[] = Rule::patch('v1/templates/{id}/dynamic-ip', UpdateTemplateDynamicIp::class);
    $rules[] = Rule::delete('v1/templates/{id}/dynamic-ip', DeleteTemplateDynamicIp::class);
    $rules[] = Rule::get('v1/unregistered-devices', GetAllUnregisteredDevices::class);
    $this->setRules($rules);
    $rules[] = Rule::get('v1/unregistered-devices/{id}', GetUnregisteredDeviceById::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/unregistered-devices/search', GetUnregisteredDevicesByParams::class);
    $rules[] = Rule::post('v1/unregistered-devices', AddUnregisteredDevice::class);
    $rules[] = Rule::patch('v1/unregistered-devices/{id}', UpdateUnregisteredDevice::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::delete('v1/unregistered-devices/{id}', DeleteUnregisteredDevice::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/devices', GetAllDevices::class);
    $this->setRules($rules);
    $rules[] = Rule::get('v1/devices/{id}', GetDeviceById::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/devices/search', GetDevicesByParams::class);
    $rules[] = Rule::post('v1/devices', AddDevice::class);
    $rules[] = Rule::patch('v1/devices/{id}', UpdateDevice::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::delete('v1/devices/{id}', DeleteDevice::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::post('v1/devices/{id}/refresh-config', RefreshTemplateDevice::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::post('v1/devices/{id}/reboot', RebootDevice::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::post('v1/devices/{id}/info', InfoDevice::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/devices/{id}/info/base', BaseDeviceInfo::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/devices/{id}/info/hosts', HostsDeviceInfo::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/devices/{id}/info/wan', WanDeviceInfo::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/devices/{id}/info/lan', LanDeviceInfo::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/devices/{id}/info/wifi', WifiDeviceInfo::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/tasks/search', TasksByParams::class);
    $rules[] = Rule::get('v1/devices/{id}/tasks', TasksByDeviceId::class)->middleware([
      CheckId::class
    ]);
    $rules[] = Rule::get('v1/models', GetAllModels::class);
    $this->setRules($rules);
    $rules[] = Rule::get('v1/models/{id}', GetModelById::class)->middleware([
      CheckId::class
    ]);
    $this->setRules($rules);
  }

  public function getBeforeMiddleware()
  {
    return [
      IpAuth::class,
      RateLimit::class,
      LogRequest::class,
    ];
  }

  public function getAfterMiddleware()
  {
    return [
      FormatResponse::class,
      LogResponse::class,
    ];
  }

  /**
   * @return array
   */
  public function getRules()
  {
    return $this->rules;
  }

  /**
   * @param array $rules
   * @return $this
   */
  public function setRules(array $rules)
  {
    $this->rules = $rules;
    return $this;
  }

}