<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 15:28
 */

namespace Centra\Configs;

use Centra\Acs\Main\AcsWorker;
use Centra\Api\Models\ApiConfig;

class AcsWorkerConfig extends ApiConfig
{
  public $url = 'http://127.0.0.1:30001';
  public $retries = 0;
  public $timeout = 0;

  /**
   * AcsWorkerConfig constructor.
   * @param null $params
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function __construct($params = null)
  {
    parent::__construct($params);
    $worker = \store(AcsWorker::class, $this);
    $worker->setThrowException(AcsWorker::THROW_EXCEPTION_NO);
//    $worker->setReturnData(AcsWorker::RETURN_DATA_NO);
  }
}