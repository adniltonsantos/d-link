<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 16.10.18
 * Time: 15:36
 */

namespace Centra\Configs;

class ApplicationConfig
{
  public $basePath = "/var/ACS/api/";
  public $paramsPath = "/var/ACS/tmp/";
  public $configPath = "/var/ACS/tarif/";

  /**
   * @return string
   */
  public function getBasePath()
  {
    return $this->basePath;
  }

  /**
   * @param string $basePath
   * @return $this
   */
  public function setBasePath($basePath)
  {
    $this->basePath = $basePath;
    return $this;
  }

  /**
   * @return string
   */
  public function getParamsPath()
  {
    return $this->paramsPath;
  }

  /**
   * @param string $paramsPath
   * @return $this
   */
  public function setParamsPath($paramsPath)
  {
    $this->paramsPath = $paramsPath;
    return $this;
  }

  /**
   * @return string
   */
  public function getConfigPath()
  {
    return $this->configPath;
  }

  /**
   * @param string $configPath
   * @return $this
   */
  public function setConfigPath($configPath)
  {
    $this->configPath = $configPath;
    return $this;
  }

}