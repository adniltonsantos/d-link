<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 14.10.18
 * Time: 14:26
 */

namespace Centra\Configs;

use Centra\Http\Main\Response as ResponseItem;

class ResponseConfig
{
  /**
   * ResponseConfig constructor.
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function __construct()
  {
    /** @var ResponseItem $response */
    $response = \store(ResponseItem::class);
    $response->setHeaders([
      ResponseItem::CONTENT_TYPE_JSON,
      ResponseItem::ACCESS_CONTROL_ALLOW_ORIGIN,
    ]);
  }
}