
var arrayParamName=[],paramValue=[],paramType=[];
var PPP_Type="";
$(document).ready(function () {

    $basepath = $('#basepath').data('bpath');
    var devId = $("input[name='devID']").val();
    var serialN = $("input[name='serialN']").val();
    $("#edit-value").attr('readonly', 'readonly');
    $('#btn-Save').prop('disabled', true);

    var selectors = {
        'tree': '#tree1',
        'input': '#input-search',
        'reset': '#btn-clear-search'
    };




    var lastPattern = ''; // closure variable to prevent redundant operation
    var clickedNodeID = -1;
    var mydata = '';
    //$('#tree1').treeview({ data: getTree("../assets/xml/names.xml") });
    $('#tree1').treeview({ data: getTree("../tmp/"+serialN+"_name.xml") });
    var $scrollingDiv = $("#editField");

    $("#getAllParams").on("click" , function () {
        var th=$(this);
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'actionName': "getAllParams",
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    th.attr("disabled", "disabled");
                    th.css("opacity", "0.5");
                    th.css("cursor", "default");
                    var success = getMssg['action_succeed'];
                    $("#actionRes").empty();
                    $("#actionRes").html(success);

                    setTimeout(function () {
                        updateActivities(devId);
                        $("body").css("cursor", "default");
                        $("#actionRes").empty();
                    }, 2000);
                    interval = setInterval(function(){
                        getTaskStatusOfTheDevice("'getAllParams'",devId); //if get all params task is completed "TR Tree" page reloaded..
                    },1000);

                } else if (result == 'false'){
                    $("body").css("cursor","default");
                    location.reload(true);

                    var failed = getMssg['connect_failed'];
                    $("#actionRes").empty();
                    $("#actionRes").html(failed);
                } else if (result = 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });

    });

    $("#btn-Save").on("click" , function () {
        var clickedNode = $('#tree1').treeview('getSelected');
        var editValue = $('#edit-value').val();
        var realValue = clickedNode[0].text.split(": ")[1];
        clickedNodeID = clickedNode[0].nodeId;
        var editName = window.mydata[clickedNodeID].baseNode;
        var editType = window.mydata[clickedNodeID].vType;
        var th = $(this);

        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];


        if(editValue != realValue && typeof realValue != 'undefined'){
            paramNames.push(editName);
            alert(editName);
            paramValues.push(editValue);  //push parameter edit value
            paramTypes.push(editType);
            alert(paramNames[0]);
            alert(paramValues[0]);
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devId,
                    'serialN': serialN,
                    'changedParamNames': paramNames,
                    'changedParamValues': paramValues,
                    'changedParamTypes': paramTypes,
                    'actionName': "setTrTree",
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        th.attr("disabled", "disabled");
                        th.css("opacity", "0.5");
                        th.css("cursor", "default");
                        var success = getMssg['action_succeed'];
                        $("#actionRes").empty();
                        $("#actionRes").html(success);

                        setTimeout(function () {
                            updateActivities(devId);
                            $("body").css("cursor", "default");
                            $("#actionRes").empty();

                        }, 2000);
                        setTimeout(function () {
                            location.reload(true);
                        }, 5000);
                    } else if (result == 'false') {
                        $("body").css("cursor","default");
                        location.reload(true);
                    } else if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if(result='cannotSend'){
                        location.reload(true);
                    }
                    //location.reload(true);

                }
            });

        }else{
            alert('Value not changed');
        }


    });


    $('#tree1').on('nodeSelected', function (event, data) {

        var clickedNode = $('#tree1').treeview('getSelected');
        clickedNodeID = clickedNode[0].nodeId;
        //alert(clickedNodeID);
        if (clickedNode[0].hasOwnProperty("writable")) {
            if (clickedNode[0].writable === "0") {
                $("#edit-value").attr('readonly', 'readonly');
                $('#btn-Save').prop('disabled', true);
            } else if (clickedNode[0].writable === "1") {
                //if pressing editable node then under node has writable node Edite field
                if(clickedNode[0].text.split(":")[0] == 'Writable' && $("#edit-value").attr('readonly') != "undefined"){
                    //if($("#edit-value").attr('readonly') != "undefined"){
                        $("#edit-value").addAttribute('readonly', 'readonly');
                        $('#btn-Save').prop('disabled', true);
                    //}

                }
                $("#edit-value").removeAttr('readonly');
                $('#btn-Save').prop('disabled', false);
            }
            $("#edit-value").val(clickedNode[0].text.split(": ")[1]);
        }
        else{
            $("#edit-value").val('');
        }

    });
    /*$('#tree1 li').each(function(i){
    	alert($(this).val());
    });*/

    $(window).scroll(function (ev) { //edit dasht@ scrolli het ijecnum e nerqev

        if( $(window).scrollTop()<$('#tree1').outerHeight()-500)
            $scrollingDiv.stop().animate({ "marginTop": ($(window).scrollTop() ) + "px" }, "slow");
    });

    $("#tree1").contextmenu(function (e) {
        console.log(e);
    });

    /* collapse and enable all before search */
    function reset(tree) {
        tree.collapseAll();
        tree.enableAll();
    }

    /* find all nodes that are not related to search and should be disabled:
     * This excludes found nodes, their children and their parents.
     * Call this after collapsing all nodes and letting search() reveal.
     */
    function collectUnrelated(nodes) {
        var unrelated = [];
        $.each(nodes, function (i, n) {
            if (!n.searchResult && !n.state.expanded) { // no hit, no parent
                unrelated.push(n.nodeId);
            }
            if (!n.searchResult && n.nodes) { // recurse for non-result children
                $.merge(unrelated, collectUnrelated(n.nodes));
            }
        });
        return unrelated;
    }

    /* search callback */
    var search = function (e) {

        var pattern = $(selectors.input).val();
        console.log(pattern);
        if (pattern === lastPattern) {
            return;
        }
        lastPattern = pattern;
        var tree = $(selectors.tree).treeview(true);
        reset(tree);
        if (pattern.length < 3) { // avoid heavy operation
            tree.clearSearch();
        } else {
            tree.search(pattern);
            /* get all root nodes: node 0 who is assumed to be
             a root node, and all siblings of node 0. */
            var roots = tree.getSiblings(0);
            roots.push(tree.getNode(0));
            /* first collect all nodes to disable, then call disable once.
             Calling disable on each of them directly is extremely slow! */
            var unrelated = collectUnrelated(roots);
            tree.disableNode(unrelated, { silent: true });
        }
    };

    /* typing in search field */
    $(selectors.input).on('keyup', search);

    /* clear button */
    $(selectors.reset).on('click', function (e) {
        $(selectors.input).val('');
        var tree = $(selectors.tree).treeview(true);
        reset(tree);
        tree.clearSearch();
    });

});
$("#tree").on("click" , function () {
        // Your logic goes here
    $('#tree1').treeview({ data: getTree("../tmp/"+serialN+"_name.xml") });
});
$("#btn_add_ppp").on("click" , function (e) {

    e.preventDefault();
    var type="pppoe";
    paramValue=[];
    if(PPP_Type=="PPTP_Relay"){
        type=="pptp";
    }
    else if(PPP_Type=="L2TP_Relay"){
        type=="l2tp";
    }
    var devId = $("input[name='devID']").val();
    var name=$("#myModal").find('input').each(function() {
        var val = $(this).val();
        if (val == "") {
            val = $(this).attr('placeHolder');
        }
        //alert(val);
        if (val[0] == ' ') {
            val=val.substring(1, val.length);
            //alert(val);
        }
        paramValue.push(val);
    });
    $('#myModal').modal('toggle');
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
        data: {
            'deviceID': devId,
            'actionName': "connection",
            'fromApp': true
        },
        async: true,
        success: function (result) {
            if (result == 'true') {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'index': '%d',
                        'connectIndex': '1',
                        'defConnection': 'false',
                        'changedParamNames': arrayParamName,
                        'changedParamValues': paramValue,
                        'changedParamTypes': paramType,
                        'interface_type': '-1',
                        'actionName': "addPPPWan",
                        'type': type,
                        'fromApp': true
                    },
                    async: false,
                    success: function (resultPPP) {
                        alert(resultPPP);
                        if(resultPPP=='true') {
                            arrayParamName = [];
                            paramValue = [];
                            paramType = [];
                            $('#myModal').model("toggle");
                        }
                        else if (resultPPP == 'false') {
                            setTimeout(function () {
                                updateAfterTheAction();
                            }, 10000);
                        } else if (resultPPP = 'logged_out') {
                            document.location.href = $basepath + 'login';
                        }

                    },
                    error: function (xhr, status, error) {
                    }
                });
            }
            else if (result == 'false') {
                setTimeout(function () {
                    updateAfterTheAction();
                }, 10000);
            } else if (result = 'logged_out') {
                document.location.href = $basepath + 'login';
            }
        }
    });
});
function createPPPCon(thielement){
    var myobj=$(thielement).parent();
    var chechID=parseInt(myobj.attr("data-nodeid"))+1;
    var lastID=0;
    for(var i=0;i<mydata.length;i++){
        var treeNode=$('#tree1').treeview("getNode",i);
        if(treeNode.parentId==chechID) {
            if(lastID==0){
                lastID=treeNode.nodeId;
            }
            var findID=treeNode.nodeId;
            if(findID-lastID==3) {
                findID = treeNode.nodeId;
                var isWite = mydata[findID + 2].Name.replace("Writable:", "");
                if (parseInt(isWite) == 1) {
                    var value = mydata[findID + 1].Name.replace("Value:", "");
                    console.log(mydata[findID].Name + ":" + value + ":" + isWite);
                    arrayParamName.push(mydata[findID].Name);
                    paramType.push(mydata[findID+1].vType);
                    //console.log(mydata[findID].Name);
                    paramValue.push(value);
                    if (mydata[findID].Name == "ConnectionType") {
                        PPP_Type = value;
                        alert(PPP_Type);
                    }
                    $("#myModal div.modal-body").append("<div class='form-group'><label for='"+mydata[findID].Name+"'>"+mydata[findID].Name+"</label>" +
                        "<input type='text' class='form-control' id='name-txt' aria-describedby='"+mydata[findID].Name+"' placeholder='"+value+"'>"+
                        "<small class='form-text text-muted'>please insert</small></div>");
                }
                /*else{
                    $("#myModal form").prepend("<div class='form-group'>" +
                        "<span>"+mydata[findID].Name+":"+"value"+"</span></div>");
                }*/
            }
            lastID=findID;
        }
    }
    var devId = $("input[name='devID']").val();
    //var name=thielement.parentElement.getAttribute('data-nodeid');
    //var expends=$("#tree1").treeview('getExpanded',name);
    //alert(expends.expandIcon);
    $('#myModal').modal('show');
    var th=$(this);
    //var r = confirm("Do you want to create new PPP connection?");

}

function xmlParser(xml) {
    var tree = [];
    var soapXML = null;
    var serialN = $("input[name='serialN']").val();

    // get soap xml
    $.ajax({
        type: "GET",
        url: "../tmp/"+serialN+"_value.xml",
        dataType: "xml",
        success: function (data) {//success: xmlParser
            soapXML = data;
        },
        async: false
    });

    // get attributes
    var attributesXML = null;
    var attributeList = new Array();
    //$.ajax({
    //    type: "GET",
    //    url: "../assets/xml/attributes.xml",
    //    dataType: "xml",
    //    success: function (data) {//success: xmlParser
    //
    //        attributesXML = data;
    //    },
    //    async: false
    //});
    // get Writable parameter from names.xml
    $(attributesXML).find("ParameterAttributeStruct").each(function () {
        item = {
            name: $(this).find("Name").text(),
            notification: $(this).find("Notification").text(),
            accessList: $(this).find("AccessList").children().contents().toArray()
        };
        attributeList.push(item);

    });


    var writableList = new Array();
    var item = null;

    // get Writable parameter from names.xml
    $(xml).find("ParameterInfoStruct").each(function () {

        item = {
            name: $(this).find("Name").text(),
            writable: $(this).find("Writable").text()
        };
        writableList.push(item);
        //console.log(item);//tpum e writable e te voch
    });

    var mytree = '';
    mydata = [{ text: 1, Name: name, baseNode: "InternetGatewayDevice", currInd: 0, nodeType: "node", vType: 'none',badge: "42", Parent: 0 }];
    var i = 0, k = 1;

    var prevName = [];

    $(soapXML).find("ParameterValueStruct").each(function () {
        var name = $(this).find("Name").text();
        var isFullName = name.substr(name.length - 1) != '.' ? true : false;
        if (!isFullName)
            return true; // continue

        var writable = function () {
            //$(this).find("Writable").text() === "0" ? 0 : 1;
            let ret = $.grep(writableList, function (n) { return n.name === name; });
            if (ret.length < 1) return [];
            else return ret[0].writable;
        }(writable); //$(this).find("Writable").text() == "0" ? 0 : 1;

        var attrib = function () {
            let ret = $.grep(attributeList, function (n) { return n.name === name; });

            if (ret.length < 1) return [];
            else return ret[0];
        }(attrib);


        var value = $(this).find("Value").text();
        //$(this).find("Value").attr('contentEditable','true');
        var valueType =$(this).find("Value").attr('xsi:type').split(":")[1];
        var splitName = name.split(".").slice(1);
        var notInSecond = splitName.slice(0);
        var tmp = 0;
        for (var i = 0, j; i < prevName.length; i++) {
            j = notInSecond.indexOf(prevName[i]);
            if (j > -1) {
                notInSecond.splice(j, 1);
            }
            else break;
        }

        let tmpInd = splitName.lastIndexOf(notInSecond[0]) - 1;
        tmp = splitName[tmpInd];

        let curINDEX = splitName.lastIndexOf(notInSecond[0]);
        var found = '';

        for (var k = mydata.length - 1; k >= 0  ; k--) {
            if (tmp == mydata[k].Name && mydata[k].nodeType === "node" && mydata[k].baseNode.includes(tmp) && mydata[k].currInd === curINDEX) {
                found = mydata[k]; break;
            }
        }

        var par = -1;
        for (i = 0; i < notInSecond.length; i++) {
            let curINDEX = splitName.length - notInSecond.length + i + 1;
            if (found == '') {
                if (i == 0)
                    par = 1;
                else {
                    par = mydata[mydata.length - 1].text;
                    //console.log("par = " + par);
                }
            }

            else {
                par = found.text;
                found = '';
            }

            mydata.push({
                text: mydata.length + 1,
                Name: notInSecond[i] ,
                baseNode: name,
                currInd: curINDEX,
                nodeType: "node",
                color: "#008DA9",
                badge: "45",
                Parent: par
            });
            if(mydata[mydata.length - 1 ].Name == "WANPPPConnection" ) {//    ConfigFile
                mydata.pop();
                mydata.push({
                    text: mydata.length + 1,
                    Name: notInSecond[i] + "<button class='btn btn-primary' style='margin-left:40px' onclick='createPPPCon(this)' > + </button>",
                    baseNode: name,
                    currInd: curINDEX,
                    nodeType: "node",
                    color: "#008DA9",
                    badge: "45",
                    Parent: par
                });
            }

            //}

        }
        //
        let lastValNodeInd = mydata[mydata.length - 1].text;
        if (value != null) { // push value
            //alert(value);
            mydata.push({
                text: mydata.length + 1,
                Name: "Value: " + value,
                baseNode: name,
                nodeType: "value",
                vType: valueType,
                writable: writable,
                //color: "blue",
                Parent: lastValNodeInd
            });
        }
        /////////////////// // push writable   ///////////////
        if (writable != null && writable != "") {
            mydata.push({
                text: mydata.length + 1,
                Name: "Writable: " + writable,
                baseNode: name,
                nodeType: "writable",
                writable: writable,
                color: "FFFFFF",
                Parent: lastValNodeInd
            });
        }
        prevName = splitName;
    });
    mytree = function (data, root) {    // convert from flat array to tree
        var r;
        data.forEach(function (a) {

            this[a.text] = {
                text: a.text,
                text: a.Name,
                color: a.color,
                tags: a.tags,
                badge: a.badge,
                nodeType: a.nodeType,
                vType: a.vType,
                writable: a.writable,
                nodes: this[a.text] && this[a.text].nodes
            };
            if (a.Parent === root) {
                r = this[a.text];
            }
            else {
                this[a.Parent] = this[a.Parent] || {};
                this[a.Parent].nodes = this[a.Parent].nodes || [];
                this[a.Parent].nodes.push(this[a.text]);
            }
        }, Object.create(null));
        return r;
    }(mydata, 0);
    tree.push({

        text: 'InternetGatewayDevice',
        badge: '42',
        nodes: mytree.nodes,

        backColor: "#FFFFFF",
        href: "#",
        state: {
            expanded: true,
            showTags: true,
        },
        selectable: true
    });
    return tree;

}

function getTree(fileName) {
    var tree = [];
    $.ajax({
        type: "GET",
        url: fileName,
        dataType: "xml",
        success: function (data) {//success: xmlParser
            tree = xmlParser(data);
        },
        async: false
    });


    return tree;
}


function updateActivities(deviceID){
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/eachDevActivity.php",
        data: {
            'deviceID': deviceID,
            'fromApp':true
        },
        async: true,
        success: function (result) {
            if (result =='logged_out') {
                document.location.href = $basepath + 'login';
            } else {
                $("#forDActiv").empty();
                $("#forDActiv").html(result);
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}


function getTaskStatusOfTheDevice(taskName,deviceId){
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
        data: {
            'taskName':taskName,
            'deviceID': deviceId,
            'fromApp':true
        },
        async: true,
        success: function (result) {
            var disabled = false;
            if (result =='logged_out') {
                document.location.href = $basepath + 'login';
            }else if(result == 0 || result == 1){
                disabled = true;
            }else {
                disabled = false;
            }

            if(disabled){
                $('#getAllParams').attr('disabled','disabled');
            }else { // if not disabled "TR Tree" page  will reloaded.
                $('#getAllParams').removeAttr("disabled");
                location.reload(true);
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}
function updateAfterTheAction() {
//        var countForm = $("#infoId").length;
//        if (countForm > 0) {
//            $("#infoId").submit();
//        } else {
//            var devidd = devId;
//            var newForm = '<form action="'+ $basepath +'devInfo/" id="infoId"  method="post" ><input type="hidden" name="devId" value="' + devidd + '" /></form>';
//            $(".devices_bl").append(newForm);
//            $("#infoId").submit();
//        }
    location.reload(true);

}