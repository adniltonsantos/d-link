$basepath = $('#basepath').data('bpath');
function getDashboard(divNAme, arrOfDeviceModel, color) {
    if (color != '') {
        Highcharts.setOptions({
            colors: color
        });
    }
     Highcharts.chart(divNAme, {
        chart: {
            type: "pie",
            options3d: {
                enabled: true,
                // alpha: 45,
                beta: 0
            },
            backgroundColor: 'none'

        },
        title: {
            text: ''
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.point.name + '</b>: ' + Highcharts.numberFormat(this.percentage, 2) + ' %';
            }
        },
        plotOptions: {

            pie: {
                innerSize: 100,
                depth: 45,
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    style: {
                        fontSize: '9px'
                    },
                    enabled: true,
                    padding: 0,
                    connectorPadding: 0,
                    // format: '<b>{point.name}</b> : {point.y} pcs</br>',
                    format: '<b>{point.name}</b> : {point.y} pcs</br> <b style="font-style: normal">({point.percentage:.2f} %)</b>',
                }
            }
        },
        series: [{
            type: 'pie',
            name: ' ',
            showInLegend: "true",
            legendText: "{label}",
            innerSize: '50%',
            startAngle: 90,
            data: arrOfDeviceModel,
        }],
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'top',
            y: 60,
            navigation: {
                enabled: true
            },
            adjustChartSize: true,
        },
        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        }
    });
}

function searchHeartbeatByIp(inputValue) {
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/filteredHeartbeat.php",
        data: {
            'searchType': 'ip',
            'searchVal': inputValue,
            'fromApp': true
        },
        async: false,
        success: function (result) {
            if (result == 'logged_out') {
                document.location.href = $basepath + 'login';
            } else {
                $("#ajaxcontainerForHear").empty();
                $("#ajaxcontainerForHear").html(result);
                $("body").css("cursor", "default");
            }
        },
        error: function (xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}

function searchHeartbeatByModel(inputValue) {
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/filteredHeartbeat.php",
        data: {
            'searchType': 'model',
            'searchVal': inputValue,
            'fromApp': true
        },
        async: false,
        success: function (result) {
            if (result == 'logged_out') {
                document.location.href = $basepath + 'login';
            } else {
                $("#ajaxcontainerForHear").empty();
                $("#ajaxcontainerForHear").html(result);
                $("body").css("cursor", "default");
            }
        },
        error: function (xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}

function searchHeartbeatByGroup(inputValue) {
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/filteredHeartbeat.php",
        data: {
            'searchType': 'group',
            'searchVal': inputValue,
            'fromApp': true
        },
        async: false,
        success: function (result) {
            if (result == 'logged_out') {
                document.location.href = $basepath + 'login';
            } else {
                $("#ajaxcontainerForHear").empty();
                $("#ajaxcontainerForHear").html(result);
                $("body").css("cursor", "default");
            }
        },
        error: function (xhr, status, error) {
            alert(error);
            //document.location.href = $basepath + '500';
        }
    });
}

function searchHeartbeatByClientInfo(inputValue) {
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/filteredHeartbeat.php",
        data: {
            'searchType': 'clients',
            'searchVal': inputValue,
            'fromApp': true
        },
        async: false,
        success: function (result) {
            if (result == 'logged_out') {
                document.location.href = $basepath + 'login';
            } else {
                $("#ajaxcontainerForHear").empty();
                $("#ajaxcontainerForHear").html(result);
                $("body").css("cursor", "default");
            }
        },
        error: function (xhr, status, error) {
            alert(error);
            //document.location.href = $basepath + '500';
        }
    });
}

$(document).ready(function () {
//   global variable


    $(document).on('click', '.update_dashboard', function () {
        getAllModelChart();
    });

    $(document).on('click', '#selectAllModelDashboard', function () {
        ShowAllModelsChart();
    });

    $(document).on('click', '#hideAllModelDashboard', function () {
        HideAllModelsChart();
    });

    function ShowAllModelsChart() {
        var chart = $('#containerForModel').highcharts();
        var legend = chart.legend;
        $.each(chart.series[0].points, function() {
            this.setVisible(true, false);
        });
        chart.redraw();
    }

    function HideAllModelsChart() {
        var chart = $('#containerForModel').highcharts();
        var legend = chart.legend;
        $.each(chart.series[0].points, function() {
            this.setVisible(false, false);
        });
        chart.redraw();
    }

    function getAllModelChart() {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getDashboard.php",
            data: {
                'actionName': "getModelChart",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var color = [];
                    var result = JSON.parse(data);
                    $("#containerForModel").html("");

                    for (var i = 0; i < result.length; i++) {
                        color.push("#" + (17 * (i + 6 * i + 5) * (i * i) + "abcde").slice(0, 6));
                    }
                    getDashboard("containerForModel", result, color);
                    $("input[name='dashboardModel']").val("");
                    $(".noDeviceByModel").hide();
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on('click', '.update_unknown_devices', function () {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getDashboard.php",
            data: {
                'actionName': "getUnknownPendingChart",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var result = JSON.parse(data);
                    var color = ["#FFA500", "#3DAD6A"];
                    var realresult = [];
                    var realcolor = [];
                    $("#containerForUnknownPendingDev").html("");
                    for (var i = 0; i < result.length; i++) {
                        if (result[i][1] != 0) {
                            realresult.push(result[i]);
                            realcolor.push(color[i]);
                        }
                    }
                    if (realresult.length > 0) {
                        getDashboard("containerForUnknownPendingDev", realresult, realcolor);
                    } else {
                        var h4="<div class='noDataFound'><h4>"+getMssg['no_device_dashboard'] +"</h4></div>";

                        $("#containerForUnknownPendingDev").html(h4);
                        $("#containerForUnknownPendingDev").show();

                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on('click', '.update_heartbeat', function () {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getDashboard.php",
            data: {
                'actionName': "getHeartbeatChart",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var color = ["#3DAD6A", "#FFA500", "#AD3D40"];
                    var result = JSON.parse(data);
                    var realresult = [];
                    var realcolor = [];
                    $("#containerForHeartbeat").html("");
                    for (var i = 0; i < result.length; i++) {
                        if (result[i][1] != 0) {
                            realresult.push(result[i]);
                            realcolor.push(color[i]);
                        }
                    }
                    getDashboard("containerForHeartbeat", realresult, realcolor);
                    $("input[name='searchHeartbeat']").val("");
                    $(".searchHeartbeatType option[value='clients']").attr('selected', 'selected');
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on('change', '.searchHeartbeatType', function () {
        $searchedval = $('.searchHeartbeatType option:selected').val();

//      $('.search_actionbtn').html($searchedvalrus + '<i class="fa fa-angle-down angledown"></i>');;
        if ($searchedval == 'clients') {
            $('.linkForSearchDev').attr('id', 'searchHeartbeatDeviByClient');
        } else if ($searchedval == 'ip') {
            $('.linkForSearchDev').attr('id', 'searchHeartbeatDeviByIp');
        } else if ($searchedval == 'model') {
            $(".linkForSearchDev").attr("id", "searchHeartbeatDeviByModel");

        } else if ($searchedval == 'group') {
            $('.linkForSearchDev').attr('id', 'searchHeartbeatDeviByGroup');

        }
    });
    $(document).on('click', '#searchHeartbeatDeviByIp', function () {
        var devInfoVal = $(this).parent().find("input[name='searchHeartbeat']").val().trim();
        searchHeartbeatByIp(devInfoVal);
    });
    $(document).on('click', '#searchHeartbeatDeviByModel', function () {
        var devInfoVal = $(this).parent().find("input[name='searchHeartbeat']").val().trim();
        searchHeartbeatByModel(devInfoVal);
    });

    $(document).on('click', '#searchHeartbeatDeviByGroup', function () {
        var devInfoVal = $(this).parent().find("input[name='searchHeartbeat']").val().trim();
        searchHeartbeatByGroup(devInfoVal);
    });
    $(document).on('click', '#searchHeartbeatDeviByClient', function () {
        var devInfoVal = $(this).parent().find("input[name='searchHeartbeat']").val().trim();
        searchHeartbeatByClientInfo(devInfoVal);
    });
})