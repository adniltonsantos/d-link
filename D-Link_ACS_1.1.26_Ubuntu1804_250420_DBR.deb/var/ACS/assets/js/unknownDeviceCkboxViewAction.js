//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg = result;
//            }
//        }
//    });
//    return retMsg;
//}

$(document).ready(function () {
    var token_cookie = $("input[name='token_cookie']").val();
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
    
    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional 
    });

    $('#unknown').find('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
                
            $('#unknown').find('.fieids').iCheck('check');
            $('#forUnknownsList').find('.trash-select').css('display', 'block');
        } else {

            $('#unknown').find('.fieids').iCheck('uncheck');
            $('#forUnknownsList').find('.trash-select').css('display', 'none');
        }
    });
    
    $('#pending').find('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
                
            $('#pending').find('.fieids').iCheck('check');
            $('#forPendingList').find('.trash-select').css('display', 'block');
            $('#forPendingList').find('.resend-selected').css('opacity', '1!important');
        } else {

            $('#pending').find('.fieids').iCheck('uncheck');
            $('#forPendingList').find('.trash-select').css('display', 'none');
            $('#forPendingList').find('.resend-selected').css('opacity', '0.6!important');
        }
    });

    $checked_arrayUnknown = new Array();
    $countOfUncheckedsUnknown = $('#unknown .forFieldsCheck').find('.fieids').length;
    $('#unknown').find('.fieids').on('ifChecked ifUnchecked', function(event){
     
        $deviceID = $(this).closest('tr').find("input[name='unknownID']").val();
        if (event.type == 'ifChecked') {
                
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('#forUnknownsList').find('.trash-select').css('display', 'block');
            
            if(!$(this).hasClass('allFields')){
                $checked_arrayUnknown.push($deviceID);
            }
            
            if($('#unknown .forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckedsUnknown){
               $('#unknown').find('#all_fields').prop('checked',true).iCheck('update');
            }
        } else {
            
            if($('#unknown').find('#all_fields').is(':checked')){
                $('#unknown').find('#all_fields').prop('checked',false).iCheck('update');
            }
            
            if(!$('#unknown').find('.forFieldsCheck').find('.fieids').is(':checked')){
               
                $('#forUnknownsList').find('.trash-select').css('display', 'none');
                $('#unknown').find('#all_fields').iCheck('uncheck');
                $checked_arrayUnknown.length = 0;
            }
            $checked_arrayUnknown.removeByVal($deviceID);
            $(this).closest('tr').css("background-color", "#FFFFFF");
        }
    });

    $checked_arrayPending = new Array();
    $countOfUncheckedsPending = $('#pending .forFieldsCheck').find("input:checkbox:not(:checked)").length;

    $('#pending').find('.fieids').on('ifChecked ifUnchecked', function(event){
     
        $deviceID = $(this).closest('tr').find("input[name='unknownID']").val();
        if (event.type == 'ifChecked') {
                
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('#forPendingList').find('.trash-select').css('display', 'block');
            $('#forPendingList').find('.resend-selected').css("opacity", "1");
            $('#forPendingList').find('.resend-selected').css("cursor", "pointer");
            $('#forPendingList').find('.resend-selected').removeAttr("disabled");
            
            if(!$(this).hasClass('allFields')){
                $checked_arrayPending.push($deviceID);
            }
            
            if($('#pending .forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckedsPending){
               $('#pending').find('#all_fields').prop('checked',true).iCheck('update');
            }
        } else {
            
            if($('#pending').find('#all_fields').is(':checked')){
                $('#pending').find('#all_fields').prop('checked',false).iCheck('update');
            }
            
            if(!$('#pending').find('.forFieldsCheck').find('.fieids').is(':checked')){
               
                $('#forPendingList').find('.trash-select').css('display', 'none');
                $('#forPendingList').find('.resend-selected').css("opacity", "0.5");
                $('#forPendingList').find('.resend-selected').css("cursor", "default");
                $('#forPendingList').find('.resend-selected').attr("disabled", "disabled");
                $('#pending').find('#all_fields').iCheck('uncheck');
                $checked_arrayPending.length = 0;
            }
            $checked_arrayPending.removeByVal($deviceID);
            $(this).closest('tr').css("background-color", "#FFFFFF");
        }
    });

    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    var titleMsg = getMssg['title_msg'];
    var msg = getMssg['remove_device_msg'];
    var rmMsg =  getMssg['remove_msg'];
    var cancelMsg = getMssg['cancel'];

    $('#forUnknownsSearchResult').on("click", ".trash20", function (){
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            removeDevices($checked_arrayUnknown);
        });
    });

    
    $('#forPendingsSearchResult').on("click", ".trash20", function (){
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            removeDevices($checked_arrayPending);
        });
    });

    
    function removeDevices(e){

        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'devId': e,
                'actionName': "removeUnknownDevice",
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['connect_succeed'];
                    $("#errConnectForUnknowns").removeClass("errorMessage");
                    $("#errConnectForUnknowns").addClass("infoMessage");
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 10000);
                } else if (result == 'false') {
                    var failed = getMssg['action_failed'];
                    $("#errConnectForUnknowns").removeClass("infoMessage");
                    $("#errConnectForUnknowns").addClass("errorMessage");
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(failed);
                    $("body").css("cursor", "default");
                    setTimeout(function () {
                        location.reload(true);
                    },10000)
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(".searchClientsForAdd").on("click", "#connectClient1", function () {
        var th = $(this);
        var groupID = $("#connGroupSelect option:selected").val();
        $("body").css("cursor", "wait");
        if ($("input[name='clientID']:checked").length == 0) {
            var select_client = getMssg['select_client'];
            $("#errConnectForUnknowns").removeClass("infoMessage");
            $("#errConnectForUnknowns").addClass("errorMessage");
            $("#errConnectForUnknowns").empty();
            $("#errConnectForUnknowns").html(select_client);
            $("body").css("cursor", "default");
        } else {
            var clientID = $("input[name='clientID']:checked").val();
            var useTarif = $("input[name='useTarif1']").is(":checked");
            var tarifId = 0;
            // alert();
            if (useTarif) {
                tarifId = $("#templateChoose option:selected").val();
                if (tarifId == 0) {
                    alert(tarifId);
                    var select_client = getMssg['not_select_template'];
                    $("#errConnectForUnknowns").removeClass("infoMessage");
                    $("#errConnectForUnknowns").addClass("errorMessage");
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(select_client);
                    $("body").css("cursor", "default");
                } else {
                    connectToUnknown(clientID, groupID, tarifId);
                }
            } else {
                connectToUnknown(clientID, groupID, tarifId);
            }
        }
    });

    function connectToUnknown(clientId, groupID, tarifId) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/connectUnknownToClient.php",
            data: {
                'method': 'connectToClient',
                'token': token_cookie,
                'groupID': groupID,
                'clientID': clientId,
                'devID': $checked_arrayUnknown,
                'templateID': tarifId,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                // var result = JSON.parse(data);
                 if (data == "true") {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("errorMessage");
                    $("#errConnectForUnknowns").addClass("infoMessage");
                    var success = getMssg['connect_succeedUnDev'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 3000);
                } else if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("infoMessage");
                    $("#errConnectForUnknowns").addClass("errorMessage");
                    var failed = getMssg['connect_failed'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(failed);
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        /*$.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/connectUnknownToClient.php",
            data: {
                'groupID': groupID,
                'clientID': clientId,
                'devID': $checked_arrayUnknown,
                'tarifID': tarifId,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (data == 'true') {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("errorMessage");
                    $("#errConnectForUnknowns").addClass("infoMessage");
                    var success = getMssg['connect_succeedUnDev'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 3000);
                } else if (data == 'false') {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("infoMessage");
                    $("#errConnectForUnknowns").addClass("errorMessage");
                    var failed = getMssg['connect_failed'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(failed);
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });*/
    }


    $(document).on("click",".resend-selected",function(){
        var th = $(this);
        if(th.attr("disabled")!="disabled"){
        
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': $checked_arrayPending,
                    'actionName': "resend",
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        th.attr("disabled", "disabled");
                        th.css("opacity", "0.5");
                        th.css("cursor", "default");
                        var success = getMssg['connect_succeed'];
                        $("#errConnectForUnknowns").removeClass("errorMessage");
                        $("#errConnectForUnknowns").addClass("infoMessage");
                        $("#errConnectForUnknowns").empty();
                        $("#errConnectForUnknowns").html(success);
                        setTimeout(function () {
                            location.reload(true);
                        }, 10000);
                    } else if (result == 'false') {
                        $("body").css("cursor","default");
                        var failed = getMssg['action_failed'];
                        $("#errConnectForUnknowns").removeClass("infoMessage");
                        $("#errConnectForUnknowns").addClass("errorMessage");
                        $("#errConnectForUnknowns").html(failed);
                        $("#errConnectForUnknowns").css("color", "red");

                        setTimeout(function () {
                            $("#errConnectForUnknowns").empty();
                        }, 10000);
                    } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

 });