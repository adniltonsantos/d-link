//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg = result;
//            }
//        }
//    });
//    return retMsg;
//}


$(document).ready(function (){
   
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
    
    
    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
                
            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {

            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
    
    $('.fieids').on('ifChecked ifUnchecked', function(event){
     
        $templID = $(this).closest('tr').find("input[name='templID']").val();
        if (event.type == 'ifChecked') {
                
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');
            
            if(!$(this).hasClass('allFields')){
                $checked_array.push($templID);
            }
            
            if($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds){
               $('#all_fields').prop('checked',true).iCheck('update');
            }
            //console.log($checked_array);
        } else {
            
            if($('#all_fields').is(':checked')){
                $('#all_fields').prop('checked',false).iCheck('update');
            }
            
            if(!$('.forFieldsCheck').find('.fieids').is(':checked')){
               
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
                //console.log($checked_array);
            }
            $checked_array.removeByVal($templID);
            //console.log($checked_array);
            $(this).closest('tr').css("background-color", "#FFFFFF");
        }
    });

    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on("click", ".trash20", function (){
        var titleMsg = getMssg['title_msg'];
        var msg = getMssg['conf_rem_template'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            removeTemplates($checked_array);
        });
    });

    
    function removeTemplates(e){
    
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/removeTemplate.php",
            data: {
                'delete': 'template',
                'templateId': e,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    location.reload(true);
                } else {
                    var fail = getMssg['failed_remove_templ'];
                    $("#failResultMsgTemplate").empty();
                    $("#failResultMsgTemplate").html(fail);
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
});

