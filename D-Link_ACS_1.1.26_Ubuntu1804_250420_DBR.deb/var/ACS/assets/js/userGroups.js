//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg = result;
//            }
//        }
//    });
//    return retMsg;
//}

$(document).ready(function(){

    $basepath = $('#basepath').data('bpath');
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
    
    $checked_array = new Array();
    
    $('#userGroupPopover').popover({
        html : true,
        content: function() {
            return $('.addUserGroupPopover').html();
        }
    });
    
    $(document).on("click","#userGroupPopover",function(e) {
        e.stopPropagation(); // watch out here...
    });

    $('#userGroupPopover').popover().on('shown.bs.popover', function () {
        
        $('.userFields').iCheck({
            checkboxClass: 'icheckbox_square-blue',
//            radioClass: 'iradio_minimal-blue',
            increaseArea: '20%' // optional
        });

        $('.userFields').on('ifChecked ifUnchecked', function(event){

            if (event.type == 'ifChecked') {
                this.setAttribute("checked","checked");

            } else {
                this.removeAttribute("checked");
            }
        });
        
        $('#allFields').on('ifChecked ifUnchecked', function(event){

            if (event.type == 'ifChecked') {
                $('.userFields').iCheck('check');

            } else {
                $('.userFields').iCheck('uncheck');
            }
        });


        $countOfUncheckeds = 5;

        $('.popover-content .userFields').on('ifChecked ifUnchecked', function(event){
            $name = $(this).attr('id');

            if (event.type == 'ifChecked') {
                if(!$(this).hasClass('allField')){
                    $checked_array.push($name);
                }
                if($('.popover-content .userFields').filter(':checked').length == $countOfUncheckeds){
                    $('#allFields').iCheck('check');
                }
            } else {
                if ($('.popover-content').find('#allFields').is(':checked')) {
                    $('.popover-content').find('#allFields').prop('checked',false).iCheck('update');
                }
                if(!$('.popover-content .forFieldsCheckPopover').find('.userFields').is(':checked')){
                    $('#allFields').iCheck('uncheck');
                    $checked_array.length = 0;
                }
                $checked_array.removeByVal($name);
            }
        });
    });

    $('#userGroupPopover').popover().on('hide.bs.popover', function () {
        if ($('.popover-content').find('.userFields').is(':checked')) {
            $('.userFields').iCheck('uncheck');
        }
        setTimeout(function(){
            $('.userFields').iCheck('destroy');
            $('.userFields').iCheck('update');
            $(".addUserGroupPopover").html($(".addUserGroupPopover .popover-content").html());
        }, 100);
    });
    
    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on('click','#addGroup',function () {
        var groupName = $("input[name='groupName']").val();
        var hour = $("input[name='hour']").val();
        var minute = $("input[name='minute']").val();
        var defLanguage = $("input[name='language']:checked");
        // var usergroupName = $(".userGroupType option:selected").val();
        
        var msgRequird = getMssg['error_message_required'];
        var msgNumberHour = getMssg['error_message_number_hour'];
        var msgNumberMinute = getMssg['error_message_number_min'];
        var msgNumberHourMax = getMssg['error_message_hour_max'];
        var msgNumberHourMin = getMssg['error_message_hour_min'];
        var msgNumberMinuteMax = getMssg['error_message_minute_max'];
        var msgNumberMinuteMin = getMssg['error_message_minute_min'];
        var msgRequiredPerm = getMssg['error_message_perm'];

        $('#addUserGroupForm').validate({
            rules: {
                groupName: {
                    required: true,
                    validateIsEmpty: true
                },
                permission: {
                    required: true
                },
                hour: {
                    digitsForTime: true,
                    max : 168,
                    digitsForTimeMin : true
                },
                minute: {
                    digitsForTime: true,
                    max : 59,
                    digitsForTimeMin : true
                }
               
            },
            messages: {
                groupName: {
                    required: msgRequird,
                    validateIsEmpty: msgRequird
                },
                permission: {
                    required: msgRequiredPerm
                },
                hour: {
                    digitsForTime: msgNumberHour,
                    max : msgNumberHourMax,
                    digitsForTimeMin : msgNumberHourMin
                },
                minute: {
                    digitsForTime: msgNumberMinute,
                    max : msgNumberMinuteMax,
                    digitsForTimeMin : msgNumberMinuteMin
                },
            },
            errorElement: "div",
            errorClass: 'error_msg',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        var th = $(this);
        if (!$("#addUserGroupForm").valid()) {
            return false;
        }
        
        // if (groupName.trim() != '') {
            var resFailAction = '';
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkUserGroupName.php",
                data: { 
                    'groupName': groupName,
                    'fromApp':true
                },
                async: false,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        resFailAction = data;
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            if (resFailAction != '') {
                $("#failAddGroupUser").empty();
                $("#failAddGroupUser").html(resFailAction);
                $("body").css("cursor", "default");
            } else {
                if ($checked_array.length > 0) {
//                    if(defLanguage.length > 0){
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/addUserGroup.php",
                            data: {
                                'name': groupName,
                                'hour': hour,
                                'minute': minute,
                                // 'groupName': usergroupName,
                                'lang': defLanguage.length > 0 ? defLanguage.attr('id') : '',
                                'permissions': $checked_array,
                                'fromApp':true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    location.reload(true);
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
//                    }else{
//                        resFailAction = getMssg['def_lang_msg'];
//                        $("#failAddGroupUser").empty();
//                        $("#failAddGroupUser").html(resFailAction);
//                        $("body").css("cursor", "default");
//                    }
                } else {
                    resFailAction = getMssg['select_perm'];
                    $("#failAddGroupUser").empty();
                    $("#failAddGroupUser").html(resFailAction);
                    $("body").css("cursor", "default");
                }
            }
        // } else {
        //     resFailAction = getMssg['gName_empty'];
        //     $("#failAddGroupUser").empty();
        //     $("#failAddGroupUser").html(resFailAction);
        //     $("body").css("cursor", "default");
        // }
    });

    $(document).on("click", ".removeUserGroup", function () {
        var grID = $(this).parent().find("input[name='userGroupID']").val();
        var permsCount = $(this).parent().find("input[name='permissionsCount']").val();
        var msg = getMssg['conf_rem_user_group'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/removeUserGroup.php",
                data: {
                    'userGroupID': grID,
                    'permissionsCount': permsCount,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result != '') {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            $("#failAddGroupUser").empty();
                            $("#failAddGroupUser").html(result);
                        }
                    } else {
                        location.reload(true);
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        });
    });

//------------------- iCheck plugin for collapse rows --------------------------

    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional 
    });

    $('#forUsersGroups #all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
            $(this).closest('tr').find('.fieids').iCheck('check');
        } else {
            $(this).closest('tr').find('.fieids').iCheck('uncheck');
        }
    });
    
    $permInColapse = new Array();
    $countOfUncheckeds = 5 ;       // permisions checkbox count not to mention "All" checkbox
    
    $('.forFieldsCheckColapse .fieids').on('ifChecked ifUnchecked', function(event){
        $name = $(this).attr('id');
        $parentId = $(this).closest('tr').attr('id');

        if(!$permInColapse.hasOwnProperty($parentId)){
            $permInColapse[$parentId];
            $temp = new Array();
        }else{
            $temp = $permInColapse[$parentId];
        }
        
        if (event.type == 'ifChecked') {
            if(!$(this).hasClass('allFieids')){
                $temp.push($name);
            }
            
            if($(this).closest('tr').find('.forFieldsCheckColapse .fieids').filter(':checked').length == $countOfUncheckeds){
               $(this).closest('tr').find('#all_fields').prop('checked',true).iCheck('update');
            }
        } else {
            
            if($(this).closest('tr').find('#all_fields').is(':checked')){
                $(this).closest('tr').find('#all_fields').prop('checked',false).iCheck('update');
            }
            
            if(!$(this).closest('tr').find('.forFieldsCheckColapse .fieids').is(':checked')){
                $(this).closest('tr').find('.textStyleAll #all_fields').iCheck('uncheck');
                $temp.length = 0;
                
            }else{
                $temp.removeByVal($name);
            }
        }
        $permInColapse[$parentId] = $temp;
    });

    function array_key_exists(key, search) {
  
        if (!search || (search.constructor !== Array && search.constructor !== Object)) {
            return false;
        }
        return key in search;
    }




    
    $(document).on("click", ".showEditForm", function () {
        var groupId = $(this).parent().find("input[name='userGroupID']").val();


            $('input').iCheck('update');
            $('#editUserGroupForm' + groupId).trigger('reset');
            $('#editUserGroupForm' + groupId).validate().destroy();

        var rowId = $(this).closest('tr').next('tr').attr('id');
//        var user = $(this).closest('tr').next('tr').find("input[name='user_administration']");
//        var group = $(this).closest('tr').next('tr').find("input[name='group_administration']");
//        var client = $(this).closest('tr').next('tr').find("input[name='client_administration']");
//        var device = $(this).closest('tr').next('tr').find("input[name='device_administration']");
//        var monitoring = $(this).closest('tr').next('tr').find("input[name='monitoring']");
        var user = $(this).closest('tr').next('tr').find("#user_administration");
        var group = $(this).closest('tr').next('tr').find("#group_administration");
        var client = $(this).closest('tr').next('tr').find("#client_administration");
        var device = $(this).closest('tr').next('tr').find("#device_administration");
        var monitoring = $(this).closest('tr').next('tr').find("#monitoring");
        
        if(!$permInColapse.hasOwnProperty(rowId)){
            $permInColapse[rowId];
            $tempInColapse = new Array();
            
            if($(user).is(':checked')){
                $tempInColapse.push(user.attr('id'));
            }
            if($(group).is(':checked')){
                $tempInColapse.push(group.attr('id'));
            }
            if($(client).is(':checked')){
                $tempInColapse.push(client.attr('id'));
            }
            if($(device).is(':checked')){
                $tempInColapse.push(device.attr('id'));
            }
            if($(monitoring).is(':checked')){
                $tempInColapse.push(monitoring.attr('id'));
            }
            
            $permInColapse[rowId] = $tempInColapse;
        }
    });
    
    $(document).on("click", "#editUserGroup", function () {
        var groupId = $(this).parent().find("input[name='userGroupID']").val();
        var grRealName = $(this).closest('tr').find("input[name='realGroupName']").val();
        var grName = $(this).closest('tr').find("input[name='groupName']").val().trim();
        var parentId = $(this).closest('tr').attr('id');
        var defLanguage = $(this).closest('tr').find("input[name='language"+parentId.substr(9)+"']:checked");
        var hour = $(this).closest('tr').find("input[name='hour']").val();
        var minute = $(this).closest('tr').find("input[name='minute']").val();
        // var groupNameUser = $(this).closest('tr').find(".userGroupType option:selected").val();
        
        var msgRequird = getMssg['error_message_required'];
        var msgNumberHour = getMssg['error_message_number_hour'];
        var msgNumberMinute = getMssg['error_message_number_min'];
        var msgNumberHourMax = getMssg['error_message_hour_max'];
        var msgNumberHourMin = getMssg['error_message_hour_min'];
        var msgNumberMinuteMax = getMssg['error_message_minute_max'];
        var msgNumberMinuteMin = getMssg['error_message_minute_min'];
        var msgRequiredPerm = getMssg['error_message_perm'];
        $('#editUserGroupForm'+groupId).validate({
            rules: {
                groupName: {
                    required: true,
                    validateIsEmpty: true
                },
                permission: {
                    required: true
                },
                hour: {
                    digitsForTime: true,
                    max : 168,
                    digitsForTimeMin : true
                },
                minute: {
                    digitsForTime: true,
                    max : 59,
                    digitsForTimeMin : true
                },

            },
            messages: {
                groupName: {
                    required: msgRequird,
                    validateIsEmpty: msgRequird
                },
                permission: {
                    required: msgRequiredPerm
                },
                hour: {
                    digitsForTime: msgNumberHour,
                    max : msgNumberHourMax,
                    digitsForTimeMin : msgNumberHourMin
                },
                minute: {
                    digitsForTime: msgNumberMinute,
                    max : msgNumberMinuteMax,
                    digitsForTimeMin : msgNumberMinuteMin
                }
            },
            errorElement: "div",
            errorClass: 'error_msg',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        var th = $(this);
        if (!$("#editUserGroupForm"+groupId).valid()) {
            return false;
        }
        
        if (grName != grRealName.trim()) {
            var resFailAction = '';
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkUserGroupName.php",
                data: { 
                    'groupName': grName,
                    'fromApp':true
                },
                async: false,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        resFailAction = data;
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            if (resFailAction != '') {
                $(this).closest('tr').find("#failAddGroupUserName").empty();
                $(this).closest('tr').find("#failAddGroupUserName").html(resFailAction);
                $("body").css("cursor", "default");
            } else {
                if (array_key_exists(parentId,$permInColapse) && $permInColapse[parentId] != '') {
//                    if(defLanguage.length > 0){
                        var permissionsArray = [];
                        permissionsArray = $permInColapse[parentId];

                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/editUserGroup.php",
                            data: {
                                'groupId': groupId,
                                'groupName': grName,
                                // 'userGroupName': groupNameUser,
                                'hour': hour,
                                'minute': minute,
                                'lang': defLanguage.length > 0 ? defLanguage.attr('id') : '',
                                'permissionsList': permissionsArray,
                                'fromApp':true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    location.reload(true);
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
//                    }else{
//                        resFailAction = getMssg['def_lang_msg'];
//                        $("#failAddGroupUser").empty();
//                        $("#failAddGroupUser").html(resFailAction);
//                        $("body").css("cursor", "default");
//                    }
                } else {
                    resFailAction = getMssg['select_perm'];
                    $(this).closest('tr').find("#failAddGroupUserName").empty();
                    $(this).closest('tr').find("#failAddGroupUserName").html(resFailAction);
                    $("body").css("cursor", "default");
                }
            }
        } else {
            if (array_key_exists(parentId,$permInColapse) && $permInColapse[parentId] != '') {
//                if(defLanguage.length > 0){
                permissionsArray = $permInColapse[parentId];

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/editUserGroup.php",
                        data: {
                            'groupId': groupId,
                            'groupName': grName,
                            // 'userGroupName': groupNameUser,
                            'hour': hour,
                            'minute': minute,
                            'lang': defLanguage.length > 0 ? defLanguage.attr('id') : '',
                            'permissionsList': permissionsArray,
                            'fromApp':true
                        },
                        async: false,
                        success: function (result) {
                            if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                location.reload(true);
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
//                }else{
//                    resFailAction = getMssg['def_lang_msg'];
//                    $("#failAddGroupUser").empty();
//                    $("#failAddGroupUser").html(resFailAction);
//                    $("body").css("cursor", "default");
//                }
            } else {
                resFailAction = getMssg['select_perm'];
                $(this).closest('tr').find("#failAddGroupUserName").empty();
                $(this).closest('tr').find("#failAddGroupUserName").html(resFailAction);
                $("body").css("cursor", "default");
            }
        }
    });

    $(document).on("click", ".eachUsersGroupsPage", function () {
        var page = $(this).find("input[name='page']").val();
        $("body").css("cursor", "wait");
    
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredUsersGroupsByPage.php",
            data: {
                'page': page,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#forUsersGroups").empty();
                    $("#forUsersGroups").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
});
