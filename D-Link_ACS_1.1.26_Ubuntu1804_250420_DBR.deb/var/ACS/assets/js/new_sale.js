$(document).ready(function () {

    $(document).on('click','.selectModel',function(){
        if ($(".modelsSaleDiv").css("display") == "none") {
            $('.saleSelectAddModel a').removeClass('activeTabModel');
            $(this).addClass('activeTabModel');
            $('.inputNewModel').hide();
            $('.hwVersion').hide();
            $('.modelsSaleDiv').show();
            $(".forNewModel").find("div.error_msg").remove();
            $(".forNewModel").find(".error_msg").removeClass("error_msg");
        }
    });

    $(document).on('click','.addModel',function(){
        if ($(".inputNewModel").css("display") == "none") {
            $('.saleSelectAddModel a').removeClass('activeTabModel');
            $(this).addClass('activeTabModel');
            $('.modelsSaleDiv').hide();
            $('.inputNewModel').show();
            $('.hwVersion').show();
            $(".modelsSaleDiv").find("div.error_msg").remove();
            $(".modelsSaleDiv").find(".error_msg").removeClass("error_msg");
        }
    });

    $(document).on("click", "input[name='forCheckSSID']", function () {
        if ($(this).is(":checked")) {
            var mac = $("input[name='mac']").val();
            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
                data: {
                    'mac':mac,
                    'fromApp':true,
                    'action': 'genPassword'
                },
                async: true,
                success: function (result) {
                    if(result=='logged_out'){
                        document.location.href = $basepath + 'login';
                    } else {
                        var myResult = result.substr(0, 4);
                        $('#autoGenerateSSID').val('aranea_' + myResult);
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click", "input[name='forCheckPass']", function () {
        if ($(this).is(":checked")) {
            var mac = $("input[name='mac']").val();
            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
                data: {
                    'mac':mac,
                    'fromApp':true,
                    'action': 'genPassword'
                },
                async: true,
                success: function (result) {
                    if(result=='logged_out'){
                        document.location.href = $basepath + 'login';
                    } else {
                        $('#autoGeneratePassword').val(result);
                        $('#showPasswordDiv').show();

                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });



    $('#autoGeneratePassword').on('input', function() {
       showPas = $('#autoGeneratePassword').val();
       if (showPas != ''){
           $('#showPasswordDiv').show();
       } else {
           $('#showPasswordDiv').hide();
       }
    });

    $(document).on("change","#chkShow",function() {
        if (this.checked) {
            $('#autoGeneratePassword').prop('type', 'text');
        } else {
            $('#autoGeneratePassword').prop('type', 'password');
        }
    });


    $(document).on("click", "#addSales", function () {

        var msgRequird = getMssg['error_message_required'];
        var msgEmpty = getMssg['error_message_empty'];
        var errMsgAtLeast10 = getMssg['error_message_at_least_10'];
        var msgInvalidEmail = getMssg['invalid_email'];
        var msgReqField = getMssg['name_required_field'];

        $('#addSale').validate({
            rules: {
                firstName: {
                    required: true,
                    noSpace: true
                },
                surName: {
                    required: true,
                    noSpace: true
                },
                newModel: {
                    required: true,
                    validateIsEmpty: true
                },
                hwVersion: {
                    required: true,
                    validateIsEmpty: true
                },
                modelId: {
                    validateNotZero: true
                },
                mac: {
                    required: true,
                    validateIsEmpty: true,
                    minlengthMac: true
                },
                newSsidName: {
                    required: true
                },
                passNewSSIDName: {
                    required: true
                }
            },
            messages: {
                firstName: {
                    required: msgRequird,
                    noSpace: msgReqField
                },
                surName: {
                    required: msgRequird,
                    noSpace: msgReqField
                },
                hwVersion: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                newModel: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                modelId: {
                    validateNotZero: msgRequird
                },
                mac: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty,
                    minlengthMac: errMsgAtLeast10
                },
                newSsidName: {
                    required: msgRequird
                },
                passNewSSIDName: {
                    required: msgRequird
                }
            },
            errorElement: "div",
            errorClass: 'error_msg_sale',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }

        });

        if (!$("#addSale").valid()) {
            $('body').css("cursor", "default");
            return false;
        }

       $("body").css("cursor", "wait");
        var err = getMssg['sale_required_fields'];


        var firstN = $("input[name='firstName']").val();
        var surname = $("input[name='surName']").val();
        var patronymicName = $("input[name='patronymicName']").val();
        var mac = $("input[name='mac']").val();
        var model = $(".modelsSale option:selected").val();

        var ssidName = th.parent().find("input[name='newSsidName']").val();
        var ssidPass = th.parent().find("input[name='passNewSSIDName']").val();

            if (firstN == '' || surname == '' || mac == '' || model == '') {
                $("#failSale").empty();
                $("#failSale").html(err);
                $("body").css("cursor", "default");
                return false;
            } else {
                var checkStatus = '';
                var newModel = $("input[name='newModel']").val();
                if (newModel.trim() != '') {
                    var hwVersion = $("input[name='hwVersion']").val();

                    if(hwVersion == ''){
                        $("#failSale").empty();
                        $("#failSale").html(err);
                        $("body").css("cursor", "default");
                        return false;
                    }

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/checkModelsExists.php",
                        data: {
                            'modelName': newModel,
                            'fromApp':true
                        },
                        async: false,
                        success: function (data) {
                            if (data == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                checkStatus = data;
                            }

                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                } else {
                    model = $(".modelsSale option:selected").val();
                    if (model == 0) {
                        var fail = getMssg['add_select_model'];
                        $("#failSale").empty();
                        $("#failSale").html(fail);
                        $("body").css("cursor", "default");
                        return false;
                    }
                }
                if (checkStatus == 'true') {
                    var fail = getMssg['model_exist'];
                    $("#failSale").empty();
                    $("#failSale").html(fail);
                    $("body").css("cursor", "default");
                    return false;
                } else {
                    checkStatus = '';

                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/checkMacsExist.php",
                            data: {
                                'mac': mac,
                                'fromApp':true
                            },
                            async: false,
                            success: function (data) {
                                if (data == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    checkStatus = data;
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                        if (checkStatus == 'true') {
                            var fail = getMssg['serial_exist'];
                            $("#failSaleError").empty();
                            $("#failSaleError").addClass("errorMessage");
                            $("#failSaleError").html(fail);
                            $("body").css("cursor", "default");
                            return false;
                        } else if (checkStatus == 'false') {
                            $(this).submit();
                        }
                    }
//                    return false;
                }

                if (ssidName != '' && ssidPass != ''){
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/addSale.php",
                        data: {
                            'ssid': ssidName,
                            'pass': ssidPass,
                            'mac': mac,
                            'con_type': 6,
                            'fromApp': true
                        },
                        async: false,
                        success: function (result) {
                            if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                if (result.trim() == 'true') {
                                    var fail = getMssg['conn_name_exist'];
                                    $("#failAddPass").empty();
                                    $("#failAddPass").addClass("errorMessage");
                                    $("#failAddPass").html(fail);
                                } else {
                                    var fail = getMssg['success'];
                                    $("#failAddPass").empty();
                                    $("#failAddPass").removeClass("errorMessage");
                                    $("#failAddPass").addClass("infoMessage");
                                    $("#failAddPass").html(fail);
                                }
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }




        $("#pptponoffswitch").attr('checked', false);
    });

});