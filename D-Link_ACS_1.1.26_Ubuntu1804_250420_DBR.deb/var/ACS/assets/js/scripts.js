function checkFirstVisit(pageName) {
    if(document.cookie.indexOf(pageName)==-1) {
        // cookie doesn't exist, create it now
        document.cookie = pageName+'=1';
    }else {

       return false;
        // not first visit, so alert
        alert('You refreshed!');
    }
}

//$(document).ready(function () {
//    $uniformed = $(".styleThese").find("select, a.uniformTest").not(".skipThese");
//    $uniformed.uniform();

//    $(".page").on("click", ".logo", function () {
//        $("body").css("cursor", "wait");
//        $.post('../../secureFiles/actions/home.php',
//            {
//            },
//            function (result) {
//                $("#forDevices").html("");
//                $("#forDevices").html(result);
//                $("body").css("cursor", "default");
//            }
//        );
//    });
//
//});
	