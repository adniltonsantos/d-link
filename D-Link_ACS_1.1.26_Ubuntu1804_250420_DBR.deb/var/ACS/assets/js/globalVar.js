/**
 * Created by Hayk Hovhannisyan on 3/15/18.
 */
const globalVar={
    HTTP:{
        POST:"POST",
        GET:"GET",
    },
    TASKS:{
        SET:'set',
        SET_TR_TREE:'setTrTree',
        GET_ALL_PARAM:'getAllParams',
        NOTIFI_TREE:'notificationTree',
        NOTIFI_RESET:'notificationReset',
        REFRESH:'refresh',
        REFRESHBUTTON:'refreshButton',
        SET_TRE_TREE:'setTrTree',
        SET_IGMP:'setIGMP',
        IGMP_OFF:'setIGMPoff',
        SET_REMOTE_ACCESS:'setRemoteAccess',
    },
    ITEMS:{
        deviceID:$("input[name='devID']").val(),
        refreshButton:$("#refreshButton"),
        basePath:$('#basepath').data('bpath'),
        forDActiv:$("#forDActiv"),
    },
    getCookie:function(name){
        var value = "; " + document.cookie;
        var parts = value.split("; " + name + "=");
        if (parts.length == 2) return parts.pop().split(";").shift();
    },
};
var ajaxRequest = (function(){
    const BASEPATH=globalVar.ITEMS.basePath;
    const UPDATE_TIMEOUT=2*1000;// two seconds
    const CHECK_STATUS_TIMEOUT=5*1000;
    const CONTROLLER_PATH="secureFiles/actions/ajaxActions/sendXML.php";
    const TACK_PATH="secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php";
    const UPDATE_ACTIVITY_PATH="secureFiles/actions/ajaxActions/eachDevActivity.php";
    var refreshButton=globalVar.ITEMS.refreshButton;
    var devId = globalVar.ITEMS.deviceID;
    const RESULT={
        TRUE:'true',
        FALSE:'false',
        LOG_OUT:'logged_out',
        WRONG_ACTION_NAME:'',
    };
    const TASK_STATUS={
        ERROR:'-1',
        DONE:'2',
    };
    //show and hide some button, maybe we should move it to the globalVar.
    function showHideButton(btn, state, disable){
        if(!state){
            btn.hide();
            btn.prop("disabled", disable);
        }else{
            btn.show();
            btn.prop("disabled", disable);
        }
    }
    var checkAction=function(actionName, btn){
        switch (actionName){
            case globalVar.TASKS.REFRESH:{ //hide refreshButton
                document.cookie = globalVar.TASKS.REFRESH+devId+"=false";
                showHideButton(btn,true,true);
                break;
            }
            case globalVar.TASKS.SET://show refreshButton
            case globalVar.TASKS.SET_IGMP:
            case globalVar.TASKS.SET_REMOTE_ACCESS:
            case globalVar.TASKS.IGMP_OFF:{
                document.cookie = globalVar.TASKS.REFRESH+devId+"=true";
                showHideButton(btn,true,false);
                break;
            }
        }
        if($("#getAllParams").is(':visible') || $("#refresh_page").is(':visible')){ //check if it's tr_tree page.
            refreshButton.hide();
        }
    };
    var checkRefreshCookie=function(btn, cookieName){
        var btnShow=globalVar.getCookie(cookieName);
        if(btnShow==='true'){
            showHideButton(btn,true,false);
        }else{
            showHideButton(btn,false,true);
        }
    };
    var ajaxRequest = function(props){
        console.log(props);
        var type=(typeof props.type!=="undefined")? props.type : globalVar.HTTP.GET;
        var url=(typeof props.url!=="undefined")? props.url : CONTROLLER_PATH;
        var data=(typeof props.data!=="undefined")? props.data : {};
        var async=(typeof props.async!=="undefined")? props.async : true;
        var response=(typeof props.response!=="undefined")? props.response : null;
        var getStatus=(typeof props.getStatus!=="undefined")? props.getStatus : null;
        var taskName=(typeof props.name!=="undefined")? props.name : null;
        var checkError=(typeof props.error!=="undefined")? props.error : null;
        var chackName=(typeof props.chack!=="undefined")? props.chack : null;
        data['actionName']=taskName;
        if(chackName==null){
            chackName=taskName;
        }
        var self=this;
        console.log(BASEPATH + url);
        $.ajax({
            type: type,
            url: BASEPATH + url,
            data: data,
            async: async,
            success: function (status) {
                if(status===RESULT.TRUE){
                    checkAction(taskName,refreshButton);
                    if(response!=null){
                        response(status);
                    }
                    setTimeout(function () {
                        updateActivity(data.deviceID);
                    }, UPDATE_TIMEOUT);
                    if(typeof taskName!=="undefined") {
                        ajaxStatusRequest({
                            'taskName': chackName,
                            'deviceID': data.deviceID,
                            'fromApp': true,
                            callBack:function(status){
                                checkRefreshCookie(refreshButton,globalVar.TASKS.REFRESH+devId);
                                if(getStatus!=null){
                                    getStatus(status);
                                }
                            }
                        })
                    }
                }else if(status==RESULT.FALSE){
                    //show error
                    if(checkError!=null){
                        checkError(status);
                    }else{
                        swal({
                            title: status,
                            text: 'ERROR',
                            type: "error"
                        });
                    }
                }else if(status==RESULT.WRONG_ACTION_NAME){
                    swal({
                         title: 'Wrong request name',
                         text: 'Warning',
                         type: "warning"
                     });
                }
                else if(status==RESULT.LOG_OUT){
                    document.location.href = BASEPATH + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = BASEPATH + '500';
            }
        });
    };
    var ajaxStatusRequest = function(props){
        //checking task status
        var checkStatus = true;
        var self=this;
        var intR=setInterval(function () {
            $.ajax({
                type: globalVar.HTTP.POST,
                url:  BASEPATH + TACK_PATH,
                data: {
                    'taskName':"'"+props.taskName+"'",
                    'deviceID': props.deviceID,
                    'fromApp':props.fromApp,
                },
                async: true,
                success: function (status) {
                    if (status === TASK_STATUS.DONE) {//it's done
                        if(props.callBack!=null) {
                            clearInterval(intR);
                            props.callBack(status);
                        }
                    }else if(status === TASK_STATUS.ERROR) {
                        if(props.callBack!=null) {
                            clearInterval(intR);
                            props.callBack(status);
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if(props.callBack!=null) {
                        clearInterval(intR);
                        props.callBack(status);
                    }
                }
            });
        }, CHECK_STATUS_TIMEOUT);
    };
    var updateActivity = function(deviceID){
        $.ajax({
            type: "POST",
            url: BASEPATH + UPDATE_ACTIVITY_PATH,
            data: {
                'deviceID': deviceID,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result ==RESULT.LOG_OUT) {
                    document.location.href = BASEPATH + 'login';
                } else {
                    globalVar.ITEMS.forDActiv.empty();
                    globalVar.ITEMS.forDActiv.html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    };
    return {
        send:function(props){
            return ajaxRequest(props);
        },
        getStatus:function(props){
            return ajaxStatusRequest(props);
        }
    }
}());