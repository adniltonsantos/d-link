$(document).ready(function () {


    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {

            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {

            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $checked_array_group = new Array();
    $countOfUncheckedsGroup = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;

    $('.fieids').on('ifChecked ifUnchecked', function(event){
        $groupID = $(this).closest('tr').find("input[name='groupID']").val();
        if (event.type == 'ifChecked') {
            // $(".addTemplateToDevice").removeClass('templateInGroup');
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');

            if(!$(this).hasClass('allFields')){
                $checked_array_group.push($groupID);
            }
            if($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckedsGroup){
                $('#all_fields').prop('checked',true).iCheck('update');
            }
        } else {
            if($('#all_fields').is(':checked')){
                $('#all_fields').prop('checked',false).iCheck('update');
            }

            if(!$('.forFieldsCheck').find('.fieids').is(':checked')){
                $('.trash-select').css('display', 'none');
//                $('#all_fields').iCheck('uncheck');
                $checked_array_group.length = 0;
            }
            $checked_array_group.removeByVal($groupID);
            $(this).closest('tr').css("background-color", "#FFFFFF");
        }
    });


    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }


    $(document).on("click", ".trash20", function (){
        var msg = getMssg['conf_rem_user'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            removeGroups($checked_array_group);
        });
    });



    function removeGroups(groupID){

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/removeGroup.php",
            data: {
                'groupID': groupID,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    location.reload(true);
                } else {
                    $("#actionMsgWithGroup").empty();
                    $("#actionMsgWithGroup").html(getMssg['action_failed']);
                    $("#actionMsgWithGroup").addClass("errorMessage");
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

});