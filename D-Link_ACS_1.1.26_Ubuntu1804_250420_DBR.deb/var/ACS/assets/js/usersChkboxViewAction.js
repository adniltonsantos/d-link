//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg = result;
//            }
//        }
//    });
//    return retMsg;
//}

$(document).ready(function (){

//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });

    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
                
            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {

            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
    
    $('.fieids').on('ifChecked ifUnchecked', function(event){
     
        $userID = $(this).closest('tr').find("input[name='userID']").val();
        if (event.type == 'ifChecked') {
                
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');
            
            if(!$(this).hasClass('allFields')){
                $checked_array.push($userID);
            }
            
            if($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds){
               $('#all_fields').prop('checked',true).iCheck('update');
            }
        } else {
            
            if($('#all_fields').is(':checked')){
                $('#all_fields').prop('checked',false).iCheck('update');
            }
            
            if(!$('.forFieldsCheck').find('.fieids').is(':checked')){
               
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
            }
            $checked_array.removeByVal($userID);
            $(this).closest('tr').css("background-color", "#FFFFFF");
        }
    });

    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on("click", ".ActivateUsers", function (){
        var msg = getMssg['conf_rem_Activate_user'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['activate_msg'];
        var cancelMsg = getMssg['cancel'];
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function () {
                ActivateDeactivatedUsers($checked_array);
            });
        });

    function ActivateDeactivatedUsers(e){

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/removeUser.php",
            data: {
                'userID': e,
                'actionName': "ActivateUsers",
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if(result != ''){
                    if(result=='logged_out'){
                        document.location.href = $basepath + 'login';
                    } else {
                        $("#failAddUser").empty();
                        $("#failAddUser").html(result);
                    }
                }else {
                    location.reload(true);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }



    $(document).on("click", ".trash20", function (){
            var action = $(".UsersType").val();
            var msg = getMssg['conf_rem_user'];
            var Dmsg = getMssg['conf_rem_deactivated_user'];
            var titleMsg = getMssg['title_msg'];
            var rmMsg =  getMssg['remove_msg'];
            var acMsg = getMssg['deactivate_msg'];
            var cancelMsg = getMssg['cancel'];
            if (action == "DeletedUsers") {
                swal({
                    title: titleMsg,
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function () {
                    removeDeactivatedUsers($checked_array);
                });
                function removeDeactivatedUsers(e){

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                        data: {
                            'userID': e,
                            'fromApp': true,
                            'actionName': "deletedUser"
                        },
                        async: false,
                        success: function (result) {
                            if (result != '') {
                                if (result == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    $("#failAddUser").empty();
                                    $("#failAddUser").html(result);
                                    location.reload(true);
                                }
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }
            } else if (action=="AllUsers") {
                swal({
                    title: titleMsg,
                    text: Dmsg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: acMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function () {
                    removeUsers($checked_array);
                });
                function removeUsers(e){

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/removeUser.php",
                        data: {
                            'userID': e,
                            'fromApp':true
                        },
                        async: false,
                        success: function (result) {
                            if(result != ''){
                                if(result=='logged_out'){
                                    document.location.href = $basepath + 'login';
                                } else {
                                    $("#failAddUser").empty();
                                    $("#failAddUser").html(result);
                                }
                            }else {
                                location.reload(true);
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }
            }
    });
    
});
