//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg=result;
//            }
//
//        }
//
//    });
//    return retMsg;
//
//}


$(document).ready(function () {
    
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
    
    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
                
            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {

            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
    
    $('.fieids').on('ifChecked ifUnchecked', function(event){
     
        $clientID = $(this).closest('tr').find("input[name='clientID']").val();
        if (event.type == 'ifChecked') {
                
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');
            
            if(!$(this).hasClass('allFields')){
                $checked_array.push($clientID);
            }
            
            if($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds){
               $('#all_fields').prop('checked',true).iCheck('update');
            }
//            console.log($checked_array);
        } else {
            
            if($('#all_fields').is(':checked')){
                $('#all_fields').prop('checked',false).iCheck('update');
            }
            
            if(!$('.forFieldsCheck').find('.fieids').is(':checked')){
               
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
//                console.log($checked_array);
            }
            $checked_array.removeByVal($clientID);
//            console.log($checked_array);
            $(this).closest('tr').css("background-color", "#FFFFFF");
        }
    });

    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on("click", ".trash20", function (){
        var titleMsg = getMssg['title_msg'];
        var msg = getMssg['remove_client_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            removeClients($checked_array);
        });
    });

    
    function removeClients(e){
    
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'clientID': e,
                'actionName': "removeClient",
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['connect_succeed'];
                    $("#failAddClient").empty();
                    $("#failAddClient").removeClass("errorMessage");
                    $("#failAddClient").addClass("infoMessage");
                    $("#failAddClient").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                } else if (result == 'false') {
                    var failed = getMssg['action_failed'];
                    $("#failAddClient").empty();
                    $("#failAddClient").removeClass("infoMessage");
                    $("#failAddClient").addClass("errorMessage");
                    $("#failAddClient").html(failed);
                    $("body").css("cursor", "default");
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
});