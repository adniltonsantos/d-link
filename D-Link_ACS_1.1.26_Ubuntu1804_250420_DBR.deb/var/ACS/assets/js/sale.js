//
//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg=result;
//            }
//
//        }
//
//    });
//    return retMsg;
//
//}

$(document).ready(function () {
    $("#pptponoffswitch").attr('checked', false);
    $('#addPassonoffswitch').attr('checked',false);
    
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
    
    $(document).on('click','#addClientSale',function(){
	if($.trim( $('.sale .error_msg').text() ).length != 0){
	    $('#addSale').validate().resetForm();
	}
        if ($("#addClient").css("display") == "none") {
            $('.sale-nav li a').removeClass('activeTab');
            $(this).addClass('activeTab');
            $('#addClient').show();
            $('#selectClient').hide();
            $('.addPasswordFormForSale').hide();
	    $('.pptpContentDiv').hide();
            $('.saleAddress').show();
            $('#pptponoffswitch').attr('checked',false);
            $('#addPassonoffswitch').attr('checked',false);
            $('.saleEmail').show();
            $("#failSale").empty();
            $('#addClient').append('<input type="radio" value="add" name="addOrChoose" checked="checked" style="display: none"/>');
            $('#selectClient').find("input[name='addOrChoose']").remove();
            $(':input', '.addPasswordFormForSale').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });
            $(':input', '.pptpContentDiv').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });

            $("#showPasswordDiv").hide();
            $("#chkShowSale").attr('checked',false);
        }


    }); 
   
    $(document).on('click','#selectClientSale',function(){
	if($.trim( $('.sale .error_msg').text() ).length != 0){
	    $('#addSale').validate().resetForm();
	}
        if ($("#selectClient").css("display") == "none") {
            $('.sale-nav li a').removeClass('activeTab');
            $(this).addClass('activeTab');
            $("#failSale").empty();
            $('#addClient').hide();
            $('.addPasswordFormForSale').hide();
	    $('.pptpContentDiv').hide();
            $('#selectClient').show();
            $('#pptponoffswitch').attr('checked',false);
            $('#addPassonoffswitch').attr('checked',false);
            $('.saleAddress').hide();
            $('.saleEmail').hide();
            $('#selectClient').append('<input type="radio" value="choose" name="addOrChoose" checked="checked" style="display: none"/>');
            $('#addClient').find("input[name='addOrChoose']").remove();
            $(':input', '.addPasswordFormForSale').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });
            $(':input', '.pptpContentDiv').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });
            $("#showPasswordDiv").hide();
            $("#chkShowSale").attr('checked',false);
        }

    }); 
    
    $(document).on('click','.selectModel',function(){
        if ($(".modelsSaleDiv").css("display") == "none") {
            $('.saleSelectAddModel a').removeClass('activeTabModel');
            $(this).addClass('activeTabModel');
            $('.inputNewModel').hide();
            $('.hwVersion').hide();
            $('.modelsSaleDiv').show();
            $(".forNewModel").find("div.error_msg_sale").remove();
            $(".forNewModel").find(".error_msg").removeClass("error_msg");
        }
    }); 
    
    $(document).on('click','.addModel',function(){
        if ($(".inputNewModel").css("display") == "none") {
            $('.saleSelectAddModel a').removeClass('activeTabModel');
            $(this).addClass('activeTabModel');
            $('.modelsSaleDiv').hide();
            $('.inputNewModel').show();
            $('.hwVersion').show();
            $(".modelsSaleDiv").find("div.error_msg").remove(); 
            $(".modelsSaleDiv").find(".error_msg").removeClass("error_msg");
        }
    }); 
    
    $(document).on("click", "input[name='forCheckPass']", function () {
        if ($(this).is(":checked")) {
            $(".addPasswordFormForSale").show();
            $("#failAddPass").empty();
            $(':input', '.addPasswordFormForSale').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });
        } else {
            $(".addPasswordFormForSale").hide();
            $("#failAddPass").empty();
            $(':input', '.addPasswordFormForSale').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });
        }
    });
    
    $(document).on("click", "input[name='forCheckPptp']", function () {
        if ($(this).is(":checked")) {
            $(".pptpContentDiv").show();
            $(':input', '.pptpContentDiv').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });
        } else {
            $(".pptpContentDiv").hide();
            $(':input', '.pptpContentDiv').each(function() {
                var type = this.type;
                if (type == 'text' || type == 'password'){
                    this.value = "";
                }
            });
        }
    });

    $(document).on("change", ".selectAPSale", function () {
        var connection = $(this).find("option:selected").text();
        if(connection == "WLAN"){
            $(".ppoeContentForSale").hide();
            $(".pptpContentForSale").hide();
            $(".l2tpContentForSale").hide();
            $(".wlanContentForSale").show();
            $("#failAddPass").empty();

            $("#showPasswordDiv").hide();
            $("#chkShowSale").attr('checked',false);
            $('.autoGenerateSale').prop('type', 'password');
            $('#autoWlanPassGenerateSale').prop('type', 'password');
        }else if(connection == "PPPoE"){
            $(".ppoeContentForSale").show();
            $(".pptpContentForSale").hide();
            $(".l2tpContentForSale").hide();
            $(".wlanContentForSale").hide();
            $("#failAddPass").empty();
            $("#conName").empty();


            $("#showPasswordDiv").hide();
            $("#chkShowSale").attr('checked',false);
            $('.autoGenerateSale').prop('type', 'password');
            $('#autoWlanPassGenerateSale').prop('type', 'password');
        }else if(connection == "PPTP"){
            $(".ppoeContentForSale").hide();
            $(".pptpContentForSale").show();
            $(".l2tpContentForSale").hide();
            $(".wlanContentForSale").hide();
            $("#failAddPass").empty();
            $("#conName").empty();


            $("#showPasswordDiv").hide();
            $("#chkShowSale").attr('checked',false);
            $('.autoGenerateSale').prop('type', 'password');
            $('#autoWlanPassGenerateSale').prop('type', 'password');
        }else if(connection == "L2TP"){
            $(".ppoeContentForSale").hide();
            $(".pptpContentForSale").hide();
            $(".l2tpContentForSale").show();
            $(".wlanContentForSale").hide();
            $("#failAddPass").empty();
            $("#conName").empty();


            $("#showPasswordDiv").hide();
            $("#chkShowSale").attr('checked',false);
            $('.autoGenerateSale').prop('type', 'password');
            $('#autoWlanPassGenerateSale').prop('type', 'password');
        }
    });

    $(document).on("change","#chkShowSale",function() {
        var th = $(this);
        var connection = th.parents('div:eq(4)').find(".selectAPSale option:selected").text();
        if(connection == 'PPPoE' || connection == 'PPTP' || connection == 'L2TP'){
            if (this.checked) {
                $(".autoGenerateSale").prop("readonly",false);
                th.parents('div:eq(4)').find('.autoGenerateSale').prop('type', 'text');
            } else {
                th.parents('div:eq(4)').find('.autoGenerateSale').prop('type', 'password');
            }
        }else if(connection == 'WLAN'){
            if (this.checked) {
                $("#autoWlanPassGenerateSale").prop("readonly",false);
                th.parents('div:eq(4)').find('#autoWlanPassGenerateSale').prop('type', 'text');
            } else {
                th.parents('div:eq(4)').find('#autoWlanPassGenerateSale').prop('type', 'password');
            }
        }
    });


    $(document).on("click", "#addSales", function () {

	var msgRequird = getMssg['error_message_required'];
	var msgEmpty = getMssg['error_message_empty'];
	var errMsgAtLeast10 = getMssg['error_message_at_least_10'];
	var msgInvalidEmail = getMssg['invalid_email'];
    var msgReqField = getMssg['name_required_field'];

	$('#addSale').validate({
            rules: {
                firstName: {
                    required: true,
                    noSpace: true
                },
                surName: {
                    required: true,
                    noSpace: true
                },
                newModel: {
                    required: true,
		            validateIsEmpty: true
                },
                hwVersion: {
                    required: true,
		            validateIsEmpty: true
                },
                modelId: {
		            validateNotZero: true
                },
                mac: {
                    required: true,
		            validateIsEmpty: true,
		            minlengthMac: true
                },
                username: {
                    required: true,
		            validateIsEmpty: true
                },
                password: {
                    required: true,
		            validateIsEmpty: true
                },
                email: {
                    email: true
                },
                conName: {
                    required: true,
		            validateIsEmpty: true
                },
                passUserName: {
                    required: true,
		            validateIsEmpty: true
                },
                passName: {
                    required: true,
		            validateIsEmpty: true
                },
                ssidName: {
                    required: true,
                    validateIsEmpty: true
                },
                ssidName5GHZ: {
                    required: true,
                    validateIsEmpty: true
                },
                passSSIDName: {
                    required: true,
                    validateIsEmpty: true
                }
	        },
            messages: {
                firstName: {
                    required: msgRequird,
                    noSpace: msgReqField
                },
                surName: {
                    required: msgRequird,
                    noSpace: msgReqField
                },
                hwVersion: {
                    required: msgRequird,
		            validateIsEmpty: msgEmpty
                },
                newModel: {
                    required: msgRequird,
		            validateIsEmpty: msgEmpty
                },
                modelId: {
		            validateNotZero: msgRequird
                },
                mac: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty,
                    minlengthMac: errMsgAtLeast10
                },
                username: {
                    required: msgRequird,
		            validateIsEmpty: msgEmpty
                },
                password: {
                    required: msgRequird,
		            validateIsEmpty: msgEmpty
                },
                email: {
                    email: msgInvalidEmail
                },
                conName: {
                    required: msgRequird,
		            validateIsEmpty: msgEmpty
                },
                passUserName: {
                    required: msgRequird,
		            validateIsEmpty: msgEmpty
                },
                passName: {
                    required: msgRequird,
		            validateIsEmpty: msgEmpty
                },
                ssidName: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                ssidName5GHZ: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                passSSIDName: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                }
            },
            errorElement: "div",
	        errorClass: 'error_msg_sale',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                error.insertAfter(element);
                }
            }

	});

    if (!$("#addSale").valid()) {
            $('body').css("cursor", "default");
            return false;
    }

//        $("body").css("cursor", "wait");
    var err = getMssg['sale_required_fields'];
    var tarifID = $(".tarifsSale option:selected").val();

        if($("#addClientSale").hasClass('activeTab')){
            var addOrChoose = 'addClientSale';
        }else{
            var addOrChoose = 'selectClientSale';
        }
        
        if ($(".pptpContentDiv").css("display") != "none") {
            var username = $("input[name='username']").val();
            var password = $("input[name='password']").val();
        }
        
        if (addOrChoose == 'addClientSale') {
            var firstN = $("input[name='firstName']").val();
            var surname = $("input[name='surName']").val();
            var patronymicName = $("input[name='patronymicName']").val();
            var contractNumber = $("input[name='contractNumber']").val();
            var mac = $("input[name='mac']").val();
            var model = $(".modelsSale option:selected").val();
        
            if (firstN == '' || surname == '' || mac == '' || model == '') {
                $("#failSale").empty();
                $("#failSale").html(err);
                $("body").css("cursor", "default");
                return false;
            } else if ($(".pptpContentDiv").css("display") != "none") {
                if (username == '' || password == '') {
                    $("#addPassError").empty();
                    $("#addPassError").html(err);
                    $("#addPassError").addClass("errorMessage");
                    $("body").css("cursor", "default");
                    return false;
                }
            } else if ($(".addPasswordFormForSale").css("display") != "none") {
                    if($("#failAddPass").hasClass("errorMessage")){
                        var fail = getMssg['add_sale_faild'];
                        $("#failSale").empty();
                        $("#failSale").addClass("errorMessage");
                        $("#failSale").html(fail);
                        return false;
                    }else if (!$("#failAddPass").hasClass("infoMessage")){
                        var fail = getMssg['add_sale_faild2'];
                        $("#failSale").empty();
                        $("#failSale").addClass("errorMessage");
                        $("#failSale").html(fail);
                        return false;
                    }
                
            } else {
                var checkStatus = '';
                var newModel = $("input[name='newModel']").val();
                if (newModel.trim() != '') {
                    var hwVersion = $("input[name='hwVersion']").val();
                    
                    if(hwVersion == ''){
                        $("#failSale").empty();
                        $("#failSale").html(err);
                        $("body").css("cursor", "default");
                        return false;
                    }
                    
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/checkModelsExists.php",
                        data: { 
                            'modelName': newModel,
                            'fromApp':true 
                        },
                        async: false,
                        success: function (data) {
                            if (data == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                checkStatus = data;
                            }

                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                } else {
                    model = $(".modelsSale option:selected").val();
                    if (model == 0) {
                        var fail = getMssg['add_select_model'];
                        $("#failSale").empty();
                        $("#failSale").html(fail);
                        $("body").css("cursor", "default");
                        return false;
                    }
                }
                if (checkStatus == 'true') {
                    var fail = getMssg['model_exist'];
                    $("#failSale").empty();
                    $("#failSale").html(fail);
                    $("body").css("cursor", "default");
                    return false;
                } else {
                    checkStatus = '';
                    var email = $("input[name='email']").val();
                    if (email == '') {
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/checkMacsExist.php",
                            data: { 
                                'mac': mac,
                                'fromApp':true  
                            },
                            async: false,
                            success: function (data) {
                                if (data == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    checkStatus = data;
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                        if (checkStatus == 'true') {
                            var fail = getMssg['serial_exist'];
                            $("#failSaleError").empty();
                            $("#failSaleError").addClass("errorMessage");
                            $("#failSaleError").html(fail);
                            $("body").css("cursor", "default");
                            return false;
                        } else if (checkStatus == 'false') {
                            $(this).submit();
                        }
                    } else {
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/validateEmailMac.php",
                            data: { 
                                'mac': mac,
                                'email': email,
                                'fromApp':true
                            },
                            async: false,
                            success: function (data) {
                                if(data != '') {
                                    $("#failSaleError").empty();
                                    $("#failSale").empty();
                                    $("#failSale").html(data);
                                    $("body").css("cursor", "default");
                                    return false;
                                } else {
                                    $(this).submit();
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                    }
//                    return false;
                }
            }
        } else {
            var mac = $("input[name='mac']").val();
            var fail = getMssg['sale_part_required_fields'];
            if (mac.trim() == '') {
                $("#failSale").empty();
                $("#failSale").html(err);
                $("body").css("cursor", "default");
                return false;
            }else if ($(".pptpContentDiv").css("display") != "none") {
                if (username == '' || password == '') {
                    $("#addPassError").empty();
                    $("#addPassError").html(fail);
                    $("#addPassError").addClass("errorMessage");
                    $("body").css("cursor", "default");
                    return false;
                }
            } else if ($(".addPasswordFormForSale").css("display") != "none") {
                    if($("#failAddPass").hasClass("errorMessage")){
                        var fail = getMssg['loginPass_Exist'];
                        $("#failSale").empty();
                        $("#failSale").addClass("errorMessage");
                        $("#failSale").html(fail);
                        return false;
                    }else if (!$("#failAddPass").hasClass("infoMessage")){
                        var fail = getMssg['loginPass_Exist'];
                        $("#failSale").empty();
                        $("#failSale").addClass("errorMessage");
                        $("#failSale").html(fail);
                        return false;
                    }
            }
            var checkStatus = '';
            var newModel = $("input[name='newModel']").val();
            if (newModel != '') {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/checkModelsExists.php",
                    data: { 
                        'modelName': newModel,
                        'fromApp':true
                    },
                    async: false,
                    success: function (data) {
                        if (data == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            checkStatus = data;
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            } else {
                var modID = $(".modelsSale option:selected").val();
                if (modID == 0) {
                    var fail = getMssg['add_select_model'];
                    $("#failSale").empty();
                    $("#failSale").html(fail);
                    $("body").css("cursor", "default");
                    return false;
                }
            }
            if (checkStatus == 'true') {
                var fail = getMssg['model_exist'];
                $("#failSale").empty();
                $("#failSale").html(fail);
                $("body").css("cursor", "default");
                return false;
            } else {
                if (mac == '') {
                    var fail = getMssg['mac_required_fields'];
                    $("#failSale").empty();
                    $("#failSale").html(fail);
                    $("body").css("cursor", "default");
                    return false;
                } else {
                    checkStatus = '';
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/checkMacsExist.php",
                        data: { 
                            'mac': mac,
                            'fromApp':true 
                        },
                        async: false,
                        success: function (data) {
                            if (data == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                checkStatus = data;
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                    if (checkStatus == 'true') {
                        var fail = getMssg['serial_exist'];
                        $("#failSaleError").empty();
                        $("#failSaleError").addClass("errorMessage");
                        $("#failSaleError").html(fail);
                        $("body").css("cursor", "default");
                        return false;
                    } else if (checkStatus == 'false') {
                        if ($("input[name='clientID']:checked").length != 0) {
                            var clID = $("input[name='clientID']:checked").val();
                            if (clID == '') {
                                var fail = getMssg['select_client_error'];
                                $("#failSaleError").empty();
                                $("#failSale").empty();
                                $("#failSale").html(fail);
                                $("body").css("cursor", "default");
                                return false;
                            } else {
                                $(this).submit();
                            }
                        } else {
                            var fail = getMssg['select_client_error'];
                            $("#failSaleError").empty();
                            $("#failSale").empty();
                            $("#failSale").html(fail);
                            $("body").css("cursor", "default");
                            return false;
                        }
                    }
                }
            }
        }
	$("#pptponoffswitch").attr('checked', false);
    });  // addSales

    $(document).on("click",".autoGenerateSale",function() {
        var th = $(this);
        if(th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")){
            th.parents('div:eq(4)').find("#showPasswordDiv").show();
        }
    });

    $(document).on('focus','.autoGenerateSale', function(e){
        var th = $(this);
        $(window).keyup(function (e) {
            var key = e.which;
            if (key  == 9) {
                if(th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")){
                    th.parents('div:eq(4)').find("#showPasswordDiv").show();
                }
            }
        });
    });

    $(document).on("click","#autoWlanPassGenerateSale",function() {
        var th = $(this);
        if(th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")){
            th.parents('div:eq(4)').find("#showPasswordDiv").show();
        }
    });

    $(document).on('focus','#autoWlanPassGenerateSale', function(e){
        var th = $(this);
        $(window).keyup(function (e) {
            var key = e.which;
            if (key  == 9) {
                if(th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")){
                    th.parents('div:eq(4)').find("#showPasswordDiv").show();
                }
            }
        });
    });
    
    $(document).on("click", "#autoPassGenerateSale", function () {
        var th = $(this);
        var mac = $("input[name='mac']").val();
        var connection = th.parent().find(".selectAPSale option:selected").text();
//        var fNamePass = $("input[name='firstName']").val();
//        var lNamePass = $("input[name='surName']").val();
//        var res = fNamePass.substr(0, 1);
//        var autoGenUser = res + lNamePass;
//        var UNameGen = document.getElementById('passUserName');
//        UNameGen.value = autoGenUser;

        if(th.parent().find('#showPasswordDiv').is(":hidden")){
            th.parent().find("#showPasswordDiv").show();
        }
   
        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
            data: {
                'mac':mac,
                'fromApp':true,
                'action': 'genPassword'
            },
            async: true,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    switch(connection){
                        case 'PPPoE':
                            th.parent().find('.autoGenerateSale').val(result);
                            break;
                        case 'PPTP':
                            th.parent().find('.autoGenerateSale').val(result);
                            break;
                        case 'L2TP':
                            th.parent().find('.autoGenerateSale').val(result);
                            break;
                        case 'WLAN':
                            th.parent().find('#autoWlanPassGenerateSale').val(result);
                            break;
                        default:
                            break;
                    }
                }
                if (!$("#addSale").valid()) {
                    $('body').css("cursor", "default");
                    return false;
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
	});
        return false;
    });

    $(document).on("click", "#autoPassSaveSale", function () {

        var msgRequird = getMssg['error_message_required'];
        var msgEmpty = getMssg['error_message_empty'];
        var errMsgAtLeast10 = getMssg['error_message_at_least_10'];
        var msgInvalidEmail = getMssg['invalid_email'];
        var msgReqField = getMssg['name_required_field'];



        $('#addSale').validate({
            rules: {
                firstName: {
                    required: true,
                    noSpace: true
                },
                surName: {
                    required: true,
                    noSpace: true
                },
                newModel: {
                    required: true,
                    validateIsEmpty: true
                },
                hwVersion: {
                    required: true,
                    validateIsEmpty: true
                },
                modelId: {
                    validateNotZero: true
                },
                mac: {
                    required: true,
                    validateIsEmpty: true,
                    minlengthMac: true
                },
                username: {
                    required: true,
                    validateIsEmpty: true
                },
                password: {
                    required: true,
                    validateIsEmpty: true
                },
                email: {
                    email: true
                },
                conName: {
                    required: true,
                    validateIsEmpty: true
                },
                passUserName: {
                    required: true,
                    validateIsEmpty: true
                },
                passName: {
                    required: true,
                    validateIsEmpty: true
                },
                ssidName: {
                    required: true,
                    validateIsEmpty: true
                },
                ssidName5GHZ: {
                    required: true,
                    validateIsEmpty: true
                },
                passSSIDName: {
                    required: true,
                    validateIsEmpty: true
                }
            },
            messages: {
                firstName: {
                    required: msgRequird,
                    noSpace: msgReqField
                },
                surName: {
                    required: msgRequird,
                    noSpace: msgReqField
                },
                hwVersion: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                newModel: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                modelId: {
                    validateNotZero: msgRequird
                },
                mac: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty,
                    minlengthMac: errMsgAtLeast10
                },
                username: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                password: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                email: {
                    email: msgInvalidEmail
                },
                conName: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                passUserName: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                passName: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                ssidName: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                ssidName5GHZ: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                passSSIDName: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                }
            },
            errorElement: "div",
            errorClass: 'error_msg_sale',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }

        });

        if (!$("#addSale").valid()) {
            $('body').css("cursor", "default");
            return false;
        }

        var connection = $(this).parent().find(".selectAPSale option:selected").text();
        var th;
        if (connection == "PPPoE") {
            th = $(".ppoeContentForSale");
        } else if (connection == "PPTP") {
            th = $(".pptpContentForSale");
        } else if (connection == "L2TP") {
            th = $(".l2tpContentForSale");
        } else {
            th = $(".wlanContentForSale");
        }
        var connectionName = th.find("input[name='conName']").val();
        var userName = th.find("input[name='passUserName']").val();
        var passName = th.find("input[name='passName']").val();
        var con_type;
        var mac = $("input[name='mac']").val();

        if (connection == "WLAN") {
            con_type = 6;
        }else if(connection == "PPPoE") {
            con_type = 1;
        } else if (connection == "PPTP") {
            con_type = 4;
        } else if (connection == "L2TP") {
            con_type = 5;
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/addSale.php",
            data: {
                'mac': mac,
                'con_type': con_type,
                'actionName': "checkConnection",
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 1){
                    var msgOffOn = getMssg['update_settings'];
                    var titleMsg = getMssg['connection_exists'];
                    var rmMsg =  getMssg['settings_reboot_yes'];
                    var cancelMsg = getMssg['cancel'];
                    swal({
                        title: titleMsg,
                        text: msgOffOn,
                        showCancelButton: true,
                        closeOnConfirm: true,
                        confirmButtonText: rmMsg,
                        cancelButtonText: cancelMsg,
                        confirmButtonColor: "#008DA9"
                    }, function (isConfirm) {
                        if (isConfirm) {
                            saveSale (th, con_type);
                        } else {
                            th.removeAttr("disabled");
                        }
                    });
                } else {
                    saveSale (th, con_type);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });



        //if(mac.trim() != ''){
        function saveSale (th, con_type) {
            if (connection == "WLAN") {


                var ssidName = th.parent().find("input[name='ssidName']").val();
                var ssidName5GHZ = th.parent().find("input[name='ssidName5GHZ']").val();
                var FinalssidName = (ssidName + "\t" + ssidName5GHZ);
                var ssidPass = th.parent().find("input[name='passSSIDName']").val();

                if (mac.trim() != '' && ssidName != '' && ssidPass != '') {
                    if (ssidPass.replace(/\s/g, "").length > 0) {
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/addSale.php",
                            data: {
                                'ssid': FinalssidName,
                                'pass': ssidPass,
                                'mac': mac,
                                'con_type': con_type,
                                'fromApp': true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    if (result.trim() == 'true') {
                                        var fail = getMssg['conn_name_exist'];
                                        $("#failAddPass").empty();
                                        $("#failAddPass").addClass("errorMessage");
                                        $("#failAddPass").html(fail);
                                    } else {
                                        var fail = getMssg['success'];
                                        $("#failAddPass").empty();
                                        $("#failAddPass").removeClass("errorMessage");
                                        $("#failAddPass").addClass("infoMessage");
                                        $("#failAddPass").html(fail);
                                    }
                                }
                            },
                            error: function (xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                    } else {
                        var fail = getMssg['error_message_password'];
                        $("#failAddPass").empty();
                        $("#failAddPass").addClass("errorMessage");
                        $("#failAddPass").html(fail);
                    }
                } else {
                    var fail = getMssg['ssidPass_Exist'];
                    $("#failAddPass").empty();
                    $("#failAddPass").addClass("errorMessage");
                    $("#failAddPass").html(fail);
                }
            } else if (mac.trim() != '' && userName.trim() != '' && passName != '' && connectionName.trim() != '') {
                if (passName.replace(/\s/g, "").length > 0) {
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/addSale.php",
                        data: {
                            'connection_name': connectionName,
                            'login': userName,
                            'pass': passName,
                            'mac': mac,
                            'con_type': con_type,
                            'fromApp': true
                        },
                        async: false,
                        success: function (result) {
                            if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                if (result.trim() == 'true') {
                                    var fail = getMssg['conn_name_exist'];
                                    $("#failAddPass").empty();
                                    $("#failAddPass").addClass("errorMessage");
                                    $("#failAddPass").html(fail);
                                } else {
                                    var fail = getMssg['success'];
                                    $("#failAddPass").empty();
                                    $("#failAddPass").removeClass("errorMessage");
                                    $("#failAddPass").addClass("infoMessage");
                                    $("#failAddPass").html(fail);
                                }
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                } else {
                    var fail = getMssg['error_message_password'];
                    $("#failAddPass").empty();
                    $("#failAddPass").addClass("errorMessage");
                    $("#failAddPass").html(fail);
                }
            } else {
                var fail = getMssg['loginPass_Exist'];
                $("#failAddPass").empty();
                $("#failAddPass").addClass("errorMessage");
                $("#failAddPass").html(fail);
            }
        }
        //}else{
        //    var fail = $('#macRequiredFields').val();
        //    $("#failAddPass").empty();
        //    $("#failAddPass").addClass("errorMessage");
        //    $("#failAddPass").html(fail);
        //}
        return false;
    });
    
    $(document).on("click", "#searchClientForSale", function () {
        $("body").css("cursor", "wait");
        var firstName = $("input[name='searchFirstName']").val().trim();
        var surName = $("input[name='searchSurName']").val().trim();
        var patName = $("input[name='searchPatronymicName']").val().trim();
        var contNum = $("input[name='searchContractNumber']").val().trim();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientsForSale.php",
            data: { 
                'firstName': firstName,
                'surName': surName,
                'patName': patName,
                'contNum': contNum,
                'page': 1,
                'fromApp':true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#searchedClientsForSale").empty();
                    $("#searchedClientsForSale").html(data);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
    $("#searchedClientsForSale").on("click", ".eachClientPage", function () {
        $("body").css("cursor", "wait");
        var firstName = $("input[name='searchFirstName']").val();
        var surName = $("input[name='searchSurName']").val();
        var page = $(this).find("input[name='page']").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientsForSale.php",
            data: {
                'firstName': firstName,
                'surName': surName,
                'page': page,
                'fromApp':true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#searchedClientsForSale").empty();
                    $("#searchedClientsForSale").html(data);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
});
