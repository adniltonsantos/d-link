$(document).ready(function () {
    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {
            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $('.fieids').on('ifChecked ifUnchecked', function(event){
        var $FileID = $(this).closest('tr').find("input[name='removeLog']").val();
        if (event.type == 'ifChecked') {
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');

            if(!$(this).hasClass('allFields')){
                $checked_array.push($FileID);
            }
            if($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds){
                $('#all_fields').prop('checked',true).iCheck('update');
            }
            console.log($checked_array);
        } else {

            if($('#all_fields').is(':checked')){
                $('#all_fields').prop('checked',false).iCheck('update');
            }

            if(!$('.forFieldsCheck').find('.fieids').is(':checked')){
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
//                console.log($checked_array);
            }
            $checked_array.removeByVal($FileID);
//            console.log($checked_array);
            $(this).closest('tr').css("background-color", "#FFFFFF");
            console.log($checked_array);

        }
    });

    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }
});

$(document).on("click", ".trash20", function (){
    var msg = getMssg['msg_remove_config'];
    var titleMsg = getMssg['title_msg'];
    var rmMsg =  getMssg['remove_msg'];
    var cancelMsg = getMssg['cancel'];
    swal({
        title: titleMsg,
        text: msg,
        showCancelButton: true,
        closeOnConfirm: true,
        confirmButtonText: rmMsg,
        cancelButtonText: cancelMsg,
        confirmButtonColor: "#008DA9"
    }, function() {
        removeFiles($checked_array);
    });
});

function removeFiles(fileName) {
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/functions.php",
        data: {
            'functionName' : 'removeAllFile',
            'fileName': fileName,
            'fromApp': true
        },
        async: false,
        success: function (result) {
            location.reload(true);
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}
