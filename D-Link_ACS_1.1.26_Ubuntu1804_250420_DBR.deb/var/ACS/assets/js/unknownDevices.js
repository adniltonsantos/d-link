//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg = result;
//            }
//        }
//    });
//    return retMsg;
//}

var allPandingsIds = new Array();

$(document).ready(function () {

    $basepath = $('#basepath').data('bpath');
    var token_cookie = $("input[name='token_cookie']").val();
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });

    function filterUnknowns(sort, searchElem, searchElemVal, model, page, searchResult, from) {
        $("body").css("cursor", "wait");
        if (searchElem == "" || searchElem != "" && searchElemVal == "") {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/nextUnknownsPage.php",
                data: {
                    'page': page,
                    'model': model,
                    'sortVal': sort,
                    'fromApp': from
                },
                async: true,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        $("#" + searchResult).empty();
                        $("#" + searchResult).html(data);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if (searchElem == "ip" && searchElemVal != "") {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/nextUnknownsPage.php",
                data: {
                    'ip': searchElemVal,
                    'page': page,
                    'model': model,
                    'sortVal': sort,
                    'fromApp': from
                },
                async: true,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        $("#" + searchResult).empty();
                        $("#" + searchResult).html(data);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if (searchElem == "mac" && searchElemVal != "") {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/nextUnknownsPage.php",
                data: {
                    'mac': searchElemVal,
                    'page': page,
                    'model': model,
                    'sortVal': sort,
                    'fromApp': from
                },
                async: true,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        $("#" + searchResult).empty();
                        $("#" + searchResult).html(data);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if (searchElem == "client" && searchElemVal != "") {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/nextUnknownsPage.php",
                data: {
                    'client': searchElemVal,
                    'page': page,
                    'model': model,
                    'sortVal': sort,
                    'fromApp': from
                },
                async: true,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        $("#" + searchResult).empty();
                        $("#" + searchResult).html(data);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    }

    $(document).on("click", ".unknown-dev", function () {
        if ($("#forUnknownsList").css("display") == "none") {
            $('.pending-dev').removeClass('unknownButtActive');
            $('.unknown-dev').addClass('unknownButtActive');
            $("#forUnknownsList").show();
            $('#unknownDevicehead').show();
            $("#forPendingList").hide();
            $('#pendingDevicehead').hide();
        }
    });

    $(document).on("click", ".pending-dev", function () {
        if ($("#forPendingList").css("display") == "none") {
            $('.unknown-dev').removeClass('unknownButtActive');
            $('.pending-dev').addClass('unknownButtActive');
            $("#forPendingList").show();
            $('#pendingDevicehead').show();
            $("#forUnknownsList").hide();
            $('#unknownDevicehead').hide();
        }
    });

    $(document).on("change", ".searchUnknownType", function () {
        var searchTypeVal = $(".searchUnknownType option:selected").val();
        if (searchTypeVal == 'ip') {
            $("#unknownDevicehead").find(".linkForSearchDev").attr("id", "searchUnknownByIp");
        } else if (searchTypeVal == 'mac') {
            $("#unknownDevicehead").find(".linkForSearchDev").attr("id", "searchUnknownByMac");
        }
    });

    $("#unknownDevicehead").on("click", ".linkForSearchDev", function () {
        var th = $(this);
        var clientInfo = $(this).parent().find("input[name='clientInfo']").val();
        var page = 1;
        var modelID = $(".modelTypeUn option:selected").val();
        $("body").css("cursor", "wait");
        if (th.attr("id") == 'searchUnknownByIp') {
            filterUnknowns("", "ip", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');

        } else if (th.attr("id") == 'searchUnknownByMac') {

            filterUnknowns("", "mac", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');
        }
        setDefaultSortValsUnknowns($("#sortUnknowns"));
    });


    $("#unknownDevicehead").on("change", ".modelTypeUn", function () {
        unknownDeviceSearch();
    });

    $("#unknownDevicehead").on("keypress", "input[name='clientInfo']", function (e) {
        var key = e.which;

        if (key == 13) { // the enter key code
            unknownDeviceSearch();
            return false;
        }
    });

    function unknownDeviceSearch() {
        var page = 1;
        var modelID = $(".modelTypeUn option:selected").val();
        var searchElem = $(".linkForSearchDev");
        var clientInfoVal = $("#unknownDevicehead").find("input[name='clientInfo']").val();

        if (searchElem.attr("id") == 'searchUnknownByIp') {

            filterUnknowns('', "ip", clientInfoVal, modelID, page, 'forUnknownsSearchResult', 'unknown');

        } else if (searchElem.attr("id") == 'searchUnknownByMac') {

            filterUnknowns('', "mac", clientInfoVal, modelID, page, 'forUnknownsSearchResult', 'unknown');
        }

        setDefaultSortValsUnknowns($("#sortUnknowns"));

    }

    $(document).on("change", ".searchPendingType", function () {
        var searchTypeVal = $(".searchPendingType option:selected").val();
        if (searchTypeVal == 'ip') {
            $("#pendingDevicehead").find(".linkForPendingSearchDev").attr("id", "searchUnknownByIp");
        } else if (searchTypeVal == 'mac') {
            $("#pendingDevicehead").find(".linkForPendingSearchDev").attr("id", "searchUnknownByMac");
        } else if (searchTypeVal == 'client') {
            $("#pendingDevicehead").find(".linkForPendingSearchDev").attr("id", "searchUnknownByClient");
        }
    });

    $("#pendingDevicehead").on("click", ".linkForPendingSearchDev", function () {
        var th = $(this);
        var clientInfo = $(this).parent().find("input[name='clientInfo']").val();
        var page = 1;
        var modelID = $(".pendingModelType option:selected").val();
        $("body").css("cursor", "wait");
        if (th.attr("id") == 'searchUnknownByIp') {

            filterUnknowns('', "ip", clientInfo, modelID, page, 'forPendingsSearchResult', 'pending');

        } else if (th.attr("id") == 'searchUnknownByMac') {

            filterUnknowns('', "mac", clientInfo, modelID, page, 'forPendingsSearchResult', 'pending');

        } else if (th.attr("id") == 'searchUnknownByClient') {

            filterUnknowns('', "client", clientInfo, modelID, page, 'forPendingsSearchResult', 'pending');
        }

        setDefaultSortValsPendings($("#sortPending"));
    });

    $('#pendingDevicehead').on("change", ".pendingModelType", function () {
        pendingDeviceSearch();
    });

    $("#pendingDevicehead").on("keypress", "input[name='clientInfo']", function (e) {
        var key = e.which;

        if (key == 13) { // the enter key code
            pendingDeviceSearch();
            return false;
        }
    });


    function pendingDeviceSearch() {
        var page = 1;
        var model = $(".pendingModelType option:selected").val();
        var searchElem = $(".linkForPendingSearchDev");
        var clientInfoVal = $("#pendingDevicehead").find("input[name='clientInfo']").val();

        if (searchElem.attr("id") == 'searchUnknownByIp') {
            filterUnknowns('', "ip", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');
        } else if (searchElem.attr("id") == 'searchUnknownByMac') {

            filterUnknowns('', "mac", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');

        } else if (searchElem.attr("id") == 'searchUnknownByClient') {

            filterUnknowns('', "client", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');
        }

        setDefaultSortValsPendings($("#sortPending"));
    }

    $("#forUnknownsList").on("click", ".connectToClient", function () {
        var th = $(this);
        if (th.closest('tr').next('tr').find('#searchedClients').is(':visible')) {
            setTimeout(function () {
                th.closest('tr').next('tr').find("#searchedClients").empty();
                th.closest('tr').next('tr').find(".unknownConnection").hide();
            }, 1000);
        }

        if (th.closest('tr').next('tr').find('#createNewClient').is(':visible')) {
            setTimeout(function () {
                th.closest('tr').next('tr').find("#createNewClient").empty();
                th.closest('tr').next('tr').find(".unknownConnection").hide();
            }, 1000);
        }
    });

    $("#forUnknownsList").on("click", ".connectToClients", function () {

        $(".searchClientsForAdd").css("display", "block");
    });

    $("#forUnknownsList").on("click", "#searchClientForSale", function () {
        $("body").css("cursor", "wait");
        var th = $(this);
        var firstName = th.parent().find("input[name='searchFirstName']").val().trim();
        var surName = th.parent().find("input[name='searchSurName']").val().trim();
        var address = th.parent().find("input[name='address']").val().trim();
        var email = th.parent().find("input[name='email']").val().trim();
        var contractNumber = th.parent().find("input[name='searchContractNumber']").val().trim();


        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientsForSale.php",
            data: {
                'firstName': firstName,
                'surName': surName,
                'address': address,
                'email': email,
                'contNum': contractNumber,
                'page': 1,
                'needTarif': true,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    th.closest('td').find("#searchedClients").empty();
                    th.closest('td').find("#searchedClients").html(data);
                    th.closest('td').find("#searchedClients").show();
                    if ($("input[name='clientID']").length > 0) {
                        th.closest('td').find(".passwordForm").trigger('reset');
                        th.closest('td').find("#showPasswordDiv").hide();
                        th.closest('td').find("#failAddPass").empty();
                        th.closest('td').find("input[name='forCheckPass']").attr('checked', false);
                        th.closest('td').find("input[name='useTarif']").attr('checked', false);
                        $('.templateChoose option[value="0"]').attr("selected", true);
                        $('.connGroupSelect option[value="-1"]').attr("selected", true);
                        th.closest('td').find(".addPasswordForm").hide();
                        th.closest('td').find(".selectTemplate").hide();
                        th.closest('td').find(".unknownConnection").show();
                    } else {
                        th.closest('td').find(".unknownConnection").hide();
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $("#forUnknownsList").on("click", "#searchClientForAdd", function () {
        $("body").css("cursor", "wait");
        var th = $(this);
        var firstName = th.parent().find("input[name='searchFirstName']").val();
        var surName = th.parent().find("input[name='searchSurName']").val();
        var address = th.parent().find("input[name='address']").val().trim();
        var email = th.parent().find("input[name='email']").val().trim();
        var contractNumber = th.parent().find("input[name='searchContractNumber']").val().trim();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientsForSale.php",
            data: {
                'firstName': firstName,
                'surName': surName,
                'address': address,
                'email': email,
                'contNum': contractNumber,
                'page': 1,
                'needTarif': true,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#searchedClientsToAdd").empty();
                    $("#searchedClientsToAdd").html(data);
                    $("#searchedClientsToAdd").show();
                    if ($("input[name='clientID']").length > 0) {
                        $(".passwordForm").trigger('reset');
                        $("#showPasswordDiv").hide();
                        $("#failAddPass").empty();
                        $("input[name='forCheckPass']").attr('checked', false);
                        $("input[name='useTarif']").attr('checked', false);
                        $('.templateChoose option[value="0"]').attr("selected", true);
                        $('.connGroupSelect option[value="-1"]').attr("selected", true);
                        $(".addPasswordForm").hide();
                        $(".selectTemplate").hide();
                        $(".unknownConnection1").show();
                    } else {
                        $(".unknownConnection1").hide();
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

//----------------------- pagination for searched clients-----------------------

    $(document).on("click", ".eachClientPage", function () {
        $("body").css("cursor", "wait");
        var th = $(this);
        var firstName = th.closest('td').find("input[name='searchFirstName']").val();
        var surName = th.closest('td').find("input[name='searchSurName']").val();
        var page = $(this).find("input[name='page']").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientsForSale.php",
            data: {
                'firstName': firstName,
                'surName': surName,
                'page': page,
                'needTarif': true,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    var serchedDiv = th.closest('td').find("#searchedClients");
                    serchedDiv.empty();
                    serchedDiv.html(data);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

//------------------------------ end pagination --------------------------------    

    $(document).on("click", "input[name='useTarif']", function () {
        if ($(this).is(":checked")) {
            $(this).closest('td').find(".selectTemplate").show();
        } else {
            $(this).closest('td').find(".selectTemplate").hide();
        }
    });

    $(document).on("click", "input[name='useTarif1']", function () {
        if ($(this).is(":checked")) {
            $(".selectTemplate").show();
        } else {
            $(".selectTemplate").hide();
        }
    });

    $(document).on("click", "input[name='forCheckPass']", function () {
        if ($(this).is(":checked")) {
            $(this).closest('td').find(".addPasswordForm").show();
        } else {
            $(this).closest('td').find(".addPasswordForm").hide();
        }
    });

    $(document).on("click", "input[name='forCheckPass1']", function () {
        if ($(this).is(":checked")) {
            $(".addPasswordForm1").show();
        } else {
            $(".addPasswordForm1").hide();
        }
    });

    $(document).on("change", ".selectAP", function () {
        var connection = $(this).find("option:selected").text();
        $(this).closest('td').find("#failAddPass").empty();
        if (connection == "WLAN") {
            $(this).closest('td').find(".ppoeContent").hide();
            $(this).closest('td').find(".pptpContent").hide();
            $(this).closest('td').find(".l2tpContent").hide();
            $(this).closest('td').find(".wlanContent").show();
            $(this).closest('td').find("#showPasswordDiv").hide();
            $(this).closest('td').find("input[name='chkShow']").attr('checked', false);
            $(this).closest('td').find('#autoGenerateUnknown').prop('type', 'password');
            //$(this).closest('td').find('#autoGenerateUnknown').val('');
            $(this).closest('td').find('#autoWlanPassGenerateUnknown').prop('type', 'password');
            //$(this).closest('td').find('#autoWlanPassGenerateUnknown').val('');
            //$(this).closest('td').find("input[name='userName']").val('');
            //$(this).closest('td').find("input[name='conName']").val('');
        } else if (connection == "PPPoE") {
            $(this).closest('td').find(".ppoeContent").show();
            $(this).closest('td').find(".pptpContent").hide();
            $(this).closest('td').find(".l2tpContent").hide();
            $(this).closest('td').find(".wlanContent").hide();
            $(this).closest('td').find("#showPasswordDiv").hide();
            $(this).closest('td').find("input[name='chkShow']").attr('checked', false);
            $(this).closest('td').find('#autoGenerateUnknown').prop('type', 'password');
            //$(this).closest('td').find('#autoGenerateUnknown').val('');
            $(this).closest('td').find('#autoWlanPassGenerateUnknown').prop('type', 'password');
            //$(this).closest('td').find('#autoWlanPassGenerateUnknown').val('');
            //$(this).closest('td').find("input[name='userName']").val('');
            //$(this).closest('td').find("input[name='ssidName']").val('');

        } else if (connection == "PPTP") {
            $(this).closest('td').find(".pptpContent").show();
            $(this).closest('td').find(".ppoeContent").hide();
            $(this).closest('td').find(".l2tpContent").hide();
            $(this).closest('td').find(".wlanContent").hide();
            $(this).closest('td').find("#showPasswordDiv").hide();
            $(this).closest('td').find("input[name='chkShow']").attr('checked', false);
            $(this).closest('td').find('.autoGenerateUnknownPPTP').prop('type', 'password');
            $(this).closest('td').find('#autoWlanPassGenerateUnknown').prop('type', 'password');
        } else if (connection == "L2TP") {
            $(this).closest('td').find(".pptpContent").hide();
            $(this).closest('td').find(".ppoeContent").hide();
            $(this).closest('td').find(".l2tpContent").show();
            $(this).closest('td').find(".wlanContent").hide();
            $(this).closest('td').find("#showPasswordDiv").hide();
            $(this).closest('td').find("input[name='chkShow']").attr('checked', false);
            $(this).closest('td').find('.autoGenerateUnknownL2TP').prop('type', 'password');
            $(this).closest('td').find('#autoWlanPassGenerateUnknown').prop('type', 'password');
        }
    });

    $(document).on("change", ".selectAP1", function () {
        var connection = $(this).find("option:selected").text();
        $("#failAddPass").empty();
        if (connection == "WLAN") {
            $(".ppoeContent").hide();
            $(".pptpContent").hide();
            $(".l2tpContent").hide();
            $(".wlanContent").show();
            $("#showPasswordDiv").hide();
            $("input[name='chkShow']").attr('checked', false);
            $('#autoGenerateUnknown').prop('type', 'password');
            $('#autoWlanPassGenerateUnknown').prop('type', 'password');
        } else if (connection == "PPPoE") {
            $(".ppoeContent").show();
            $(".pptpContent").hide();
            $(".l2tpContent").hide();
            $(".wlanContent").hide();
            $("#showPasswordDiv").hide();
            $("input[name='chkShow']").attr('checked', false);
            $('#autoGenerateUnknown').prop('type', 'password');
            $('#autoWlanPassGenerateUnknown').prop('type', 'password');
        } else if (connection == "PPTP") {
            $(".pptpContent").show();
            $(".ppoeContent").hide();
            $(".l2tpContent").hide();
            $(".wlanContent").hide();
            $("#showPasswordDiv").hide();
            $("input[name='chkShow']").attr('checked', false);
            $('.autoGenerateUnknownPPTP').prop('type', 'password');
            $('#autoWlanPassGenerateUnknown').prop('type', 'password');
        } else if (connection == "L2TP") {
            $(".pptpContent").hide();
            $(".ppoeContent").hide();
            $(".l2tpContent").show();
            $(".wlanContent").hide();
            $("#showPasswordDiv").hide();
            $("input[name='chkShow']").attr('checked', false);
            $('.autoGenerateUnknownL2TP').prop('type', 'password');
            $('#autoWlanPassGenerateUnknown').prop('type', 'password');
        }
    });

    $(document).on("change", "input[name='chkShow']", function () {
        var th = $(this);
        var connection = th.parents('div:eq(4)').find(".selectAP option:selected").text();
        if (connection == 'PPPoE') {
            if (this.checked) {
                th.parents('div:eq(4)').find('#autoGenerateUnknown').prop('type', 'text');
            } else {
                th.parents('div:eq(4)').find('#autoGenerateUnknown').prop('type', 'password');
            }
        } else if (connection == 'WLAN') {
            if (this.checked) {
                th.parents('div:eq(4)').find('#autoWlanPassGenerateUnknown').prop('type', 'text');
            } else {
                th.parents('div:eq(4)').find('#autoWlanPassGenerateUnknown').prop('type', 'password');
            }
        } else if (connection == 'PPTP') {
            if (this.checked) {
                th.parents('div:eq(4)').find('.autoGenerateUnknownPPTP').prop('type', 'text');
            } else {
                th.parents('div:eq(4)').find('.autoGenerateUnknownPPTP').prop('type', 'password');
            }
        } else if (connection == 'L2TP') {
            if (this.checked) {
                th.parents('div:eq(4)').find('.autoGenerateUnknownL2TP').prop('type', 'text');
            } else {
                th.parents('div:eq(4)').find('.autoGenerateUnknownL2TP').prop('type', 'password');
            }
        }
    });

    $(document).on("click", "#autoGenerateUnknown", function () {
        var th = $(this);
        if (th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")) {
            th.parents('div:eq(4)').find("#showPasswordDiv").show();
        }
    });

    $(document).on("click", ".autoGenerateUnknownPPTP", function () {
        var th = $(this);
        if (th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")) {
            th.parents('div:eq(4)').find("#showPasswordDiv").show();
        }
    });
    $(document).on("click", ".autoGenerateUnknownL2TP", function () {
        var th = $(this);
        if (th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")) {
            th.parents('div:eq(4)').find("#showPasswordDiv").show();
        }
    });


    $(document).on('focus', '#autoGenerateUnknown', function (e) {
        var th = $(this);
        $(window).keyup(function (e) {
            var key = e.which;
            if (key == 9) {
                if (th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")) {
                    th.parents('div:eq(4)').find("#showPasswordDiv").show();
                }
            }
        });
    });

    $(document).on("click", "#autoWlanPassGenerateUnknown", function () {
        var th = $(this);
        if (th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")) {
            th.parents('div:eq(4)').find("#showPasswordDiv").show();
        }
    });

    $(document).on('focus', '#autoWlanPassGenerateUnknown', function (e) {
        var th = $(this);
        $(window).keyup(function (e) {
            var key = e.which;
            if (key == 9) {
                if (th.parents('div:eq(4)').find('#showPasswordDiv').is(":hidden")) {
                    th.parents('div:eq(4)').find("#showPasswordDiv").show();
                }
            }
        });
    });

    $(document).on("click", ".autoPassGenerateUnknown", function (e) {
        e.preventDefault();
        var th = $(this);
        if (th.parent().find('#showPasswordDiv').is(":hidden")) {
            th.parent().find("#showPasswordDiv").show();
        }
        var unMAC = th.parent().find("input[name='unknownMac']").val();
        var connection = th.parent().find(".selectAP option:selected").text();
        generetePassword(th, unMAC, connection);

    });

    $(document).on("click", ".generateUserName", function (e) {
        e.preventDefault();
        var th = $(this);
        var unMAC = th.parent().closest('td').find("input[name='unknownMac']").val();
        var connection = th.parent().closest('td').find(".selectAP option:selected").text();
        generateUserName(th, unMAC, connection);

    });

    $(document).on("click", ".generatePassword", function (e) {
        e.preventDefault();
        var th = $(this);
        if (th.closest('td').find('#showPasswordDiv').is(":hidden")) {
            th.parent().closest('td').find("#showPasswordDiv").show();
        }
        var unMAC = th.closest('td').find("input[name='unknownMac']").val();
        var connection = th.closest('td').find(".selectAP option:selected").text();
        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
            data: {
                'mac': unMAC,
                'fromApp': true,
                'action': 'genPassword'
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    switch (connection) {
                        case 'PPPoE':
                            th.parent().find('#autoGenerateUnknown').val(result);
                            break;
                        case 'PPTP':
                            th.parent().find('.autoGenerateUnknownPPTP').val(result);
                            break;
                        case 'L2TP':
                            th.parent().find('.autoGenerateUnknownL2TP').val(result);
                            break;
                        case 'WLAN':
                            th.parent().find('#autoWlanPassGenerateUnknown').val(result);
                            break;
                        default:
                            break;
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });

    });

    function generetePassword(th, unMAC, connection) {
        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
            data: {
                'mac': unMAC,
                'fromApp': true,
                'action': 'genPassword'
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    switch (connection) {
                        case 'PPPoE':
                            th.parent().find('#autoGenerateUnknown').val(result);
                            break;
                        case 'PPTP':
                            th.parent().find('.autoGenerateUnknownPPTP').val(result);
                            break;
                        case 'L2TP':
                            th.parent().find('.autoGenerateUnknownL2TP').val(result);
                            break;
                        case 'WLAN':
                            th.parent().find('#autoWlanPassGenerateUnknown').val(result);
                            break;
                        default:
                            break;
                    }
                    generateUserName(th, unMAC, connection);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function generateUserName(th, unMAC, connection) {
        if (th.closest('td').find("input[name='clientID']:checked").length != 0) {
            var clientID = th.closest('td').find("input[name='clientID']:checked").val();

            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
                data: {
                    'clientId': clientID,
                    'action': 'genUsernameUnknown',
                    'fromApp': true
                },
                async: true,
                success: function (output) {
                    // generate username
                    var mix = output.split(" ");
                    if (connection == 'PPPoE') {
                        th.parent().find("input[name='userName']").val(mix[0][0] + mix[1]);
                    } else if (connection == 'PPTP') {
                        th.parent().find("input[name='userNamePPTP']").val(mix[0][0] + mix[1]);
                    } else if (connection == 'L2TP') {
                        th.parent().find("input[name='userNameL2TP']").val(mix[0][0] + mix[1]);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else {
            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
                data: {
                    'mac': unMAC,
                    'fromApp': true,
                    'action': 'genPassword'
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        switch (connection) {
                            case 'PPPoE':
                                th.parent().find("input[name='userName']").val(result);
                                break;
                            case 'PPTP':
                                th.parent().find("input[name='userNamePPTP']").val(result);
                                break;
                            case 'L2TP':
                                th.parent().find("input[name='userNameL2TP']").val(result);
                                break;
                            default:
                                break;
                        }
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    }

    $(document).on("click", ".autoPassSaveUnknown", function (e) {
        e.preventDefault();
        var th = $(this);
        var connectionName;
        var userName;
        var passName;
        var connection = th.parent().find(".selectAP option:selected").text();
        var con_type;
        var mac = $(this).parent().find("input[name='unknownMac']").val();
        if (connection == "WLAN") {
            var ssidName = th.parent().find("input[name='ssidName']").val();
            var ssidPass = th.parent().find("input[name='passSSIDName']").val();
            con_type = 6;

            if (ssidName != '' && ssidPass != '') {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/addSale.php",
                    data: {
                        'ssid': ssidName,
                        'pass': ssidPass,
                        'mac': mac,
                        'con_type': con_type,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            if (result.trim() == 'true') {
                                var fail = getMssg['conn_name_exist'];
                                th.parent().find("#failAddPass").empty();
                                th.parent().find("#failAddPass").addClass("errorMessage");
                                th.parent().find("#failAddPass").html(fail);
                            } else {
                                var fail = getMssg['success'];
                                th.parent().find("#failAddPass").empty();
                                th.parent().find("#failAddPass").removeClass("errorMessage");
                                th.parent().find("#failAddPass").addClass("infoMessage");
                                th.parent().find("#failAddPass").html(fail);
                            }
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            } else {
                var fail = getMssg['ssidPass_ExistUn'];
                th.parent().find("#failAddPass").empty();
                th.parent().find("#failAddPass").addClass("errorMessage");
                th.parent().find("#failAddPass").html(fail);
            }
        } else {
            if (connection == "PPPoE") {
                con_type = 1;
                connectionName = th.parent().find("input[name='conName']").val();
                userName = th.parent().find("input[name='userName']").val();
                passName = th.parent().find("input[name='passName']").val();
            } else if (connection == "PPTP") {
                con_type = 4;
                connectionName = th.parent().find("input[name='conNamePPTP']").val();
                userName = th.parent().find("input[name='userNamePPTP']").val();
                passName = th.parent().find("input[name='passNamePPTP']").val();
            } else if (connection == "L2TP") {
                con_type = 5;
                connectionName = th.parent().find("input[name='conNameL2TP']").val();
                userName = th.parent().find("input[name='userNameL2TP']").val();
                passName = th.parent().find("input[name='passNameL2TP']").val();
            }

            if (userName != '' && passName != '') {

                if (connectionName != '') {
                    if (userName.replace(/\s/g, "").length > 0 && passName.replace(/\s/g, "").length > 0 && connectionName.replace(/\s/g, "").length > 0) {
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/addSale.php",
                            data: {
                                'connection_name': connectionName,
                                'login': userName,
                                'pass': passName,
                                'mac': mac,
                                'con_type': con_type,
                                'fromApp': true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    if (result.trim() == 'true') {
                                        var fail = getMssg['conn_name_exist'];
                                        th.parent().find("#failAddPass").empty();
                                        th.parent().find("#failAddPass").addClass("errorMessage");
                                        th.parent().find("#failAddPass").html(fail);
                                    } else {
                                        var fail = getMssg['success'];
                                        th.parent().find("#failAddPass").empty();
                                        th.parent().find("#failAddPass").removeClass("errorMessage");
                                        th.parent().find("#failAddPass").addClass("infoMessage");
                                        th.parent().find("#failAddPass").html(fail);
                                    }
                                }
                            },
                            error: function (xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                    } else {
                        var failPass = getMssg['unknown_dev_fields'];
                        th.parent().find("#failAddPass").empty();
                        th.parent().find("#failAddPass").addClass("errorMessage");
                        th.parent().find("#failAddPass").html(failPass);
                    }
                } else {
                    var fail = getMssg['group_required_fields'];
                    th.parent().find("#failAddPass").empty();
                    th.parent().find("#failAddPass").addClass("errorMessage");
                    th.parent().find("#failAddPass").html(fail);
                }
            } else {
                var fail = getMssg['loginPass_ExistUn'];
                th.parent().find("#failAddPass").empty();
                th.parent().find("#failAddPass").addClass("errorMessage");
                th.parent().find("#failAddPass").html(fail);
            }
        }
        return false;
    });

    $("#forUnknownsList").on("click", "#connectClient", function () {
        var th = $(this);
        var devID = th.parent().find("input[name='unknownID']").val();
        var groupID = th.closest('td').find(".connGroupSelect option:selected").val();
        $("body").css("cursor", "wait");
        if (th.closest('td').find("input[name='clientID']:checked").length == 0) {
            var select_client = getMssg['select_client'];
            $("#errConnectForUnknowns").removeClass("infoMessage");
            $("#errConnectForUnknowns").addClass("errorMessage");
            $("#errConnectForUnknowns").empty();
            $("#errConnectForUnknowns").html(select_client);
            $("body").css("cursor", "default");
        } else {
            var clientID = th.closest('td').find("input[name='clientID']:checked").val();
            var useTarif = th.closest('tr').find("input[name='useTarif']").is(":checked");
            var tarifId = 0;
            if (useTarif) {
                tarifId = th.closest('tr').find(".templateChoose option:selected").val();
                if (tarifId == 0) {
                    var select_client = getMssg['not_select_template'];
                    $("#errConnectForUnknowns").removeClass("infoMessage");
                    $("#errConnectForUnknowns").addClass("errorMessage");
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(select_client);
                    $("body").css("cursor", "default");
                } else {
                    connectToUnknown(clientID, devID, groupID, tarifId);
                }
            } else {
                connectToUnknown(clientID, devID, groupID, tarifId);
            }
        }
    });

    function connectToUnknown(clientId, devID, groupID, tarifId) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/connectUnknownToClient.php",
            data: {
                'token': token_cookie,
                'method': 'connectToClient',
                'groupID': groupID,
                'clientID': clientId,
                'devID': devID,
                'templateID': tarifId,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                // var result = JSON.parse(data);
                if (data == "true") {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("errorMessage");
                    $("#errConnectForUnknowns").addClass("infoMessage");
                    var success = getMssg['connect_succeedUnDev'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 3000);
                } else if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("infoMessage");
                    $("#errConnectForUnknowns").addClass("errorMessage");
                    var failed = getMssg['connect_failed'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(failed);
                    // setTimeout(function () {
                    // location.reload(true);
                    // }, 1000);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        /*$.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/connectUnknownToClient.php",
            data: {
                'groupID': groupID,
                'clientID': clientId,
                'devID': devID,
                'tarifID': tarifId,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (data == 'true') {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("errorMessage");
                    $("#errConnectForUnknowns").addClass("infoMessage");
                    var success = getMssg['connect_succeedUnDev'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 3000);
                } else if (data == 'false') {
                    $("body").css("cursor", "default");
                    $("#errConnectForUnknowns").removeClass("infoMessage");
                    $("#errConnectForUnknowns").addClass("errorMessage");
                    var failed = getMssg['connect_failed'];
                    $("#errConnectForUnknowns").empty();
                    $("#errConnectForUnknowns").html(failed);
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });*/
    }

    $(document).on("click", ".removeUnDevice", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
            th.css("opacity", "0.5");
            th.css("cursor", "default");
            var msg = getMssg['remove_device_msg'];
            var devID = th.parent().find("input[name='unknownID']").val();
            var titleMsg = getMssg['title_msg'];
            var rmMsg = getMssg['remove_msg'];
            var cancelMsg = getMssg['cancel'];
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function (isConfirm) {
                if (isConfirm) {
                    $("body").css("cursor", "wait");
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                        data: {
                            'devId': devID,
                            'actionName': 'removeUnknownDevice',
                            'fromApp': true
                        },
                        async: false,
                        success: function (result) {
                            if (result == 'true') {
                                var success = getMssg['connect._succeed'];
                                $("#errConnectForUnknowns").removeClass("errorMessage");
                                $("#errConnectForUnknowns").addClass("infoMessage");
                                $("#errConnectForUnknowns").empty();
                                $("#errConnectForUnknowns").html(success);
                                setTimeout(function () {
                                    location.reload(true);
                                }, 10000);
                            } else if (result == 'false') {
                                var failed = getMssg['action_failed'];
                                $("#errConnectForUnknowns").removeClass("infoMessage");
                                $("#errConnectForUnknowns").addClass("errorMessage");
                                $("#errConnectForUnknowns").empty();
                                $("#errConnectForUnknowns").html(failed);
                                $("body").css("cursor", "default");
                                setTimeout(function () {
                                    location.reload(true);
                                }, 10000)
                            } else if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                } else {
                    th.removeAttr("disabled");
                    th.css("opacity", "1");
                    th.css("cursor", "pointer");
                }
            });
        }
    });

//--------------------- pagination for unknownDevices --------------------------

    $(document).on("click", ".eachUnknownPage", function () {
        $("body").css("cursor", "wait");
        var page = $(this).find("input[name='page']").val();
        var modelID = $(".modelTypeUn option:selected").val();
        var searchElem = $(".linkForSearchDev");
        var clientInfo = $(this).parent().find("input[name='clientInfo']").val();
        var sortVal = $("#sortUnknowns option:selected").val();


        var sortBy = $(".sort_unknown_by").attr("id");

        if (sortBy == "DESC") {
            sortBy = "ASC";
        } else {
            sortBy = "DESC";
        }

        sortVal = sortVal + ":" + sortBy;

        if (searchElem.attr("id") == 'searchUnknownByIp') {
            filterUnknowns(sortVal, "ip", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');

        } else if (searchElem.attr("id") == 'searchUnknownByMac') {
            filterUnknowns(sortVal, "mac", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');
        }
    });

//-------------------- for panding devices -------------------------------------


    $(document).on("click", "#resendTask", function () {
        var th = $(this);
        var devID = th.parent().find("input[name='unknownID']").val();
        resendTaskPendingDevice(th, devID);
    });

    $(document).on("click", ".resend-all", function () {
        var th = $(this);
        var devIDs = allPandingsIds;
        resendTaskPendingDevice(th, devIDs);
    });

    function resendTaskPendingDevice(th, id) {
        if (th.attr("disabled") != "disabled") {
            if ($.isArray(id)) {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': id,
                        'actionName': "resend",
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            th.attr("disabled", "disabled");
                            th.css("opacity", "0.5");
                            th.css("cursor", "default");
                            var success = getMssg['connect_succeed'];
                            $("#errConnectForUnknowns").removeClass("errorMessage");
                            $("#errConnectForUnknowns").addClass("infoMessage");
                            $("#errConnectForUnknowns").empty();
                            $("#errConnectForUnknowns").html(success);
                            setTimeout(function () {
                                location.reload(true);
                            }, 10000);
                        } else if (result == 'false') {
                            $("body").css("cursor", "default");
                            var failed = getMssg['action_failed'];
                            $("#errConnectForUnknowns").removeClass("infoMessage");
                            $("#errConnectForUnknowns").addClass("errorMessage");
                            $("#errConnectForUnknowns").html(failed);
                            $("#errConnectForUnknowns").css("color", "red");

                            setTimeout(function () {
                                $("#errConnectForUnknowns").empty();
                            }, 10000);
                        } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            } else {
                var ip = th.parent().find("input[name='unknownIp']").val();
                var mac = th.parent().find("input[name='unknownMac']").val();

                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        // 'token': token_cookie,
                        // 'ip': ip,
                        // 'serial_number': mac,
                        // 'method': "connectDevice",
                        'deviceID': id,
                        'actionName': "resend",
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        // var result = JSON.parse(result);
                        if (result == 'false') {
                            $("body").css("cursor", "default");
                            var failed = getMssg['action_failed'];
                            $("#errConnectForUnknowns").removeClass("infoMessage");
                            $("#errConnectForUnknowns").addClass("errorMessage");
                            $("#errConnectForUnknowns").html(failed);
                            $("#errConnectForUnknowns").css("color", "red");

                            setTimeout(function () {
                                $("#errConnectForUnknowns").empty();
                            }, 10000);
                        } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            th.attr("disabled", "disabled");
                            th.css("opacity", "0.5");
                            th.css("cursor", "default");
                            var success = getMssg['connect_succeed'];
                            $("#errConnectForUnknowns").removeClass("errorMessage");
                            $("#errConnectForUnknowns").addClass("infoMessage");
                            $("#errConnectForUnknowns").empty();
                            $("#errConnectForUnknowns").html(success);
                            setTimeout(function () {
                                location.reload(true);
                            }, 10000);
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });

            }
        }
    }

//------------------- pagination for pendingDevices ----------------------------

    $(document).on("click", ".eachPendingPage", function () {
        $("body").css("cursor", "wait");
        var page = $(this).find("input[name='page']").val();
        var model = $(".pendingModelType option:selected").val();
        var searchElem = $(".linkForPendingSearchDev");
        var clientInfoVal = $("#pendingDevicehead").find("input[name='clientInfo']").val();

        var sortVal = $("#sortPending option:selected").val();

        var sortBy = $(".sort_pending_by").attr("id");

        if (sortBy == "DESC") {
            sortBy = "ASC";
        } else {
            sortBy = "DESC";
        }

        sortVal = sortVal + ":" + sortBy;

        if (searchElem.attr("id") == 'searchUnknownByIp') {
            filterUnknowns(sortVal, "ip", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');
        } else if (searchElem.attr("id") == 'searchUnknownByMac') {
            filterUnknowns(sortVal, "mac", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');
        } else if (searchElem.attr("id") == 'searchUnknownByClient') {
            filterUnknowns(sortVal, "client", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');
        }
    });

//----------------Help Unknown devices page Info----------------------------------

    $(document).on("click", ".unknownInform", function () {
        var helpUnknown = getMssg['help_info_connect_client'];
        var help = getMssg['help'];
        swal({
            title: help,
            text: helpUnknown
        });
    });

//------------End  Help Unknown devices page Info---------------------------------


    $(document).on("click", ".autoCreatType", function () {
        var autoCreateCl = $(".autoCreatType option:selected").val();
        if (autoCreateCl == 'MACAddress') {
            $('#defaultSettingsPopover').removeClass('for_all_display_none');
        } else {
            $('#defaultSettingsPopover').addClass('for_all_display_none');
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/updateClientInsert.php",
            data: {
                'autoCreateCl': autoCreateCl,
                'actionName': "AutoCreateClient",
                'fromApp': true

            },
            async: false,
            success: function (result) {
                if (result == 'true') {

                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });


    $(document).on("click", "input[name='UnknownRemotOnoffswitch']", function () {
        if ($(this).is(":checked")) {
            $(this).addClass('RemoteOn');
            $(".UnkremoteAccessInput").show();
        } else if ($(this).is(":unchecked")) {
            $(this).removeClass('RemoteOn');
            $("#UnknownRemoteAccessInput-error").hide();
            $(".UnkremoteAccessInput").hide();
        }
    });

    $(document).on("click", "input[name='UnknownPeriodicOnoffswitch']", function () {
        if ($(this).is(":checked")) {
            $(this).addClass('PeriodicOn');
            $(".UnkPeriodicAccessInput").show();
        } else if ($(this).is(":unchecked")) {
            $(this).removeClass('PeriodicOn');
            $("#UnknownPeriodicAccessInput-error").hide();
            $(".UnkPeriodicAccessInput").hide();
        }
    });

    $(document).on("click", "input[name='UnknownStunOnoffswitch']", function () {
        if ($(this).is(":checked")) {
            $(this).addClass('StunOn');
        } else if ($(this).is(":unchecked")) {
            $(this).removeClass('StunOn');
        }
    });


    var UnknownDevicePasswordInput = $('#UnknownDevicePasswordInput').val();
    var UnknownPasswordInput = $('#UnknownPasswordInput').val();
    $(document).on("click", "input[name='UnknownDevParamsOnoffswitch']", function () {
        if ($(this).is(":checked")) {
            $('#UnknownDevicePasswordInput').val(UnknownDevicePasswordInput);
            $(this).addClass('DevParamOn');
            $(".UnkDevUsernameInput").show();
            $(".UnkDevPasswordInput").show();
        } else if ($(this).is(":unchecked")) {
            $(this).removeClass('DevParamOn');
            $("#UnknownDeviceUsernameInput-error").hide();
            $("#UnknownDevicePasswordInput-error").hide();
            $(".UnkDevUsernameInput").hide();
            $(".UnkDevPasswordInput").hide();
            $(".UnkDevRepPasswordInput").hide();
        }
    });

    $(document).on("click", "input[name='UnknownPasswordOnoffswitch']", function () {
        if ($(this).is(":checked")) {
            $('#UnknownPasswordInput').val(UnknownPasswordInput);
            $(this).addClass('PasswordOn');
            $(".UnkPasswordAccessInput").show();
        } else if ($(this).is(":unchecked")) {
            $(this).removeClass('PasswordOn');
            $("#UnknownPasswordInput-error").hide();
            $(".UnkPasswordAccessInput").hide();
            $(".UnkRepPasswordInput").hide();
        }
    });

    $(document).on("click", "input[name='UnknownDeviceUsernameInput']", function () {
        $(this).removeAttr('readonly');
    });

    $(document).on("click", "input[name='UnknownDevPassword']", function () {
        $(this).removeAttr('readonly');
    });

    $(document).on("click", "#DefaultParametersClick", function () {

        var msgRequird = getMssg['error_message_required'];
        var msgNumber = getMssg['error_message_number'];
        var msgGe1 = getMssg['error_message_ge_1'];
        var msgLe65535 = getMssg['error_message_le_65535'];
        var msgRepassword = getMssg['error_message_repassword'];
        var msgSpaces = getMssg['error_message_empty'];
        var msgPort = getMssg['error_message_for_port'];

        $('#DefaultSettings').validate({
            rules: {
                UnknownRemoteAccessInput: {
                    required: true,
                    digits: true,
                    validatePort: true,
                    min: 1,
                    max: 65535
                },

                UnknownInfTime: {
                    required: true,
                    digits: true,
                    min: 1

                },

                UnknownDeviceUsernameInput: {
                    required: true
                },

                UnknownDevPassword: {
                    required: true,
                    noSpace: true
                },

                reWriteUnknownDevPass: {
                    equalTo: "#UnknownDevicePasswordInput"
                },

                UnknownPassword: {
                    required: true,
                    noSpace: true
                },

                reWriteUnknownPass: {
                    equalTo: "#UnknownPasswordInput",
                    required: true
                }
            },
            messages: {
                UnknownRemoteAccessInput: {
                    required: msgRequird,
                    digits: msgNumber,
                    min: msgGe1,
                    max: msgLe65535,
                    validatePort: msgPort
                },

                UnknownInfTime: {
                    required: msgRequird,
                    digits: msgNumber,
                    min: msgGe1
                },

                UnknownDeviceUsernameInput: {
                    required: msgRequird
                },

                UnknownDevPassword: {
                    required: msgRequird,
                    noSpace: msgSpaces
                },

                UnknownPassword: {
                    required: msgRequird,
                    noSpace: msgSpaces
                },

                reWriteDevPass: {
                    equalTo: msgRepassword
                },

                reWriteUnknownPass: {
                    equalTo: msgRepassword,
                    required: msgRequird
                }

            },
            errorElement: "div",
            errorClass: 'error_msg',
            errorPlacement: function (error, element) {
                $("#UnknownRemoteAccessInput").empty();
                $("#UnknownPeriodicAccessInput").empty();
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }

        });

        if (!$("#DefaultSettings").valid()) {
            $('body').css("cursor", "default");
            return false;
        }

        var UnknownInfTime = $("input[name='UnknownInfTime']").val();
        var UnknownRemoteAccessInput = $("input[name='UnknownRemoteAccessInput']").val();
        var UnknownDeviceUsernameInput = $("input[name='UnknownDeviceUsernameInput']").val();
        var UnknownDevPass = $("input[name='UnknownDevPassword']").val();
        var UnknownPass = $("input[name='UnknownPassword']").val();
        var UnknownPeriodicEnable = '';
        var UnknownremoteAccessEnable = '';
        var UnknownStunEnable = '';
        var UnknownDevParamsEnable = '';
        var UnknownPasswordEnable = '';


        var a = $(".PeriodicOn").val();
        if (a == 'on') {
            UnknownPeriodicEnable = 1;
        } else {
            UnknownPeriodicEnable = 0;
        }

        var b = $(".RemoteOn").val();
        if (b == 'on') {
            UnknownremoteAccessEnable = 1;
        } else {
            UnknownremoteAccessEnable = 0;
        }

        var c = $(".StunOn").val();
        if (c == 'on') {
            UnknownStunEnable = 1;
        } else {
            UnknownStunEnable = 0;
        }

        var d = $(".DevParamOn").val();
        if (d == 'on') {
            UnknownDevParamsEnable = 1;
        } else {
            UnknownDevParamsEnable = 0;
        }

        var f = $(".PasswordOn").val();
        if (f == 'on') {
            UnknownPasswordEnable = 1;
        } else {
            UnknownPasswordEnable = 0;
        }


        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/updateClientInsert.php",
            data: {
                'UnknownInfTime': UnknownInfTime,
                'UnknownRemoteAccessInput': UnknownRemoteAccessInput,
                'UnknownDeviceUsernameInput': UnknownDeviceUsernameInput,
                'UnknownDevPass': UnknownDevPass,
                'UnknownPass': UnknownPass,
                'UnknownremoteAccessEnable': UnknownremoteAccessEnable,
                'UnknownStunEnable': UnknownStunEnable,
                'UnknownPeriodicEnable': UnknownPeriodicEnable,
                'UnknownDevParamsEnable': UnknownDevParamsEnable,
                'UnknownPasswordEnable': UnknownPasswordEnable,
                'actionName': "DefaultParameters",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    location.reload(true);
                    // resFailAction = data;
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });


    });

    $(document).on('change', '.sortDevs1', function () {

        var devType = $(this).attr('id');
        var page = 1;
        if (devType == 'sortPending') {

            var model = $(".pendingModelType option:selected").val();
            var searchElem = $(".linkForPendingSearchDev");
            var clientInfoVal = $("#pendingDevicehead").find("input[name='clientInfo']").val();

            var sortVal = $("#sortPending option:selected").val();
            var sortBy = $(".sort_pending_by").attr("id");

            if (sortBy == "DESC") {
                sortBy = "ASC";
            } else {
                sortBy = "DESC";
            }

            sortVal = sortVal + ":" + sortBy;

            if (searchElem.attr("id") == 'searchUnknownByIp') {
                filterUnknowns(sortVal, "ip", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');

            } else if (searchElem.attr("id") == 'searchUnknownByMac') {
                filterUnknowns(sortVal, "mac", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');

            } else if (searchElem.attr("id") == 'searchUnknownByClient') {
                filterUnknowns(sortVal, "client", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');
            }
        } else {
            var modelID = $(".modelTypeUn option:selected").val();
            var searchElem = $(".linkForSearchDev");
            var clientInfo = $("#unknownDevicehead").find("input[name='clientInfo']").val();
            var sortVal = $("#sortUnknowns option:selected").val();

            var sortBy = $(".sort_unknown_by").attr("id");

            if (sortBy == "DESC") {
                sortBy = "ASC";
            } else {
                sortBy = "DESC";
            }

            sortVal = sortVal + ":" + sortBy;

            if (searchElem.attr("id") == 'searchUnknownByIp') {
                filterUnknowns(sortVal, "ip", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');

            } else if (searchElem.attr("id") == 'searchUnknownByMac') {
                filterUnknowns(sortVal, "mac", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');
            }
        }


    });

    $(document).on('click', '#unknown_sort', function () {

        //  var devType=$(this).parent().parent().find(".sortDevs1").attr('id');
        var page = 1;

        var modelID = $(".modelTypeUn option:selected").val();
        var searchElem = $(".linkForSearchDev");
        var clientInfo = $("#unknownDevicehead").find("input[name='clientInfo']").val();
        var sortVal = $("#sortUnknowns option:selected").val();

        var sortBy = $(".sort_unknown_by").attr("id");

        var th = $(".sort_unknown_by");


        if (sortBy == "DESC") {
            th.attr("id", "ASC");
            th.attr("src", $basepath + "assets/images/down_arrow_34.png");

            th.attr("title", getMessage("by_desc"));
        } else {
            th.attr("id", "DESC");
            th.attr("src", $basepath + "assets/images/up_arrow_34.png");
            th.attr("title", getMessage("by_asc"));
        }

        sortVal = sortVal + ":" + sortBy;


        if (searchElem.attr("id") == 'searchUnknownByIp') {
            filterUnknowns(sortVal, "ip", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');

        } else if (searchElem.attr("id") == 'searchUnknownByMac') {
            filterUnknowns(sortVal, "mac", clientInfo, modelID, page, 'forUnknownsSearchResult', 'unknown');
        }


    });

    $(document).on('click', '#pending_sort', function () {

        var devType = $(this).parent().find(".sortDevs1").attr('id');
        var page = 1;

        var model = $(".pendingModelType option:selected").val();
        var searchElem = $(".linkForPendingSearchDev");
        var clientInfoVal = $("#pendingDevicehead").find("input[name='clientInfo']").val();

        var sortVal = $("#sortPending option:selected").val();
        var sortBy = $(".sort_pending_by").attr("id");

        var th = $(".sort_pending_by");
        if (sortBy == "DESC") {
            th.attr("id", "ASC");
            th.attr("src", $basepath + "assets/images/down_arrow_34.png");

            th.attr("title", getMessage("by_desc"));
        } else {
            th.attr("id", "DESC");
            th.attr("src", $basepath + "assets/images/up_arrow_34.png");
            th.attr("title", getMessage("by_asc"));
        }

        sortVal = sortVal + ":" + sortBy;


        if (searchElem.attr("id") == 'searchUnknownByIp') {
            filterUnknowns(sortVal, "ip", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');

        } else if (searchElem.attr("id") == 'searchUnknownByMac') {
            filterUnknowns(sortVal, "mac", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');

        } else if (searchElem.attr("id") == 'searchUnknownByClient') {
            filterUnknowns(sortVal, "client", clientInfoVal, model, page, 'forPendingsSearchResult', 'pending');
        }


    });

    function setDefaultSortValsUnknowns(element) {
        element.val("last_inform_time");
        $(".sort_unknown_by").attr("id", "ASC");
        $(".sort_unknown_by").attr("src", $basepath + "assets/images/down_arrow_34.png");
        $(".sort_unknown_by").attr("title", getMessage("by_desc"));

    }

    function setDefaultSortValsPendings(element) {
        element.val("last_inform_time");
        $(".sort_pending_by").attr("id", "ASC");
        $(".sort_pending_by").attr("src", $basepath + "assets/images/down_arrow_34.png");
        $(".sort_pending_by").attr("title", getMessage("by_desc"));

    }

});

