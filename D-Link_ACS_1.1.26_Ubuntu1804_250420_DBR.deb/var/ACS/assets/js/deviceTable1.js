//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg=result;
//            }
//        }
//    });
//    return retMsg;
//}


$(document).ready(function () {

    $basepath = $('#basepath').data('bpath');
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });

//$("#deviceTable").on("click",".viewDevParams",function (){
//    var devId = $(this).parent().find("input[name='devID']").val();
//    $("#infoId").find("input[name='devId']").val(devId);
//    $("#infoId").submit();
//});

//     $(".checkStatus").click(function () {
//         var devId = $(this).parent().find("input[name='devID']").val();
//         var th = $(this);
//         $('body').oLoader({
//             image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'
//         });
//
//         $.ajax({
//             type: "POST",
//             url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
//             data: {
//                 'deviceID': devId,
//                 'actionName': "connection",
//                 'fromApp':true
//             },
//             async: true,
//             success: function (result) {
//                 if (result == 'true') {
//                     th.removeClass('offline');
//                     th.addClass('online');
//                     th.attr("title",getMssg['device_ready']);
// //                        $("body").css("cursor", "default");
//                 } else if (result == 'false') {
//                     th.removeClass('online');
//                     th.addClass('offline');
//                     th.attr("title",getMssg['device_not_ready']);
// //                        $("body").css("cursor", "default");
//                 } else if (result = 'logged_out') {
//                     document.location.href = $basepath + 'login';
//                 }
//                     $('body').oLoader('hide');
//             },
//             error: function(xhr, status, error) {
//                 document.location.href = $basepath + '500';
//             }
//         });
//     });

// ----------- Checkbox iCheck plugin-----------


    $("#deviceTable").on("click", ".trash20", function (){
        var msg = getMssg['remove_device_msg'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            removeDevices($checked_array);
        });
    });

    
    function removeDevices(e){
    
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceId': e,
                'actionName': "removeDevice",
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    // var success = getMssg['action_succeed'];
                    // $("#resMsgForDev").empty();
                    // $("#resMsgForDev").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 10000);
                } else if (result == 'false') {
                    var failed = getMssg['connect_failed'];
                    $("#resMsgForDev").empty();
                    $("#resMsgForDev").html(failed);
                    $("body").css("cursor", "default");
                    setTimeout(function () {
                        location.reload(true);
                    },10000)
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
     
    $("#deviceTable").on("click", ".addTemplateToDevice", function (){
        var th = $(this);
        th.addClass('templateInGroup');
        var templateId = $(this).parent().find(".templateChoose option:selected").val();
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['change_msg'];
        var cancelMsg = getMssg['noChange'];
        var msg = getMssg['msg_addTemplate_device'];

        swal({
            title: titleMsg,
            text:  msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9",
            html: true
        }, function(isConfirm) {
            if(isConfirm){
                if(templateId != '-1'){
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                        data: {
                            'deviceId': $checked_array,
                            'templateId' : templateId,
                            'actionName': "setTemplate",
                            'fromDevices' : true,
                            'fromApp':true
                        },
                        async: false,
                        success: function (result) {
                            if (result == 'true') {
                                var success = getMssg['action_succeed'];
                                $("#resMsgForDev").empty();
                                $("#resMsgForDev").html(success);
                                setTimeout(function () {
                                    location.reload(true);
                                }, 10000);
                            } else if (result == 'false') {
                                var failed = getMssg['connect_failed'];
                                $("#resMsgForDev").empty();
                                $("#resMsgForDev").html(failed);
                                $("body").css("cursor", "default");
                                setTimeout(function () {
                                    location.reload(true);
                                },10000)
                            } else if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }else{
                    th.removeClass('templateInGroup');
                    return false;
                }
            }else{
                th.removeClass('templateInGroup');
            }
        });
    });

    $("#deviceTable").on("click", ".moveDeviceToGroups", function (){
        var th = $(this);
        th.addClass('templateInGroup');
        var groupId = $(this).parent().find(".groupTypeForAdd option:selected").val();
        var modelID = $(".modelType option:selected").val();
        var groupIDSelect=$(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        var action = '';
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['change_msg'];
        var cancelMsg = getMssg['noChange'];
        var msg = getMssg['msg_addGroup_device'];
        var data = [];
        if($checked_array.length == 0) {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getDeviceIds.php",
                data: {
                    'groupId': groupIDSelect,
                    'modelId': modelID,
                    'fwVersion': fwVersion,
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = 'login';
                    } else if (result == 'false') {
                        var msg = getMssg["action_failed"];
                        $("#resMsgForDev").empty();
                        $("#resMsgForDev").html(msg);
                        $("body").css("cursor", "default");
                    } else {
                        data = result;
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            data = '';
        } else {
            data = $checked_array;
        }
        if (groupId == '-1') {
            action = 'remove';
        } else {
            action =  'add';
        }
        swal({
            title: titleMsg,
            text:  msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9",
            html: true
        }, function(isConfirm) {
            if(isConfirm){
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/removeFromGroupOrAdd.php",
                    data: {
                        'deviceID': data,
                        'groupID': groupId,
                        'changeTemplate' : false,
                        'action': action,
                        'fromApp':true
                    },
                    async: true,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = 'login';
                        } else if (result == 'false') {
                            var msg = getMssg["action_failed"];
                            $("#resMsgForDev").empty();
                            $("#resMsgForDev").html(msg);
                            $("body").css("cursor", "default");
                        } else {
                            var msg = getMssg["action_succeed"];
                            // $("#resMsgForDev").empty();
                            // $("#resMsgForDev").html(msg);
                            $("body").css("cursor", "default");
                            setTimeout(function () {
                                location.reload(true);
                            },10000)
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }else{
                th.removeClass('templateInGroup');
            }
        });
    });

    $("#deviceTable").on("click", ".sendTaskToDevice", function (){
        var th = $(this);
        th.addClass('templateInGroup');
        var taskType = $(this).parent().find(".sendGroupTask option:selected").val();
        var modelID = $(".modelType option:selected").val();
        var groupIDSelect=$(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        var action = '';
        var data = {};
        if($checked_array.length == 0) {
            data = {
                'modelID': modelID,
                'groupId': groupIDSelect,
                'fwVersion': fwVersion,
                'actionName': taskType,
                'fromApp': true
            };
        } else {
            data = {
                'deviseId' :$checked_array,
                'actionName': taskType,
                'fromApp': true
            };
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: data,
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = 'login';
                } else if (result == 'false') {
                    var msg = getMssg["action_failed"];
                    $("#resMsgForDev").empty();
                    $("#resMsgForDev").html(msg);
                    $("body").css("cursor", "default");
                } else {
                    var msg = getMssg["action_succeed"];
                    $("#resMsgForDev").empty();
                    $("#resMsgForDev").html(msg);
                    $("body").css("cursor", "default");
                    setTimeout(function () {
                        location.reload(true);
                    }, 10000)
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });

    });

    // function sortDevsBySerial(page,clientInfo){
    //     $.ajax({
    //         type: "POST",
    //         url: $basepath + "secureFiles/actions/ajaxActions/sortDevices.php",
    //         data: {
    //             'page':page,
    //             'clientInfo': clientInfo,
    //             'fromApp':true
    //         },
    //         async: true,
    //         success: function (result) {
    //             if (result == 'logged_out') {
    //                 document.location.href = $basepath + 'login';
    //             } else {
    //                 $(".subClients").empty();
    //                 $(".subClients").html(result);
    //                 $("#deviceTable").empty();
    //                 $("body").css("cursor", "default");
    //             }
    //         },
    //         error: function(xhr, status, error) {
    //             document.location.href = $basepath + '500';
    //         }
    //     });
    // }
    // function sortDevsByIp(page,clientInfo){
    //
    // }
    // function sortDevsByModel(page,clientInfo){
    //
    // }
    // function  sortDevsByGroup(page,clientInfo){
    //
    // }


});

