
var arrayParamName=[],paramValue=[],paramType=[], ppp_conType="pppoe", pop_actionName, add_conn_type;
var indexArr=[];
var realValue ="";
var BTN_TYPE={
    EMPTY:0,
    SETTINGS:1,
    MAIN:2
};
var addConnArr = new Array();
function getAllNodes(){
    var treeViewObject = $('#tree1').data('treeview'),
        allCollapsedNodes = treeViewObject.getCollapsed(),
        allExpandedNodes = treeViewObject.getExpanded(),
        allNodes = allCollapsedNodes.concat(allExpandedNodes);

    return allNodes;
}
function setProgressTR(current_progress){
    $("#progressTR")
        .css("width", current_progress + "%")
        .attr("aria-valuenow", current_progress);
}
var trTree = (function() {
    const NOTIFY_ON="2";
    var VALUE_CHANGE_EXIST=true;
    var trArray=[];
    var valueChange=[];
    var notifyArray=[];
    var serialN = $("input[name='serialN']").val();
    var devId = $("input[name='devID']").val();
    var serLoading=$("#search_loading");
    var getArray = function(){
            return trArray;
    };
    var findTRItem = function(element, index, array){
        console.log(element);
    };
    var setDefault = function(){
        var trArray=[];
        var valueChange=[];
        var notifyArray=[];
    }
    var initTree=function(){


        if(trArray!=null) {
            $('#tree1').treeview({data:trArray});
            var nodes=getAllNodes();
            var lastParentID=0;
            for(var i in nodes){
                if(nodes[i].text.indexOf("addConn(this)")>0) {
                    var node = $('#tree1').treeview('getNode', nodes[i].parentId);
                    var index=node.text.indexOf("editConn(this)");
                    if(index>0){
                        var index=node.text.indexOf("<button");
                        node.text=node.text.substring(0,index);
                    }
                }
            }
            if(notifyArray.length>0) {
                setProgressTR(80);
                var idArray=[];
                for (var j in notifyArray) {
                    for (var i in nodes) {
                        if (notifyArray[j].name == nodes[i].baseNode) {
                            var node = nodes[i];
                            //var newValue=node.text.replace("Value: ","");
                            //if(notifyArray[j].value!=newValue) {
                                idArray.push(node.nodeId);
                                var count = 0;
                                while (typeof node != 'undefined') {
                                    //$('#tree1').treeview("expandNode", [node.nodeId, {silent: true}]);
                                    idArray.push(node.parentId);
                                    node = nodes[node.parentId - 1];
                                    //idArray.push(nodes[i].nodeId);
                                    count++;
                                    //break;
                                }
                            //}s
                           // notifyArray.splice(j, 1);
                            break;
                        }
                    }
                }
                idArray = idArray.filter(function(value, index, self){
                        return self.indexOf(value)===index;
                });
                setProgressTR(90);
                setTimeout(function(){
                    if(VALUE_CHANGE_EXIST) {
                        for (var k in idArray) {
                            $('#tree1').treeview("expandNode", [idArray[k], {level: 2, silent: true}]);
                        }
                    }
                    setProgressTR(100);
                    $('.progress').hide();
                    console.log(idArray);
                },1000);
            }else{
                setProgressTR(100);
                $('.progress').hide();
            }
            $('#tree1').show();
        }  else{
            showTreeWorning();
        }
    };
    var getXMLValue = function(xml){
        $.ajax({
            type: "POST",
            url: "../tmp/"+serialN+"_value.xml",
            data: "token="+getTreeCookie("token"),
            dataType: "xml",
            cache:false,
            success: function (data) {
                parseXML(data, xml);
                initTree();
                setTreeSelect();
                ajaxRequest.send({
                    type: globalVar.HTTP.POST,
                    name:globalVar.TASKS.NOTIFI_RESET,
                    data: {
                        'deviceID': devId,
                        'valueFile':serialN+"_value.xml",
                        'valueFileNew':serialN+"_value_change.xml",
                        'fromApp': true
                    }
                });
            },
            error: function(xhr, status, error) {
                showTreeWorning();
            },
            async: true
        });
    };
    var checkNotify = function () {

        $.ajax({
            type: "POST",
            url: "../tmp/"+serialN+"_notify.xml",
            data: "token="+getTreeCookie("token"),
            dataType: "xml",
            cache:false,
            success: function (notifyXML) {
                $(notifyXML).find("ParameterAttributeStruct").each(function () {
                    var notify=$(this).find("Notification").text();
                    if(notify===NOTIFY_ON){
                        notifyArray.push({name:$(this).find("Name").text(), value:null});
                    }
                });
                getValueChange();
            },
            error: function(xhr, status, error) {
                showTreeWorning();
            },
            async: false,
        });
    };
    var getValueChange = function(){
        $.ajax({
            type: "POST",
            url: "../tmp/"+serialN+"_value_change.xml", //_change
            data: "token="+getTreeCookie("token"),
            dataType: "xml",
            cache:false,
            success: function (data) {
                if(data==null){
                    VALUE_CHANGE_EXIST=false;
                    getXML();
                }else {
                    $.ajax({
                        type: "POST",
                        url: "../tmp/" + serialN + "_value.xml",
                        data: "token=" + getTreeCookie("token"),
                        dataType: "xml",
                        cache: false,
                        success: function (data) {
                            notifyArray.forEach(function (element, index, array) {
                                $(data).find("ParameterValueStruct").each(function () {
                                    if (element.name == $(this).find($("#txt_name").text()).text()) {

                                        //  console.log("value=",$(this).find("Value").text());
                                        array[index] = {
                                            name: element.name,
                                            value: $(this).find($("#txt_value").text()).text()
                                        };
                                    }
                                });
                            });
                             getXML();
                        },
                        error: function (xhr, status, error) {
                            //notifyArray=[];
                            VALUE_CHANGE_EXIST = false;
                            getXML();
                        },
                        async: true
                    });
                }
            },
            error: function(xhr, status, error) {
                //notifyArray=[];
                VALUE_CHANGE_EXIST=false;
                getXML();
            },
            async: true
        });
    };
    var createTree = function(){
        setDefault();
        checkNotify();
    };
    var getXML = function() {
        $('.progress').show();
        $('#tree1').hide();
        setProgressTR(5);
        $.ajax({
            type: "POST",
            url: "../tmp/"+serialN+"_name.xml",
            data: "token="+getTreeCookie("token"),
            dataType: "xml",
            cache:false,
            success: function (xmlName) {//success: xmlParser
                setProgressTR(10);
                getXMLValue(xmlName);
            },
            error: function(xhr, status, error) {
                showTreeWorning();
            },
            async: true,
        });
    };
    var parseXML = function (data, xml) {//success: xmlParser
        setProgressTR(20);
        var soapXML = data;
        var attributesXML = null;
        var attributeList = new Array();
        var btn_plus=$("#btn_add").clone(true,true);
        var btn_edit=$("#btn_edit").clone(true,true);
        var btn_newConn=$("#btn_newConn").clone(true,true);
        var btn_notify=$("#btn_notify").clone(true,true);
        var btn_notify_ckeck=$("#btn_notify_check").clone(true,true);
        var btn_delete=$("#btn_delete").clone(true,true);
        // get Writable parameter from names.xml
        $(attributesXML).find("ParameterAttributeStruct").each(function () {
            //console.log($(this).find("Name").text());
            item = {
                name: $(this).find("Name").text(),
                notification: $(this).find("Notification").text(),
                accessList: $(this).find("AccessList").children().contents().toArray()
            };
            attributeList.push(item);
        });

        var writableList = new Array();
        var searchTags = [];
        var item = null;

        var valueNum=0;
        $('#selectConn').selectpicker({
            style: 'btn-primary'
        });
        $('#selectConnPath').selectpicker({
            style: 'btn-default'
        });
        var selectConn=$("#selectConn");
        var selectConnPath=$("#selectConnPath");
        setProgressTR(30);
        $(xml).find("ParameterInfoStruct").each(function () {
            var txt=$(this).find("Name").text();
            var writable=$(this).find("Writable").text();
            var type=0;
            //if(parseInt(names[names.length-1])>0) {
            if (txt[txt.length - 1] == '.' && parseInt(writable) == 1) {
                var names=txt.split(".");
                if(names.length>3) {//because if step lower than 3 device does not accept new connection 'create' command
                    if (parseInt(names[names.length - 2]) > 0) {
                        //console.log(parseInt(names[names.length - 2]));
                    } else {
                        item = {
                            name: names[names.length - 2],
                            path:txt
                            //type: type
                        };
                        var check=true;
                        var options = selectConn.find('option').each(function(index){
                            if($(this).text()==item.name){
                                check=false;
                            }
                        });
                        if(check) {
                            selectConn.append('<option val="' + options.length + '">' + item.name + '</option>');
                            selectConn.selectpicker('refresh');
                        }
                        selectConnPath.append('<option val="' + addConnArr.length + '">' + item.path + '</option>');
                        selectConnPath.selectpicker('refresh');
                        addConnArr.push(item);
                        var check=true;
                        for(var index in searchTags){
                            //console.log(searchTags[index] + "---------" + item.name);
                            if(searchTags[index]==item.name){
                                check=false;
                                break;
                            }
                        }
                        if(check) {
                            searchTags.push(item.name);
                        }
                    }
                }
            }
            else {
                //}
                valueNum++;
                item = {
                    name: txt,
                    writable: $(this).find("Writable").text()
                };
                writableList.push(item);
            }
        });
        setProgressTR(40);
        var mytree = '';
        mydata = [{ text: 1, Name: "InternetGatewayDevice c  OOOOOO", baseNode: "InternetGatewayDevice", currInd: 0, nodeType: "node", vType: 'none',badge: "42", Parent: 0, btntype: BTN_TYPE.EMPTY }];
        function pushData(name, baseNode, curentIndex, parentIndex, global_type, vtype){
            mydata.push({
                text: mydata.length + 1,
                Name: name,
                baseNode: baseNode,
                currInd: curentIndex,
                nodeType: vtype,
                color: "#008DA9",
                badge: "45",
                Parent: parentIndex,
                btntype: global_type
            });
        }
        var i = 0, k = 1;

        var prevName = [];
        var global_parent=0;
        var num=0;
        /*for(var l in addConnArr){
            console.log("Names="+addConnArr[l].path);
        }*/
        var fault_str=$(soapXML).find("FaultString").text();
        var fault_code=$(soapXML).find("FaultCode").text();
        if(fault_str.length>0 && fault_code.length>0) {
            swal({
                title: fault_str,
                text: fault_code,
                type: "error"
            });
        }
        $(soapXML).find("ParameterValueStruct").each(function () {
            var name = $(this).find("Name").text();
            var writeParam = function () {
                //$(this).find("Writable").text() === "0" ? 0 : 1;
                var ret = $.grep(writableList, function (n) {
                    //console.log(n.name);
                    return n.name === name;
                });
                if (ret.length < 1) return [];
                else return ret[0];
            }(writeParam);
            var name = $(this).find("Name").text();
            var value = $(this).find("Value").text();
            //$(this).find("Value").attr('contentEditable','true');
            var valueType =$(this).find("Value").attr('xsi:type').split(":")[1];
            var splitName=name.split('.');
            var curentIndex=1;
            var parentIndex=1;
            var parent_name="InternetGatewayDevice";
            var baseNode=name;
            var findNode=false;
            var parent_index=0;
            var global_type=BTN_TYPE.EMPTY;
            if(name.indexOf("WANPPPConnection")>=0){
                var index=getNodeID(splitName);
                //return;
            }
            for(var i=mydata.length-1; i>=0; i--){
                if(findNode==true) {
                    break;
                }
                if(mydata[i].nodeType=='node') {
                    var bNode = mydata[i].baseNode.split('.');
                    parent_index=getNodeParentName(bNode, splitName);
                    parent_name = bNode[parent_index];
                    if (parent_name != "InternetGatewayDevice") {
                        var baseNode = "";
                        for (var j in splitName) {
                            if (j > 0) {
                                baseNode += ".";
                            }
                            if (j >= parent_index - 1) {
                                baseNode += splitName[j];
                                break;
                            }
                            baseNode += splitName[j];
                        }
                        for (var j = mydata.length - 1; j >= 0; j--) {
                            if (parent_name == mydata[j].Name) {
                                var bn = mydata[j].baseNode;
                                if (baseNode == bn) {
                                    parentIndex = mydata[j].text;
                                    findNode = true;
                                    baseNode += "." + parent_name;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if(parentIndex==1) {
                for (var i in splitName) {
                    if (splitName[i] == "InternetGatewayDevice") {
                        continue;
                    }
                    var baseNode="";
                    for(var j in splitName){
                        if(j==i){
                            break;
                        }
                        if(j>0){
                            baseNode+=".";
                        }
                        baseNode+=splitName[j];
                    }
                    global_type = getBtnType(splitName[i]);
                    pushData(splitName[i],baseNode,curentIndex,parentIndex,global_type,"node");
                    curentIndex++;
                    global_type=BTN_TYPE.EMPTY;
                    parentIndex=mydata.length;
                }
            }
            else{
                for (var i = 0; i< splitName.length; i++) {
                    if(i!=parent_index) {
                        splitName.splice(i, 1);
                        i--;
                        parent_index--;
                    }
                    else {
                        splitName.splice(i, 1);
                        break;
                    }
                }
                for (var i in splitName) {
                    if (splitName[i] == "InternetGatewayDevice") {
                        continue;
                    }
                    global_type = getBtnType(splitName[i]);
                    pushData(splitName[i],baseNode,curentIndex,parentIndex,global_type,"node");
                    curentIndex++;
                    parentIndex=mydata.length;
                    baseNode+="."+splitName[i];
                    global_type=BTN_TYPE.EMPTY;
                }
            }
            /////////////////// // push value   ///////////////
            var lastValNodeInd = mydata[mydata.length - 1].text;
            if (value != null) { // push value
                //alert(value);
                //console.log(checkMACValid(value)+'-----'+value);
                var dataName= $("#txt_value").text()+": " + value;
                pushData(dataName,name,curentIndex,mydata.length,BTN_TYPE.EMPTY,"value");
                mydata[mydata.length-1].writable=writeParam.writable;
                mydata[mydata.length-1].vType=valueType;
                mydata[mydata.length-1].color="FFFFFF";
            }
            /////////////////// // push writable   ///////////////
            var val_write=$("#txt_yes").text();
            if(writeParam.writable==0){
                val_write=$("#txt_no").text();
            }
            /////////////////// // push writable   ///////////////
            if (writeParam.writable != null && writeParam.writable != "") {
                var dataName= $("#txt_writable").text()+": " + val_write;
                pushData(dataName,name,curentIndex,mydata.length-1,BTN_TYPE.EMPTY,"writable");
                mydata[mydata.length-1].writable=writeParam.writable;
                mydata[mydata.length-1].vType=valueType;
                mydata[mydata.length-1].color="FFFFFF";
            }
            //prevName = splitName;
        });
        setProgressTR(50);
        mytree = function (data, root) {    // convert from flat array to tree
            var r;
            var txt_value=$('#txt_value').text();
            data.forEach(function (a) {
                var bNotify=btn_notify;
                var name=a.Name;
                notifyArray.forEach(function(element, index, self){
                    if(element.name===a.baseNode){
                        // if(element.name=="InternetGatewayDevice.ManagementServer.PeriodicInformInterval")
                        // {
                        //     alert(element.name+ "  "+element.value);
                        // }

                        bNotify=btn_notify_ckeck;
                        var value= a.Name.replace(txt_value,"");
                        if(element.value == value){
                            self.splice(index,1);
                        }else{
                            if(a.Name.indexOf('Editable')<0 && element.value!=null) {
                                a.Name = $("#txt_value").text()+": " + element.value;
                            }
                            //self.splice(index,1);
                        }
                    }
                });
                switch (a.btntype){
                    case BTN_TYPE.MAIN:
                        name+=btn_plus.html();
                        break;
                    case BTN_TYPE.SETTINGS:
                        name+=btn_edit.html() + btn_delete.html();
                        break;
                    default:
                        name=a.Name;
                        if(name.indexOf(txt_value)>=0 && name.indexOf('Editable')<0){
                            name+=bNotify.html();
                        }
                        break;
                }
                this[a.text] = {
                    text: name,
                    color: a.color,
                    tags: a.tags,
                    badge: a.badge,
                    nodeType: a.nodeType,
                    vType: a.vType,
                    writable: a.writable,
                    baseNode: a.baseNode,
                    nodes: this[a.text] && this[a.text].nodes
                };
                if (a.Parent == root) {
                    r = this[a.text];
                }
                else {
                    this[a.Parent] = this[a.Parent] || {};
                    this[a.Parent].nodes = this[a.Parent].nodes || [];
                    this[a.Parent].nodes.push(this[a.text]);
                }
            }, Object.create(null));
            return r;
        }(mydata, 0);
        setProgressTR(60);
        trArray.push({

            text: 'InternetGatewayDevice' + btn_newConn.html(),
            badge: '42',
            nodes: mytree.nodes,

            backColor: "#FFFFFF",
            href: "#",
            state: {
                expanded: true,
                showTags: true
            },
            selectable: true
        });
        $("#input-search").autocomplete({
            source: searchTags,
            messages:{
                noResults:'',
                resultts:function(){}
            },
            select:function(e,ui){
                $("#search_loading").show();
                setTimeout(function(){
                    treeSearch(ui.item.label);
                    serLoading.hide();
                },1000);
            }
        });
        setProgressTR(70);
    };
    var setTreeSelect= function(){
        $('#tree1').on('nodeSelected', function (event, data) {
            var myTree=$(this);
            var clickedNode =myTree.treeview('getSelected');
            realValue=clickedNode[0].text.split(": ")[1];
            clickedNodeID = clickedNode[0].nodeId;
            $("#edit_suggest").text("");
            $(this).treeview('enableAll', {silent:true});
            $("#edit-value").val("");
            if (clickedNode[0].nodeType=="value") {
                if (clickedNode[0].writable === "0") {
                    //console.log("2");
                    $("#edit-value").attr('readonly', 'readonly');
                    $('#btn-Save').prop('disabled', true);
                    var new_input=$("#edit-value");
                    var res=set_inputParam(new_input,"");
                    new_input=res[0];
                    return false;
                } else if (clickedNode[0].writable === "1") {
                    //console.log(new_input,clickedNode[0].vType);
                    //if pressing editable node then under node has writable node Edite field
                    if(clickedNode[0].text.split(":")[0] == 'Writable' && $("#edit-value").attr('readonly') != "undefined"){
                        //if($("#edit-value").attr('readonly') != "undefined"){
                        $("#edit-value").addAttribute('readonly', 'readonly');
                        $('#btn-Save').prop('disabled', true);
                    }
                    $("#edit-value").removeAttr('readonly');
                    $('#btn-Save').prop('disabled', true);
                    var suggest=$("#txt_pleaseInsert").text();
                    var new_input=$("#edit-value");
                    var txt=clickedNode[0].text.split(": ")[1];
                    if(typeof txt!=='undefined') {
                        var clearNum = txt.indexOf('<button');
                        if (clearNum >= 0) {
                            txt = txt.substring(0, clearNum);
                        }
                    }
                    var res=set_inputParam(new_input,clickedNode[0].vType, txt);
                    new_input=res[0];
                    suggest+=' ' + res[1];
                    $("#edit_suggest").text(suggest);
                    new_input.val(txt);
                    return true;
                }
            }
            else if(clickedNode[0].nodeType=="writable"){
                //console.log("3");
                $("#edit-value").attr('readonly', 'readonly');
                $('#btn-Save').prop('disabled', true);
                myTree.treeview('disableNode', [data.nodeId,{silent:true}]);
                var new_input=$("#edit-value");
                var res=set_inputParam(new_input,"");
                new_input=res[0];
                return false;
            }
        });
    };
    return {
        getTree:function(){
            return getXML();
        },
        createTree:function(){
            return createTree();
        },
        getDeviceID:function(){
            return devId;
        }
    }
}());
$(document).ready(function () {
    console.log('new Tree');
    var refreshPage = $("#refresh_page");
    var getAllParams = $("#getAllParams");
    var autoRefresh=false;
    $('#refreshButton').hide();
    $basepath = $('#basepath').data('bpath');
    var devId = $("input[name='devID']").val();
    var serialN = $("input[name='serialN']").val();
    $("#edit-value").attr('readonly', 'readonly');
    $('#btn-Save').prop('disabled', true);
    if(getTreeCookie('chk-ignore-case')=="true")
        $("#chk-ignore-case").prop("checked",true);
    if(getTreeCookie('chk-exact-match')=="true")
        $("#chk-exact-match").prop("checked",true);
    if(getTreeCookie('chk-autoRefresh')=="true") {
        autoRefresh=true;
        //getAllParams.prop("disabled",true);
        //refreshPage.hide();
        $("#chk-autoRefresh").prop("checked", true);
    }
    var selectors = {
        'tree': '#tree1',
        'input': '#input-search',
        'reset': '#btn-clear-search'
    };
    trTree.createTree();
    //getTree("../tmp/"+serialN+"_name.xml");
    $("#chk-ignore-case, #chk-exact-match").change(function(e){
        var str=$("#input-search").val();
        $("#input-search").val(str);
        $("#input-search").trigger('change');
        setCookie($(this).attr("id"),$(this).prop("checked"));
    });
    $("#chk-autoRefresh").change(function(e){
        var str=$("#input-search").val();
        if(str==true){
            autoRefresh=true;
            //getAllParams.prop("disabled",false);
        }else{
            autoRefresh=false;
            refreshPage.hide();
            //getAllParams.prop("disabled",true);
        }
        setCookie($(this).attr("id"),$(this).prop("checked"));
    });
    $("#btn_new_Modelconn").on("click touchend", function(e){
        e.stopPropagation();
        var trName=$("#selectConnPath").find('option:selected').text();
        $("#getAllParams").hide();
        $("#refresh_page").show();
        sendRequest("addTRConn",trName);
        $('#myModelConn').modal('toggle');
        return false;
    });
    var lastPattern = ''; // closure variable to prevent redundant operation
    var clickedNodeID = -1;
    //var mydata = '';
    var $scrollingDiv = $("#editField");
    $("#getAllParams, #refresh_page").on("click" , function () {
        var th=$(this);
        var refBtn=$('#refresh_page');
        var getAllBtn=$('#getAllParams');
        ajaxRequest.send({
            type:globalVar.HTTP.POST,
            name:globalVar.TASKS.GET_ALL_PARAM,
            check:globalVar.TASKS.REFRESH,
            data: {
                'deviceID': devId,
                'fromApp':true
            },
            response:function(respons) {
                th.prop("disabled", true);
                updateActivities(devId);
                actionAnimate();
                showRefresh();
                $("body").css("cursor", "default");
            },
            getStatus:function(status){
                //task was done
                refBtn.prop("disabled",false);
                refBtn.hide();
                getAllBtn.prop("disabled",false);
                getAllBtn.show();
                var serialN = $("input[name='serialN']").val();
                location.reload();
            }
        });
    });
    $("#selectConn").on("change" , function () {
        var name=$(this).find('option:selected').text();
        var selectConnPath = $("#selectConnPath");
        selectConnPath.find('option').remove();
        for(var i in addConnArr){
            if(name==addConnArr[i].name){
                selectConnPath.append('<option val="' + i + '">' + addConnArr[i].path + '</option>');
            }
        }
        selectConnPath.selectpicker('refresh');
    });
    $("#btn-Save").on("click" , function () {
        if(!checkInput($("#edit-value"))){
            return false;
        }
        else {
            var clickedNode = $('#tree1').treeview('getSelected');
            var editValue = $('#edit-value').val();
            var realValue = clickedNode[0].text.split(": ")[1];
            clickedNodeID = clickedNode[0].nodeId;
            var editName = window.mydata[clickedNodeID].baseNode;
            var editType = window.mydata[clickedNodeID].vType;
            var th = $(this);
            var paramNames = [];
            var paramValues = [];
            var paramTypes = [];

            if (editValue != realValue && typeof realValue != 'undefined') {
                paramNames.push(editName);
                paramValues.push(editValue);  //push parameter edit value
                paramTypes.push(editType);
                saveTrTree(devId,serialN,paramNames,paramValues,paramTypes);
                $("#edit-value").val("");
            }
            $('#btn-Save').prop('disabled', true);
        }
    });
    $("#edit-value").on("input" , function () {
        var res=checkInput($(this));
        //console.log(res);
        if(!res){
            $('#btn-Save').prop('disabled', true);
        }
        else if($(this).val()==realValue || $(this).val()=="") {
            $('#btn-Save').prop('disabled', true);
        }
        else{
            $('#btn-Save').prop('disabled', false);
        }
    });
    $("#myModel").on('click', 'input', function (e){
        var holder=$(this).attr('placeholder');
        if($(this).val()=="") {
            $(this).val(holder);
        }
    });
    $("#myModel").on('input','input', function (e){
        if($(this).val()=="" && $(this).attr('type')!="string"){//firefox checking
            var txt_small=$(this).parent().find('small');
            txt_small.addClass('errorMessage');
        }else {
            checkInput($(this));
        }
    });

    $(window).scroll(function (ev) { //edit dasht@ scrolli het ijecnum e nerqev

        if( $(window).scrollTop()<$('#tree1').outerHeight()-500)
            $scrollingDiv.stop().animate({ "marginTop": ($(window).scrollTop() ) + "px" }, "slow");
    });

    $("#tree1").contextmenu(function (e) {
        console.log(e);
    });
    $(selectors.reset).on('click', function (e) {
        $(selectors.input).val('');
        var tree = $(selectors.tree).treeview(true);
        reset(tree);
        tree.clearSearch();
        $("#tree1").treeview("expandNode",0);
    });
    $("#input-search").on('change paste keyup', function (e) {
        var val=$(this).val();
        setTimeout(function(){
            treeSearch(val);
         },500);
    });
});
/* collapse and enable all before search */
function reset(tree) {
    tree.collapseAll();
    tree.enableAll();
}
/* find all nodes that are not related to search and should be disabled:
 * This excludes found nodes, their children and their parents.
 * Call this after collapsing all nodes and letting search() reveal.
 */
function collectUnrelated(nodes) {
    var unrelated = [];
    $.each(nodes, function (i, n) {
        if (!n.searchResult && !n.state.expanded) { // no hit, no parent
            unrelated.push(n.nodeId);
        }
        if (!n.searchResult && n.nodes) { // recurse for non-result children
            $.merge(unrelated, collectUnrelated(n.nodes));
        }
    });
    return unrelated;
}
function treeSearch(str) {
    var srch=$("#search_loading");
    srch.show();
    var options = {
        ignoreCase: $('#chk-ignore-case').is(':checked'),
        exactMatch: $('#chk-exact-match').is(':checked')
    };
    var tree=$("#tree1");
    var treeView = tree.treeview(true);
    var txt_val=$("#txt_value").text();
    reset(treeView);
    if (str.length < 2) { // avoid heavy operation
        treeView.clearSearch();
        tree.treeview("expandNode",0);
        srch.hide();
    } else {
        setTimeout(function(){
            var res=treeView.search(str);
            if(res.length==0){
                res=treeView.search(txt_val+": "+str);
                if(res.length==0){
                    res=treeView.search(txt_val+": "+str);
                }
            }
            var roots = treeView.getSiblings(0);
            roots.push(treeView.getNode(0));
            var unrelated = collectUnrelated(roots);
            treeView.disableNode(unrelated, { silent: true });
            srch.hide();
        },100);
    }
};
$("#tree").on("click" , function () {
    // Your logic goes here
    //trTree.createTree();
});
function getConnValue(key){
    for(var i=0; i<arrayParamName.length;i++){
        if(arrayParamName[i]==key){
            return paramValue[i];
        }
    }
    return null;
}
$("#btn_edit_values").on("click" , function (e) {
    e.preventDefault();
    getNewModelValue();
    if(!checkForm()){
        return;
    }
    else {
        var err = $('#myModel').find('.errorMessage').length;
        if (err > 0) {
            return false;
        }
        else {
            var devId = $("input[name='devID']").val();
            var serialN = $("input[name='serialN']").val();
            $("#getAllParams").hide();
            $("#refresh_page").show();
            saveTrTree(devId,serialN,arrayParamName,paramValue,paramType);
            $('#myModel').modal('toggle');
        }
    }
    return false;
});
function showRefresh() {
    var autoRefresh=false;
    if(getTreeCookie('chk-autoRefresh')=="true") {
        autoRefresh = true;
    }
    if(!autoRefresh) {
        $("#getAllParams").hide();
        $("#refresh_page").show();
    }
}
function saveTrTree(devId,serialN,paramNames,paramValues,paramTypes){
    ajaxRequest.send({
        type:globalVar.HTTP.POST,
        name:globalVar.TASKS.SET_TRE_TREE,
        check:globalVar.TASKS.SET,
        data: {
            'deviceID': devId,
            'serialN': serialN,
            'changedParamNames': paramNames,
            'changedParamValues': paramValues,
            'changedParamTypes': paramTypes,
            'fromApp': true
        },
        response:function(respons) {
            //updateActivities(devId);
            actionAnimate();
            $("body").css("cursor", "default");
            updateActivities(devId);
            var id=devId;
            if(getTreeCookie('chk-autoRefresh')=="true") {
                setTimeout(function(){
                    $("#getAllParams").click();
                },5000);
            }
            showRefresh();
        },
        getStatus:function(status){
            /*if(!ajaxRequest) {
                $("#getAllParams").hide();
                $("#refresh_page").show();
                $('#refreshButton').hide();
            }*/
        }
    });
}
function createBridge(bridgeName,vlanID,bridgePort,bridgeType){
    var devId = $("input[name='devID']").val();
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
        data: {
            'deviceID': devId,
            'actionName': "createBridge",
            'bridgeName': bridgeName,
            'vlanID': vlanID,
            'bridgePort': bridgePort,
            'bridgeType': bridgeType,
            'fromApp': true
        },
        async: true,
        success: function (result) {
            if (result == 'logged_out') {
                document.location.href = $basepath + 'login';
            } else if (result == 'true') {
                var success = getMssg['action_succeed'];
                $("#actionRes").empty();
                $("#actionRes").html(success);
                $("#actionRes").removeClass("errorMessage");
                $("#actionRes").addClass("infoMessage");

                setTimeout(function () {
                    $("#actionRes").empty();
//          updateAfterTheAction();
                }, 10000);

            } else {
                var fail = getMssg['action_failed'];
                $("#actionRes").empty();
                $("#actionRes").html(fail);
                $("#actionRes").removeClass("infoMessage");
                $("#actionRes").addClass("errorMessage");
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}
function getNewModelValue(){
    paramValue=[];
    //arrayParamName=[];
    var newValues=[];
    var newType=[];
    var devId = $("input[name='devID']").val();
    var name=$("#myModel").find('input').each(function(index) {
        var val = $(this).val();
        if (val == "") {
            //arrayParamName.pop(index);
            return;
        }
        if (val[0] == ' ') {
            val=val.substring(1, val.length);
            //alert(val);
        }
        newValues.push(arrayParamName[index]);
        newType.push(paramType[index]);
        paramValue.push(val);
    });
    arrayParamName = newValues;
    paramType= newType;
    //return newValues;
}
function sendRequest(actionName, name){
    //console.log(connectIndex + " " + index);
    var devId = $("input[name='devID']").val();
    var th=$(this);
    ajaxRequest.send({
        type:globalVar.HTTP.POST,
        name:actionName,
        check:globalVar.TASKS.REFRESH,
        data: {
            'deviceID': devId,
            'trName':name,
            'fromApp':true
        },
        response:function(respons) {
            th.prop("disabled", true);
            //updateActivities(devId);

            $("body").css("cursor", "default");
            if(getTreeCookie('chk-autoRefresh')=="true") {
                setTimeout(function(){
                    $("#getAllParams").click();
                },5000);
            }
            actionAnimate();
            showRefresh();
        }
    });
}
function actionAnimate(){
    var action=$("#actionRes");
    action.show();
    action.empty();
    action.html(getMssg['action_succeed']);
    setTimeout(function () {
        action.hide();
    },5000)
}
function checkForm(){
    //var res=true;
    var input=$('#myModel').find('input').each(function (index) {
        //var type=$(this).attr('type');
        //var value=$(this).value();
        if(!checkInput($(this))){
            return false;
        }
    });
    return true;
}
function checkInput(input){
    var res=true;
    var type=input.attr('type');
    var value=input.val();
    var txt_small=input.parent().find('small');
    txt_small.removeClass('errorMessage');
    // if(value.length==0){
    //     return false;
    // }
    // if(value.replace(/\s/g,'').length==0){ //check space, tabs and line brakes
    //     txt_small.addClass('errorMessage');
    //     return false;
    // }
    if(type=="string"){
        return true;
    }
    var txt_error=$("#txt_tr_error_value").text();
    if(type=="unsignedInt" && value!=""){
        if($.isNumeric(value)) {
            if (parseInt(value) < 0) {
                txt_small.addClass('errorMessage');
                //txt_small.text(txt_error);
                return false;
            }
            else{
                txt_small.text($("#txt_pleaseInsert").text()+' unsignedInt');
                return true;
            }
        }
        else{
            txt_small.addClass('errorMessage');
            //txt_small.text('sxala');
            return false;
        }
    }
    else if(type=="number" && value!=""){
        if($.isNumeric(value)) {
            var max=input.attr("max");
            if(max==1) {
                if (parseInt(value) == 0 || parseInt(value) == 1) {
                    //txt_small.text($("#txt_pleaseInsert").text()+' number');
                    return true;
                }
                else{
                    txt_small.addClass('errorMessage');
                    //txt_small.text(txt_error);
                    return false;
                }
            }
            else{
                //txt_small.text($("#txt_pleaseInsert").text()+' number');
                console.log('ne normal');
                return true;
            }
        }
        else{
            txt_small.addClass('errorMessage');
            //txt_small.text(txt_error);
            return false;
        }
    }
    else if(type=="ipAddress" && value!=""){
        if(!chechIPv4Valid(value)) {
            txt_small.addClass('errorMessage');
            //txt_small.text(txt_error);
            return false;
        }
        else {
            txt_small.text($("#txt_pleaseInsert").text()+' ipAddress');
            return true;
        }
    }
    else if(type=="MACAddress" && value!=""){
        if(!checkMACValid(value)) {
            txt_small.addClass('errorMessage');
            //txt_small.text(txt_error);
            return false;
        }
        else{
            txt_small.text($("#txt_pleaseInsert").text()+' macAddress');
            return true;
        }
    }
    else{
        //txt_small.addClass('errorMessage');
        return true;
    }
}
/*function createPPP(){
    var devId = $("input[name='devID']").val();
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
        data: {
            'deviceID': devId,
            'actionName': "connection",
            'fromApp': true
        },
        async: true,
        success: function (result) {
            if (result == 'true') {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'index': '%d',
                        'connectIndex': '1',
                        'defConnection': 'false',
                        'changedParamNames': arrayParamName,
                        'changedParamValues': paramValue,
                        'changedParamTypes': paramType,
                        'interface_type': '-1',
                        'actionName': 'addPPPWan',
                        'type': addPPPOE,
                        'fromApp': true
                    },
                    async: false,
                    success: function (resultPPP) {
                        alert(resultPPP);

                    },
                    error: function (xhr, status, error) {
                    }
                });
            }
            else if (result == 'false') {
                setTimeout(function () {
                    updateAfterTheAction();
                }, 10000);
            } else if (result = 'logged_out') {
                document.location.href = $basepath + 'login';
            }
        }
    });
}*/
function getAllIndex(nodeID){
    indexArr=[];
    var node = $('#tree1').treeview('getNode', nodeID);
    //remove buttons
    while(typeof node.nodeId!=="undefined"){
        var _txt=node.text;
        var _btnIndex=_txt.indexOf("<button")>0;
        if(_btnIndex>0){
            _txt=_txt.substring(0,_btnIndex);
        }
        //console.log(node.parentId+"=="+node.text);
        if($.isNumeric(_txt)==true){
            indexArr.push(parseInt(_txt));
        }
        node = $('#tree1').treeview('getNode', node.parentId);
    }
}
function getAllPath(nodeID){
    indexArr=[];
    var node = $('#tree1').treeview('getNode', nodeID);
    //remove buttons
    var path="";
    while(typeof node.nodeId!=="undefined"){
        var _txt=node.text;
        var _btnIndex=_txt.indexOf("<button");
        if(_btnIndex>0){
            _txt=_txt.substring(0,_btnIndex);
        }
        _txt.replace(/\r?\n|\r/,"");
        indexArr.push(_txt);
        //console.log(node.parentId+"=="+node.text);
        /*if($.isNumeric(_txt)==true){
         indexArr.push(parseInt(_txt));
         }*/
        node = $('#tree1').treeview('getNode', node.parentId);
    }
    //console.log(indexArr.length);
    for(var i=indexArr.length-1;i>=0;i--)
    {
        path+=indexArr[i]+'.';
    }
    return path
}
function addConn(element){
    var obj=$(element);
    var type=obj.attr("name");
    $("#getAllParams").hide();
    $("#refresh_page").show();
    var chechID=parseInt(obj.parent().attr("data-nodeid"));
    var trName=getAllPath(chechID);
    sendRequest("addTRConn",trName);
    var node=$('#tree1').treeview("getNode",chechID);
    node.text=node.text.substring(0,node.text.indexOf("<button"));
    node.text+=$("#btn_add_disabled").html();
    return false;
}
function addNewConn(event, element){
    if(event.stopPropagation){
        event.stopPropagation();
    }
    else{
        event.cancelable=true;
    }
    $("#selectConn").change();
    $('#myModelConn').modal('show');
    return false;
}
function notifyConn(element){
    var obj=$(element);
    var th = $(this);
    var clickedNodeID=parseInt(obj.parent().attr("data-nodeid"));
    //var numIn = $("input[name='numIndex']").val();
    var trName=getAllPath(clickedNodeID);
    var node=$('#tree1').treeview("getNode",clickedNodeID);
    //var clickedNode = $('#tree1').treeview('getSelected');
    var editValue = $('#edit-value').val();
    //var realValue = clickedNode[0].text.split(": ")[1];
    //clickedNodeID = clickedNode[0].nodeId;
    var editName = window.mydata[clickedNodeID].baseNode;
    var editType = window.mydata[clickedNodeID].vType;
    var paramNames = [];
    var paramValues = [];
    var paramTypes = [];
    paramNames.push(trName);
    var devId = trTree.getDeviceID();
    var notificationStatus='2';
    if(node.text.indexOf('glyphicon-check')>=0) {
        notificationStatus='0';
    }
    ajaxRequest.send({
        type:globalVar.HTTP.POST,
        name:globalVar.TASKS.NOTIFI_TREE,
        data: {
            'deviceID': devId,
            'name': editName,
            'notificationStatus': notificationStatus,
            'fromApp': true
        },
        response:function(respons) {
            if(notificationStatus=='2') {
                node.text = node.text.substring(0, node.text.indexOf("<button"));
                node.text +=  $("#btn_notify_check").html();
            }else{
                node.text = node.text.substring(0, node.text.indexOf("<button"));
                node.text += $("#btn_notify").html() ;
            }
            $('#tree1').treeview("selectNode",clickedNodeID);
        },
    });
    return false;
}
function deleteConn(element){
    var obj=$(element);
    var type=obj.attr("name");
    var chechID=parseInt(obj.parent().attr("data-nodeid"));
    var trName=getAllPath(chechID);
    var devId = trTree.getDeviceID();
    var serialN = $("input[name='serialN']").val();
    var node=$('#tree1').treeview("getNode",chechID);

    swal({
            title: $("#txt_swal_deleteConnection").text(),
            text:  $("#txt_swal_are_you_sure").text(),
            type: "info",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: $("#txt_yes").text(),
            cancelButtonText: $("#txt_no").text(),
            closeOnConfirm: true,
            closeOnCancel: true
        },
        function(isConfirm) {
            if (isConfirm) {
                $("#getAllParams").hide();
                $("#refresh_page").show();
                ajaxRequest.send({
                    type:globalVar.HTTP.POST,
                    name:"deleteTRConn",//actionName,//globalVar.TASKS.DEL_CONN,
                   // check:globalVar.TASKS.REFRESH,
                    url:"secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                                'deviceID': devId,
                                'trName': trName,
                                'fromApp': true
                    },
                    response:function(respons) {

                    },
                    getStatus:function(status){
                        //task was done

                        node.text=node.text.substring(0,node.text.indexOf("<button"));
                        node.text+=$("#btn_delete_disabled").html();
                        $('#tree1').treeview("selectNode",chechID);

                        if(getTreeCookie('chk-autoRefresh')=="true") {
                            setTimeout(function(){
                                $("#getAllParams").click();
                            },5000);
                        }else{
                           // location.reload();
                            $("#getAllParams").hide();
                            $("#refresh_page").show();
                        }
                        actionAnimate();
                        showRefresh();
                        return false;
                    }
                });

                // $.ajax({
                //     type: "POST",
                //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                //     data: {
                //         'deviceID': devId,
                //         'serialN': serialN,
                //         'index': _txt,
                //         'connectIindex': 1,
                //         'actionName': 'delPPPWan',
                //         'fromApp': true
                //     },
                //     async: false,
                //     success: function (result) {
                //         $("#getAllParams").hide();
                //         $("#refresh_page").show();
                //         node.text=node.text.substring(0,node.text.indexOf("<button"));
                //         node.text+=$("#btn_delete_disabled").html();
                //         $('#tree1').treeview("selectNode",chechID);
                //
                //         if(getTreeCookie('chk-autoRefresh')=="true") {
                //             setTimeout(function(){
                //                 $("#getAllParams").click();
                //             },5000);
                //         }
                //         actionAnimate();
                //         showRefresh();
                //         return false;
                //     },
                //     error: function(xhr, status, error) {
                //
                //     }
                // });
            }
        });
}

function editConn(element){
    var myobj=$(element).parent();
    add_conn_type=myobj.attr("name");
    arrayParamName=[];
    paramValue=[];
    paramType=[];
    $("#myModel").find('.form-group').each(function() {
        $(this).remove();
    });
    var chechID=parseInt(myobj.attr("data-nodeid"));
    var lastID=0;
    getAllIndex(chechID);
    for(var i=0;i<mydata.length;i++){
        var treeNode=$('#tree1').treeview("getNode",i);
        /*if(treeNode.parentId==146){
         alert(mydata[treeNode.nodeId + 1].Name);
         }*/
        if(treeNode.parentId==chechID) {
            if(lastID==0){
                lastID=treeNode.nodeId;
            }
            var findID=treeNode.nodeId;
            if(findID-lastID==3 || findID-lastID==0) {
                findID = treeNode.nodeId;
                var isWite = mydata[findID + 2].Name.replace( $("#txt_writable").text()+": ", "");

                var value = mydata[findID + 1].Name.replace($("#txt_value").text()+": ", "");
                //console.log(mydata[findID].Name + ":" + value + ":" + isWite);
                if(mydata[findID].Name=="ConnectionType"){
                    if(value==" L2TP_Relay"){
                        ppp_conType="l2tp";
                        pop_actionName="addPPPWan";
                    }
                    else if(value==" PPTP_Relay"){
                        ppp_conType="pptp";
                        pop_actionName="addPPPWan";
                    }
                }
                //alert(mydata[findID+1].vType);
                if (isWite==$("#txt_yes").text() && mydata[findID+1].vType!='') {
                    var form=$("<div class='form-group'><label for='"+mydata[findID].Name+"'>"+mydata[findID].Name+"</label>");
                    var newInput=$("<input class='form-control' id='name-txt'>");
                    var res=set_inputParam(newInput,mydata[findID+1].vType,value);
                    newInput=res[0];
                    var txt_type=$("#txt_pleaseInsert").text()+' '+res[1];
                    newInput.attr('name','form_input');
                    /*if(mydata[findID+1].vType=='int'){
                     newInput.attr('type','number');
                     //newInput.attr('min','0');
                     txt_type='number';
                     }
                     else if(mydata[findID+1].vType=='unsignedInt'){
                     newInput.attr('type','text');
                     newInput.attr('min','0');
                     }
                     else if(mydata[findID+1].vType=='string'){
                     newInput.attr('type','text');
                     }
                     else if(mydata[findID+1].vType=='boolean'){
                     newInput.attr('type','number');
                     newInput.attr('min','0');
                     newInput.attr('max','1');
                     txt_type='boolean'
                     }*/
                    //console.log(mydata[findID].Name + ":" + value + ":" + isWite + ":" + mydata[findID+1].vType);
                    newInput.attr('placeholder',value);
                    form.append(newInput);
                    form.append("<small class='form-text text-muted'>" + txt_type + "</small></div>");
                    $("#myModel div.modal-body").append(form);

                    paramType.push(mydata[findID+1].vType);
                    arrayParamName.push(mydata[findID].baseNode + "."+mydata[findID].Name);
                    //console.log(mydata[findID].Name);
                    paramValue.push(value);
                }
                /*else{
                 $("#myModel div.modal-body").append("<div class='form-group'><label for='"+mydata[findID].Name+"'>"+mydata[findID].Name+"</label>" +
                 "<input type='text' class='form-control' id='name-txt' aria-describedby='"+mydata[findID].Name+"' placeholder='"+value+"' disabled>"+
                 "<small class='form-text text-muted'>please insert</small></div>");
                 }*/
                /*else{
                 $("#myModel form").prepend("<div class='form-group'>" +
                 "<span>"+mydata[findID].Name+":"+"value"+"</span></div>");
                 }*/
            }
            lastID=findID;
        }
    }
    var devId = $("input[name='devID']").val();
    //var name=thielement.parentElement.getAttribute('data-nodeid');
    //var expends=$("#tree1").treeview('getExpanded',name);
    //alert(expends.expandIcon);
    $('#myModel').modal('show');
    var th=$(this);
    //var r = confirm("Do you want to create new PPP connection?");
}
function set_inputParam(input, type,txt) {
    var param = "string";
    //input.unmask();
    /*var options =  {
     placeholder:"__"

     };*/
    //input.mask("",options);
    input.unmask();
    input.removeAttr('min');
    input.removeAttr('max');
    input.attr('type', 'text');
    input.removeAttr('placeholder');
    if (type == 'int') {
        input.attr('type', 'number');
        //newInput.attr('min','0');
        param = 'number';
    }
    else if (type == 'unsignedInt') {
        console.log(type);
        input.attr('type', 'number');
        input.attr('min', '0');
        param = "unsignedInt";
    }
    else if (type == 'string') {
        input.attr('type', 'string');
        param = "string";
    }
    else if (type == 'boolean') {
        input.attr('type', 'number');
        input.attr('min', '0');
        input.attr('max', '1');
        param = 'boolean';
    }
    else if (type == 'ipaddres') {
        if (chechIPv4Valid(txt)) { // or myip.isIpv6()
            input.attr('type', 'ipaddres');
            var options = {
                onKeyPress: function (cep, event, currentField, options) {
                    //console.log('An key was pressed!:', cep, ' event: ', event,'currentField: ', currentField, ' options: ', options);
                    if (cep) {
                        var ipArray = cep.split(".");
                        var lastValue = ipArray[ipArray.length - 1];
                        if (lastValue != "" && parseInt(lastValue) > 255) {
                            ipArray[ipArray.length - 1] = '255';
                            var resultingValue = ipArray.join(".");
                            currentField.attr('value', resultingValue);
                        }
                    }
                },
                placeholder: "___.___.___.___"

            };
            input.mask("000.000.000.000", options);
        }
        param = 'ipaddres';
    }
    else if (type == 'MACAddress') {
        if (checkMACValid(txt)) {
            input.attr('type', 'macAddress');
            var options = {
                onKeyPress: function (cep, event, currentField, options) {
                    //console.log('An key was pressed!:', cep, ' event: ', event,'currentField: ', currentField, ' options: ', options);
                    if (cep) {
                        //var ipArray = cep.split(":");
                        //var lastValue = ipArray[ipArray.length-1];
                        if (lastValue != "" && parseInt(lastValue) > 255) {
                            ipArray[ipArray.length - 1] = '255';
                            var resultingValue = ipArray.join(".");
                            currentField.attr('value', resultingValue);
                        }
                        currentField.attr('value', resultingValue);
                    }
                },
                placeholder: "__:__:__:__:__:__"

            };
            input.mask('AA:AA:AA:AA:AA:AA', options);
        }
        param = 'MACAddress';
        /*else {
         input.removeAttr('min');
         input.removeAttr('max');
         input.attr('type', 'text');
         //param="string";
         }*/
    }
    return [input, param];
}
function chechIPv4Valid(str){
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if(str.match(ipformat)!=null){
        return true;
    }
    else {
        return false;
    }
}
function checkMACValid(str){
    var regex = /^(?!(?:ff:ff:ff:ff:ff:ff|00:00:00:00:00:00))(?:[\da-f]{2}:){5}[\da-f]{2}$/i;
    return regex.test(str);
}
function getNodeParentName(bNode,node){
    var name=0;
    for(var i=0;i<bNode.length;i++){
        if (bNode[i] == node[i]) {
            name=i;
        }
        else{
            break;
        }
    }
    return name;
}
function getNodeID(name){
    var index=0;
    for(var i=name.length-1;i>=0;i--){
        var num=parseInt(name[i]);
        if(!isNaN(num)){
            index=num;
            break;
        }
    }
    return index;
}
function checkBaseNode(bNode, node){
    var res=true;
    if(bNode.length==1){
        return false;
    }
    for(var i=0; i<=bNode.length-2; i++){
        if(parseInt(bNode[i])!=false) {
            if (bNode[i] != node[i]) {
                res = false;
                break;
            }
        }
    }
    return res;
}
function getBtnType(name){
    var global_type = BTN_TYPE.EMPTY;
    if(!isNaN(parseInt(name))){
        global_type=BTN_TYPE.SETTINGS
    }
    else {
        for (var j in addConnArr) {
            if (name == addConnArr[j].name) {//    ConfigFile
                global_type = BTN_TYPE.MAIN;
                break;
            }
        }
    }
    return global_type;
}


function updateActivities(deviceID){
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/eachDevActivity.php",
        data: {
            'deviceID': deviceID,
            'fromApp':true
        },
        async: true,
        success: function (result) {
            if (result =='logged_out') {
                document.location.href = $basepath + 'login';
            } else {
                $("#forDActiv").empty();
                $("#forDActiv").html(result);
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}

/*
function getTaskStatusOfTheDevice(that, taskName,deviceId, myFunction){
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
        data: {
            'taskName':taskName,
            'deviceID': deviceId,
            'fromApp':true
        },
        async: true,
        success: function (result) {
            console.log(result)
            if (result =='logged_out') {
                clearInterval(that);
                document.location.href = $basepath + 'login';
            }else if(result==2){
                clearInterval(that);
                myFunction();
            }
        },
        error: function(xhr, status, error) {
            sowError(error);
            clearInterval(that);
        }
    });
}*/
function updateAfterTheAction() {
//        var countForm = $("#infoId").length;
//        if (countForm > 0) {
//            $("#infoId").submit();
//        } else {
//            var devidd = devId;
//            var newForm = '<form action="'+ $basepath +'devInfo/" id="infoId"  method="post" ><input type="hidden" name="devId" value="' + devidd + '" /></form>';
//            $(".devices_bl").append(newForm);
//            $("#infoId").submit();
//        }
    location.reload(true);
}
function getTreeCookie(name) {
    //var a=""+name;
    //a.replace("a","");
    //return $.cookie(name);
    var matches = document.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
}
function setCookie(name, value, options) {
    options = options || {};

    var expires = options.expires;

    if (typeof expires == "number" && expires) {
        var d = new Date();
        d.setTime(d.getTime() + expires * 1000);
        expires = options.expires = d;
    }
    if (expires && expires.toUTCString) {
        options.expires = expires.toUTCString();
    }

    value = encodeURIComponent(value);

    var updatedCookie = name + "=" + value;

    for (var propName in options) {
        updatedCookie += "; " + propName;
        var propValue = options[propName];
        if (propValue !== true) {
            updatedCookie += "=" + propValue;
        }
    }

    document.cookie = updatedCookie;
}
function showTreeWorning(){
    $('.progress').hide();
    swal({
            title: $("#txt_swal_xml_missed").text(),
            text:  $("#txt_swal_create_get_params").text(),
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: $("#txt_yes").text(),
            cancelButtonText: $("#txt_no").text(),
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function(isConfirm) {
            if (isConfirm) {
                $("#getAllParams").click();
                swal("Created", $("#txt_swal_task_created").text(), "success");
            } else {
                swal($("#txt_swal_xml_missed").text(), $("#txt_swal_no_create_tree").text(), "error");
            }
        });
}
function sowError(result){
    swal("Error", result, "error");
}


