$(document).ready(function () {
    
    $('#vlanPopover').popover({
        html : true,
        content: function() {
            return $('#createBridgediv').html();
        }
    });

    $('#vlanPopover').on('shown.bs.popover', function () {
        $('.popover-content').find('.port').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            increaseArea: '20%' // optional
        });
        
    });
    
    $('#vlanPopover').popover().on('hide.bs.popover', function () {
        $("#forVlanIdError").empty();
        setTimeout(function(){
            $('#forName').show();
            $('#forVlanID').show();
            $('#forPort').show();
            $('#forUntagged').hide();
            if($('.createBridge .error_message').attr('id') && $.trim( $('.createBridge .error_message').text() ).length != 0){
                $('#createBridge').validate().resetForm();
            }
            $('.popover-content .port').iCheck('destroy');
            $('.port').iCheck('update');
            $("#createBridgediv").html($(".createBridge .popover-content").html());
        }, 100);
    });
    
});

