//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg=result;
//            }
//
//        }
//
//    });
//    return retMsg;
//
//}

$basepath = $('#basepath').data('bpath');
//var getMssg = '';
//
//$.ajax({
//    type: "POST",
//    url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//    data: {
////            'message': msg,
//        'fromApp':true
//    },
//    dataType: 'json',
//    async: false,
//    success: function (result) {
//        if (result == 'logged_out') {
//            document.location.href = 'login';
//        } else {
//            getMssg = result;
//        }
//    }
//});

// $(document).on("input", "#configSearch", function (e) {
//     $('#searchDeviceForGroup').removeAttr("disabled");
// });
//
// $(document).click(function(e){
//     var target = e.target?e.target:e.srcElement;
//     if (target.id == 'searchDeviceForGroup' || target.id == 'configSearch'){
//         return false;
//     } else{
//         if(!$('#searchDeviceForGroup').is(':disabled')){
//             $("#searchDeviceForGroup").attr("disabled","disabled");
//             $("#configSearch").val('');
//         }
//     }
// });

$(document).on("click", "#searchDeviceForGroup", function () {
    $("input[name='deviceGroupingModel']").val('');
    $("input[name='deviceGroupingIpMask']").val('');
    $("input[name='deviceGroupingFirmware']").val('');
    $("input[name='deviceGroupingManufacturer']").val('');
    searchDeviceForGroups();
});

function searchDeviceForGroups(){
    new scrolingConf();
    var searchVal = $('.searchType option:selected').val();
    var devInfo = $("input[name='devInfo']").val();
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/searchDevicesForGroups.php",
        data: {
            'searchVal': searchVal,
            'devInfo': devInfo,
            'fromApp':true
        },
        async: false,
        success: function (result) {
            if(result=='logged_out'){
                document.location.href = $basepath + 'login';
            } else {
                $(".forPagingResult").empty();
                $(".forPagingResult").html(result);

                $("body").css("cursor", "default");
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}

$(document).on("click", "#deviceGroupingFilter", function () {
    var msgIp = getMssg['error_message_ipv4'];
    var msgMask = getMssg['error_message_mask'];
    $("#groupMsg").removeClass("for_all_display_none");

    $("#deviceGroupingForm").validate({
        rules: {
            deviceGroupingIpMask: {
                validateIpAddressInMask: true,
                validateIpMask: true
            }
        },

        messages: {
            deviceGroupingIpMask: {
                validateIpAddressInMask: msgIp,
                validateIpMask: msgMask

            }
        },
        errorElement: "div",
        errorClass: 'error_message',
        errorPlacement: function(error, element) {
            var placement = $(element).data('error');
            if (placement) {
                $(placement).append(error)
            } else {
                error.insertAfter(element);
            }
        }
    });

    if (!$("#deviceGroupingForm").valid()) {
        $('body').css("cursor", "default");
        return false;
    }
    filteredDeviceForModelFwManufIpmask();
    // groupingFilteredDevices();
    $('.popover').hide();
});

function groupingFilteredDevices(){
    new scrolingConf();
    var model = $("input[name='deviceGroupingModel']").val();
    var ip_mask = $("input[name='deviceGroupingIpMask']").val();
    var firmware = $("input[name='deviceGroupingFirmware']").val();
    var manufacturer = $("input[name='deviceGroupingManufacturer']").val();
    var msg = getMssg["changed_saved"];
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/getFilteredDevices.php",
        dataType: 'json',
        data: {
            'model': model,
            'ip_mask': ip_mask,
            'firmware': firmware,
            'manufacturer': manufacturer,
            'fromApp': true
        },
        async: false,
        success: function (result) {

            if(result=='logged_out'){
                document.location.href = $basepath + 'login';
            } else {
                var groupId = $('#deviceGroupingForm').parent().find(".groupTypeForAdd option:selected").val();
                drop(result, groupId);

                $("body").css("cursor", "default");
                $("#groupMsg").html(msg);
                setTimeout(function () {
                    $("#groupMsg").addClass("for_all_display_none");
                }, 1000);
            }

        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    })
}

function filteredDeviceForModelFwManufIpmask() {
    new scrolingConf();
    var model = $("input[name='deviceGroupingModel']").val();
    var ip_mask = $("input[name='deviceGroupingIpMask']").val();
    var firmware = $("input[name='deviceGroupingFirmware']").val();
    var manufacturer = $("input[name='deviceGroupingManufacturer']").val();
    var msg = getMssg["changed_saved"];
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/filteredDevicesByIpModelFwManuf.php",
        dataType: 'json',
        data: {
            'model': model,
            'ip_mask': ip_mask,
            'firmware': firmware,
            'manufacturer': manufacturer,
            'forGroupChange':true,
            'fromApp': true
        },
        async: false,
        success: function (result) {

            if(result=='logged_out'){
                document.location.href = $basepath + 'login';
            } else {
                 var groupId = $('#deviceGroupingForm').parent().find(".groupTypeForAdd option:selected").val();

                console.log(result);console.log(groupId);
                drop(result, groupId);

                $("body").css("cursor", "default");
                $("#groupMsg").html(msg);
                setTimeout(function () {
                    $("#groupMsg").addClass("for_all_display_none");
                }, 1000);
                // setTimeout(function() {
                //     location.reload(true);
                // }, 1000);
                // $(".forPagingResult").empty();
                // $(".forPagingResult").html(result);
                //
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    })
}


function drop(ev, groupId) {
    if($.isArray(ev)) {
        data = ev;

    } else {
        ev.preventDefault();
        var data = ev.dataTransfer.getData("Text");
    }
    var changeTemplate = true;

    $("input[name='groupID']").each(function () {
        if ($(this).val() == groupId) {
            $(this).parent().parent().removeClass("activeGr");
        }
    });
    
    var titleMsg = getMssg['msg_toMove_grup_notice'];
    var rmMsg =   getMssg['change_msg'];
    var cancelMsg =  getMssg['noChange'];
    var msg =  getMssg['msg_toMove_grup'];

    if(data.length > 0){
        if (groupId == '-1') {
            /*swal({
                title: '<h4>' + titleMsg + '</h4>',
                text:  msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9",
                html: true
            }, function(isConfirm) {
                if(!isConfirm){*/
                    changeTemplate = false;
                /*}*/
                
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/removeFromGroupOrAdd.php",
                    data: {
                        'deviceID': data,
                        'groupID': groupId,
                        'changeTemplate' : changeTemplate,
                        'action': 'remove',
                        'fromApp':true
                    },
                    async: true,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = 'login';
                        } else if (result == 'true') {
                            var searchGroups = $(".searchGroups").val();
                            if (searchGroups == 'yes'){
                                var model = $("input[name='deviceGroupingModel']").val();
                                var ip_mask = $("input[name='deviceGroupingIpMask']").val();
                                var firmware = $("input[name='deviceGroupingFirmware']").val();
                                var manufacturer = $("input[name='deviceGroupingManufacturer']").val();
                                if ( ip_mask != '' ){
                                    filteredDeviceForModelFwManufIpmask();
                                } else {
                                    searchDeviceForGroups();
                                }
                            } else {
                                $('.groupDev').click();
                            }
                            // $('.groupDev').click();
                            // searchDeviceForGroups();
                        } else {
                            var msg = getMssg["action_failed"];
                            $("#actionMsgWithGroup").empty();
                            $("#actionMsgWithGroup").html(msg);
                            $("body").css("cursor", "default");
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            // });
        } else {

            /*swal({
                title: '<h4 style="margin: 0px 20px;">' + titleMsg + '</h4>',
                text:  msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9",
                html: true
            }, function(isConfirm) {
                if(!isConfirm){*/
                    changeTemplate = false;
                /*}*/
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/removeFromGroupOrAdd.php",
                    data: {
                        'deviceID': data,
                        'groupID': groupId,
                        'changeTemplate' : changeTemplate,
                        'action': 'add',
                        'fromApp':true
                    },
                    async: true,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = 'login';
                        } else if (result == 'false') {
                            var msg = getMssg["action_failed"];
                            $("#actionMsgWithGroup").empty();
                            $("#actionMsgWithGroup").html(msg);
                            $("body").css("cursor", "default");
                            
                        } else {
                            if(changeTemplate){
                                $.ajax({
                                    type: "POST",
                                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                    data: {
                                        'deviceId': data,
                                        'templateId' : '',
                                        'groupID': groupId,
                                        'actionName': "setTemplate",
                                        'fromApp':true
                                    },
                                    async: false,
                                    success: function (result) {
                                        if (result == 'true') {
                                            var success = getMssg['action_succeed'];
                                            $("#actionMsgWithGroup").empty();
                                            $("#actionMsgWithGroup").removeClass("errorMessage");
                                            $("#actionMsgWithGroup").addClass("infoMessage");
                                            $("#actionMsgWithGroup").html(success);
                                            setTimeout(function () {
                                                location.reload(true);
                                            }, 10000);
                                        } else if (result == 'false') {
                                            var failed = getMssg['connect_failed'];
                                            $("#actionMsgWithGroup").empty();
                                            $("#actionMsgWithGroup").html(failed);
                                            $("body").css("cursor", "default");
                                            setTimeout(function () {
                                                location.reload(true);
                                            },10000)
                                        } else if (result == 'logged_out') {
                                            document.location.href = $basepath + 'login';
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        document.location.href = $basepath + '500';
                                    }
                                }); 
                            }else{
                                var searchGroups = $(".searchGroups").val();
                                if (searchGroups == 'yes'){
                                    var model = $("input[name='deviceGroupingModel']").val();
                                    var ip_mask = $("input[name='deviceGroupingIpMask']").val();
                                    var firmware = $("input[name='deviceGroupingFirmware']").val();
                                    var manufacturer = $("input[name='deviceGroupingManufacturer']").val();
                                    if ( ip_mask != ''){
                                        filteredDeviceForModelFwManufIpmask();
                                    } else {
                                        searchDeviceForGroups();
                                    }
                                } else {
                                    $('.groupDev').click();
                                }
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            // });
        }
    }
}

function allowDrop(ev, groupId) {
    ev.preventDefault();
    $("input[name='groupID']").each(function () {
        if ($(this).val() == groupId) {
            $(this).parent().parent().addClass("activeGr");
        }
    })
}

function removeDrop(ev, groupId) {
    ev.preventDefault();
    $("input[name='groupID']").each(function () {
        if ($(this).val() == groupId) {
            $(this).parent().parent().removeClass("activeGr");
        }
    })
}

function  removeDevicesFromGroup(th, deviceID) {
    if(th.attr("disabled")!="disabled"){
        th.attr("disabled", "disabled");
        th.css("opacity", "0.5");
        th.css("cursor", "default");
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        var msg = getMssg['remove_device_msg'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function(isConfirm) {
            if(isConfirm){
                $("body").css("cursor", "wait");
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceId': deviceID,
                        'actionName': "removeDevice",
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            var success = getMssg['action_succeed'];
                            $("#msgForGroup").empty();
                            $("#msgForGroup").addClass('mainColor');
                            $("#msgForGroup").html(success);
                            setTimeout(function () {
                                location.reload(true);
                            }, 10000);
                        } else if (result == 'false') {
                            var failed = getMssg['connect_failed'];
                            $("#msgForGroup").empty();
                            $("#msgForGroup").addClass('errorMessage');
                            $("#msgForGroup").html(failed);
                            $("body").css("cursor", "default");
                            setTimeout(function () {
                                location.reload(true);
                            },10000)
                        } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }else{
                th.removeAttr("disabled");
                th.css("opacity","1");
                th.css("cursor","pointer");
            }
        });
    }else {
        th.removeAttr("disabled");
        th.css("opacity","1");
        th.css("cursor","pointer");
    }
}

$(document).ready(function () {
   
    $('#groupPopover').popover({
        html : true,
        content: function() {
            return $('.addGroupPopover').html();
        }
    });

    $('#groupPopover').on('hidden.bs.popover', function () {
        $('#actionMsgWithGroup').empty();
    });

    $('#deviceGrouping').popover({
        html : true,
        content: function() {
            return $('.deviceGroupingPopover').html();
        }
    });

    $('#deviceGrouping').on('hidden.bs.popover', function () {
        $('#actionMsgWithGroup').empty();
    });

    setTimeout(function () {
        $('#actionMsgWithGroup').empty();
    },10000);

    $(document).on("click", ".moveDeviceToGroups", function (){
        var groupId = $(this).parent().find(".groupTypeForAdd option:selected").val();
        drop($checked_array, groupId);
    });
    $(document).on("click", ".deleteDeviceFromGroup", function (){
        var th = $(this);
        removeDevicesFromGroup(th, $checked_array);
    });

    $(document).on("click", "#addGroup", function () {

        $("body").css("cursor", "wait");
        var gName = $("input[name='groupName']").val().trim();
        var gDesc = $("textarea[name='groupDesc']").val();
        var msgAndResult = '';
        if (gName != '') {
           
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkGroupName.php",
                data: { 
                    'groupName': gName,
                    'fromApp':true 
                },
                async: false,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        msgAndResult = data;
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            if (msgAndResult != '') {
                $("#actionMsgWithGroup").empty();
                $("#actionMsgWithGroup").html(msgAndResult);
                $("#actionMsgWithGroup").addClass("errorMessage");
                $("body").css("cursor", "default");
            } else {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/addGroup.php",
                    data: {
                        'groupName': gName,
                        'gDescription': gDesc,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else if (result == 'true') {
                            location.reload(true);
                        } else {
                            msgAndResult = getMssg["action_failed"];
                            $("#actionMsgWithGroup").empty();
                            $("#actionMsgWithGroup").html(msgAndResult);
                            $("#actionMsgWithGroup").addClass("errorMessage");
                            $("body").css("cursor", "default");
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        } else {
            msgAndResult = getMssg["group_required_fields"];
            $("#actionMsgWithGroup").empty();
            $("#actionMsgWithGroup").html(msgAndResult);
            $("#actionMsgWithGroup").addClass("errorMessage");
            $("body").css("cursor", "default");
        }
    });

        $(".search-button").on("keypress","input[name='devInfo']",function(e){
        var key = e.which;
        if(key == 13) { // the enter key code
            searchDeviceForGroups();
            return false;
        }
    });


    $(document).on("click", ".groupDev", function () {
        var th = $(this);
        $(".eachGroup").removeClass("clickedGr");
        th.closest('tr').addClass("clickedGr");
        var groupID = th.parent().find("input[name='groupID']").val();
        $("body").css("cursor", "wait");

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllDevicesOfTheGroup.php",
            data: {
                'getDevices' : true,
                'groupID': groupID,
                'page': 1,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    th.closest('tr').next('tr').find(".forEachGroup").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", ".groupByDevices", function () {
        var th = $(this);
        var groupID = th.parent().find("input[name='groupID']").val();
        if($("#show"+groupID).is(":visible")) {
            $("#show"+groupID).hide();
            return false;
        } else {
            $("#show" + groupID).show();
            return false;
        }
        });

    $(document).on("click", ".removeDevice", function (){
        var th = $(this);
        var deviceID = th.parent().parent().find("input[name='devID']").val();
        removeDevicesFromGroup(th, deviceID);
    });


//---------------- pagination for groups ---------------------------------------

    $(document).on("click", ".eachGroupPage", function () {
        var page = $(this).find("input[name='page']").val();
        $("body").css("cursor", "wait");
        
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/filteredGroupsByPage.php",
            data: {
                'page': page,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $(".forPagingResult").empty();
                    $(".forPagingResult").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
//---------------- end pagination for groups -----------------------------------    
    
    $(document).on("click", ".removeGroup", function () {
            //  $("body").css("cursor", "wait");
            var groupID = $(this).parent().find("input[name='groupID']").val();
            var msg = getMssg['conf_rem_user_group'];
            var titleMsg = getMssg['title_msg'];
            var rmMsg = getMssg['remove_msg'];
            var cancelMsg = getMssg['cancel'];
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/removeGroup.php",
                    data: {
                        'groupID': groupID,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else if (result == 'true') {
                            location.reload(true);
                        } else {
                            $("#actionMsgWithGroup").empty();
                            $("#actionMsgWithGroup").html(getMssg['action_failed']);
                            $("#actionMsgWithGroup").addClass("errorMessage");
                            $("body").css("cursor", "default");
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            });
    });
    
    function showInputs(th,id) {
//            if ($(this).find("input").length == 0) {
            $(".forChange").hide();
            $(".defaultText").show();
            $(th).find(".forChange").show();
            $(th).find(".defaultText").hide();
            var currName = $(th).find(".defaultText").html();
            $(th).find("input").val(currName);
            $(th).find("textarea").val(currName);
            $(th).find("a").attr('id',id);
//            }
    }
    
    $(document).on("dblclick", ".groupName", function () {
        var th = $(this);
        showInputs(th,'changeGroupName');
    });
    
    $(document).on("dblclick", ".groupDescription", function () {
        var th = $(this);
        showInputs(th,'changeGroupDesc');
    });
    
    $(document).on("click",".changeData",function(e) {
        e.stopPropagation(); // watch out here...
    });
    
    $(document).on("click",".defaultText",function(e) {
        e.stopPropagation(); // watch out here...
    });

    
    $(document).on("click", "#resetGroup", function (e){
       var target = e.target?e.target:e.srcElement;
       if (target.id == 'changeClientImg'){
           return false;
       } else{
           $(".forChange").hide();
           $(".defaultText").show();
       }
    });
    
    $(document).on("click", "#changeGroupName", function () {
        var th = $(this);
        var groupName = th.parent().find("input").val().trim();
        var msgAndResult = '';
        if (groupName != '') {
            $("body").css("cursor", "wait");
            var groupID = th.closest('tr').find("input[name='groupID']").val();
                
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkGroupName.php",
                data: { 
                    'groupName': groupName,
                    'fromApp':true 
                },
                async: false,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        msgAndResult = data;
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            
            if (msgAndResult != '') {
                    $("#actionMsgWithGroup").empty();
                    $("#actionMsgWithGroup").html(msgAndResult);
                    $("#actionMsgWithGroup").addClass("errorMessage");
                    $("body").css("cursor", "default");
            } else {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/changeGroup.php",
                    data: {
                        'groupName': groupName,
                        'gDescription': null,
                        'gID': groupID,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else if (result == 'true') {
                            th.closest("td").find('.defaultText').html(groupName);
                            $(".forChange").hide();
                            $(".defaultText").show();
                            $("body").css("cursor", "default");
                            $("#actionMsgWithGroup").empty();
                        } else {
                            $("#actionMsgWithGroup").empty();
                            $("#actionMsgWithGroup").html(getMssg['action_failed']);
                            $("#actionMsgWithGroup").addClass("errorMessage");
                            $("body").css("cursor", "default");
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        } else {
            $("#actionMsgWithGroup").empty();
            $("#actionMsgWithGroup").html(getMssg['gName_empty']);
            $("#actionMsgWithGroup").addClass("errorMessage");
            $("body").css("cursor", "default");
        }
    });
    
    $(document).on("click", "#changeGroupDesc", function () {
        var th = $(this);
        var groupDesc = th.parent().find("textarea").val();
        var groupID = $(this).closest('tr').find("input[name='groupID']").val();
        $("body").css("cursor", "wait");
        
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changeGroup.php",
            data: {
                'groupName': null,
                'gDescription': groupDesc,
                'gID': groupID,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    th.closest("td").find('.defaultText').html(groupDesc);
                    $(".forChange").hide();
                    $(".defaultText").show();
                    $("body").css("cursor", "default");
                    $("#actionMsgWithGroup").empty();
                } else {
                    $("#actionMsgWithGroup").empty();
                    $("#actionMsgWithGroup").html(getMssg['action_failed']);
                    $("#actionMsgWithGroup").addClass("errorMessage");
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });

    });

    
//--------------- pagination for groupDevices.php ------------------------------

    $(document).on("click", ".eachClientDevPage", function () {
        var th = $(this);
        var page = $(this).find("input[name='page']").val();
        var groupID = $(this).closest('div').find("input[name='groupID']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllDevicesOfTheGroup.php",
            data: {
                'groupID': groupID,
                'page': page,
                'getDevices' : true,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    var div = th.closest('tr').find(".forEachGroup");
                    div.empty();
                    div.html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
//--------------- end pagination for groupDevices.php ------------------------------

//----------------Help Group page Info-----------------------------------------

    $(document).on("click", ".groupInform", function () {
        var helpGroup = getMssg['help_info_change_dev_group'];
        var help = getMssg['help'];
        swal({
            title: help,
            text: helpGroup
        });
    });

//------------End  Help  Group  page Info--------------------------------------
    
    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;




    
    $(document).on("click", ".addTemplateToDevice", function (){
        var th = $(this);
        th.addClass('templateInGroup');
        var templateId = $(this).parent().find(".templateChoose option:selected").val();
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['change_msg'];
        var cancelMsg = getMssg['noChange'];
        var msg = getMssg['msg_addTemplate_group'];

        swal({
            title: titleMsg,
            text:  msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9",
            html: true
        }, function(isConfirm) {
            if(isConfirm){
                if(templateId != '-1'){

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/getAllDevicesOfTheGroup.php",
                        data: {
                            'groupID': $checked_array,
                            'getDevices' : false,
                            'fromApp':true
                        },
                        async: false,
                        dataType : "json",
                        success: function (result) {
                            for (var i = 0; i < result.length; i++) {
                                if (jQuery.parseJSON(result[i]) == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else if (jQuery.parseJSON(result[i]) == false) {
                                    $("#actionMsgWithGroup").empty();
                                    $("#actionMsgWithGroup").addClass("errorMessage");
                                    $("#actionMsgWithGroup").html(getMssg['msg_empty_group']);
                                } else {
                                    $.ajax({
                                        type: "POST",
                                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                        data: {
                                            'deviceId': result,
                                            'templateId': templateId,
                                            'groupID': $checked_array,
                                            'actionName': "setTemplate",
                                            'fromDevices': false,
                                            'fromApp': true
                                        },
                                        async: false,
                                        success: function (result) {
                                            if (result == 'true') {
                                                var success = getMssg['action_succeed'];
                                                $("#actionMsgWithGroup").empty();
                                                $("#actionMsgWithGroup").removeClass("errorMessage");
                                                $("#actionMsgWithGroup").addClass("infoMessage");
                                                $("#actionMsgWithGroup").html(success);
                                                setTimeout(function () {
                                                    location.reload(true);
                                                }, 10000);
                                            } else if (result == 'false') {
                                                var failed = getMssg['connect_failed'];
                                                $("#actionMsgWithGroup").empty();
                                                $("#actionMsgWithGroup").html(failed);
                                                $("body").css("cursor", "default");
                                                setTimeout(function () {
                                                    location.reload(true);
                                                }, 10000)
                                            } else if (result == 'logged_out') {
                                                document.location.href = $basepath + 'login';
                                            }
                                        },
                                        error: function (xhr, status, error) {
                                            document.location.href = $basepath + '500';
                                        }
                                    });
                                }
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }else{
                    th.removeClass('templateInGroup');
                    return false;
                }
            }else{
                th.removeClass('templateInGroup');
            }
        });
    });

});
