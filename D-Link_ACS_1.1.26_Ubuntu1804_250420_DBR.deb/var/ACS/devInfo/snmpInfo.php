<?php
	if(!isset($_POST['action'])) {
		return 0;
	}
    // TODO the function need to move global spase.
    function readAcsSettings()
    {
        $settingsFile = '/etc/acs/config/acs.conf';
        $content = file_get_contents($settingsFile);
        $contentArray = explode("\n", $content);
        $settingsArray = array();
        foreach($contentArray as $setting)
        {
            list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
            if ($value !== NULL)
            {
                $settingsArray[trim($key)] = trim($value);
            }
        }
        return $settingsArray;
    }

    $SNMP_PASSWORD = readAcsSettings()['password'];
    $SNMP_USER = readAcsSettings()['username'];;
    $SNMP_DB_NAME = 'SNMP';

	try {
	  $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER,  $SNMP_PASSWORD);
	} catch(PDOException $e) {
	  die("Error: " . $e->getMessage());
	}

	switch($_POST['action']) {
		case 'getSwitchInfo':
      		getSwitchInfo();	    
			break;
		case 'getSwitchInfoByRouterMAC':
      		getSwitchInfoByRouterMAC();   
			break;
		case 'getConnectionSwitchInfo':
      		$data = getConnectionSwitchInfo($_POST['mac'], array(), 0);
      		echo json_encode($data);
			break;
	}
		
function getSwitchInfo() {
	global $dbh;
	$mac = $_POST['mac']; 
	$counter = 1;	
	echo "<table id='portStatusSNMP' class='portStatusSNMP'>";
	echo "<thead>";
	echo "<tr>";
	echo "<th>#</th>";
	echo "<th>Link</th>";
	echo "<th>Speed (Mb/s)</th>";
	echo "<th>Up (Mb/s)</th>";
	echo "<th>Down (Mb/s)</th>";
	echo "<th>inerrors</th>";
	echo "<th>outerrors</th>";
	echo "<th>band_util</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	foreach($dbh->query(" SELECT * FROM `tb_devices`  
				  INNER JOIN tb_interfaces 
				  ON tb_interfaces.device_id =
					  tb_devices.id 
				  INNER JOIN
				  tb_bandUtil 
				  ON tb_interfaces.id = tb_bandUtil.interface_id
				  WHERE tb_devices.MAC = '$mac'") as $row) {
		echo "<tr class='switchPortInfo' id='port$counter' style='border-bottom:1px solid black;'>";
		echo "<td>" . $counter . "</td>"; 
		echo "<td>" . $row['link'] . "</td>"; 
		echo "<td>" . floatval(number_format($row['ifspeed'] / 1000000 , 2)). "</td>"; 
		echo "<td>" . floatval(number_format ($row['byte_sent'] / 1000000, 2)) . "</td>"; 
		echo "<td>" . floatval(number_format ($row['byte_received'] / 1000000, 2)) . "</td>"; 
		echo "<td>" . $row['inerrors'] .  "</td>"; 
		if($row['outerrors'] == 1) {
			echo "<td bgcolor='#FE4141'><font color='#FFFFFF'>" . $row['outerrors'] . "</td>"; 
		} else {
			echo "<td>" . $row['outerrors'] . "</td>"; 
		}
		$color_band = abs(($row['band_util']*100.) - 100);
		echo "<td data-w3-color='hwb($color_band, 9%, 28%)'>" . "<font color='#ffffff'>" .
		$row['band_util']*100 . '%' .  "</font></td>"; 
		echo "</tr>";
		$counter++;
	}
	echo "</tbody>";
	echo "</table>";
}

function getConnectionSwitchInfo($mac, $data, $iter) 
{
   global $dbh;
   $connection = $dbh->query("SELECT * FROM `tb_connections` WHERE mac_to = '$mac'", PDO::FETCH_ASSOC);
   $conData = $connection->fetch();
   $endpoint = $dbh->query("SELECT * FROM `tb_connections` WHERE port_to = '0'", PDO::FETCH_ASSOC);
   $acsConData = $endpoint->fetch();
   $index = count($data);
   if(empty($conData) && $acsConData['mac_from'] != $mac) {
       return array();
   }
   if($acsConData['mac_from'] == $mac) 
   {
		//if($iter == 0) {
		//    return array();
		//}
		$conData['port_to'] = $acsConData['port_from'];
		$conData['mac_from'] = $acsConData['mac_to'];
		$conData['port_from'] = $acsConData['port_to'];
   		$data[$index]['connection'] = $conData;
   		$device = $dbh->query("SELECT * FROM `tb_devices` 
                	INNER JOIN tb_interfaces 
                	ON tb_interfaces.device_id = tb_devices.id 
	   		        WHERE MAC = '$mac'", PDO::FETCH_ASSOC);
   		$devData = $device->fetch();
   		$data[$index]['device'] = $devData;
   		$index = count($data);
   		$data[$index]['connection'] = array();
		$devData['MAC'] = $acsConData['mac_to'];
		$devData['name'] = "ACS server is out best friend!!!";
   		$data[$index]['device'] = $devData;
		return $data;
   }
   $data[$index]['connection'] = $conData;
   $portNumber = $conData['port_to'];
   $device = $dbh->query("SELECT * FROM `tb_devices` 
                	INNER JOIN tb_interfaces 
                	ON tb_interfaces.device_id = tb_devices.id 
	   		WHERE MAC = '$mac' and tb_interfaces.number = '$portNumber'", PDO::FETCH_ASSOC);
   $devData = $device->fetch();
   $data[$index]['device'] = $devData;
   $iter = $iter + 1;
   return getConnectionSwitchInfo($conData['mac_from'], $data, $iter);
}


function getSwitchInfoByRouterMAC() 
{
	global $dbh;
	$mac = $_POST['mac']; 
	foreach($dbh->query("SELECT * FROM `tb_devices`  
						INNER JOIN tb_interfaces 
						ON tb_interfaces.device_id = tb_devices.id 
						INNER JOIN tb_mac 
						ON tb_mac.interface_id = tb_interfaces.id
						WHERE tb_mac.mac = '$mac'") as $row) {
				echo json_encode($row);
	}
	
}
	
?>
