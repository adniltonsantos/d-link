<?php

class LogFile {

    public function getMsgFormat($msg){
        if (session_id() == '') {
            session_start();
        }
        $login=$_SESSION['logged_in'];
        $date=date('m/d/Y h:i:s a', time());
        return $login."(".$date.')-'.$msg;
    }

    public function createInLog($msg){
        if (!$handle = fopen('/var/www/ACS_09_04_2014/dbConf/usrGroup/ACS/web.log', 'w')) {
            return false;
        }
        if (!fwrite($handle, $msg)) {
            return false;
        }
        fclose($handle);
        return true;
    }

    public function createErrorInLog($msg){
        if (!$handle = fopen('/var/www/ACS_09_04_2014/dbConf/usrGroup/ACS/error.log', 'w')) {
            return false;
        }
        if (!fwrite($handle, $msg)) {
            return false;
        }
        fclose($handle);
        return true;

    }

} 