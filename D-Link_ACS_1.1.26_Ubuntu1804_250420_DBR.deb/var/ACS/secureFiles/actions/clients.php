<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try {
        include $_SESSION['APPPATH'] . 'models/modelClient.php';
        include $_SESSION['APPPATH'] . 'util/pagingConstants.php';

        $client = new ModelClient();
        $page = 1;


        $limit = PagingConstants::$clientsCount;
        $offset = ($page - 1) * $limit;
        $sortedVal = "first_name";
        $clients = $client->getAllClients($limit, $offset);

        $allClientsCount = $client->getAllClientsCount();

        $notEmptyRowsCountByAddress=$client->getNotEmptyRowsCountByColumnName("address");
        $notEmptyRowsCountByPatronic=$client->getNotEmptyRowsCountByColumnName("patronymic_name");

        $clientsCount = $allClientsCount[0]->count;


        include $_SESSION['APPPATH'] . 'util/paging.php';

        $pagesCount = Paging::getPagesCount($clientsCount, $limit);

        include $_SESSION['APPPATH'] . 'views/tiles/admin/clients_view.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}