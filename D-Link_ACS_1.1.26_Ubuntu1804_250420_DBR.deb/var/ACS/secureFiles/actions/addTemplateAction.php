<?php if (session_id() == '') { session_start(); }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            return "logged_out";
//        }
//    }
    
if (isset($_SESSION['logged_in'])) {
    try{
        define("BASEPATH", $_SESSION['BASEPATH']);
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }

        if(isset($_POST['action']) && $_POST['action'] != '' && isset($_POST['fromApp'])){
            if($_POST['action'] == 'addTemplate'){
                $toAdd = 'true';
                include $_SESSION['APPPATH'].'views/content/admin/addTemplate.php';

            }else if($_POST['action'] == 'showDescritors') {
                try{
                    $page = 1;
                    if(isset($_POST['page'])){
                        $page = $_POST['page']; 
                    }

                    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
                    $limit = 5;
                    $offset = ($page - 1) * $limit;

                    $mTemplates = new ModelTemplates();
                    $defaultDescriptor = $mTemplates->getDefaultDescriptor();
                    $descriptors = $mTemplates->getAllDescriptorsList($limit,$offset);
                    $allDescriptorsCount = $mTemplates->getAllDesctiptorsCount();
                    $devCount = $allDescriptorsCount[0]->count;
                    if ($devCount < $limit) {
                        $pagesCount = 1;
                    } else {

                        if ($devCount % $limit == 0) {
                            $pagesCount = $devCount / $limit;
                        } else {
                            $pagesCount = ($devCount / $limit - ($devCount % $limit) * (1 / $limit)) + 1;
                        }
                    }

                    include  $_SESSION['APPPATH'].'views/content/admin/showDescriptors.php';
                }catch (\Exception $e){
                    error_log($e->getMessage());
                    header('HTTP/1.1 500 Internal Server Error');
                    header("Status: 500 Internal Server Error");
                    exit();
                } 
            }
        }
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    echo 'logged_out';
}