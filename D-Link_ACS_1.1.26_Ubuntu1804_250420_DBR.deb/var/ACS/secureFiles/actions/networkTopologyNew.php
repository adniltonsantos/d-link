<?php
if (session_id() == '') {
    session_start();
}

if (isset($_SESSION['lang'])) {
    $lang = $_SESSION['lang'];
}
if ($lang == '' || $lang == 'en') {
    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
} else {
    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
}


function readAcsSettings()
{
	$settingsFile = '/etc/acs/config/acs.conf';
	$content = file_get_contents($settingsFile);
	$contentArray = explode("\n", $content);
	$settingsArray = array();
	foreach($contentArray as $setting)
	{
		list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
		if ($value !== NULL)
		{
			$settingsArray[trim($key)] = trim($value);
		}
	}
	return $settingsArray;
}
$SNMP_SERVER_IP = '127.0.0.1';
$SNMP_SERVER_PORT = '30008';
$DB = readAcsSettings();
$SNMP_PASSWORD = $DB['password'];
$SNMP_USER_NAME = $DB['username'];
$SNMP_DB_NAME = 'SNMP'; // TODO the db name must be moved to /etc/acs/config... file 


function checkSNPServerIsUnreachable() 
{
    global $SNMP_SERVER_IP;
    global $SNMP_SERVER_PORT;
    $ch = curl_init("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if (curl_errno($ch) == 7) {
		header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);	
        error_log("(SNMP Server): $SNMP_SERVER_IP:$SNMP_SERVER_PORT Destination Host Unreachable");
        require_once 'secureFiles/views/content/admin/error500.php';
        exit(1);
    } 
}


class PortParam 
{
   const IN_ERROR = 1;
   const OUT_ERROR = 2;
   const LINK = 3;
   const STATUS = 4;
};

class ConnectionType {
    const DEFAULT_ = 0; // simple connection
    const ACS = 1;     // connect to ACS server
    const Inet = 2;   //  internet connection
};

function ProcessingPortStatus($PStatus, $PBinary, $PPortParam)
{
	$b = 0;
	switch($PPortParam)
	{
		case PortParam::IN_ERROR:
			$b = $PBinary<<3;
		break;
		case PortParam::OUT_ERROR:
			$b = $PBinary<<2;
		break;
		case PortParam::LINK:
			$b = $PBinary<<1;
		break;
		case PortParam::STATUS:
			$b = $PBinary<<0;
		break;
	}
	$PStatus = $PStatus|$b; 
	return $PStatus;
}

function ConvertToBinary($PParam, $PPortParam )
{
	if($PPortParam == PortParam::IN_ERROR 
	or $PPortParam == PortParam::OUT_ERROR)
	{
		if($PParam > 0)	{
			return 0x1;
		} 
		else 
		{
			return 0x0;
		}

	} 
	else if($PPortParam == PortParam::STATUS
		  or$PPortParam == PortParam::LINK)
	{
		if($PParam >= 2)
		{
				return 0x1;
		} else if($PParam == 1)
		{
		   return 0x0;
		}
	}
}


function GetPortColor($PInError, $POutError, $PLink, $PStatus) 
{
	$InError = ConvertToBinary($PInError, PortParam::IN_ERROR);
	$OutError = ConvertToBinary($POutError, PortParam::OUT_ERROR);
	$Link = ConvertToBinary($PLink, PortParam::LINK);
	$Status = ConvertToBinary($PStatus, PortParam::STATUS);
	$Data = 0;	
	$Data = ProcessingPortStatus($Data, $InError, PortParam::IN_ERROR);
	$Data = ProcessingPortStatus($Data, $OutError, PortParam::OUT_ERROR);
	$Data = ProcessingPortStatus($Data, $Link, PortParam::LINK);
	$Data = ProcessingPortStatus($Data, $Status, PortParam::STATUS);
	return $Data;
}



	
//checkSNPServerIsUnreachable(); // TODO after implement API beed to recoment this line.

function getInterfaces($devID, $dbh)
{
    $interfaces = array(); 
    $tb_interfaces = $dbh->query("SELECT * FROM `tb_interfaces` WHERE `device_id` = $devID ");
    if($tb_interfaces != null) {
        foreach($tb_interfaces as $rowInterface) {
            $rrdTool  = $dbh->query("SELECT status FROM `tb_rrdtool` WHERE `device_id`='$devID' AND  `ifac_number`='$rowInterface[number]'"
            , PDO::FETCH_ASSOC)->fetch();
            $rowInterface['rrdtool_status'] = isset($rrdTool['status']) == true ? $rrdTool['status'] == 1 ? true : false : false ;
            $macDB = $dbh->query("SELECT GROUP_CONCAT(mac  SEPARATOR '\n') as mac FROM `tb_mac` WHERE `interface_id` = '$rowInterface[id]'");
            if( $macDB->rowCount() > 0) {
                foreach($macDB as $rowMAC) {
                    $interfaces[] = array_merge($rowInterface, $rowMAC);
                }
            } else {
                $interfaces[] = $rowInterface;
            }
        }
        return $interfaces;
    } else {
        global $SNMP_DB_NAM ;
        error_log("The 'tb_interfaces' table doesn't exist in the $SNMP_DB_NAM database. ");
        require_once 'secureFiles/views/content/admin/error500.php';
    }

}


function getUnknowDevices($devices, $dbh)
{
    $devID = rand();
    $macsDB = $dbh->query("SELECT * FROM `MAC`");
    $tmp = $devices;
    /*
    echo "<pre>";
    foreach($macsDB as $mac) {
        $devDB = $dbh->query("SELECT * FROM `devices` WHERE `MAC` = '$mac[mac]'");
        if( $devDB->rowCount() == 0 ) {
            foreach($dbh->query("SELECT * FROM `interfaces` WHERE `id` = $mac[interface_id]") as $inter) {
                print_r($inter);
                //print_r($inter['id'] . " :  " . $inter['device_id'] . " : " .  $inter['countMAC'] . "<br />");
                //foreach($dbh->query("SELECT * FROM `devices` WHERE `id` = '$inter[device_id]'") as $tmpDev) {
                //    $devices[] = array("name" => "Unknow device $mac[mac]"
                //                        , "id" => "unknow" . $devID
                //                        , "MAC" => $mac['mac']
                //                        , 'interfaces' => array( array("number" => "1", "mac" => $tmpDev['MAC']) ));
                //}
            
            }
        }
    }
    echo "</pre>";
    exit(1);
    */
    
    //SELECT i.*, d.* FROM interfaces i INNER JOIN devices d ON d.id = i.device_id WHERE i.countMAC <> 0
    foreach($dbh->query("SELECT i.*, d.*, i.id as interfaceId FROM interfaces i INNER JOIN devices d ON d.id = i.device_id WHERE i.countMAC <> 0") as $data) {
           foreach($dbh->query("SELECT m.MAC FROM interfaces i INNER JOIN MAC m ON i.id = m.interface_id WHERE m.interface_id = $data[interfaceId] LIMIT 1") as $MAC) {
        $devices[] = array("name" => "Unknow device $data[countMAC]"
                            , "id" => "unknow" . $devID
                            , "MAC" => $MAC['MAC']
                            , 'interfaces' => array( array("number" => "1", "mac" => $data['MAC']) ));
       }
    
    }
    return $devices;
        
}

function createDevices($data) 
{
    $result = array();
    foreach($data as $key => $row) {
        $dev = array();  
        $dev['name'] = $row['name'];
        $dev['mac'] = $row['MAC'];
        $dev['ip'] = $row['IP'];
        $dev['key'] = $row['id'];
        $dev['devStatus'] = $row['dev_status'];
        $topArray = array();
        $bottomArray = array();
        $portList = array();
        $portCount = 0;
        $indexPort = 0;
        $tmp = array();
        foreach($row["interfaces"] as $port1) {
            $tmp[] = $port1['number'];
        }
        $portCount = count(array_unique($tmp));
        $dividePort = $portCount/2;
        foreach($row["interfaces"] as $index => $port) {
            if(in_array($port['number'], $portList)) {
                continue;
            }
            $portList[] = $port['number'];
			$PortColor = GetPortColor($port['inerrors'], $port['outerrors'], $port['link'], $port['status']);
            if($indexPort < $dividePort) {
                //{"portColor":"#d488a2", "portNumber": "1", "portId":"top0"}
                $topArray[]=array( "portColor" => $PortColor
                                 , "portNumber" => $port['number']
                                 , "rrdtool_status" => $port['rrdtool_status']
                                 , "portId" => strval($port['number'])
                                 , "status" => $port['status']
                                 , 'mac' => isset($port['mac']) ? $port['mac'] : "");
            } else {
                $bottomArray[]=array("portColor" => $PortColor
                                   , "portNumber" => $port['number']
                                   , "rrdtool_status" => $port['rrdtool_status']
                                   , "portId" => strval($port['number'])
                                   , "status" => $port['status']
                                   , 'mac' => isset($port['mac']) ? $port['mac'] : "");
            }

            $indexPort =  $indexPort + 1;
        }
		$dev['topArray'] = $topArray;
		$dev['bottomArray'] = $bottomArray;
		//if(((count($topArray) + count($bottomArray)) & 1)  == 0) {
		//} else {
        //	$dev['topArray'] = array();
        //	$dev['bottomArray'] = array();

		//}
        $result[] = $dev;
    }
    return $result;
}

function getSwitchInfo() {
	global $SNMP_DB_NAME;
	global $SNMP_USER_NAME;
	global $SNMP_PASSWORD;
	global $ini_array;
	$dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER_NAME, $SNMP_PASSWORD);
	$id = $_POST['id']; 
	$counter = 1;	
	echo "<table id='portStatusSNMP' class='portStatusSNMP networkTopologyTable'>";
	echo "<thead>";
	echo "<tr>";
	echo "<th>" . $ini_array['port']. "</th>";
	echo "<th>" . $ini_array['link']. "</th>";
	echo "<th>" . $ini_array['speed']. "</th>";
	echo "<th>" . $ini_array['Traffic_received']. "</th>";
	echo "<th>" . $ini_array['Traffic_sent']. "</th>";
	echo "<th>" . $ini_array['errors_downloading']. "</th>";
	echo "<th>" . $ini_array['errors_upload']. "</th>";
	echo "<th>" . $ini_array['band_usage']. "</th>";
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	$tb_devices = $dbh->query(" SELECT * FROM `tb_devices`  
				  INNER JOIN tb_interfaces 
				  ON tb_interfaces.device_id = tb_devices.id 
				  INNER JOIN
				  tb_bandUtil 
				  ON tb_interfaces.id = tb_bandUtil.interface_id
				  WHERE tb_devices.id = $id");
    if($tb_devices != null) {
        foreach($tb_devices as $row) {
            echo "<tr class='switchPortInfo' id='port$counter' style='border-bottom:1px solid black;'>";
            echo "<td>" . $counter . "</td>";
            if ($row['link'] == 1) {
                echo "<td>" . "up" . "</td>";
            } else if ($row['link'] == 2) {
                echo "<td>" . "down" . "</td>";
            } else {
                echo "<td>" . $row['link'] . "</td>";
            }
            echo "<td>" . floatval(number_format($row['ifspeed'] / 1000000 , 2)). "</td>";
            echo "<td>" . floatval(number_format ($row['byte_sent'] / 1000000, 2)) . "</td>";
            echo "<td>" . floatval(number_format ($row['byte_received'] / 1000000, 2)) . "</td>";
            echo "<td>" . $row['inerrors'] .  "</td>"; 
            if($row['outerrors'] == 1) {
                echo "<td bgcolor='#FE4141'><font color='#FFFFFF'>" . $row['outerrors'] . "</td>";
            } else {
                echo "<td>" . $row['outerrors'] . "</td>";
            }
            $color_band = abs($row['band_util'] - 100);
            echo "<td data-w3-color='hwb($color_band, 9%, 10%)'>" . "<font color='#ffffff'>" .
            $row['band_util'] . '%' .  "</font></td>"; 
            echo "</tr>";
            $counter++;
        }
        echo "</tbody>";
        echo "</table>";
    } else {
            global $SNMP_DB_NAM ;
            error_log("The tb_devices table doesn't exist in the $SNMP_DB_NAME database.");
            require_once 'secureFiles/views/content/admin/error500.php';
            return;

    }
}
	try {
		$devices = array();
        try {
            $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER_NAME, $SNMP_PASSWORD);
        } catch(PDOException $e) {
            global $SNMP_DB_NAM ;
            error_log("The $SNMP_DB_NAME database doesn't exist.");
            require_once 'secureFiles/views/content/admin/error500.php';
            return;
        }
        $swiches = $dbh->query('SELECT * FROM `tb_devices`');
        if($swiches != null) {
            foreach($swiches as $row) {
                $devices[] = $row;
            }
            foreach($devices as $index => $row ) {
                $devices[$index]['interfaces'] = getInterfaces($row['id'], $dbh);
            }
            $dev = createDevices($devices);

            $devS = json_encode($dev);
            $dbh = null;
        } else {
            global $SNMP_DB_NAM ;
            error_log("The 'tb_devices' table doesn't exist in the $SNMP_DB_NAM database. ");
            require_once 'secureFiles/views/content/admin/error500.php';
        }
	} catch (PDOException $e) {
		print "Error!: " . $e->getMessage() . "<br/>";
		die();
    }
    if(!empty($_POST))  {
        if( isset($_POST['action']) && $_POST['action'] == 'switch')  {
            echo $devS;
        }

        if( isset($_POST['action']) && $_POST['action'] == 'getSwitchInfo')  {
			getSwitchInfo();
        }

        if( isset($_POST['action']) && $_POST['action'] == 'getConnections')  {
            $connections = array();
			$dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER_NAME, $SNMP_PASSWORD);
            foreach($dbh->query('SELECT * FROM `tb_connections`', PDO::FETCH_ASSOC) as $connection) {
                $dev_from = $dbh->query("SELECT * FROM `tb_devices` WHERE mac = '$connection[mac_from]'"
                    , PDO::FETCH_ASSOC)->fetch(); 
                $dev_to = $dbh->query("SELECT * FROM `tb_devices` WHERE mac = '$connection[mac_to]'" 
                    , PDO::FETCH_ASSOC)->fetch(); 
                $con = array(  'fromSwitch' => $dev_from['id']
                             , 'toSwitch' => $dev_to['id']
                             , 'fromMac'  => $connection['mac_from']
                             , 'toMac'  => $connection['mac_to']
                             , 'fromPortNumber'  => $connection['port_from']
                             , 'toPortNumber'  => $connection['port_to']
                             , 'status'  => $connection['status']
                             , 'conn_type'  => $connection['conn_type']
                             );
                $connections[] = $con;

            }
            echo json_encode($connections);

        }
        

        if( isset($_POST['action']) && $_POST['action'] == 'login')  {
            // TODO the cndition is tmp 
            echo json_encode(array('status' => 'ok'));	
            
        }

        if( isset($_POST['action']) && $_POST['action'] == 'removeConnection')  {
			$fromMAC = isset($_POST['fromMAC']) ? $_POST['fromMAC'] : '' ;
			$toMAC = isset($_POST['toMAC'])  ? $_POST['toMAC'] : '' ;
			$fromPort = isset($_POST['fromPort']) ? $_POST['fromPort'] : '' ;
			$toPort = isset($_POST['toPort']) ? $_POST['toPort'] : '' ;
			$data = getMethod14($fromMAC, $fromPort, $toMAC, $toPort);
			$r = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
			if(isset($r['Result']) && $r['Result'] == 1) {
				echo json_encode(array('status' => 'ok'));	
			}
		}

        if( isset($_POST['action']) && $_POST['action'] == 'newConnection')  {
			$fromSwID = isset($_POST['fromSwID']) ? $_POST['fromSwID'] : '' ;
			$toSwID = isset($_POST['toSwID']) ? $_POST['toSwID'] : '' ;
			$toPortNumber = isset($_POST['toPortNumber']) ? $_POST['toPortNumber'] : '' ;
			$fromPortNumber = isset($_POST['fromPortNumber']) ? $_POST['fromPortNumber'] : '' ;
			$data = getMethod2($fromSwID, $fromPortNumber, $toSwID, $toPortNumber);
			$r = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
			if(isset($r['Result']) && $r['Result'] == 1) {
				echo json_encode(array('status' => 'ok'));	
			} 
            
        }

	if( isset($_POST['action']) && $_POST['action'] == 'disableConnection')  {
			$id = isset($_POST['id']) ? $_POST['id'] : '' ;
			$port = isset($_POST['port']) ? $_POST['port'] : '' ;
			$data = getMethod1($id, $port, 2); 
			$r = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
			if(isset($r['Result']) && $r['Result'] == 1) {
				echo json_encode(array('status' => 'ok'));	
			}
		}

        if( isset($_POST['action']) && $_POST['action'] == 'enableConnection')  {
			$id = isset($_POST['id']) ? $_POST['id'] : '' ;
			$port = isset($_POST['port']) ? $_POST['port'] : '' ;
			$data = getMethod1($id, $port, 1); 
			$r = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
			if(isset($r['Result']) && $r['Result'] == 1) {
				echo json_encode(array('status' => 'ok'));	
			}
		}
        if( isset($_POST['action']) && $_POST['action'] == 'enableRRDToll')  {
			$id = isset($_POST['id']) ? $_POST['id'] : '' ;
			$port = isset($_POST['port']) ? $_POST['port'] : '' ;
			$data = getMethod4($id, $port); 
			$r = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
			if(isset($r['Result']) && $r['Result'] == 1) {
				echo json_encode(array('status' => 'ok'));	
			}
		}
        if( isset($_POST['action']) && $_POST['action'] == 'disableRRDToll')  {
			$id = isset($_POST['id']) ? $_POST['id'] : '' ;
			$port = isset($_POST['port']) ? $_POST['port'] : '' ;
			$data = getMethod16($id, $port); 
			$r = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
			if(isset($r['Result']) && $r['Result'] == 1) {
				echo json_encode(array('status' => 'ok'));	
			}
		}
        if( isset($_POST['action']) && $_POST['action'] == 'checkSwitchStatus')  {
			$id = isset($_POST['id']) ? $_POST['id'] : '' ;
			$data = getMethod3($id); 
			$r = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
			if(isset($r['Result']) && $r['Result'] == 1) {
				echo json_encode(array('status' => 'ok'));	
			}
		}
        if( isset($_POST['action']) && $_POST['action'] == 'getACSServer')  {
            $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER_NAME, $SNMP_PASSWORD);
            $ACS_server = $dbh->query("SELECT * FROM tb_connections WHERE conn_type = " . ConnectionType::ACS
                , PDO::FETCH_ASSOC)->fetch();
            echo json_encode($ACS_server);

        }

        if( isset($_POST['action']) && $_POST['action'] == 'getInet')  {
            $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER_NAME, $SNMP_PASSWORD);
            $ACS_server = $dbh->query("SELECT * FROM tb_connections WHERE conn_type = " . ConnectionType::Inet
                , PDO::FETCH_ASSOC)->fetch();
            echo json_encode($ACS_server);

        }

        if( isset($_POST['action']) && $_POST['action'] == 'translate')  {
            if (isset($_POST['words']) ) {
                    $translated = [];
                    foreach( $_POST['words'] as $key ) {
                        if(!isset($ini_array[$key])) continue;
                        $translated[$key] = $ini_array[$key];
                    }
                    echo json_encode($translated);
            } else {
                error_log("The word key has not been in the \$_POST map");
                require_once 'secureFiles/views/content/admin/error500.php';
            }
        }

    } else {
        require_once $_SESSION['APPPATH'].'views/tiles/admin/networkTopology_viewNew.php';
    }

	function getMethod14($fromMAC, $fromPort, $toMAC, $toPort)
	{
		$r = array('Method' => 14
				   , 'Type' => 1
                   , 'From' => array('MAC' => $fromMAC, 'Port' => $fromPort)
                   , 'To' => array('MAC' => $toMAC, 'Port' => $toPort)
		);						
		return $r;
	}

	function getMethod1($id, $port, $action)
	{
		$r = array(  'Method' => 1 
				   , 'Type' => 1
                   , 'Device' => array(array( 'id' => $id
                                              ,'Port' => $port
                                              ,'Link' => $action 
                                           ) 
                                )
		);						
		return $r;
	}

    /**
     *  Get Method 4 is envisaged to Enable  RRDTool
     * @param $id
     * @param $port
     * @return array
     */
	function getMethod4($id, $port)
	{
		$r = array(  'Method' => 4 
				   , 'Type' => 1
                   , 'Device' => array( array(  'id' => $id
                                              ,'Port' => array($port) // TODO for the array($port) need discussion with Hayk
                                            ) 
                                      )
		);						
		return $r;
	}

    /**
     *  Get Method 16 is envisaged to disable  RRDTool
     * @param $id
     * @param $port
     * @return array
     */
	function getMethod16($id, $port)
	{
		$r = array(  'Method' => 16
				   , 'Type' => 1
                   , 'Device' => array( array(  'id' => $id
                                              ,'Port' => array($port) // TODO for the array($port) need discussion with Hayk
                                            ) 
                                      )
		);						
		return $r;
	}

	function getMethod3($id)
	{
		$r = array(  'Method' => 3 
				   , 'Type' => 2
                   , 'Device' => array( array('id' => $id) ));						
		return $r;
	}

	function getMethod2($fromSwID, $fromPortNumber, $toSwID, $toPortNumber)
	{
		$r = array(  'Method' => 2 
				   , 'Type' => 1
                   , 'Device' => array(  array( 'From' =>  array( 'id' => $fromSwID 
                                                                 ,'Port' => $fromPortNumber) 
                                           ,    'To' =>array( 'id' => $toSwID 
                                                             ,'Port' => $toPortNumber)
                                              )
                                     )
		);						
		return $r;
	}


	function sendConfigToSNMPServer($url, $data)
	{
		$data_string = json_encode($data);
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
					'Content-Type: application/json',
					'Accept: application/json',
					'Content-Length: ' . strlen($data_string))
				);
		$response = curl_exec($ch);
		return $response;
	}

?>
