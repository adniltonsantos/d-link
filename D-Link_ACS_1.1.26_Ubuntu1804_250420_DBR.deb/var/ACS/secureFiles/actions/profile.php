<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        require_once $_SESSION['APPPATH'].'util/pagingConstants.php';
        require_once $_SESSION['APPPATH'].'models/device.php';
        require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
        require_once $_SESSION['APPPATH']."actions/api/token.php";

        $dev = new Device();
        $userName = $_SESSION['logged_in'];
        $user = new ModelUser();
        $token = token::create_token($userName);
        $account = $user->getProfileInfo($userName);
        $HeartINT = $dev->getDevHeartInter();
        $HeartWAR = $dev->getDevHeartWar();
        $HeartERR = $dev->getDevHeartErr();
        $needFilesList = array();
        $fileListIsEmpty = true;
        $dirName = $_SESSION['REALPATH']."/"."CSV";
        $i = 1;
        if(file_exists($dirName)){
            $files = scandir($dirName);
            foreach ($files as $f){
                if($f !="." && $f !=".." && preg_match("/.csv/", $f) && $f=="file.csv"){
                    array_push($needFilesList, $f);
                    $i++;
                    $fileListIsEmpty = false;
                }
            }
        }
        require_once $_SESSION['APPPATH'].'views/tiles/admin/pofiles_view.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}