<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        require_once $_SESSION['APPPATH'].'models/modelClient.php';
        require_once $_SESSION['APPPATH'].'util/pagingConstants.php';
        require_once $_SESSION['APPPATH'].'util/paging.php';
        require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
        require_once $_SESSION['APPPATH'].'models/device.php';
        require_once $_SESSION['APPPATH'].'models/modelParams.php';
        require_once $_SESSION['APPPATH'].'models/modelUser.php';
        if (isset($_SESSION['permissions'])) {
            require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
            $permissionsArray = $_SESSION['permissions'];
            $groupID = $_SESSION['group_id'];
        }

        $client = new ModelClient();
        $page = 1;
        $limit = PagingConstants::$clientsCount;
        $offset = ($page - 1) * $limit;

        $sortedVal = "last_inform_time";
        $unknownsDevicesList = $client->getAllUnknownDevices(0,$limit, $offset);

        $pendingDevicesList = $client->getAllUnknownDevicesByClientID(0,$limit, $offset);

        $pendingAllDevicesList = $client->getAllPendingDevicesByClientID("");

        $allPendingDevicesList = $client->getAllUnknownDevicesCount1(0);
        $modelsFromPending = $client->getAllModelsFrmUnknowns1();

        $pendingsCount = $allPendingDevicesList[0]->count;
        $pendingPagesCount = Paging::getPagesCount($pendingsCount,$limit);

        $allUnknownsDevicesList = $client->getAllUnknownDevicesCount(0);

        $unknownsCount = $allUnknownsDevicesList[0]->count;

        $pagesCount = Paging::getPagesCount($unknownsCount,$limit);

        $allExistingClientsCount = $client->getAllExistingClientsCount();

        $allClientsCount = $client->getAllClientsCount();

        $modelsFromUnknowns=$client->getAllModelsFrmUnknowns();
        // for connecting tarifs
        $templ = new ModelTemplates();
        $allTemplates = $templ->getAllTemplates();

        $device = new Device();
        if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
            $groups = $device->getAllGroupsForUnknown($_SESSION['userID']);
        } else {
            $groups = $device->getAllGroups();
        }

        $modParams = new ModelParams();
        $params = $modParams->conectionType();

        $modUser = new modelUser();
        $clientType = $modUser->getAutoCreateClinet();

        $intervalTime = $modUser->getUnknownInfTime();
        $remoteAccessInput = $modUser->getUnknownRemoteAccessInp();
        $stunEnable = $modUser->getUnknownStunEn();
        $DeviceUserName = $modUser->getUnknownDevUsName();
        $DevicePassword = $modUser->getUnknownDevPas();
        $UnknownPassword = $modUser->getUnknownPassword();


        require_once $_SESSION['APPPATH'].'views/tiles/admin/unknowns_view.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}
