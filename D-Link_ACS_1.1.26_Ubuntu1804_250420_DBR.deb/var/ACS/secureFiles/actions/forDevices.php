<?php

function devices(){
    require_once $_SESSION['APPPATH'].'models/device.php';
    require_once $_SESSION['APPPATH'] . 'util/usersConstants.php';
    require_once $_SESSION['APPPATH'].'util/paging.php';
    require_once $_SESSION['APPPATH'].'util/utils.php';
    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
    
    require_once $_SESSION['APPPATH'] . 'sockets/createXML.php';
    require_once $_SESSION['APPPATH'] . 'sockets/connectTCP.php';
    require_once $_SESSION['APPPATH'] . 'util/actionNamesConstants.php';
    $permissionsArray = array();
    $unGroup = false;
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupID = $_SESSION['group_id'];
        }
    }
    $page = 1;
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    
//    if(isset($_SESSION['rowCount'])){
//        $limit = $_SESSION['rowCount'];




    if(property_exists($userSettings, 'rowCount')){
        $limit = $rowCount = $userSettings->rowCount;

    }  else {
        $limit = 10;
    }
    //$limit = 1;

    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }
    
    $offset = ($page - 1) * $limit;

    $dev = new Device();
    $HeartINT = $dev->getDevHeartInter();
    $HeartWAR = $dev->getDevHeartWar();
    $HeartERR = $dev->getDevHeartErr();
    if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
//        $devCount = 0;
        $devices = array();
        $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
        $countGroups=count($groupList);
        $devices = $dev->getDevicesByGroups($groupList, $countGroups,$limit,$offset,"");
        $devCount = $dev->getAllDevicesCountByGroups($groupList, $countGroups);
//        if ($devCount > $limit) {
//            for($i=0; $i<$limit; $i++) {
//                $devices[$i] = $devices1[$i];
//            }
//        } else {
//            $devices = $devices1;
//        }
        $groupIDs = array();

            for($i = 0; $i < $countGroups; $i++) {
                if($groupList[$i]->name != "Ungrouped") {
                    array_push($groupIDs, $groupList[$i]->id);
                } else {
                    $unGroup = true;
                }
            }
            $models = $dev->getAllModelsHavingMin1ActiveDevByGroups($groupIDs, $unGroup);
        $groups = $groupList;
    } else if ($groupID == 'Manager'){
        $groupList=$dev->getGroup_task_allow($_SESSION['userID']);
        $devices = $dev->getDevices($limit, $offset,"");
        $groups = $dev->getAllGroups();
        $models = $dev->getAllModelsHavingMin1ActiveDev();
        $allDeviceCount = $dev->getAllDevicesCount();
        $devCount = $allDeviceCount[0]->count;
    }else {
        $devices = $dev->getDevices($limit, $offset,"");
        $groups = $dev->getAllGroups();
        $models = $dev->getAllModelsHavingMin1ActiveDev();
        $allDeviceCount = $dev->getAllDevicesCount();
        $devCount = $allDeviceCount[0]->count;
    }

//    $models = $dev->getAllModelsHavingMin1ActiveDev();
    $modelsForDescription=$dev->getAllModels();

//    $allDeviceCount = $dev->getAllDevicesCount();

    $devicesIds = array();
    $devicesMACs = array();
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);

    if(!empty($devices)){
        Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    }
    
    $havePerm = false;
    $permissionsArray = $_SESSION['permissions'];
    
    if (in_array(UsersConstants::$devicePermission,$permissionsArray)){
            $havePerm = true;
    } else {
            $havePerm = false;
    }

    $templ = new ModelTemplates();
    $allTemplates = $templ->getAllTemplates();

    $pagesCount = Paging::getPagesCount($devCount,$limit);

    require_once $_SESSION['APPPATH'].'views/tiles/admin/devices_view.php';
}

if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try {
        devices();
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
    
} else {
    require_once 'secureFiles/actions/login.php';
}