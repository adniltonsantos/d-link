<?php

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try {
            require_once $_SESSION['APPPATH'] . 'models/device.php';
            if(isset($_SESSION['group_id'])) {
                $groupID = $_SESSION['group_id'];
            }
            $dev = new Device();
            
            $groupId = $_POST['groupId'];
            $models = '';
            if($groupId > 0 || $groupId == -2){
                $models = $dev->getAllModelsByGroup($groupId);
            }else if($groupId == 0){
                if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
                    $unGroup = false;
                    $groups=array();
                    $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);

                    for ($i = 0; $i < count($groupList); $i++) {
                        if ($groupList[$i]->name != "Ungrouped") {
                            array_push($groups, $groupList[$i]->id);
                        } else {
                            $unGroup = true;
                        }
                    }

                    $models = $dev->getAllModelsHavingMin1ActiveDevByGroups($groups, $unGroup);
                } else {
                    $models = $dev->getAllModelsHavingMin1ActiveDev();
                }
            }
            
            $data = '';
            if (is_array($models) && !empty($models)) {
                foreach ($models as $model) {
                   $data .= '<option value="'. $model->id .'">'. $model->name. ' | '. $model->hw_version .'</option>';
                } 
            } 
                                      
            echo $data;
            
        } catch (Exception $exc) {
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
            
    } else {
        echo "logged_out";
    }
} else {
    exit('No direct script access allowed');
}




