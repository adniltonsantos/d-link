<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        if(!class_exists("ModelUser")){
            include $_SESSION['APPPATH'].'models/modelUser.php';
        }

        $user = new ModelUser();
        $userGroups = $user->getAllUserGroups();
        $groupss = $user->getGroupsForUserGroup();
        $ungrouped = $user->getUngrouped();
        $ungroup=false;
        $userId = $_POST['userId'];
        $users = $user->getUsersById($userId);

            $groupList=$user->getGroupsSelectedUser($users[0]->id);
            $username = $users[0]->username;
            if(!$groupList){
                $groupList=array();
                $ungroup = false;
            }
            for($j=0; $j<count($groupList); $j++) {
                if($groupList[$j]->default==1){
                    $ungroup = true;
                    break;
                } else {
                    $ungroup = false;
                }
            }
            $users[0] = (object) array_merge((array)$users[0], array( 'groupList' => $groupList));
            $users[0] = (object) array_merge((array)$users[0], array( 'ungrouped' => $ungroup));
            $groupN = $users[0]->groupList;
            $uncheckedArray = array();
            for($k = 0; $k < count($groupN); $k++) {
                array_push($uncheckedArray, $groupN[$k]->id);
            }
            $uncheckedGroups = $user->getUncheckedGroups($uncheckedArray);
            $users[0] = (object) array_merge((array)$users[0], array( 'uncheckedGroups' => $uncheckedGroups));
        $adminsCountArr = $user->getAdminsCount();
        $adminsCount = (int)$adminsCountArr[0]->count;

        include $_SESSION['APPPATH'] . 'views/content/admin/editUsers.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}

