<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') { session_start(); }   
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if(!class_exists("ParamNamesConstants")){include $_SESSION['APPPATH'] . "util/paramNamesConstants.php";}
    
if (isset($_SESSION['logged_in'])) {
    try{
        $lang = $_SESSION['lang'];
        define('BASEPATH', $_SESSION['BASEPATH']);
        if ($lang == 'en') {
            $ini_array = parse_ini_file( $_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file( $_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }

        $waId = $_POST['id'];
        $connType = $_POST['connType'];
        $paramNames = $_POST['paramN'];
        $paramValues = $_POST['paramV'];
        $params = array();

        if ($connType == "static") {

            if(in_array(ParamNamesConstants::$name,$paramNames)){
                $ii = array_search(ParamNamesConstants::$name,$paramNames); 
                $params['Name'] = $paramValues[$ii];
            } else { 
                $params['Name'] = ''; 
            }

            if(in_array(ParamNamesConstants::$ext_ip_address,$paramNames)){
                $ii = array_search(ParamNamesConstants::$ext_ip_address,$paramNames); 
                $params['ip'] = $paramValues[$ii];
            } else { 
                $params['ip'] = ''; 
            }

            if(in_array(ParamNamesConstants::$subnet_mask,$paramNames)){
                $ii = array_search(ParamNamesConstants::$subnet_mask,$paramNames); 
                $params['netmask'] = $paramValues[$ii]; 
            } else {  
                $params['netmask']='';  
            }

            if(in_array(ParamNamesConstants::$mtuDesc,$paramNames)){ 
                $ii = array_search(ParamNamesConstants::$mtuDesc,$paramNames); 
                $params['mtu'] = $paramValues[$ii];  
            } else {    
                $params['mtu'] = 0;  
            }

            if(in_array(ParamNamesConstants::$macDesc,$paramNames)){ 
                $ii = array_search(ParamNamesConstants::$macDesc,$paramNames);  
                $params['mac'] = $paramValues[$ii]; 
            } else {  
                $params['mac'] = '';   
            }

            if(in_array(ParamNamesConstants::$def_gateway,$paramNames)){
                $ii = array_search(ParamNamesConstants::$def_gateway,$paramNames); 
                $params['gateway'] = $paramValues[$ii]; 
            } else {  
                $params['gateway'] = '';  
            }

            if(in_array(ParamNamesConstants::$dns,$paramNames)){
                $ii = array_search(ParamNamesConstants::$dns,$paramNames); 
                $dns = explode(',', $paramValues[$ii]);
    //            $params['dns'] = $paramValues[$ii]; 
                $params['primaryDns'] = $dns[0]; 
                if(isset($dns[1])){
                    $params['secondaryDns'] = $dns[1]; 
                }  else {
                    $params['secondaryDns'] = '';
                } 
            } else {  
                $params['primaryDns'] = '';  
                $params['secondaryDns'] = '';    
            }

            if(in_array(ParamNamesConstants::$nat,$paramNames)){
                $ii = array_search(ParamNamesConstants::$nat,$paramNames); 
                $params['enableNat'] = $paramValues[$ii]; 
            } else {  
                $params['enableNat'] = 0;  
            }

            if(in_array(ParamNamesConstants::$enableDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$enableDesc,$paramNames);
                $params['enable'] = $paramValues[$ii]; 
            } else {  
                $params['enable'] = 0;  
            }

    //        $toAdd = 'true';
            include  $_SESSION['APPPATH'].'views/content/admin/wanStaticTarif.php';

        } else if ($connType == "dynamic") {
    //        TODO: Commented out as there is no DNSEnabled on Dynamic connection of wan of tarif
    //        $params = array( "enableDns" => array("DNSEnabled", trim($paramsFromModel[0]->dns_enabled)));

            if(in_array(ParamNamesConstants::$name,$paramNames)){
                $ii = array_search(ParamNamesConstants::$name,$paramNames); 
                $params['Name'] = $paramValues[$ii];
            } else { 
                $params['Name'] = ''; 
            }

            if(in_array(ParamNamesConstants::$mtuDesc,$paramNames)){ 
                $ii = array_search(ParamNamesConstants::$mtuDesc,$paramNames); 
                $params['mtu'] = $paramValues[$ii];  
            } else {    
                $params['mtu'] = 0;    
            }

            if(in_array(ParamNamesConstants::$macDesc,$paramNames)){ 
                $ii = array_search(ParamNamesConstants::$macDesc,$paramNames);  
                $params['mac'] = $paramValues[$ii]; 
            } else {
                $params['mac'] = '';      
            }

            if(in_array(ParamNamesConstants::$dns_servers,$paramNames)){
                $ii = array_search(ParamNamesConstants::$dns_servers,$paramNames); 
                $dns = explode(',', $paramValues[$ii]);
    //            $params['dns'] = $paramValues[$ii]; 
                $params['primaryDns'] = $dns[0]; 
                if(isset($dns[1])){
                    $params['secondaryDns'] = $dns[1]; 
                }  else {
                    $params['secondaryDns'] = '';
                }

            } else {  
                $params['primaryDns'] = '';  
                $params['secondaryDns'] = '';  
            }

            if(in_array(ParamNamesConstants::$nat,$paramNames)){
                $ii = array_search(ParamNamesConstants::$nat,$paramNames); 
                $params['enableNat'] = $paramValues[$ii]; 
            } else {  
                $params['enableNat'] = 0; 
            }

            if(in_array(ParamNamesConstants::$enableDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$enableDesc,$paramNames); 
                $params['enable'] = $paramValues[$ii]; 
            } else {  
                $params['enable'] = 0; 
            }

            if(in_array(ParamNamesConstants::$dnsEnable,$paramNames)){
                $ii = array_search(ParamNamesConstants::$dnsEnable,$paramNames); 
                $params['enableDns'] = $paramValues[$ii]; 
            } else {  
                $params['enableDns'] = 0;  
            }

            include  $_SESSION['APPPATH'].'views/content/admin/wanDynamicTarif.php';

        } else if ($connType == "ppp" || $connType == "l2tp" || $connType == "pptp") {

            if(in_array(ParamNamesConstants::$mruDesc,$paramNames)){ 
                $ii = array_search(ParamNamesConstants::$mruDesc,$paramNames); 
                $params['mru'] = $paramValues[$ii];  
            } else {    
                $params['mru'] = 0;    
            }

            if(in_array(ParamNamesConstants::$usernameDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$usernameDesc,$paramNames); 
                $params['username'] = $paramValues[$ii]; 
            } else {  
                $params['username'] = '';  
            }

            if(in_array(ParamNamesConstants::$passwordDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$passwordDesc,$paramNames); 
                $params['password'] = $paramValues[$ii]; 
            } else {  
                $params['password'] = '';  
            }

            if(in_array(ParamNamesConstants::$name,$paramNames)){
                $ii = array_search(ParamNamesConstants::$name,$paramNames); 
                $params['name'] = $paramValues[$ii]; 
            } else {  
                $params['name'] = '';  
            }

            if(in_array(ParamNamesConstants::$auto_protocol,$paramNames)){
                $ii = array_search(ParamNamesConstants::$auto_protocol,$paramNames); 
                $params['ppp_auth_protocol'] = $paramValues[$ii]; 
            } else {  
                $params['ppp_auth_protocol'] = 'AUTO';  
            }

            if(in_array(ParamNamesConstants::$nat,$paramNames)){
                $ii = array_search(ParamNamesConstants::$nat,$paramNames); 
                $params['enableNat'] = $paramValues[$ii]; 
            } else {  
                $params['enableNat'] = 0;
            }

            if(in_array(ParamNamesConstants::$enableDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$enableDesc,$paramNames); 
                $params['enable'] = $paramValues[$ii]; 
            } else {  
                $params['enable'] = 0;
            }

            if(in_array(ParamNamesConstants::$echo_name,$paramNames)){
                $ii = array_search(ParamNamesConstants::$echo_name,$paramNames); 
                $params['ppp_lcp_echo'] = $paramValues[$ii]; 
            } else {  
                $params['ppp_lcp_echo'] = 0;  
            }

            if(in_array(ParamNamesConstants::$echo_retry,$paramNames)){
                $ii = array_search(ParamNamesConstants::$echo_retry,$paramNames); 
                $params['ppp_lcp_retry'] = $paramValues[$ii]; 
            } else { 
                $params['ppp_lcp_retry'] = 0;
            }

            if(in_array(ParamNamesConstants::$service_name,$paramNames)){
                $ii = array_search(ParamNamesConstants::$service_name,$paramNames); 
                $params['serviceName'] = $paramValues[$ii]; 
            } else {  
                $params['serviceName'] = '';  
            }

            if ($connType == "ppp") {
                include  $_SESSION['APPPATH'].'views/content/admin/wanPPPTarif.php';
            } else if ($connType == "l2tp") {
                include  $_SESSION['APPPATH'].'views/content/admin/wanL2TPTarif.php';
            } else {
                include  $_SESSION['APPPATH'].'views/content/admin/wanPPTPTarif.php';
            }
        }
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 
} else {
    $result = "logged_out";
    echo $result;
}
} else {
    exit('No direct script access allowed');
}









