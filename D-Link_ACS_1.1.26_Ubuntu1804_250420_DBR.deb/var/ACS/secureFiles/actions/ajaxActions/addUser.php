<?php
function addUser($userName, $email, $password,$userGroupId, $groupIDs,$groupTaskAllow)
{
    include $_SESSION['APPPATH'].'models/modelUser.php';
    include $_SESSION['APPPATH'].'util/pagingConstants.php';

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $user = new ModelUser();
    $result = $user->addUser($userName, $email, $password,$userGroupId, $groupIDs,$groupTaskAllow);
    if (!$result) {
//        $_SESSION['failed_add_user'] = $ini_array['username_deleted_status'];
        $_SESSION['userName'] = $userName;
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;
    } else {
//        $_SESSION['add_user_succeed'] = $ini_array['add_client_succeed'];
    }
}

function editUser($editUserName, $editEmail, $editPassword,$editUserGrId, $user_ID, $groupName, $uncheckedGroups,$groupTaskAllow)
{
    include $_SESSION['APPPATH'].'models/modelUser.php';
    include $_SESSION['APPPATH'].'util/pagingConstants.php';

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    
    $user = new ModelUser();
    $result = $user->editUser($editUserName, $editEmail, $editPassword,$editUserGrId, $user_ID, $groupName, $uncheckedGroups,$groupTaskAllow);
    if (!$result) {
//        $_SESSION['failed_add_user'] = $ini_array['username_deleted_status'];
        $_SESSION['userName1'] = $editUserName;
        $_SESSION['email1'] = $editEmail;
        $_SESSION['password1'] = $editPassword;
    } else {
//        $_SESSION['add_user_succeed'] = $ini_array['add_client_succeed'];
    }
}

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }

//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }

            $actionName = $_POST['actionName'];
            if ($actionName == 'addUser') {
                $userName = $_POST['userName'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $userGroupId = $_POST['userGrId'];
                if (isset($_POST['groups'])){
                    $groupIDs = $_POST['groups'];
                } else{
                    $groupIDs = NULL;
                }
                $groupTaskAllow = $_POST['groupTaskAllow'];

                if ($userName != "" && $email != "" & $password != "") {

                    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        addUser($userName, $email, $password, $userGroupId, $groupIDs,$groupTaskAllow);
                    } else {
                        //                $_SESSION['failed_add_user'] = $ini_array['invalid_email'];
                        $_SESSION['userName'] = $userName;
                        $_SESSION['email'] = $email;
                        $_SESSION['password'] = $password;
                    }
                } else {
                    //            $_SESSION['failed_add_user'] = $ini_array['all_fields_required'];
                    $_SESSION['userName'] = $userName;
                    $_SESSION['email'] = $email;
                    $_SESSION['password'] = $password;
                }
            } else if ($actionName == 'editUser') {
                $editUserName = $_POST['editUserName'];
                $oldUserName = $_POST['oldUserName'];
                $editEmail = $_POST['editEmail'];
                $groupTaskAllow = $_POST['groupTaskAllow'];
                if(isset($_POST['editPassword'])) {
                    $editPassword = $_POST['editPassword'];
                } else {
                    $editPassword='';
                }
                $editUserGrId = $_POST['editUserGrId'];
                $user_ID = $_POST['user_ID'];
                $edit = $_POST['edit'];
                if(isset($_POST['groupName'])) {
                    $groupName = $_POST['groupName'];
                } else {
                    $groupName = '';
                }
                if(isset($_POST['uncheckedGroups'])) {
                    $uncheckedGroups = $_POST['uncheckedGroups'];
                } else {
                    $uncheckedGroups = '';
                }

                if (filter_var($editEmail, FILTER_VALIDATE_EMAIL)) {
                    if($editUserName != $oldUserName && $_SESSION['logged_in'] == $oldUserName){
//                        $_SESSION['logged_in'] = $editUserName;
                        $oldName = $_SESSION['logged_in'];
                        $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
                        $userSettings = json_decode($_COOKIE[$cookie_name]);
                        $_SESSION['logged_in'] = $editUserName;
                        setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
                        setcookie('loggedInUser', $editUserName, -1, '/');
                        setcookie($oldName, null, -1, '/');
                    }
                    editUser($editUserName, $editEmail, $editPassword, $editUserGrId, $user_ID, $groupName, $uncheckedGroups,$groupTaskAllow);
                } else {
                    //                $_SESSION['failed_add_user'] = $ini_array['invalid_email'];
                    $_SESSION['userName'] = $userName;
                    $_SESSION['userID'] = $userID;
                    $_SESSION['email'] = $email;
                    $_SESSION['password'] = $password;
                }
            }

            /*if($edit != ''){
                if (filter_var($editEmail, FILTER_VALIDATE_EMAIL)) {
                    if($editUserName != $oldUserName && $_SESSION['logged_in'] == $oldUserName){
                        $_SESSION['logged_in'] = $editUserName;
                    }
                    editUser($editUserName, $editEmail, $editPassword, $editUserGrId, $user_ID);
                } else {
    //                $_SESSION['failed_add_user'] = $ini_array['invalid_email'];
                    $_SESSION['userName'] = $userName;
                    $_SESSION['userID'] = $userID;
                    $_SESSION['email'] = $email;
                    $_SESSION['password'] = $password;
                }
            }else if ($userName != "" && $email != "" & $password != "" && $edit == "") {

                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    addUser($userName, $email, $password, $userGroupId);
                } else {
    //                $_SESSION['failed_add_user'] = $ini_array['invalid_email'];
                    $_SESSION['userName'] = $userName;
                    $_SESSION['email'] = $email;
                    $_SESSION['password'] = $password;
                }
            } else {
    //            $_SESSION['failed_add_user'] = $ini_array['all_fields_required'];
                $_SESSION['userName'] = $userName;
                $_SESSION['email'] = $email;
                $_SESSION['password'] = $password;
            }*/
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
