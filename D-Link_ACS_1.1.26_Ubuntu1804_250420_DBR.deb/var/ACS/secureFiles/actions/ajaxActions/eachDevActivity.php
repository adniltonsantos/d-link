<?php

function getAllWebTasksByDevIDByPage($deviceID, $page)
{
    include $_SESSION['APPPATH'].'models/modelWebTask.php';
    include $_SESSION['APPPATH'].'models/device.php';
    include $_SESSION['APPPATH'].'util/pagingConstants.php';
    include $_SESSION['APPPATH'].'util/utils.php';


    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupID = $_SESSION['group_id'];
        }
    }
    $userID = $_SESSION['userID'];

    $limit = PagingConstants::$activityCount;
    $offset = ($page - 1) * $limit;

    $webTask = new ModelWebTask();
    if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
        $activities = $webTask->getAllWebTaskByDevIdAndPageExcludeItemByUser($deviceID, $userID, $limit, $offset, "'createPort', 'selectInterface', 'taggedNatParam'");
        $allActivitiesCount = $webTask->getAllWebTasksCountByDevIdExcludeItemByUser($deviceID, $userID, "'createPort', 'selectInterface', 'taggedNatParam'");
    } else {
//    $activities = $webTask->getAllWebTaskByDevIdAndPage($deviceID, $limit, $offset);
        $activities = $webTask->getAllWebTaskByDevIdAndPageExcludeItem($deviceID, $limit, $offset, "'createPort', 'selectInterface', 'taggedNatParam'");
//    $allActivitiesCount = $webTask->getAllWebTasksCountByDevId($deviceID,"'create_port', 'select_interface'");
        $allActivitiesCount = $webTask->getAllWebTasksCountByDevIdExcludeItem($deviceID, "'createPort', 'selectInterface', 'taggedNatParam'");
    }
    $activitiesCount = $allActivitiesCount[0]->count;
    if ($activitiesCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($activitiesCount % $limit == 0) {
            $pagesCount = $activitiesCount / $limit;
        } else {
            $pagesCount = ($activitiesCount / $limit - ($activitiesCount % $limit) * (1 / $limit)) + 1;
        }
    }


    foreach ($activities as  $activity){
        if(trim($activity->type_name)=='getSelectedParams'){
$xml=$webTask->getXmlOfTheWebTaskByTaskID($activity->id);

            $tabName=Utils::getTabnameINActivity($xml[0]->xml);
            $tabN=array($activity->type_name,$tabName);
            $activity->type_name=$tabN;

        }
    }

    include $_SESSION['APPPATH'].'views/content/admin/deviceActivities.php';

    return true;
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
           $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }
            define('BASEPATH', $_SESSION['BASEPATH']);
            $devID = $_POST['deviceID'];
            $page = 1;
            getAllWebTasksByDevIDByPage($devID, $page);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}


