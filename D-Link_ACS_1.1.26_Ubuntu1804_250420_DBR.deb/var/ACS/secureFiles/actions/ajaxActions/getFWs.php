<?php
function  deviceFWs($deviceID)
{
    include $_SESSION['APPPATH'].'models/device.php';
    $dev = new Device();
    $fws = $dev->getDeviceFW($deviceID);
    $filtredFws = array();
    
    for($i = 0; $i < count($fws); $i++){
        $fullPath =  parse_url($fws[$i]->path);
//        $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
        $filePath = realpath(getcwd() . '/../../..' . str_replace('%20', ' ', $fullPath['path']));
        if (file_exists($filePath)) {
            array_push($filtredFws, $fws[$i]);
        }
    }
    
    include $_SESSION['APPPATH'].'views/content/admin/update_fw.php';
    return true;
}

function  removeFWs($deviceID,$fwId)
{
    include $_SESSION['APPPATH'].'models/device.php';
    $dev = new Device();
    $fws = $dev->getDeviceFW($deviceID);
    
    for($i = 0; $i < count($fws); $i++){
        if($fws[$i]->id == $fwId){
           $fullPath =  parse_url($fws[$i]->path);
        }
    }
    
    $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
    if (file_exists($filePath)) {
        if(unlink($filePath)){
            $dev->removeDeviceFW($fwId);
            echo 'true';
        }else {
            echo 'false';
        }
    }
    echo false;
}


if(isset($_POST['fromApp'])) {
    if (session_id() == '') { session_start(); }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $deviceID = $_POST['deviceID'];
            $action = $_POST['actionName'];

            if($action == 'getFirmwares'){
                deviceFWs($deviceID);
            }

            if($action == 'removeFw' && isset($_POST['firmwareId'])){
                $fwId = $_POST['firmwareId'];
                removeFWs($deviceID,$fwId);
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}