<?php
function getTaskStatus($deviceId,$task){
    include $_SESSION['APPPATH'].'models/modelParams.php';

    $modParams = new ModelParams();
    $params = $modParams-> getLastActivityStatusByDevId($deviceId,$task);
    return is_array($params) && count($params)>0 ? $params[0]->operation_status:"-1";
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            require_once $_SESSION['APPPATH'].'models/fwConfigFile.php';
            require_once $_SESSION['APPPATH'].'models/device.php';

            $dirName =  $_SESSION['REALPATH']."/putConfigs";
            $fwConfig = new FwConfigFile();

            if(isset($_POST['showConfig']) && $_POST['showConfig'] == 'true'){
                $mac = $_POST['macAddress'];
                $needFilesList = array();

                if(file_exists($dirName)){
                    //scan $dirname directory
                    //$files = scandir($dirName);
                    $files = preg_grep('~^' . $mac . '_~i', scandir($dirName));
                    //cut first 2 files which names are .,..
                    //$files=array_slice($files, 2);

                    //do paging
                    if(isset($_POST['page'])){
                        $page = $_POST['page'];
                    }else{
                        $page = 1;
                    }

                    $limit = 5;
                    $offset = ($page - 1) * $limit;

                    $filesCount = count($files);
                    if($filesCount > $limit){
                        $files = array_slice($files, $offset,$limit);
                        if ($filesCount % $limit == 0) {
                            $pagesCount = $filesCount / $limit;
                        } else {
                            $pagesCount = ($filesCount / $limit - ($filesCount % $limit) * (1 / $limit)) + 1;
                        }

                    }else {
                        $pagesCount = 1;
                    }
                    //end paging

                    //for each file check if that belong to our device
                    foreach($files as $f){
                        if(stripos(trim($f),trim($mac)) !== false) {

                            $configFromDb = $fwConfig->getConfigByName($f);

                            if(is_array($configFromDb) && count($configFromDb)>0){
                                $needFilesList[] = array("is_in_db"=>1,"id"=>$configFromDb[0]->id,"model"=>$configFromDb[0]->model_name,"config_name"=>$configFromDb[0]->config_name,"file_size"=>$configFromDb[0]->file_size);
                            } else {
                                $needFilesList[] = array("is_in_db"=>0,"id"=>0,"model"=>"","config_name"=>$f,"file_size"=>filesize($dirName."/".$f));
                            }
                        }
                    }
                }
                $needFilesList = array_reverse($needFilesList);

                require_once $_SESSION['APPPATH'].'views/content/admin/downloadedFilesList.php';

            } else if(isset($_POST['showConfig']) && $_POST['showConfig'] == 'false') {
                $coinfigId = (int)$_POST['configId'];
                $coinfigName = $_POST['coinfigName'];

                if($coinfigId == 0){
                    $filePath = $dirName. '/'. $coinfigName;
                    if (file_exists($filePath)) {
                        if(unlink($filePath)){
                            echo 'true';
                        }else {
                            echo 'false';
                        }
                    }
                }else {
                    $configFromDb = $fwConfig->getConfigByName($coinfigName);
                    $fullPath =  parse_url($configFromDb[0]->config_path);
                    $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
                    $dev = new Device();

                    if (file_exists($filePath)) {
                        if(unlink($filePath)){
                            $dev->removeConfig($coinfigId);
                            echo 'true';
                        }else {
                            echo 'false';
                        }
                    }
                }
            } else if(isset($_POST['deleteConfig']) && $_POST['deleteConfig'] == 'true') {
                $coinfigId = $_POST['configId'];
                $coinfigName = $_POST['configName'];
                for ($i = 0; $i < count($coinfigName); $i++) {
                    if($coinfigId[$i] == 0){
                        $filePath = $dirName. '/'. $coinfigName[$i];
                        if (file_exists($filePath)) {
                            if(unlink($filePath)){
                                echo 'true';
                            }else {
                                echo 'false';
                            }
                        }
                    }else {
                        $configFromDb = $fwConfig->getConfigByName($coinfigName[$i]);
                        $fullPath =  parse_url($configFromDb[0]->config_path);
                        $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
                        $dev = new Device();

                        if (file_exists($filePath)) {
                            if(unlink($filePath)){
                                $dev->removeConfig($coinfigId[$i]);
                                echo 'true';
                            }else {
                                echo 'false';
                            }
                        }
                    }
                }
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        echo 'logged_out';
    }
} else {
    exit('No direct script access allowed');
}

function  removeFWs($deviceID,$fwId)
{
    try{
        include $_SESSION['APPPATH'].'models/device.php';
        $dev = new Device();
        $fws = $dev->getDeviceFW($deviceID);

        for($i = 0; $i < count($fws); $i++){
            if($fws[$i]->id == $fwId){
                $fullPath =  parse_url($fws[$i]->path);
            }
        }

        $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
        if (file_exists($filePath)) {
            if(unlink($filePath)){
                $dev->removeDeviceFW($fwId);
                echo 'true';
            }else {
                echo 'false';
            }
        }
        echo false;
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    }
}