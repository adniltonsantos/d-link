<?php
if(isset($_POST['fromApp'])){
    if (version_compare(phpversion(), '5.4.0', '<')) {
        if(session_id() == '') {
           session_start();
        }
    }else {
       if (session_status() == PHP_SESSION_NONE) {
           session_start();
        }
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
//    if (isset($_SESSION['logged_in'])) {
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
//        $msg = $_POST['message'];
//        echo $ini_array[$msg];
        echo json_encode($ini_array);
//    } else {
////        $result = "logged_out";
//        echo json_encode("logged_out");
//    }
} else {
    exit('No direct script access allowed');
}