<?php

function changeProf($userName, $email,$ini_array)
{
    include $_SESSION['APPPATH'].'models/modelUser.php';
    include $_SESSION['APPPATH'].'util/pagingConstants.php';

    $realUserName = $_SESSION['logged_in'];
    $user = new ModelUser();
    $result = $user->changeProf($realUserName, $userName, $email);
    if (!$result) {
        $_SESSION['failed_add_user'] = $ini_array['username_deleted_status'];
    } else {
        $_SESSION['add_user_succeed'] = $ini_array['add_client_succeed'];
        if ($userName != '') {
            $oldName = $_SESSION['logged_in'];
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $_SESSION['logged_in'] = $userName;
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
            setcookie('loggedInUser', $userName, -1, '/');
            setcookie($oldName, null, -1, '/');
        }
    }
}

if(isset($_POST['fromApp'])){

    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $lang = $_SESSION['lang'];
            $ini_array = '';
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
            }
            if(isset($_POST['actionName']) && $_POST['actionName']=="DeviceHeartbeats") {
                $heartInterval = $_POST['heartInterval'];
                $heartWarning = $_POST['heartWarning'];
                $heartError = $_POST['heartError'];
                include $_SESSION['APPPATH'] . 'models/modelUser.php';
                $HeartParams = new modelUser();
                $HeartINT = $HeartParams->insertHeartInterval($heartInterval);
                $HeartWAR = $HeartParams->insertHeartWarning($heartWarning);
                $HeartERR = $HeartParams->insertHeartError($heartError);
////                if(isset($HeartINT) && isset($HeartWAR) && isset($HeartERR)) {
//                    return true;
////                }
            } else {
                $userName = $_POST['userName'];
                $email = $_POST['email'];
                if ($email != "" && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    changeProf($userName, $email, $ini_array);
                } else if ($email == "") {
                    changeProf($userName, $email, $ini_array);
                } else {
                    $_SESSION['failed_add_user'] = $ini_array['invalid_email'];
                }
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
     exit('No direct script access allowed');
}
