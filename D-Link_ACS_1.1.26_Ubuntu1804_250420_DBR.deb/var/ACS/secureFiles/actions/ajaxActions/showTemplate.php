<?php
        
//if(isset($_POST['fromApp'])){
    if (session_id() == ''){session_start();}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if(!class_exists("ParamNamesConstants")){include $_SESSION['APPPATH'] . "util/paramNamesConstants.php";}

    if  (isset($_SESSION['logged_in'])) {
        try{
//            $templId = $_POST['templateId'];
            $templId = $tmplId;
            include $_SESSION['APPPATH'] . "models/modelTemplates.php";
            $templ = new ModelTemplates();
            $tarif = $templ->getTemplateById($templId);
            $templPath = $tarif[0]->path;
            $lan = array();
            $wan = array();
            $wifi = array();

            $wanParams = array();

            $wanParamsPPPOE = array(); //selected pppoe parameter
            $wanParamsL2TP = array(); //selected l2tp parameter
            $wanParamsStatic = array(); //selected static-ip parameter
            $wanParamsDynamic = array(); //selected dynamic-ip parameter

        if(file_exists($templPath)){

            $fileCont = file_get_contents($templPath);
    //        $ppCount = substr_count($fileCont,"PPPOE");
            $ppCount = substr_count($fileCont,"[PPP]");
            if($ppCount > 1){
                for($i = 1; $i <= $ppCount; $i++){
    //                $pos = strpos($fileCont,"OE]");
    //                $search = "OE]";
    //                $replace = "OE".$i."]";
                    $pos = strpos($fileCont,"P]");
                    $search = "P]";
                    $replace = "P".$i."]";
                    $search_len = strlen($search);
                    $string_len = strlen($fileCont);
                    $fileNewCont = substr($fileCont,0,$pos).$replace.substr($fileCont,$pos + $search_len,max(0,$string_len-($pos+$search_len)));
                    $fileCont = $fileNewCont;
                }
            }

            $wifiCount = substr_count($fileCont,"[WI-FI]");
            if($wifiCount > 1){
                for($i = 1; $i <= $wifiCount; $i++){
                    //                $pos = strpos($fileCont,"OE]");
                    //                $search = "OE]";
                    //                $replace = "OE".$i."]";
                    $pos = strpos($fileCont,"I]");
                    $search = "I]";
                    $replace = "I".$i."]";
                    $search_len = strlen($search);
                    $string_len = strlen($fileCont);
                    $fileNewCont = substr($fileCont,0,$pos).$replace.substr($fileCont,$pos + $search_len,max(0,$string_len-($pos+$search_len)));
                    $fileCont = $fileNewCont;
                }
            }

    //        $l2tpCount = substr_count($fileCont,"L2TP");
    //        if($l2tpCount > 1){
    //            for($i = 1; $i <= $l2tpCount; $i++){
    //                $pos = strpos($fileCont,"TP]");
    //                $search = "TP]";
    //                $replace = "TP".$i."]";
    //                $search_len = strlen($search);
    //                $string_len = strlen($fileCont);
    //                $fileNewCont = substr($fileCont,0,$pos).$replace.substr($fileCont,$pos + $search_len,max(0,$string_len-($pos+$search_len)));
    //                $fileCont = $fileNewCont;
    //            }
    //        }

            $tmpFName = str_replace(".ini",date("h:i:s A").".ini",$templPath);
            if (!$handle = fopen($tmpFName, 'w')) {
                return false;
            }
            if (!fwrite($handle, $fileCont)) {
                return false;
            }

    //        $arr = parse_ini_file($tmpFName,true);

            try {
                if (($arr = @parse_ini_file($tmpFName, true)) == false)
                    throw new Exception();
            }catch (Exception $e) {
                $_SESSION['ini_read'] = $ini_array['teplate_file_error'];
                error_log($e->getMessage());
                fclose($handle);
                unlink ($tmpFName );
                header('HTTP/1.1 500 Internal Server Error');
                header("Status: 500 Internal Server Error");
                header( 'Location: '.BASEPATH.'template/show' );
                exit();
            }

            fclose($handle);
            unlink ($tmpFName );

            $config = array();
            $lan = array();

            if(array_key_exists('LAN',$arr)){
                $params = array();
                $paramValues = array();

                if(array_key_exists(ParamNamesConstants::$ip_address,$arr['LAN'])){
                    $lan[ParamNamesConstants::$ip_address] = $arr['LAN'][ParamNamesConstants::$ip_address];
        //            $paramNames[]=ParamNamesConstants::$ipAddr;
        //            $paramValues[]=$arr['LAN']['ip_address'];
                }

                if(array_key_exists(ParamNamesConstants::$netmaskDesc,$arr['LAN'])){
                    $lan[ParamNamesConstants::$netmaskDesc] = $arr['LAN'][ParamNamesConstants::$netmaskDesc];
        //            $paramNames[]=ParamNamesConstants::$netmask;
        //            $paramValues[]=$arr['LAN']['netmask'];
                }

                if(array_key_exists(ParamNamesConstants::$mode,$arr['LAN'])){
                    $lan[ParamNamesConstants::$mode] = $arr['LAN'][ParamNamesConstants::$mode];
        //            $paramNames[]=ParamNamesConstants::$dhcpEnable;
        //            $paramValues[]=$arr['LAN']['mode'];
                }

                if(array_key_exists(ParamNamesConstants::$start_ip,$arr['LAN'])){
                    $lan[ParamNamesConstants::$start_ip]=$arr['LAN'][ParamNamesConstants::$start_ip];
        //            $paramNames[]=ParamNamesConstants::$startIp;
        //            $paramValues[]=$arr['LAN']['start_ip'];
                }

                if(array_key_exists(ParamNamesConstants::$end_ip,$arr['LAN'])){
                    $lan[ParamNamesConstants::$end_ip] = $arr['LAN'][ParamNamesConstants::$end_ip];
        //            $paramNames[]=ParamNamesConstants::$endIp;
        //            $paramValues[]=$arr['LAN']['end_ip'];
                }

                if(array_key_exists(ParamNamesConstants::$lease_time,$arr['LAN'])){
                    $lan[ParamNamesConstants::$lease_time] = $arr['LAN'][ParamNamesConstants::$lease_time];
        //            $paramNames[]=ParamNamesConstants::$dhcpLeaseTime;
        //            $paramValues[]=$arr['LAN']['lease_time'];
                }
            }

    //---------------- show information about Static ip in page template -----------

            $staticArray = array();
            $existSTATIC = false;
            foreach($arr as $key => $value){
                if(substr($key,0,9) == 'STATIC-IP'){
                    $staticArray[] = $key;
                    $existSTATIC = true;
                }
            }

            for($i = 0; $i < count($staticArray); $i++){
                $eachSTATIC = array();
                $params = array();

                $val = $staticArray[$i];
                if(array_key_exists($val,$arr)){

                    $paramNames = array();
                    $paramValues = array();

                    if(array_key_exists(ParamNamesConstants::$name,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$name;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$name];
                    }

                    if(array_key_exists(ParamNamesConstants::$mtuDesc,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$mtuDesc;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$mtuDesc];
                    }

                    if(array_key_exists(ParamNamesConstants::$macDesc,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$macDesc;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$macDesc];
                    }

                    if(array_key_exists(ParamNamesConstants::$ext_ip_address,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$ext_ip_address;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$ext_ip_address];
                    }

                    if(array_key_exists(ParamNamesConstants::$subnet_mask,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$subnet_mask;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$subnet_mask];
                    }

                    if(array_key_exists(ParamNamesConstants::$def_gateway,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$def_gateway;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$def_gateway];
                    }

                    if(array_key_exists(ParamNamesConstants::$dns,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$dns;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$dns];
                    }

                    if(array_key_exists(ParamNamesConstants::$ethernetBytesReceived,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$ethernetBytesReceived;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$ethernetBytesReceived];
                    }

                    if(array_key_exists(ParamNamesConstants::$ethernetBytesSent,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$ethernetBytesSent;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$ethernetBytesSent];
                    }

                    if(array_key_exists(ParamNamesConstants::$nat,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$nat;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$nat];
                    }

                    if(array_key_exists(ParamNamesConstants::$enableDesc,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$enableDesc;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$enableDesc];
                    }

                    if(array_key_exists('def_connection',$arr[$val])){
                        $paramNames[] = 'def_connection';
                        $paramValues[] = $arr[$val]['def_connection'];
                    }

                    $params['names'] = $paramNames;
                    $params['values'] = $paramValues;
                    $wanParamsStatic[] = $params;
                }
            }

    //------------ show information about Dynamic ip in page template --------------

            $staticArray = array();
            $existSTATIC = false;
            foreach($arr as $key => $value){
                if(substr($key,0,10) == 'DYNAMIC-IP'){
                    $staticArray[] = $key;
                    $existSTATIC = true;
                }
            }

            for($i = 0; $i < count($staticArray); $i++){
                $eachSTATIC = array();
                $params = array();

                $val = $staticArray[$i];
                if(array_key_exists($val,$arr)){
                    $paramNames=array();
                    $paramValues=array();

                    if(array_key_exists(ParamNamesConstants::$name,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$name;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$name];
                    }

                    if(array_key_exists(ParamNamesConstants::$mtuDesc,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$mtuDesc;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$mtuDesc];
                    }

                    if(array_key_exists(ParamNamesConstants::$macDesc,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$macDesc;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$macDesc];
                    }

                    if(array_key_exists(ParamNamesConstants::$dnsEnable,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$dnsEnable;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$dnsEnable];
                    }

                    if(array_key_exists(ParamNamesConstants::$nat,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$nat;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$nat];
                    }

                    if(array_key_exists(ParamNamesConstants::$enableDesc,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$enableDesc;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$enableDesc];
                    }

                    if(array_key_exists(ParamNamesConstants::$ethernetBytesReceived,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$ethernetBytesReceived;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$ethernetBytesReceived];
                    }

                    if(array_key_exists(ParamNamesConstants::$ethernetBytesSent,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$ethernetBytesSent;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$ethernetBytesSent];
                    }

                    if(array_key_exists(ParamNamesConstants::$dns_servers,$arr[$val])){
                        $paramNames[] = ParamNamesConstants::$dns_servers;
                        $paramValues[] = $arr[$val][ParamNamesConstants::$dns_servers];
                    }

                    if(array_key_exists('def_connection',$arr[$val])){
                        $paramNames[] = 'def_connection';
                        $paramValues[] = $arr[$val]['def_connection'];
                    }

                    $params['names'] = $paramNames;
                    $params['values'] = $paramValues;
                    $wanParamsDynamic[] = $params;
                }
            }

    //-------------------------------- end -----------------------------------------


    //--------------- show information about PPPoE in page template ----------------

            $ppArray = array();
            $existPPP = false;
            foreach($arr as $key => $value){
                if(substr($key,0,3) == 'PPP'){
                    $ppArray[] = $key;
                    $existPPP = true;
                }
            }

//            $l2tpArray = array();
//            $existL2TP = false;
//            foreach($arr as $key => $value){
//                if(substr($key,0,4) == 'L2TP'){
//                    $l2tpArray[] = $key;
//                    $existL2TP = true;
//                }
//            }

            if($existPPP){
//                showPPPoEAndL2TP($arr,$ppArray,'ppp');
                for($i = 0; $i < count($ppArray); $i++){
                    $eachPPPOE = array();
                    $params = array();
                    $val = $ppArray[$i];
                    if(array_key_exists($val,$arr)){
                        $paramNames = array();
                        $paramValues = array();

                        if(array_key_exists(ParamNamesConstants::$name,$arr[$val])){
                //            $eachPPPOE['name']=$arr[$val]['name'];
                            $paramNames[] = ParamNamesConstants::$name;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$name];
                        }

                        if(array_key_exists(ParamNamesConstants::$service_name,$arr[$val])){
                //            $eachPPPOE['service_name']=$arr[$val]['service_name'];
                            $paramNames[] = ParamNamesConstants::$service_name;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$service_name];
                        }

                        if(array_key_exists(ParamNamesConstants::$usernameDesc,$arr[$val])){
                //            $eachPPPOE['username']=$arr[$val]['username'];
                            $paramNames[] = ParamNamesConstants::$usernameDesc;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$usernameDesc];
                        }

                        if(array_key_exists(ParamNamesConstants::$passwordDesc,$arr[$val])){
                //            $eachPPPOE['password']=$arr[$val]['password'];
                            $paramNames[] = ParamNamesConstants::$passwordDesc;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$passwordDesc];
                        }

                        if(array_key_exists(ParamNamesConstants::$mruDesc,$arr[$val])){
                //            $eachPPPOE['mru']=$arr[$val]['mru'];
                            $paramNames[] = ParamNamesConstants::$mruDesc;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$mruDesc];
                        }

                        if(array_key_exists(ParamNamesConstants::$nat,$arr[$val])){
                //            $eachPPPOE['nat']=$arr[$val]['nat'];
                            $paramNames[] = ParamNamesConstants::$nat;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$nat];
                        }

                        if(array_key_exists(ParamNamesConstants::$auto_protocol,$arr[$val])){
                //            $eachPPPOE['auth_protocol']=$arr[$val]['auth_protocol'];
                            $paramNames[] = ParamNamesConstants::$auto_protocol;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$auto_protocol];
                        }

                        if(array_key_exists(ParamNamesConstants::$echo_name,$arr[$val])){
                //            $eachPPPOE['echo_name']=$arr[$val]['echo_name'];
                            $paramNames[] = ParamNamesConstants::$echo_name;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$echo_name];
                        }

                        if(array_key_exists(ParamNamesConstants::$echo_retry,$arr[$val])){
                //            $eachPPPOE['echo_retry']=$arr[$val]['echo_retry'];
                            $paramNames[] = ParamNamesConstants::$echo_retry;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$echo_retry];
                        }

                        if(array_key_exists(ParamNamesConstants::$enableDesc,$arr[$val])){
                //            $eachPPPOE['enable']=$arr[$val]['enable'];
                            $paramNames[] = ParamNamesConstants::$enableDesc;
                            $paramValues[] = $arr[$val][ParamNamesConstants::$enableDesc];
                        }

                        if(array_key_exists('conn_type',$arr[$val])){
                //            $eachPPPOE['enable']=$arr[$val]['enable'];
                            $paramNames[] = 'conn_type';
                            $paramValues[] = $arr[$val]['conn_type'];
                        }

                        if(array_key_exists('def_connection',$arr[$val])){
                            $paramNames[] = 'def_connection';
                            $paramValues[] = $arr[$val]['def_connection'];
                        }

//                        global $wanParamsPPPOE;
//                        global $wanParamsL2TP;
                        $params['names'] = $paramNames;
                        $params['values'] = $paramValues;
//                        if($type == 'ppp'){
                            $wanParamsPPPOE[] = $params;
//                        }
//
//                        if($type == 'l2tp'){
//                            $wanParamsL2TP[] = $params;
//                        }
                    }
                }
            }

//            if($existL2TP){
////                showPPPoEAndL2TP($arr,$l2tpArray,'l2tp');
//                for($i = 0; $i < count($ppArray); $i++){
//                    $eachPPPOE = array();
//                    $params = array();
//                    $val = $ppArray[$i];
//                    if(array_key_exists($val,$arr)){
//                        $paramNames = array();
//                        $paramValues = array();
//
//                        if(array_key_exists(ParamNamesConstants::$name,$arr[$val])){
//                //            $eachPPPOE['name']=$arr[$val]['name'];
//                            $paramNames[] = ParamNamesConstants::$name;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$name];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$service_name,$arr[$val])){
//                //            $eachPPPOE['service_name']=$arr[$val]['service_name'];
//                            $paramNames[] = ParamNamesConstants::$service_name;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$service_name];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$usernameDesc,$arr[$val])){
//                //            $eachPPPOE['username']=$arr[$val]['username'];
//                            $paramNames[] = ParamNamesConstants::$usernameDesc;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$usernameDesc];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$passwordDesc,$arr[$val])){
//                //            $eachPPPOE['password']=$arr[$val]['password'];
//                            $paramNames[] = ParamNamesConstants::$passwordDesc;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$passwordDesc];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$mruDesc,$arr[$val])){
//                //            $eachPPPOE['mru']=$arr[$val]['mru'];
//                            $paramNames[] = ParamNamesConstants::$mruDesc;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$mruDesc];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$nat,$arr[$val])){
//                //            $eachPPPOE['nat']=$arr[$val]['nat'];
//                            $paramNames[] = ParamNamesConstants::$nat;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$nat];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$auto_protocol,$arr[$val])){
//                //            $eachPPPOE['auth_protocol']=$arr[$val]['auth_protocol'];
//                            $paramNames[] = ParamNamesConstants::$auto_protocol;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$auto_protocol];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$echo_name,$arr[$val])){
//                //            $eachPPPOE['echo_name']=$arr[$val]['echo_name'];
//                            $paramNames[] = ParamNamesConstants::$echo_name;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$echo_name];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$echo_retry,$arr[$val])){
//                //            $eachPPPOE['echo_retry']=$arr[$val]['echo_retry'];
//                            $paramNames[] = ParamNamesConstants::$echo_retry;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$echo_retry];
//                        }
//
//                        if(array_key_exists(ParamNamesConstants::$enableDesc,$arr[$val])){
//                //            $eachPPPOE['enable']=$arr[$val]['enable'];
//                            $paramNames[] = ParamNamesConstants::$enableDesc;
//                            $paramValues[] = $arr[$val][ParamNamesConstants::$enableDesc];
//                        }
//
//                        if(array_key_exists('conn_type',$arr[$val])){
//                //            $eachPPPOE['enable']=$arr[$val]['enable'];
//                            $paramNames[] = 'conn_type';
//                            $paramValues[] = $arr[$val]['conn_type'];
//                        }
//
//                        if(array_key_exists('def_connection',$arr[$val])){
//                            $paramNames[] = 'def_connection';
//                            $paramValues[] = $arr[$val]['def_connection'];
//                        }
//
////                        global $wanParamsPPPOE;
////                        global $wanParamsL2TP;
//                        $params['names'] = $paramNames;
//                        $params['values'] = $paramValues;
////                        if($type == 'ppp'){
////                            $wanParamsPPPOE[] = $params;
////                        }
////
////                        if($type == 'l2tp'){
//                            $wanParamsL2TP[] = $params;
////                        }
//                    }
//                }
//            }


    //------------- show information about Wi Fi -------------------- --------------    


//            if(array_key_exists('WI-FI',$arr)){
            $wifiArray = array();
            $existWifi = false;
            foreach($arr as $key => $value){
                if(substr($key,0,2) == 'WI'){
                    $wifiArray[] = $key;
                    $existWifi = true;
                }
            }
            if($existWifi) {
                for($i = 0; $i < count($wifiArray); $i++) {
                    $paramsWifi = array();
                    $val = $wifiArray[$i];
                    if (array_key_exists($val, $arr)) {
                        $paramNamesWifi = array();
                        $paramValuesWifi = array();
                        if (array_key_exists(ParamNamesConstants::$enableDesc, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$enableDesc;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$enableDesc];
                            //            $paramNames[]=ParamNamesConstants::$enable;
                            //            $paramValues[]=$arr['WI-FI']['enable'];
                        }

                        if (array_key_exists(ParamNamesConstants::$frequency_band, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$frequency_band;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$frequency_band];
                            //            $paramNames[]=ParamNamesConstants::$enable;
                            //            $paramValues[]=$arr['WI-FI']['enable'];
                        }

                        if (array_key_exists(ParamNamesConstants::$ssidDesc, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$ssidDesc;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$ssidDesc];
//                        $wifi[ParamNamesConstants::$ssidDesc] = $arr['WI-FI'][ParamNamesConstants::$ssidDesc];
                            //            $paramNames[]=ParamNamesConstants::$ssid;
                            //            $paramValues[]=$arr['WI-FI']['ssid'];
                        }

                        if (array_key_exists(ParamNamesConstants::$auto_enable, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$auto_enable;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$auto_enable];
                            //            $paramNames[]=ParamNamesConstants::$enable;
                            //            $paramValues[]=$arr['WI-FI']['enable'];
                        }

                        if (array_key_exists(ParamNamesConstants::$channelDesc, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$channelDesc;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$channelDesc];
//                        $wifi[ParamNamesConstants::$channelDesc] = $arr['WI-FI'][ParamNamesConstants::$channelDesc];
                            //            $paramNames[]=ParamNamesConstants::$channel;
                            //            $paramValues[]=$arr['WI-FI']['channel'];
                        }

                        if (array_key_exists(ParamNamesConstants::$standardDesc, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$standardDesc;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$standardDesc];
//                        $wifi[ParamNamesConstants::$standardDesc] = $arr['WI-FI'][ParamNamesConstants::$standardDesc];
                            //            $paramNames[]=ParamNamesConstants::$standard;
                            //            $paramValues[]=$arr['WI-FI']['standard'];
                        }

                        if (array_key_exists(ParamNamesConstants::$txPower, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$txPower;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$txPower];
//                        $wifi[ParamNamesConstants::$txPower] = $arr['WI-FI'][ParamNamesConstants::$txPower];
                        }

                        if (array_key_exists(ParamNamesConstants::$maxAssociatedClients, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$maxAssociatedClients;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$maxAssociatedClients];
//                        $wifi[ParamNamesConstants::$maxAssociatedClients] = $arr['WI-FI'][ParamNamesConstants::$maxAssociatedClients];
                        }

                        if (array_key_exists(ParamNamesConstants::$beacon_type, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$beacon_type;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$beacon_type];
                            //            $paramNames[]=ParamNamesConstants::$enable;
                            //            $paramValues[]=$arr['WI-FI']['enable'];
                        }

                        if (array_key_exists(ParamNamesConstants::$wpa_encrypt, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa_encrypt;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa_encrypt];
//                        $wifi[ParamNamesConstants::$wpa_encrypt] = $arr['WI-FI'][ParamNamesConstants::$wpa_encrypt];
                        }

                        if (array_key_exists(ParamNamesConstants::$wpa_encrypt2, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa_encrypt2;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa_encrypt2];
                        }

                        if (array_key_exists(ParamNamesConstants::$basic, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$basic;
                            $paramValuesWifi[] = 'None';
//                        $wifi[ParamNamesConstants::$basic] = $arr['WI-FI'][ParamNamesConstants::$basic];

                            //            $paramNames[]=ParamNamesConstants::$open;
                            //            $paramValues[]=$arr['WI-FI']['basic_mode'];

                        } else if (array_key_exists(ParamNamesConstants::$wpa_psk, $arr[$val]) &&
                            !array_key_exists(ParamNamesConstants::$wpa_psk2, $arr[$val])) {
                            //            $paramNames[]=ParamNamesConstants::$wpaPsk;
                            //            $paramValues[]=$arr['WI-FI']['wpa-psk'];
                            $paramNamesWifi[] = ParamNamesConstants::$wpa_psk;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa_psk];
//                        $wifi[ParamNamesConstants::$wpa_psk] = $arr['WI-FI'][ParamNamesConstants::$wpa_psk];

                            if (array_key_exists(ParamNamesConstants::$key_psk, $arr[$val])) {
                                $paramNamesWifi[] = ParamNamesConstants::$key_psk;
                                $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$key_psk];
//                            $wifi[ParamNamesConstants::$key_psk] = $arr['WI-FI'][ParamNamesConstants::$key_psk];
                                //                $paramNames[]=ParamNamesConstants::$presharedKey;
                                //                $paramValues[]=$arr['WI-FI']['key_psk'];
                            }

                        } else if (array_key_exists(ParamNamesConstants::$wpa_psk2, $arr[$val]) &&
                            !array_key_exists(ParamNamesConstants::$wpa_psk, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa_psk2;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa_psk2];
//                        $wifi[ParamNamesConstants::$wpa_psk2] = $arr['WI-FI'][ParamNamesConstants::$wpa_psk2];
                            //            $paramNames[]=ParamNamesConstants::$wpaPsk2;
                            //            $paramValues[]=$arr['WI-FI']['wpa-psk2'];

                            if (array_key_exists(ParamNamesConstants::$key_psk, $arr[$val])) {
                                //                $paramNames[]=ParamNamesConstants::$presharedKey;
                                //                $paramValues[]=$arr['WI-FI']['key_psk'];
                                $paramNamesWifi[] = ParamNamesConstants::$key_psk;
                                $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$key_psk];
//                            $wifi[ParamNamesConstants::$key_psk] = $arr['WI-FI'][ParamNamesConstants::$key_psk];
                            }
                        } else if (array_key_exists(ParamNamesConstants::$wpa_psk, $arr[$val])
                            && array_key_exists(ParamNamesConstants::$wpa_psk2, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa_psk;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa_psk];
//                        $wifi[ParamNamesConstants::$wpa_psk] = $arr['WI-FI'][ParamNamesConstants::$wpa_psk];
                            $paramNamesWifi[] = ParamNamesConstants::$wpa_psk2;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa_psk2];
//                        $wifi[ParamNamesConstants::$wpa_psk2] = $arr['WI-FI'][ParamNamesConstants::$wpa_psk2];
                            //            $paramNames[]=ParamNamesConstants::$wpaPsk2;
                            //            $paramValues[]=$arr['WI-FI']['wpa-psk2'];

                            if (array_key_exists(ParamNamesConstants::$key_psk, $arr[$val])) {
                                //                $paramNames[]=ParamNamesConstants::$presharedKey;
                                //                $paramValues[]=$arr['WI-FI']['key_psk'];
                                $paramNamesWifi[] = ParamNamesConstants::$key_psk;
                                $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$key_psk];
//                            $wifi[ParamNamesConstants::$key_psk] = $arr['WI-FI'][ParamNamesConstants::$key_psk];
                            }
                        } else if (array_key_exists(ParamNamesConstants::$wpa, $arr[$val]) && !array_key_exists(ParamNamesConstants::$wpa2, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa];
//                        $wifi[ParamNamesConstants::$wpa] = $arr['WI-FI'][ParamNamesConstants::$wpa];

                        } else if (array_key_exists(ParamNamesConstants::$wpa2, $arr[$val]) && !array_key_exists(ParamNamesConstants::$wpa, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa2;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa2];
//                        $wifi[ParamNamesConstants::$wpa2] = $arr['WI-FI'][ParamNamesConstants::$wpa2];

                        } else if (array_key_exists(ParamNamesConstants::$wpa, $arr[$val]) && array_key_exists(ParamNamesConstants::$wpa2, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa];
//                        $wifi[ParamNamesConstants::$wpa] = $arr['WI-FI'][ParamNamesConstants::$wpa];
                            $paramNamesWifi[] = ParamNamesConstants::$wpa2;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa2];
//                        $wifi[ParamNamesConstants::$wpa2] = $arr['WI-FI'][ParamNamesConstants::$wpa2];

                        }


                        if (array_key_exists(ParamNamesConstants::$wpa_reneval, $arr[$val])) {
                            $paramNamesWifi[] = ParamNamesConstants::$wpa_reneval;
                            $paramValuesWifi[] = $arr[$val][ParamNamesConstants::$wpa_reneval];
//                        $wifi[ParamNamesConstants::$wpa_reneval] = $arr['WI-FI'][ParamNamesConstants::$wpa_reneval];
                            //            $paramNames[]=ParamNamesConstants::$wpaReneval;
                            //            $paramValues[]=$arr['WI-FI']['wpa_reneval'];
                        }

                        $paramsWifi['names'] = $paramNamesWifi;
                        $paramsWifi['values'] = $paramValuesWifi;
//                        if($type == 'ppp'){
                        $wifi[] = $paramsWifi;
//                        }
                    }
//            }
                }
            }
        }else {
            $_SESSION['ini_read'] = $ini_array['teplate_file_exist'];
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            header( 'Location: '.BASEPATH.'template/show');
            exit(); 
        }

//            define("BASEPATH", $_SESSION['BASEPATH']);
            $lang = $_SESSION['lang'];

            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }

            $toAdd = 'false';
//            include $_SESSION['APPPATH'].'views/content/admin/editTemplate.php';
            require_once  $_SESSION['APPPATH'].'views/tiles/admin/templates_view.php';
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            header( 'Location: '.BASEPATH.'500' );
            exit();
        } 
    } else {
        require_once 'secureFiles/actions/login.php';
//        $result = "logged_out";
//        echo $result;
    }
    
//} else {
//    exit('No direct script access allowed');
//}

//function showPPPoEAndL2TP($arr,$ppArray,$type){
//
//    for($i = 0; $i < count($ppArray); $i++){
//        $eachPPPOE = array();
//        $params = array();
//        $val = $ppArray[$i];
//        if(array_key_exists($val,$arr)){
//            $paramNames = array();
//            $paramValues = array();
//
//            if(array_key_exists(ParamNamesConstants::$name,$arr[$val])){
//    //            $eachPPPOE['name']=$arr[$val]['name'];
//                $paramNames[] = ParamNamesConstants::$name;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$name];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$service_name,$arr[$val])){
//    //            $eachPPPOE['service_name']=$arr[$val]['service_name'];
//                $paramNames[] = ParamNamesConstants::$service_name;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$service_name];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$usernameDesc,$arr[$val])){
//    //            $eachPPPOE['username']=$arr[$val]['username'];
//                $paramNames[] = ParamNamesConstants::$usernameDesc;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$usernameDesc];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$passwordDesc,$arr[$val])){
//    //            $eachPPPOE['password']=$arr[$val]['password'];
//                $paramNames[] = ParamNamesConstants::$passwordDesc;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$passwordDesc];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$mruDesc,$arr[$val])){
//    //            $eachPPPOE['mru']=$arr[$val]['mru'];
//                $paramNames[] = ParamNamesConstants::$mruDesc;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$mruDesc];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$nat,$arr[$val])){
//    //            $eachPPPOE['nat']=$arr[$val]['nat'];
//                $paramNames[] = ParamNamesConstants::$nat;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$nat];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$auto_protocol,$arr[$val])){
//    //            $eachPPPOE['auth_protocol']=$arr[$val]['auth_protocol'];
//                $paramNames[] = ParamNamesConstants::$auto_protocol;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$auto_protocol];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$echo_name,$arr[$val])){
//    //            $eachPPPOE['echo_name']=$arr[$val]['echo_name'];
//                $paramNames[] = ParamNamesConstants::$echo_name;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$echo_name];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$echo_retry,$arr[$val])){
//    //            $eachPPPOE['echo_retry']=$arr[$val]['echo_retry'];
//                $paramNames[] = ParamNamesConstants::$echo_retry;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$echo_retry];
//            }
//
//            if(array_key_exists(ParamNamesConstants::$enableDesc,$arr[$val])){
//    //            $eachPPPOE['enable']=$arr[$val]['enable'];
//                $paramNames[] = ParamNamesConstants::$enableDesc;
//                $paramValues[] = $arr[$val][ParamNamesConstants::$enableDesc];
//            }
//
//            if(array_key_exists('conn_type',$arr[$val])){
//    //            $eachPPPOE['enable']=$arr[$val]['enable'];
//                $paramNames[] = 'conn_type';
//                $paramValues[] = $arr[$val]['conn_type'];
//            }
//
//            if(array_key_exists('def_connection',$arr[$val])){
//                $paramNames[] = 'def_connection';
//                $paramValues[] = $arr[$val]['def_connection'];
//            }
//
//            global $wanParamsPPPOE;
//            global $wanParamsL2TP;
//            $params['names'] = $paramNames;
//            $params['values'] = $paramValues;
//            if($type == 'ppp'){
//                $wanParamsPPPOE[] = $params;
//            }
//
//            if($type == 'l2tp'){
//                $wanParamsL2TP[] = $params;
//            }
//        }
//    }
//}