<?php
if(isset($_POST['fromApp'])){

    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    $lang = $_POST['lang'];
    $_SESSION['lang'] = $lang;

} else {
    exit('No direct script access allowed');
}
