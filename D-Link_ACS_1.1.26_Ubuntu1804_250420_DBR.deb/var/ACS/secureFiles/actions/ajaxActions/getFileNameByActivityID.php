<?php
function getFileNameByType($activityID,$activityType,$endFile){
    include $_SESSION['APPPATH'] . 'models/modelWebTask.php';
    $webTask = new ModelWebTask();
    $task=$webTask->getActivityByID($activityID);
    $fileName=$task[0]->serial_number.'_'.str_replace(" ","-",$task[0]->create_date);
    $notif = false;

    $fileName=$fileName.$endFile;

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $GLOBALS['myArr'][0]['name'] = $ini_array['file_name'];

    $GLOBALS['myArr'][0]['value'] = $fileName;

    $params = $GLOBALS['myArr'];
    $count = count($GLOBALS['myArr']);
    include $_SESSION['APPPATH'] . 'views/content/admin/activityParamsValues.php';
}

function getFWOrConfig($activityID,$activityType){

    include $_SESSION['APPPATH'] . 'models/modelWebTask.php';
    $notif = false;
    $webTask = new ModelWebTask();
    $xml = $webTask->getXmlOfTheWebTaskByTaskID($activityID);
    $posDel = strpos($xml[0]->xml, "cwmp:Download");

    $GLOBALS['myArr'] = array();

    $startPart = substr($xml[0]->xml, strlen("<cwmp:Download"), strlen($xml[0]->xml));
    $endVersion = '<cwmp:Download xmlns:soap="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:cwmp="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' . $startPart;
    $xml = simplexml_load_string($endVersion);
    $paramName = $xml->Url;
    $paramName = substr($paramName, 0,strpos($paramName, "?"));
    $urlArr=explode("/",$paramName);

    $paramName=$urlArr[count($urlArr)-1];

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $GLOBALS['myArr'][0]['name']  =$ini_array['file_name'];

    $GLOBALS['myArr'][0]['value'] = $paramName;

    $params = $GLOBALS['myArr'];
    $count = 1;
    include $_SESSION['APPPATH'] . 'views/content/admin/activityParamsValues.php';
}

if(isset($_POST['fromApp'])){
if (session_id() == '') {
session_start();
}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

if (isset($_SESSION['logged_in'])) {
try{
$activityID = $_POST['activityID'];
$activityType=$_POST['activityType'];
define('BASEPATH', $_SESSION['BASEPATH']);
$endFile="";
    if($activityType=='logUp'){
        $endFile='.log';
        getFileNameByType($activityID,$activityType,$endFile);
    }else if($activityType=='configUp'){
        $endFile='_config.tar.gz';
        getFileNameByType($activityID,$activityType,$endFile);
    } else if ($activityType=='config' || $activityType=='firmware'){
        getFWOrConfig($activityID,$activityType);
    }


}catch (\Exception $e){
error_log($e->getMessage());
header('HTTP/1.1 500 Internal Server Error');
header("Status: 500 Internal Server Error");
exit();
}
} else {
$result = "logged_out";
echo $result;
}
} else {
exit('No direct script access allowed');
}