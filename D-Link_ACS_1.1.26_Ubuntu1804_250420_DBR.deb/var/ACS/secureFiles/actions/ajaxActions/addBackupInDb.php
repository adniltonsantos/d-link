<?php
function getTaskStatus($deviceId,$task){
    include $_SESSION['APPPATH'].'models/modelParams.php';

    $modParams = new ModelParams();
    $params = $modParams-> getLastActivityStatusByDevId($deviceId,$task);
    return is_array($params) && count($params)>0 ? $params[0]->operation_status:"-1";
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
    
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'].'models/fwConfigFile.php';
            include $_SESSION['APPPATH'].'models/device.php';
            include $_SESSION['APPPATH'].'models/modelUser.php';
            $fwConfig=new FwConfigFile();
            $dev=new Device();

            $devId = $_POST['deviceID'];
            $modelId=$dev->getModelNameByDevId($devId);
            $fileName = $_POST['fileName'];
            $fileSize = $_POST['fileSize'];

            $user = new ModelUser();
            $ip = $user->getIp()[0];
            $port = $user->getPort()[0];
            $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            $configUrl = /*$protocol . $ip->settings_value . ":" . $port->settings_value . */"/putConfigs" . "/"  . $fileName;
            $resForInsert=$fwConfig->addConfig($modelId[0]->model_id,$fileSize,$configUrl,$fileName);

            if ($resForInsert) {
                echo 'true';
            } else {
                echo 'false';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }  
    } else {
        echo 'logged_out';
    }
} else {
    exit('No direct script access allowed');
}
