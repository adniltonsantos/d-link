<?php
function cidrToRange($cidr) {
    $range = array();
    $pos = strpos($cidr, "/");
    if($pos) {
        $count = substr_count($cidr, '/');
        if($count > 1) {
            return false;
        } else {
            $cidr = explode('/', $cidr);
            if($cidr[1] > 32) {
                return false;
            }
            $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
            $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
            return $range;
        }
    } else {
        return $pos;
    }
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
    session_start();
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            require_once $_SESSION['APPPATH'].'util/utils.php';
            require_once $_SESSION['APPPATH'].'models/device.php';
            require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';

            define('BASEPATH', $_SESSION['BASEPATH']);
            $groupID = $_SESSION['group_id'];
            $searchValue = $_POST['searchVal'];
            $devInfo = $_POST['devInfo'];
            $dev = new Device();
            $limit = 20;
            $limitDev = 10;

            $ipMaskStart = 0;
            $ipMaskEnd = 0;
            if($searchValue == "ip") {
                if($devInfo != '') {
                    $ipMask = cidrToRange($devInfo);
                    if($ipMask) {
                        $ipMaskStart = $ipMask[0];
                        $ipMaskEnd = $ipMask[1];
                    }
                }
            }

            if (!isset($_POST['numDev'])){
                $numDev = 0;
            }else{
                $numDev = $_POST['numDev'];
            }

            if (!isset($_POST['num'])){
                $num = 0;
            }else{
                $num = $_POST['num'];
            }

            if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
                $groups = $dev->getGroupsOfUser($_SESSION['userID'], $limit, $num);
                $allgroups = $dev->getAllGroupsOfUser($_SESSION['userID']);
                $ungrouped = $dev->getUnGroupsOfUser($_SESSION['userID'], $limit, $num);
                if (count($groups)== 0){
                    $data = 1;
                    echo $data;
                    return false;
                }
            } else{
                $groups = $dev->getAllGroupsOfLimit($limit, $num);
                $allgroups = $dev->getAllGroups();
                $ungrouped =  $dev->getUnGrouped($limit, $num);
                if (count($groups)== 0){
                    $data = 1;
                    echo $data;
                    return false;
                }
            }


            $devices = array();
            $devicesCount = array();
            $devCaunt = 0;
            for ($k = 0; $k < count($allgroups); $k++){
                if($searchValue == "ip") {
                    $devicesCount[$k] = $dev->searchDeviceCountByIpForGroup($devInfo, $allgroups[$k]->id, $ipMaskStart, $ipMaskEnd);
                    $devCaunt += count($devicesCount[$k]);
                } elseif ($searchValue == "serial"){
                    $devicesCount[$k] = $dev->searchDeviceCountBySerialForGroup( $devInfo, $allgroups[$k]->id);
                    $devCaunt += count($devicesCount[$k]);
                } elseif ($searchValue == "mac"){
                    $devicesCount[$k] =$dev->searchDeviceCountByMacForGroup($devInfo, $allgroups[$k]->id);
                    $devCaunt += count($devicesCount[$k]);
                }
            }
            for($i=0; $i<count($groups); $i++) {
                if($searchValue == "ip") {
                    $devices[$i] = $dev->searchDeviceByIpForGroup($devInfo, $groups[$i]->id,$limitDev, $numDev, $ipMaskStart, $ipMaskEnd);
                } elseif ($searchValue == "serial"){
                    $devices[$i] = $dev->searchDeviceBySerialForGroup( $devInfo, $groups[$i]->id,$limitDev, $numDev);
                } elseif ($searchValue == "mac"){
                    $devices[$i] =$dev->searchDeviceByMacForGroup($devInfo, $groups[$i]->id,$limitDev, $numDev);
                }
            }
            if(!empty($ungrouped)) {
                if ($searchValue == "ip") {
                    $ungroupedDevices = $dev->searchDeviceByIpForGroup($devInfo, '', $limitDev, $numDev, $ipMaskStart, $ipMaskEnd);
                    $ungroupedDevicesCount = $dev->searchDeviceCountByIpForGroup($devInfo, '',  $ipMaskStart, $ipMaskEnd);
                    $devCaunt += count($ungroupedDevicesCount);
                } elseif ($searchValue == "serial") {
                    $ungroupedDevices = $dev->searchDeviceBySerialForGroup($devInfo, '', $limitDev, $numDev);
                    $ungroupedDevicesCount = $dev->searchDeviceCountBySerialForGroup($devInfo, '');
                    $devCaunt += count($ungroupedDevicesCount);
                } elseif ($searchValue == "mac") {
                    $ungroupedDevices = $dev->searchDeviceByMacForGroup($devInfo, '', $limitDev, $numDev);
                    $ungroupedDevicesCount = $dev->searchDeviceCountByMacForGroup($devInfo, '');
                    $devCaunt += count($ungroupedDevicesCount);
                }
            }
            $templ = new ModelTemplates();
            $allTemplates = $templ->getAllTemplates();

            include $_SESSION['APPPATH'].'views/content/admin/searchedDevicesForGroups.php';

        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}