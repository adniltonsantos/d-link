<?php

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }

    if (isset($_SESSION['logged_in'])) {
        try{

            require_once $_SESSION['APPPATH'].'util/utils.php';
            require_once $_SESSION['APPPATH'].'models/device.php';
            require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';

            define('BASEPATH', $_SESSION['BASEPATH']);
            $groupID = $_SESSION['group_id'];
            $filterModel = $_POST['model'];
            $filterIpMask = $_POST['ip_mask'];
            $filterFirmware = $_POST['firmware'];
            $filterManufacturer = $_POST['manufacturer'];


            $dev = new Device();
            $limit = 20;
            $limitDev = 10;

            if (!isset($_POST['numDev'])){
                $numDev = 0;
            }else{
                $numDev = $_POST['numDev'];
            }

            if (!isset($_POST['num'])){
                $num = 0;
            }else{
                $num = $_POST['num'];
            }

            if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
                $groups = $dev->getGroupsOfUser($_SESSION['userID'], $limit, $num);
                $allgroups = $dev->getAllGroupsOfUser($_SESSION['userID']);
                $ungrouped = $dev->getUnGroupsOfUser($_SESSION['userID'], $limit, $num);
                if (count($groups)== 0){
                    $data = 1;
                    echo $data;
                    return false;
                }
            } else {
                $groups = $dev->getAllGroupsOfLimit($limit, $num);
                $allgroups = $dev->getAllGroups();
                $ungrouped =  $dev->getUnGrouped($limit, $num);
                if (count($groups)== 0){
                    $data = 1;
                    echo $data;
                    return false;
                }
            }

            $devices = array();
            $devicesCount = array();
            $SearchedDevices = array();
            $devCaunt = 0;

            function cidrToRange($cidr) {
                $range = array();
                $cidr = explode('/', $cidr);
                $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
                $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
                return $range;
            }

            if ($filterIpMask == ''){
                $filterIpMaskStart = '0.0.0.0';
                $filterIpMaskEnd = '255.255.255.255';
            }else{
                $ipMask = cidrToRange($filterIpMask);
                $filterIpMaskStart = $ipMask[0];
                $filterIpMaskEnd = $ipMask[1];
            }

            for ($k = 0; $k < count($allgroups); $k++){
                $devicesCount[$k] = $dev->filteredDeviceCountByIpMaskModelFwManufForGroup($filterModel,$filterIpMaskStart,$filterIpMaskEnd,$filterFirmware,$filterManufacturer,$allgroups[$k]->id);
                $devCaunt += count($devicesCount[$k]);
            }
            if(isset($_POST['forGroupChange'])){
                for($i=0; $i<count($groups); $i++) {
                    $devices[$i] = $dev->filterDeviceByIpMaskModelFwManufForChangeGroup($filterModel,$filterIpMaskStart,$filterIpMaskEnd,$filterFirmware,$filterManufacturer,$groups[$i]->id);

                    $p = 1;
                    foreach ($devices[$i] as $z) {
                        array_push($SearchedDevices, $z -> id);
                    }
                    $p++;
                }
            }else {
                for($i=0; $i<count($groups); $i++) {
                    $devices[$i] = $dev->filterDeviceByIpMaskModelFwManufForGroup($filterModel,$filterIpMaskStart,$filterIpMaskEnd,$filterFirmware,$filterManufacturer,$groups[$i]->id,$limitDev,$numDev);
                    $p = 1;
                    foreach ($devices[$i] as $z) {
                        array_push($SearchedDevices, $z -> id);
                    }
                    $p++;
                }
            }

            if(!empty($ungrouped)) {
                if(isset($_POST['forGroupChange'])){
                    $ungroupedDevices = $dev->filterDeviceByIpMaskModelFwManufForChangeGroup($filterModel, $filterIpMaskStart, $filterIpMaskEnd, $filterFirmware, $filterManufacturer, '');

                }else {
                    $ungroupedDevices = $dev->filterDeviceByIpMaskModelFwManufForGroup($filterModel, $filterIpMaskStart, $filterIpMaskEnd, $filterFirmware, $filterManufacturer, '', $limitDev, $numDev);
                }
                $ungroupedDevicesCount = $dev->filteredDeviceCountByIpMaskModelFwManufForGroup($filterModel,$filterIpMaskStart,$filterIpMaskEnd,$filterFirmware,$filterManufacturer,'');
                $devCaunt += count($ungroupedDevicesCount);
                $p = 0;
                foreach ($ungroupedDevices as $z) {
                    array_push($SearchedDevices, $z -> id);
                }
                $p++;
            }

            echo  json_encode($SearchedDevices);

            $templ = new ModelTemplates();
            $allTemplates = $templ->getAllTemplates();

//            include $_SESSION['APPPATH'].'views/content/admin/searchedDevicesForGroups.php';

        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}