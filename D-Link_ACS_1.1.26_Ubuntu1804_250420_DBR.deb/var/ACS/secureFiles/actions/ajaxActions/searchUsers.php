<?php

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    function strpos_all($haystack, $needle) {
        $offset = 0;
        $allpos = array();
        while (($pos = strpos($haystack, $needle, $offset)) !== FALSE) {
            $offset   = $pos + 1;
            $allpos[] = $pos;
        }
        return $allpos;
    }

if (isset($_SESSION['logged_in'])) {
    try{
        define('BASEPATH', $_SESSION['BASEPATH']);
        include $_SESSION['APPPATH'].'models/modelUser.php';
        include $_SESSION['APPPATH'].'util/pagingConstants.php';
//        require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//        require_once $_SESSION['APPPATH']."actions/api/token.php";
        $page = 1;
        $limit = PagingConstants::$activityCount;
        $offset = ($page - 1) * $limit;
        $user = new ModelUser();
	    $adminsCountArr = $user->getAdminsCount();
	    $adminsCount = (int)$adminsCountArr[0]->count;
        $clientInfo = $_POST["userInfo"];
        $searchVal = $_POST["searchVal"];
        $userType = $_POST["userType"];
        $userGroups = $user->getAllUserGroups();

        $indexes = strpos_all($clientInfo, "%");
        $reversed = array_reverse($indexes);
        $arrayClientInfor = str_split($clientInfo,1);

        for($i=0; $i< count($reversed); $i++) {
        array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
        }
        $stringClientInfor = implode('',$arrayClientInfor);
        $clientInfo = $stringClientInfor;

        if($userType == "DeletedUsers") {
            if ($searchVal == 'userNames') {
                $users = $user->searchDeletedUsers(trim($clientInfo), $limit, $offset);
                $allUsersCount = $user->getDelUsersCountByUserInfo(trim($clientInfo));
                $clientsCount = $allUsersCount[0]->count;
            } else if ($searchVal == 'userEmail') {
                $users = $user->searchDeletedUsersByEmail(trim($clientInfo), $limit, $offset);
                $allUsersCount = $user->getDelUsersCountByEmail(trim($clientInfo));
                $clientsCount = $allUsersCount[0]->count;
            } else if ($searchVal == 'userGroups') {
                $users = $user->searchDelUsersByUserGroups(trim($clientInfo), $limit, $offset);
                $allUsersCount = $user->getdelUsersCountByUserGroups(trim($clientInfo));
                if (isset($allUsersCount[0]->count)) {
                    $clientsCount = $allUsersCount[0]->count;
                } else {
                    $clientsCount = '';
                }
            }
        } else if ($userType == "AllUsers"){
            if ($searchVal == 'userNames') {
                $users = $user->searchUsers(trim($clientInfo), $limit, $offset);
                $allUsersCount = $user->getAllUsersCountByUserInfo(trim($clientInfo));
                $clientsCount = $allUsersCount[0]->count;
            } else if ($searchVal == 'userEmail') {
                $users = $user->searchUsersByEmail(trim($clientInfo), $limit, $offset);
                $allUsersCount = $user->getAllUsersCountByEmail(trim($clientInfo));
                $clientsCount = $allUsersCount[0]->count;
            } else if ($searchVal == 'userGroups') {
                $users = $user->searchUsersByUserGroups(trim($clientInfo), $limit, $offset);
                $allUsersCount = $user->getAllUsersCountByUserGroups(trim($clientInfo));
                if (isset($allUsersCount[0]->count)) {
                    $clientsCount = $allUsersCount[0]->count;
                } else {
                    $clientsCount = '';
                }
            }
//            for($i=0;$i<count($users);$i++){
//                $username = $users[$i]->username;
//                $token = token::create_token($username);
//                $users[$i] = (object) array_merge((array)$users[$i], array( 'token' => $token));
//            }
        }
//        $users = $user->searchUsers(trim($clientInfo), $limit, $offset);
//        $userGroups = $user->getAllUserGroups();
//        $allUsersCount = $user->getAllUsersCountByUserInfo(trim($clientInfo));
//        $clientsCount = $allUsersCount[0]->count;
//        $groupss =$user->getGroupsFromUserGroup();
        $groupss = $user->getGroupsForUserGroup();
        $ungrouped = $user->getUngrouped();
        $ungroup=false;

        for($i=0;$i<count($users);$i++){
            $groupList=$user->getGroupsSelectedUser($users[$i]->id);
            if(!$groupList){
                $groupList=array();
            }
            for($j=0; $j<count($groupList); $j++) {
                if($groupList[$j]->default==1){
                    $ungroup = true;
                    break;
                }
            }
            $users[$i] = (object) array_merge((array)$users[$i], array( 'groupList' => $groupList));
            $users[$i] = (object) array_merge((array)$users[$i], array( 'ungrouped' => $ungroup));
            $groupN = $users[$i]->groupList;
            $uncheckedArray = array();
            for($k = 0; $k < count($groupN); $k++) {
                array_push($uncheckedArray, $groupN[$k]->id);
            }
            $uncheckedGroups = $user->getUncheckedGroups($uncheckedArray);
            $users[$i] = (object) array_merge((array)$users[$i], array( 'uncheckedGroups' => $uncheckedGroups));

        }
        if ($clientsCount < $limit) {
            $pagesCount = 1;
        } else {
            if ($clientsCount % $limit == 0) {
                $pagesCount = $clientsCount / $limit;
            } else {
                $pagesCount = ($clientsCount / $limit - ($clientsCount % $limit) * (1 / $limit)) + 1;
            }
        }
        include $_SESSION['APPPATH'].'views/content/admin/searchedUsers.php';
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 
} else {
    $result = "logged_out";
    echo $result;
}
} else {
    exit('No direct script access allowed');
}
