
<?php

function viewNextUnknowns($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd)
{
    include $_SESSION['APPPATH'] . 'models/modelClient.php';

    include $_SESSION['APPPATH'] . 'util/pagingConstants.php';
    $client = new ModelClient();
    $limit = PagingConstants::$clientsCount;
    $offset = ($page - 1) * $limit;

    if($searchElem == "" || $searchElem != "" && $searchElemVal == ""){

         $unknownsDevicesList = $client->getAllUnknownDevicesBySort($sortVal,trim($modelID), $limit, $offset);

        $allUnknownsDevicesList = $client->getAllUnknownDevicesCount(trim($modelID));
    } else if($searchElem == "ip" && $searchElemVal != ""){

        $unknownsDevicesList = $client->getAllUnknownDevicesByIp($sortVal,$searchElemVal,trim($modelID), $limit, $offset, $ipMaskStart, $ipMaskEnd);
        $allUnknownsDevicesList = $client->getAllUnknownDevicesCountByIp($searchElemVal,trim($modelID), $ipMaskStart, $ipMaskEnd);
    } else if($searchElem == "mac" && $searchElemVal != ""){

        $unknownsDevicesList = $client->getAllUnknownDevicesByMac($sortVal,$searchElemVal,trim($modelID), $limit, $offset);
        $allUnknownsDevicesList = $client->getAllUnknownDevicesCountByMac($searchElemVal,trim($modelID));
    }

    $clientsCount = $allUnknownsDevicesList[0]->count;
    if ($clientsCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($clientsCount % $limit == 0) {
            $pagesCount = $clientsCount / $limit;
        } else {
            $pagesCount = ($clientsCount / $limit - ($clientsCount % $limit) * (1 / $limit)) + 1;
        }
    }

    $allExistingClientsCount = $client->getAllExistingClientsCount();
    
    // for connecting tarifs
    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
    $templ = new ModelTemplates();
    $allTemplates = $templ->getAllTemplates();
    
    require_once $_SESSION['APPPATH'].'models/device.php';
    $device = new Device();
    $groups = $device->getAllGroups();
    
//    require_once $_SESSION['APPPATH'].'models/modelParams.php';
//    $modParams = new ModelParams();
//    $params = $modParams->conectionType();
    $allClientsCount = $client->getAllClientsCount();

//var_dump($unknownsDevicesList);

    //added  custom sort by ip
    if ($sortVal != '') {
        $sortedValVar = trim(explode(":", $sortVal)[0]);
        $sortBy = trim(explode(":", $sortVal)[1]);
        include $_SESSION['APPPATH'] . 'util/utils.php';

        if ($sortedValVar == 'ip') {
        $unknownsDevicesList = Utils::sortDeviceIps($unknownsDevicesList, $sortBy,$limit,$offset);
        }
    }



    include $_SESSION['APPPATH'] . 'views/content/admin/pagingUnknownDevices.php';
}

function viewNextUnknowns1($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd)
{
    include $_SESSION['APPPATH'] . 'models/modelClient.php';

    include $_SESSION['APPPATH'] . 'util/pagingConstants.php';
    $client = new ModelClient();
    $limit = PagingConstants::$clientsCount;
    $offset = ($page - 1) * $limit;
    
    if($searchElem == "" || $searchElem != "" && $searchElemVal == ""){
              $pendingDevicesList = $client->getAllUnknownDevicesByClientIDBySort($sortVal,trim($modelID), $limit, $offset);


        $allPendingDevicesList = $client->getAllUnknownDevicesCount1(trim($modelID));
        $pendingAllDevicesList = $client->getAllPendingDevicesByClientID($modelID);
    } else if($searchElem == "ip" && $searchElemVal != ""){
        $pendingDevicesList = $client->getAllUnknownDevicesByIp1($sortVal,$searchElemVal,trim($modelID), $limit, $offset, $ipMaskStart, $ipMaskEnd);
        $allPendingDevicesList = $client->getAllUnknownDevicesCountByIp1($searchElemVal,trim($modelID), $ipMaskStart, $ipMaskEnd);
        $pendingAllDevicesList = $client->getAllPendingDevicesByIp($searchElemVal,trim($modelID), $ipMaskStart, $ipMaskEnd);
    } else if($searchElem == "mac" && $searchElemVal != ""){
        $pendingDevicesList = $client->getAllUnknownDevicesByMac1($sortVal,$searchElemVal,trim($modelID), $limit, $offset);
        $allPendingDevicesList = $client->getAllUnknownDevicesCountByMac($searchElemVal,trim($modelID));
        $pendingAllDevicesList = $client->getAllPendingDevicesByMac($searchElemVal,trim($modelID));
    } else if($searchElem=="client" && $searchElemVal != ""){
        $pendingDevicesList = $client->getAllUnknownDevicesByClientName($sortVal,$searchElemVal,trim($modelID), $limit, $offset);
        $allPendingDevicesList = $client->getAllPendingDevicesByClientNameCount($searchElemVal,trim($modelID));
        $pendingAllDevicesList = $client->getAllPendingDevicesByClientName($searchElemVal,trim($modelID));
    }
    
    $clientsCount = $allPendingDevicesList[0]->count;
    if ($clientsCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($clientsCount % $limit == 0) {
            $pagesCount = $clientsCount / $limit;
        } else {
            $pagesCount = ($clientsCount / $limit - ($clientsCount % $limit) * (1 / $limit)) + 1;
        }
    }

    $allExistingClientsCount = $client->getAllExistingClientsCount();

    //added  custom sort by ip
    if ($sortVal != '') {
        $sortedValVar = trim(explode(":", $sortVal)[0]);
        $sortBy = trim(explode(":", $sortVal)[1]);
        include $_SESSION['APPPATH'] . 'util/utils.php';

        if ($sortedValVar == 'ip') {

        $pendingDevicesList = Utils::sortDeviceIps($pendingDevicesList, $sortBy,$limit, $offset);
        }
    }




    include $_SESSION['APPPATH'] . 'views/content/admin/pagingUnknownDevices.php';
}

function cidrToRange($cidr) {
    $range = array();
    $pos = strpos($cidr, "/");
    if($pos) {
        $count = substr_count($cidr, '/');
        if($count > 1) {
            return false;
        } else {
            $cidr = explode('/', $cidr);
            if($cidr[1] > 32) {
                return false;
            }
            $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
            $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
            return $range;
        }
    } else {
        return $pos;
    }
}

try{
    $ipMaskStart = 0;
    $ipMaskEnd = 0;
    if(isset($_POST['ip'])) {
        $searchElemVal = $_POST['ip'];
        if($searchElemVal != '') {
            $ipMask = cidrToRange($searchElemVal);
            if($ipMask) {
                $ipMaskStart = $ipMask[0];
                $ipMaskEnd = $ipMask[1];
            }
        }
    }
    if (isset($_POST['fromApp']) && $_POST['fromApp'] == 'unknown') {
        if (session_id() == '') {
            session_start();
        }
//        if(isset($_COOKIE['timeOut'])){
//            if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//                echo "logged_out";
//                exit();
//            }
//        }
        
        if (isset($_SESSION['logged_in'])) {
            define('BASEPATH', $_SESSION['BASEPATH']);
            $page = $_POST['page'];
            $modelID = $_POST['model'];
            $searchElem = "";
            $searchElemVal = "";
            $sortVal = $_POST['sortVal'];
            if (isset($_POST['ip'])) {
                $searchElem = "ip";
                $searchElemVal = $_POST['ip'];
                viewNextUnknowns($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd);
            } else if (isset($_POST['mac'])) {
                $searchElem = "mac";
                $searchElemVal = $_POST['mac'];
                viewNextUnknowns($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd);
            }else {
                viewNextUnknowns($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd);
            }
        } else {
            $result = "logged_out";
            echo $result;
        }

    }elseif(isset($_POST['fromApp']) && $_POST['fromApp'] == 'pending') {
        if (session_id() == '') {
            session_start();
        }

        if (isset($_SESSION['logged_in'])) {
            define('BASEPATH', $_SESSION['BASEPATH']);
            $page = $_POST['page'];
            $modelID = $_POST['model'];
            $searchElem = "";
            $searchElemVal = "";

            $sortVal = $_POST['sortVal'];

            if (isset($_POST['ip'])) {
                $searchElem = "ip";
                $searchElemVal = $_POST['ip'];
                viewNextUnknowns1($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd);
            } elseif (isset($_POST['mac'])) {
                $searchElem = "mac";
                $searchElemVal = $_POST['mac'];
                viewNextUnknowns1($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd);
            }elseif (isset($_POST['client'])) {
                $searchElem = "client";
                $searchElemVal = $_POST['client'];
                viewNextUnknowns1($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd);
            }else {

                viewNextUnknowns1($sortVal,$searchElem,$searchElemVal,$page, $modelID, $ipMaskStart, $ipMaskEnd);
            }
        } else {
            $result = "logged_out";
            echo $result;
        }

    }else {
        exit('No direct script access allowed');
    }
}catch (\Exception $e){
    error_log($e->getMessage());
    header('HTTP/1.1 500 Internal Server Error');
    header("Status: 500 Internal Server Error");
    exit();
}