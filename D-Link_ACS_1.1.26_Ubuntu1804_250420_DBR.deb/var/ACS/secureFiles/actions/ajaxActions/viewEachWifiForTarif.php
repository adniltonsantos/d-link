<?php
if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
    if(!class_exists("ParamNamesConstants")){include $_SESSION['APPPATH'] . "util/paramNamesConstants.php";}

    if (isset($_SESSION['logged_in'])) {
        try {
            $lang = $_SESSION['lang'];
            define('BASEPATH', $_SESSION['BASEPATH']);
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
            }
            $wifiId = $_POST['id'];
            $paramNames = $_POST['paramN'];
            $paramValues = $_POST['paramV'];
            $params = array();
            if(in_array(ParamNamesConstants::$enableDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$enableDesc,$paramNames);
                $params['enable'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$frequency_band,$paramNames)){
                $ii = array_search(ParamNamesConstants::$frequency_band,$paramNames);
                $params['FrequencyBand'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$ssidDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$ssidDesc,$paramNames);
                $params['ssid'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$channelDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$channelDesc,$paramNames);
                $params['channel'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$standardDesc,$paramNames)){
                $ii = array_search(ParamNamesConstants::$standardDesc,$paramNames);
                $params['standard'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$txPower,$paramNames)){
                $ii = array_search(ParamNamesConstants::$txPower,$paramNames);
                $params['transmit_power'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$maxAssociatedClients,$paramNames)){
                $ii = array_search(ParamNamesConstants::$maxAssociatedClients,$paramNames);
                $params['max_associated_clients'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$wpa_encrypt,$paramNames)){
                $ii = array_search(ParamNamesConstants::$wpa_encrypt,$paramNames);
                $params['wpa_encrypt'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$wpa_encrypt2,$paramNames)){
                $ii = array_search(ParamNamesConstants::$wpa_encrypt2,$paramNames);
                $params['wpa_encrypt2'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$basic,$paramNames)){
                $ii = array_search(ParamNamesConstants::$basic,$paramNames);
                $params['basic_mode'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$wpa_psk,$paramNames)){
                $ii = array_search(ParamNamesConstants::$wpa_psk,$paramNames);
                $params['wpa_psk'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$wpa_psk2,$paramNames)){
                $ii = array_search(ParamNamesConstants::$wpa_psk2,$paramNames);
                $params['wpa_psk2'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$key_psk,$paramNames)){
                $ii = array_search(ParamNamesConstants::$key_psk,$paramNames);
                $params['key_psk'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$wpa,$paramNames)){
                $ii = array_search(ParamNamesConstants::$wpa,$paramNames);
                $params['wpa'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$wpa2,$paramNames)){
                $ii = array_search(ParamNamesConstants::$wpa2,$paramNames);
                $params['wpa2'] = $paramValues[$ii];
            }

            if(in_array(ParamNamesConstants::$wpa_reneval,$paramNames)){
                $ii = array_search(ParamNamesConstants::$wpa_reneval,$paramNames);
                $params['wpa_reneval'] = $paramValues[$ii];
            }

            include  $_SESSION['APPPATH'].'views/content/admin/wirelessPageForTarif.php';
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}