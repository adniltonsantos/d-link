<?php
if (session_id() == '') {
    session_start();
}

function sendFileToClient($file)
{
    $file =  $_SERVER['DOCUMENT_ROOT'] . $file;
    if (file_exists($file))
    {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }else{
        return false;
    }
}



    if (isset($_POST['token']) && isset($_POST['actionName'])) {
        $file =  $_POST['actionName'];

        include $_SESSION['APPPATH'].'models/JWT/JWT.php';
        include $_SESSION['APPPATH'].'models/xor/xor.php';
        include $_SESSION['APPPATH'].'actions/api/token.php';
        $token = trim($_POST['token']);
        if ($token != '') {
            $login = token::check_token($token);
            if ($login != false) {
                sendFileToClient($file);

            } else {
                return false;
            }
        } else {
            return false;
        }
    }
