<?php
if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//
    function searchByType()
    {

    }

    if (isset($_SESSION['logged_in'])) {
        try {
            define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'] . 'models/modelClient.php';
            include $_SESSION['APPPATH'] . 'util/pagingConstants.php';

            $client = new ModelClient();
            $page = 1;

            $limit = PagingConstants::$clientsCount;
            $offset = ($page - 1) * $limit;
            $sortedVal = $_POST['sortedVal'];
            $clientInfo = $_POST['clientInfo'];
            $searchVal = $_POST['searchVal'];

            if ($clientInfo != '') {
                if ($searchVal == 'firstName') {
                    $clients = $client->searchClientByFirstNameBySort($sortedVal, trim($clientInfo), $limit, $offset);
                    $allClientsCount = $client->getAllClientsCountByFirstName(trim($clientInfo));

                } else if ($searchVal == 'surName') {
                    $clients = $client->searchClientBySurNameBySort($sortedVal, trim($clientInfo), $limit, $offset);
                    $allClientsCount = $client->getAllClientsCountBySurName(trim($clientInfo));

                } else if ($searchVal == 'patronymicName') {
                    $clients = $client->searchClientByPatNameBySort($sortedVal, trim($clientInfo), $limit, $offset);
                    $allClientsCount = $client->getAllClientsCountByPatName(trim($clientInfo));

                } else if ($searchVal == 'contractNumber') {
                    $clients = $client->searchClientByContNumBySort($sortedVal, trim($clientInfo), $limit, $offset);
                    $allClientsCount = $client->getAllClientsCountByContNum(trim($clientInfo));
                }
            } else {
                $clients = $client->getAllClientsBySort($sortedVal, $limit, $offset);
                $allClientsCount = $client->getAllClientsCount();
            }
            $clientsCount = $allClientsCount[0]->count;

            include $_SESSION['APPPATH'] . 'util/paging.php';

            $pagesCount = Paging::getPagesCount($clientsCount, $limit);

            //var_dump($clients);

            //added custom sorting for address
            if ($sortedVal != '') {
                $sortedValVar = trim(explode(":", $sortedVal)[0]);
                $sortBy = trim(explode(":", $sortedVal)[1]);
            } else {
                $sortedValVar = "first_name";
                $sortBy = "DESC";
            }
            include $_SESSION['APPPATH'] . 'util/utils.php';
            if ($sortedValVar == 'address') {
                $clients = Utils::sortClientAddresses($clients, $sortBy,$limit,$offset);
            }
            $action = "fromClientsView";
            include $_SESSION['APPPATH'] . 'views/content/admin/searchedClients.php';
        } catch (\Exception $e) {
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = 'logged_out';
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}

