<?php
if (isset($_POST['fromApp'])) {

    if (session_id() == '') {
        session_start();
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            include $_SESSION['APPPATH'] . 'models/modelClient.php';
            $client = new ModelClient();
            $clientInfo = $_POST['clientInfo'];
            $sortedVal =  $_POST['sortedVal'];
            $searchVal =  $_POST['searchVal'];
            $searchVal1="";

            if($sortedVal=='first_name' || $sortedVal=='sur_name' || $sortedVal=='patronymic_name' || $sortedVal=='address') {
                if ($clientInfo != '') {

                    if ($searchVal == 'firstName') {
                        $searchVal1 = 'first_name';
                    } elseif ($searchVal == 'surName') {
                        $searchVal1 = 'sur_name';
                    } elseif ($searchVal == 'patronymicName') {
                        $searchVal1 = 'patronymic_name';
                    } elseif ($searchVal == 'contractNumber') {
                        $searchVal1 = 'contract_number';
                    } else {
                        $searchVal1 = 'loggedOut';

                    }
                    if ($searchVal1 != 'loggedOut') {
                        $allClientsCount = $client->getSearchedClientsCountBySort($searchVal1, $sortedVal, trim($clientInfo));
                        echo $allClientsCount[0]->count;
                    } else {
                        $result = "logged_out";
                        echo $result;
                    }
                } else {
                    $allClientsCount = $client->getNotEmptyRowsCountByColumnName($sortedVal);
                    echo $allClientsCount[0]->count;
                }
            } else  {
                $result = "logged_out";
                echo $result;
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
