<?php

if (isset($_POST['fromApp'])) {
    if (session_id() == '') { session_start();}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            require_once $_SESSION['APPPATH'].'models/modelParams.php';
            $modelParams = new ModelParams();
            $action = $_POST['action'];
            $host = $_POST['host'];
            $type = $_POST['type'];

            if($action == 'insert' && trim($host) != ''){
                $result = insert($host,$type,$modelParams);
                if($result != 0){
                    echo $result;
                }else {
                    echo 'false';
                }

            }elseif ($action == 'delete' && trim($host) != '') {
                    $result = delete($host,$modelParams);
                    echo $result;
            }else {
                echo 'false';
            } 
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        echo "logged_out";
    }
} else {
    exit('No direct script access allowed');
}


function insert($host,$type,$modelParams){
    return $modelParams->setHost($host,$type);
}

function delete($host,$modelParams){
    $res = $modelParams->removeHost($host);
    return $res;
}