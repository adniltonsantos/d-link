<?php
function changePass($pass,$ini_array)
{
    include $_SESSION['APPPATH'].'models/modelUser.php';
    include $_SESSION['APPPATH'].'util/pagingConstants.php';

   $realUserName = $_SESSION['logged_in'];
    $user = new ModelUser();
    $res = $user->changePass($realUserName, $pass);
    if (!$res) {
        $_SESSION['change_pass'] = $ini_array['fail_change_pass'];
    } else {
        $_SESSION['change_pass'] = $ini_array['success_change_pass'];
    }
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $lang = $_SESSION['lang'];
                $ini_array='';
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }
            $pass = $_POST['password'];
            changePass($pass,$ini_array);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}