<?php
function convertUnixTimestamp($time){
    date_default_timezone_set("UTC");

    $date = DateTime::createFromFormat('Y-m-d\TH:i:s.u', $time);
//    $date = date_create_from_format('Y-m-d H:i:s', $time);
    $seconds = $date->getTimestamp()*1000000 + intval($date->format("u"));

    return $seconds;
}

function after($symbol, $inthat)
{
    if (!is_bool(strpos($inthat, $symbol)))
        return substr($inthat, strpos($inthat,$symbol)+strlen($symbol));
};

function before($symbol, $inthat)
{
    return substr($inthat, 0, strpos($inthat, $symbol));
};

function getWanParams($wanID, $serialN, $connType, $devStatus, $havePerms, $devID) {

    include $_SESSION['APPPATH'] . 'models/modelParams.php';
    $modParams = new ModelParams();
    $getIp = $modParams->getIPForDiagnostic();
    $getUploadFileSize = $modParams->getUploadFileSizeForDiagnostic();
    $getAllConnections = $modParams->getAllWanParams($serialN);
    $hasPPPConnections = $modParams->getCountWanPPOEParams($serialN);
    $connIndexArr = $modParams->getConnIndexOfDeviceBySerial($serialN);
    $connIndex = 1;
    if (!empty($connIndexArr)) {
        $connIndex = $connIndexArr[0]->conn_index;
    } else {
        $connIndex = 1;
    }
    $deviceStatus = $devStatus;
    $havPerms = $havePerms;
    if ($connType == "Static") {
        $uploadDownload = array();
        $paramsFromModel = $modParams->getWanStaticParams($wanID, $serialN);
        if (!empty($paramsFromModel)) {
            $dns = explode(',',trim($paramsFromModel[0]->dns_servers));

            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name" => array("Name", $paramsFromModel[0]->name), 
                "mtu" => array("MaxMTUSize", $paramsFromModel[0]->max_mtu_size), 
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)), 
                "ip" => array("ExternalIPAddress", trim($paramsFromModel[0]->external_ip_address)), 
                "netmask" => array("SubnetMask", trim($paramsFromModel[0]->subnet_mask)), 
                "gateway" => array("DefaultGateway", trim($paramsFromModel[0]->default_gateway)), 
//                "dns" => array("DNSServers", trim($paramsFromModel[0]->dns_servers)),
                "primaryDns" => array("DNSServers", $dns[0]),
                "secondaryDns" => array("DNSServers", isset($dns[1]) ? $dns[1] : ''),
                "enablePing" => array("X_DLINK_PingEnabled", trim($paramsFromModel[0]->ping_enabled)),
                "enableNat" => array("NATEnabled", trim($paramsFromModel[0]->nat_enabled)), 
                "enableIGMP" => array("X_COM_IGMPEnabled", $paramsFromModel[0]->igmp_multicast ),
                "enable" => array("Enable", $paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)),
                "exist" => "1", 
                "valueChange" => $paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change, 
                "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "trdefconn" => $paramsFromModel[0]->trdefconn,
                "hasPPPConnections" => $hasPPPConnections,
                "defconn" => array("DefaultConn", $paramsFromModel[0]->defconn)); 
        } else {
            $dynamicPar = $modParams->getWanDynamicParams($wanID, $serialN);
            if ($dynamicPar) {
                $params = array(
                    "id" => array("id", $dynamicPar[0]->id),
                    "index" => array("index", $dynamicPar[0]->num_index),
                    "name" => array("Name", $dynamicPar[0]->name), 
                    "mtu" => array("MaxMTUSize", 1500), 
                    "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address), 
                    "ip" => array("ExternalIPAddress", ''), 
                    "netmask" => array("SubnetMask", ''), 
                    "gateway" => array("DefaultGateway", ''), 
//                    "dns" => array("DNSServers", ''), 
                    "primaryDns" => array("DNSServers", ''),
                    "secondaryDns" => array("DNSServers", ''),
                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableNat" => array("NATEnabled", 1), 
                    "enableIGMP" => array("X_COM_IGMPEnabled",0),
                    "enable" => array("Enable", 0), 
                    "exist" => "0", 
                    "valueChange" => 0, 
                    "numIndex" => 0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn" => array("DefaultConn","0"));// must be checked in fron end
            } else {
                $params = array(
                    "index" => array("index", 1), 
                    "name" => array("Name", ""), 
                    "mtu" => array("MaxMTUSize", 1500), 
                    "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address), 
                    "ip" => array("ExternalIPAddress", ''), 
                    "netmask" => array("SubnetMask", ''), 
                    "gateway" => array("DefaultGateway", ''), 
//                    "dns" => array("DNSServers", ''), 
                    "primaryDns" => array("DNSServers", ''),
                    "secondaryDns" => array("DNSServers", ''),
                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableNat" => array("NATEnabled", 1), 
                    "enableIGMP" => array("X_COM_IGMPEnabled",0),
                    "enable" => array("Enable", 0), 
                    "exist" => "0", 
                    "valueChange" => 0, 
                    "numIndex" => 0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn" => array("DefaultConn","1"));//array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.1."));
            }
        }
        $wanType = 3;
        $diagnostic = $modParams->getPingResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($diagnostic)) {
            $failCount = $diagnostic[0]->received;
            $successCount = $diagnostic[0]->sent;
            $lost = 0;

            if ($failCount + $successCount != 0) {
                $lost = $failCount / ($failCount + $successCount) * 100;
            }
            $min = $diagnostic[0]->minimum;
            $max = $diagnostic[0]->maximum;
            $average = $diagnostic[0]->average;
        }
        $i = 0;
        $downloadResult = $modParams->getDownloadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($downloadResult)) {
            $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
            $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
            $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
            $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
            $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
            $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Download',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $uploadResult = $modParams->getUploadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($uploadResult)) {
            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
            $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
            $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
            $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
            $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
            $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Upload',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $toAddConnect = 'false';
        include $_SESSION['APPPATH'] . 'views/content/admin/wanStatic.php';
    } else if ($connType == "Static_v6") {
            $paramsFromModel = $modParams->getWanStaticIPv6Params($wanID, $serialN);
//        var_dump($paramsFromModel);


        if (!empty($paramsFromModel)) {
            $dns = explode(',',trim($paramsFromModel[0]->dns_servers));
            $ip = before('/', $paramsFromModel[0]->external_ip_address);
            $prefix = after('/', $paramsFromModel[0]->external_ip_address);

            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name"=>array("Name",  $paramsFromModel[0]->name),
                "mtu" => array("MaxMTUSize", $paramsFromModel[0]->max_mtu_size),
                "mac" => array("MACAddress",   $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)),
                "ip" => array("ExternalIPAddress", $ip),
                "prefix" => array("Prefix", $prefix),
                "netmask" => array("SubnetMask", trim($paramsFromModel[0]->subnet_mask)),
                "gateway" => array("DefaultGateway", trim($paramsFromModel[0]->default_gateway)),
//                    "dns" => array("DNSServers", ''),
                "primaryDns" => array("DNSPrim", $dns[0]),
                "secondaryDns" => array("DNSSec", isset($dns[1]) ? $dns[1] : ''),
                "enableIGMP" => array("X_COM_IGMPEnabled", $paramsFromModel[0]->igmp_multicast),
                "enable" => array("Enable",$paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)),
//                "enablePing" => array("X_DLINK_PingEnabled",$paramsFromModel[0]->ping_enabled),
                "exist" => "1",
                "valueChange"=>$paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change,
                "numIndex"=>$paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "defconn"=>array("DefaultConn", $paramsFromModel[0]->defconn));


        } else {
            $params = array(
//                "flagl" => array("flagl", "addStaticWan"),
                "flagl" => array("flagl", "setStaticIPv6Wan"),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name"=>array("Name", ""),
                "mtu" => array("MaxMTUSize", 1500),
                "mac" => array("MACAddress", /*$serialN*/ $paramsFromModel[0]->mac_address),
                "ip" => array("ExternalIPAddress", ''),
                "prefix" => array("Prefix", ''),
                "netmask" => array("SubnetMask", ''),
                "gateway" => array("DefaultGateway", ''),
//                "dns" => array("DNSServers", ''),
                "primaryDns" => array("DNSPrim", ''),
                "secondaryDns" => array("DNSSec", ''),
                "enableIGMP" => array("X_COM_IGMPEnabled", $paramsFromModel[0]->igmp_multicast),
                "enable" => array("Enable",0),
//                "enablePing" => array("X_DLINK_PingEnabled",0),
                "exist" => "0",
                "valueChange"=>0,
                "numIndex"=>0,
                "interfaceType" => array("internet", "-1"),
                "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.".$paramsFromModel[0]->num_index.".")
            );
        }
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanStaticV6.php';


    } else if ($connType == "DHCP") {
        $uploadDownload = array();
        $paramsFromModel = $modParams->getWanDynamicParams($wanID, $serialN);
        if (!empty($paramsFromModel)) {
            $dns = explode(',',trim($paramsFromModel[0]->dns_servers));

            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name" => array("Name", $paramsFromModel[0]->name),
                "mtu" => array("MaxMTUSize", $paramsFromModel[0]->max_mtu_size),
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)),
//                "dns" => array("DNSServers", trim($paramsFromModel[0]->dns_servers)),
                "primaryDns" => array("DNSServers", $dns[0]),
                "secondaryDns" => array("DNSServers", isset($dns[1]) ? $dns[1] : ''),
                "enablePing" => array("X_DLINK_PingEnabled", trim($paramsFromModel[0]->ping_enabled)),
                "enableNat" => array("NATEnabled", trim($paramsFromModel[0]->nat_enabled)),
                "enableDns" => array("DNSOverrideAllowed", trim($paramsFromModel[0]->dns_enabled)),
                "enableIGMP" => array("X_COM_IGMPEnabled", $paramsFromModel[0]->igmp_multicast ),
                "enable" => array("Enable", $paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)),
                "exist" => "1",
                "ip" => $paramsFromModel[0]->ip,
                "valueChange" => $paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change,
                "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "trdefconn" => $paramsFromModel[0]->trdefconn,
                "SubnetMask" => $paramsFromModel[0]->subnet_mask,
                "DefaultGateway" => $paramsFromModel[0]->default_gateway,
                "ConnectionStatus" => $paramsFromModel[0]->conn_status,
                "Uptime" => $paramsFromModel[0]->uptime,
                "hasPPPConnections" => $hasPPPConnections,
                "defconn" => array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANIPConnection." . $paramsFromModel[0]->num_index . ".")
            );
        } else {
            $staticPar = $modParams->getWanStaticParams($wanID, $serialN);
            if ($staticPar) {
                $params = array(
                    "id" => array("id", $staticPar[0]->id),
                    "index" => array("index", $staticPar[0]->num_index),
                    "name" => array($staticPar[0]->name),
                    "mtu" => array("MaxMTUSize", 1500),
                    "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address),
//                    "dns" => array("DNSServers", ''),
                    "primaryDns" => array("DNSServers", ''),
                    "secondaryDns" => array("DNSServers", ''),
                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableNat" => array("NATEnabled", 1),
                    "enableDns" => array("DNSOverrideAllowed", 1),
                    "enableIGMP" => array("X_COM_IGMPEnabled",0),
                    "exist" => "0",
                    "ip" => "",
                    "enable" => array("Enable", 0),
                    "valueChange" => 0,
                    "numIndex" => 0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn" => array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANIPConnection." . $staticPar[0]->num_index . "."));
            } else {
                $params = array(
                    "index" => array("index", 1),
                    "name" => array("Name", ""),
                    "mtu" => array("MaxMTUSize", 1500),
                    "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address),
//                    "dns" => array("DNSServers", ''),
                    "primaryDns" => array("DNSServers", ''),
                    "secondaryDns" => array("DNSServers", ''),
                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableNat" => array("NATEnabled", 1),
                    "enableDns" => array("DNSOverrideAllowed", 1),
                    "enableIGMP" => array("X_COM_IGMPEnabled",0),
                    "exist" => "0",
                    "ip" => "",
                    "enable" => array("Enable", 0),
                    "valueChange" => 0,
                    "numIndex" => 0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn" => array("DefaultConn","0"));
            }
        }
        $wanType = 3;
        $diagnostic = $modParams->getPingResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($diagnostic)) {
            $failCount = $diagnostic[0]->received;
            $successCount = $diagnostic[0]->sent;
            $lost = 0;

            if ($failCount + $successCount != 0) {
                $lost = $failCount / ($failCount + $successCount) * 100;
            }
            $min = $diagnostic[0]->minimum;
            $max = $diagnostic[0]->maximum;
            $average = $diagnostic[0]->average;
        }

        $downloadResult = $modParams->getDownloadResultsForWan($devID, $params['index'][1], $wanType);
        $i = 0;
        if(!empty($downloadResult)) {
            $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
            $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
            $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
            $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
            $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
            $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Download',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $uploadResult = $modParams->getUploadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($uploadResult)) {
            $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
            $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
            $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
            $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
            $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
            $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Upload',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $toAddConnect = 'false';

        include $_SESSION['APPPATH'] . 'views/content/admin/wanDynamic.php';
    }    else if ($connType == "DHCP_v6") {
        $uploadDownload = array();
        $paramsFromModel = $modParams->getWanDynamicIPv6Params($wanID, $serialN);
        if (!empty($paramsFromModel)) {
            $dns = explode(',',trim($paramsFromModel[0]->dns_servers));

            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name" => array("Name", $paramsFromModel[0]->name),
                "mtu" => array("MaxMTUSize", $paramsFromModel[0]->max_mtu_size),
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)),
//                "dns" => array("DNSServers", trim($paramsFromModel[0]->dns_servers)),
                "primaryDns" => array("DNSPrim", $dns[0]),
                "secondaryDns" => array("DNSSec", isset($dns[1]) ? $dns[1] : ''),
                "Slaac" => array("DefaultGateway", $paramsFromModel[0]->default_gateway),
//                "enablePing" => array("X_DLINK_PingEnabled", trim($paramsFromModel[0]->ping_enabled)),
                "enableDns" => array("DNSOverrideAllowed", trim($paramsFromModel[0]->dns_enabled)),
                "enableSlaac" => array("SLAAC", trim($paramsFromModel[0]->slaac)),
                "enableIGMP" => array("X_COM_IGMPEnabled", $paramsFromModel[0]->igmp_multicast ),
                "enable" => array("Enable", $paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)),
                "exist" => "1",
                "ip" => $paramsFromModel[0]->ip,
                "valueChange" => $paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change,
                "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "trdefconn" => $paramsFromModel[0]->trdefconn,
                "hasPPPConnections" => $hasPPPConnections,
                "defconn" => array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANIPConnection." . $paramsFromModel[0]->num_index . ".")
            );
        } else {
                $params = array(
                    "flagl" => array("flagl", "setDynamicWanIPv6"),
                    "index" => array("index", 1),
                    "name" => array("Name", ""),
                    "mtu" => array("MaxMTUSize", 1500),
                    "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address),
//                    "dns" => array("DNSServers", ''),
                    "primaryDns" => array("DNSPrim", ''),
                    "secondaryDns" => array("DNSSec", ''),
                    "Slaac" => array("DefaultGateway", ''),
//                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableDns" => array("DNSOverrideAllowed", 1),
                    "enableSlaac" => array("SLAAC", 1),
                    "enableIGMP" => array("X_COM_IGMPEnabled",0),
                    "enable" => array("Enable", 0),
                    "exist" => "0",
                    "ip" => "",
                    "valueChange" => 0,
                    "numIndex" => 0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn" => array("DefaultConn","0"));
        }
        $wanType = 3;
        $diagnostic = $modParams->getPingResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($diagnostic)) {
            $failCount = $diagnostic[0]->received;
            $successCount = $diagnostic[0]->sent;
            $lost = 0;

            if ($failCount + $successCount != 0) {
                $lost = $failCount / ($failCount + $successCount) * 100;
            }
            $min = $diagnostic[0]->minimum;
            $max = $diagnostic[0]->maximum;
            $average = $diagnostic[0]->average;
        }

        $downloadResult = $modParams->getDownloadResultsForWan($devID, $params['index'][1], $wanType);
        $i = 0;
        if(!empty($downloadResult)) {
            $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
            $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
            $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
            $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
            $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
            $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Download',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $uploadResult = $modParams->getUploadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($uploadResult)) {
            $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
            $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
            $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
            $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
            $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
            $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Upload',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $toAddConnect = 'false';

        include $_SESSION['APPPATH'] . 'views/content/admin/wanDynamic_IPv6.php';
    } else if ($connType == "PPPoE") {
        $uploadDownload = array();
        $paramsFromModel = $modParams->getWanPPOEParams($wanID, $serialN);
        $dns = explode(',',trim($paramsFromModel[0]->dns_servers));
        if (!empty($paramsFromModel)) {
            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name" => array("Name", $paramsFromModel[0]->name), 
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)), 
                "username" => array("Username", trim($paramsFromModel[0]->username)), 
                "password" => array("Password", trim($paramsFromModel[0]->password)),
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", trim($paramsFromModel[0]->ppp_authentication_protocol)),
                "mru" => array("MaxMRUSize", trim($paramsFromModel[0]->max_mru_size)), 
                "ppp_lcp_echo" => array("PPPLCPEcho", trim($paramsFromModel[0]->ppplcp_echo)), 
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", trim($paramsFromModel[0]->ppplcp_echo_retry)),
                "enablePing" => array("X_DLINK_PingEnabled", trim($paramsFromModel[0]->ping_enabled)),
                "enableNat" => array("NATEnabled", trim($paramsFromModel[0]->nat_enabled)), 
                "serviceName" => array("PPPoEServiceName", trim($paramsFromModel[0]->service_name)), 
                "enable" => array("Enable", $paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)), 
                "exist" => "1",
                "valueChange" => $paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change,
                "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "trdefconn" => $paramsFromModel[0]->trdefconn,
                "primaryDns" => array("DNSServers", $dns[0]),
                "secondaryDns" => array("DNSServers", isset($dns[1]) ? $dns[1] : ''),
                "DefaultGateway" => $paramsFromModel[0]->default_gateway,
                "ConnectionStatus" => $paramsFromModel[0]->conn_status,
                "Uptime" => $paramsFromModel[0]->uptime,
                "defconn" =>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection." . $paramsFromModel[0]->num_index ."."));
        } else {
            $params = array(
                "index" => array("index", 1),
                "name" => array("Name", ''), 
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address), 
                "username" => array("Username", ''),
                "password" => array("Password", ''), 
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'), 
                "mru" => array("MaxMRUSize", 0), 
                "ppp_lcp_echo" => array("PPPLCPEcho", 0), 
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", 0),
                "enablePing" => array("X_DLINK_PingEnabled", 1),
                "enableNat" => array("NATEnabled", 1),
                "serviceName" => array("PPPoEServiceName", ''), 
                "enable" => array("Enable", 0),
                "exist" => "0",
                "valueChange" => 0, 
                "numIndex" => 0,
                "interfaceType" => array("internet", "-1"),
//                "defconn" => array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.".$paramsFromModel[0]->num_index .".")
                "defconn" => array("DefaultConn","0")
                );
        }

        $wanType = 1;
        $diagnostic = $modParams->getPingResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($diagnostic)) {
            $failCount = $diagnostic[0]->received;
            $successCount = $diagnostic[0]->sent;
            $lost = 0;

            if ($failCount + $successCount != 0) {
                $lost = $failCount / ($failCount + $successCount) * 100;
            }
            $min = $diagnostic[0]->minimum;
            $max = $diagnostic[0]->maximum;
            $average = $diagnostic[0]->average;
        }
        $i = 0;
        $downloadResult = $modParams->getDownloadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($downloadResult)) {
            $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
            $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
            $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
            $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
            $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
            $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Download',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $uploadResult = $modParams->getUploadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($uploadResult)) {
            $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
            $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
            $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
            $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
            $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
            $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Upload',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $toDoForPPPOE = "changePPPWan";
        $toAddConnect = 'false';
        include $_SESSION['APPPATH'] . 'views/content/admin/wanPPP.php';
    } else if ($connType == "PPPoE_v6") {
        $uploadDownload = array();
        $paramsFromModel = $modParams->getWanPPOEV6Params($wanID, $serialN);
        $dns = explode(',',trim($paramsFromModel[0]->dns_servers));
        if (!empty($paramsFromModel)) {
            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name" => array("Name", $paramsFromModel[0]->name),
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)),
                "Slaac" => array("DefaultGateway", trim($paramsFromModel[0]->default_gateway)),
                "enablePing" => array("X_DLINK_PingEnabled", trim($paramsFromModel[0]->ping_enabled)),
                "username" => array("Username", trim($paramsFromModel[0]->username)),
                "password" => array("Password", trim($paramsFromModel[0]->password)),
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", trim($paramsFromModel[0]->ppp_authentication_protocol)),
                "mtu" => array("MaxMTUSize", $paramsFromModel[0]->max_mtu_size),
                "primaryDns" => array("DNSServers", $dns[0]),
                "secondaryDns" => array("DNSServers", isset($dns[1]) ? $dns[1] : ''),
                "ppp_lcp_echo" => array("PPPLCPEcho", trim($paramsFromModel[0]->ppplcp_echo)),
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", trim($paramsFromModel[0]->ppplcp_echo_retry)),
                "enableDns" => array("DNSOverrideAllowed", trim($paramsFromModel[0]->dns_enabled)),
                "enableSlaac" => array("SLAAC", trim($paramsFromModel[0]->slaac)),
                "enableNat" => array("NATEnabled", trim($paramsFromModel[0]->nat_enabled)),
                "serviceName" => array("PPPoEServiceName", trim($paramsFromModel[0]->service_name)),
                "enable" => array("Enable", $paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)),
                "exist" => "1",
                "valueChange" => $paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change,
                "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "trdefconn" => $paramsFromModel[0]->trdefconn,
                "defconn" =>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection." . $paramsFromModel[0]->num_index ."."));
        } else {
            $params = array(
                "index" => array("index", 1),
                "name" => array("Name", ''),
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address),
                "Slaac" => array("DefaultGateway", ''),
                "enablePing" => array("X_DLINK_PingEnabled", 1),
                "username" => array("Username", ''),
                "password" => array("Password", ''),
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'),
                "mtu" => array("MaxMTUSize", 1500),
                "primaryDns" => array("DNSServers", ''),
                "secondaryDns" => array("DNSServers", ''),
                "ppp_lcp_echo" => array("PPPLCPEcho", 0),
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", 0),
                "enableDns" => array("DNSOverrideAllowed", 1),
                "enableSlaac" => array("SLAAC", 1),
                "enableNat" => array("NATEnabled", 1),
                "serviceName" => array("PPPoEServiceName", ''),
                "enable" => array("Enable", 0),
                "exist" => "0",
                "valueChange" => 0,
                "numIndex" => 0,
                "interfaceType" => array("internet", "-1"),
//                "defconn" => array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.".$paramsFromModel[0]->num_index .".")
                "defconn" => array("DefaultConn","0")
            );
        }

        $wanType = 1;
        $diagnostic = $modParams->getPingResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($diagnostic)) {
            $failCount = $diagnostic[0]->received;
            $successCount = $diagnostic[0]->sent;
            $lost = 0;

            if ($failCount + $successCount != 0) {
                $lost = $failCount / ($failCount + $successCount) * 100;
            }
            $min = $diagnostic[0]->minimum;
            $max = $diagnostic[0]->maximum;
            $average = $diagnostic[0]->average;
        }
        $i = 0;
        $downloadResult = $modParams->getDownloadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($downloadResult)) {
            $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
            $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
            $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
            $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
            $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
            $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Download',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $uploadResult = $modParams->getUploadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($uploadResult)) {
            $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
            $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
            $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
            $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
            $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
            $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Upload',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $toDoForPPPOE = "changePPPIPv6Wan";
        $toAddConnect = 'false';
        include $_SESSION['APPPATH'] . 'views/content/admin/wanPPP_IPv6.php';
    } else if ($connType == "L2TP") {
        $uploadDownload = array();
        $paramsFromModel = $modParams->getWanPPOEParams($wanID, $serialN);
        if (!empty($paramsFromModel)) {
            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name" => array("Name", $paramsFromModel[0]->name), 
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)), 
                "username" => array("Username", trim($paramsFromModel[0]->username)), 
                "password" => array("Password", trim($paramsFromModel[0]->password)),
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", trim($paramsFromModel[0]->ppp_authentication_protocol)),
                "mru" => array("MaxMRUSize", trim($paramsFromModel[0]->max_mru_size)), 
                "ppp_lcp_echo" => array("PPPLCPEcho", trim($paramsFromModel[0]->ppplcp_echo)), 
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", trim($paramsFromModel[0]->ppplcp_echo_retry)),
                "enablePing" => array("X_DLINK_PingEnabled", trim($paramsFromModel[0]->ping_enabled)),
                "enableNat" => array("NATEnabled", trim($paramsFromModel[0]->nat_enabled)), 
                "serviceName" => array("PPPoEServiceName", trim($paramsFromModel[0]->service_name)), 
                "enable" => array("Enable", $paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)), 
                "exist" => "1",
                "valueChange" => $paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change,
                "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "trdefconn" => $paramsFromModel[0]->trdefconn,
                "DefaultGateway" => $paramsFromModel[0]->default_gateway,
                "ConnectionStatus" => $paramsFromModel[0]->conn_status,
                "Uptime" => $paramsFromModel[0]->uptime,
                "defconn" =>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection." . $paramsFromModel[0]->num_index ."."));
        } else {
            $params = array(
                "index" => array("index", 1),
                "name" => array("Name", ''), 
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address), 
                "username" => array("Username", ''),
                "password" => array("Password", ''), 
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'), 
                "mru" => array("MaxMRUSize", 0), 
                "ppp_lcp_echo" => array("PPPLCPEcho", 0), 
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", 0),
                "enablePing" => array("X_DLINK_PingEnabled", 1),
                "enableNat" => array("NATEnabled", 1),
                "serviceName" => array("PPPoEServiceName", ''), 
                "enable" => array("Enable", 0), 
                "exist" => "0",
                "valueChange" => 0, 
                "numIndex" => 0,
                "interfaceType" => array("internet", "-1"),
//                "defconn" => array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.".$paramsFromModel[0]->num_index .".")
                "defconn" => array("DefaultConn","0")
                );
        }

        $wanType = 1;
        $diagnostic = $modParams->getPingResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($diagnostic)) {
            $failCount = $diagnostic[0]->received;
            $successCount = $diagnostic[0]->sent;
            $lost = 0;

            if ($failCount + $successCount != 0) {
                $lost = $failCount / ($failCount + $successCount) * 100;
            }
            $min = $diagnostic[0]->minimum;
            $max = $diagnostic[0]->maximum;
            $average = $diagnostic[0]->average;
        }

        $i = 0;
        $uploadResult = $modParams->getUploadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($uploadResult)) {
            $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
            $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
            $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
            $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
            $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
            $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Upload',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $downloadResult = $modParams->getDownloadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($downloadResult)) {
            $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
            $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
            $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
            $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
            $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
            $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Download',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        $toDoForPPPOE = "changePPPWan";
        $toAddConnect = 'false';
        include $_SESSION['APPPATH'] . 'views/content/admin/wanL2TP.php';
        
    } else if ($connType == "PPTP") {
        $uploadDownload = array();
        $paramsFromModel = $modParams->getWanPPOEParams($wanID, $serialN);
        if (!empty($paramsFromModel)) {
            $params = array(
                "id" => array("id", $paramsFromModel[0]->id),
                "index" => array("index", $paramsFromModel[0]->num_index),
                "name" => array("Name", $paramsFromModel[0]->name), 
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : trim($paramsFromModel[0]->mac_address)), 
                "username" => array("Username", trim($paramsFromModel[0]->username)), 
                "password" => array("Password", trim($paramsFromModel[0]->password)),
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", trim($paramsFromModel[0]->ppp_authentication_protocol)),
                "mru" => array("MaxMRUSize", trim($paramsFromModel[0]->max_mru_size)), 
                "ppp_lcp_echo" => array("PPPLCPEcho", trim($paramsFromModel[0]->ppplcp_echo)), 
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", trim($paramsFromModel[0]->ppplcp_echo_retry)),
                "enablePing" => array("X_DLINK_PingEnabled", trim($paramsFromModel[0]->ping_enabled)),
                "enableNat" => array("NATEnabled", trim($paramsFromModel[0]->nat_enabled)), 
                "serviceName" => array("PPPoEServiceName", trim($paramsFromModel[0]->service_name)), 
                "enable" => array("Enable", $paramsFromModel[0]->enable == null ? 0 : trim($paramsFromModel[0]->enable)), 
                "exist" => "1",
                "valueChange" => $paramsFromModel[0]->value_change == null ? 0 : $paramsFromModel[0]->value_change,
                "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                "interfaceType" => array($paramsFromModel[0]->vlan_id == 0 ? '' : '.'.$paramsFromModel[0]->vlan_id, "-1"),
                "trdefconn" => $paramsFromModel[0]->trdefconn,
                "DefaultGateway" => $paramsFromModel[0]->default_gateway,
                "ConnectionStatus" => $paramsFromModel[0]->conn_status,
                "Uptime" => $paramsFromModel[0]->uptime,
                "defconn" =>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection." . $paramsFromModel[0]->num_index ."."));
        } else {
            $params = array("index" => array("index", 1),
                "name" => array("Name", ''), 
                "mac" => array("MACAddress", $_SESSION['site_type'] == 'armentel' ? $serialN : $getAllConnections[0]->mac_address), 
                "username" => array("Username", ''),
                "password" => array("Password", ''), 
                "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'), 
                "mru" => array("MaxMRUSize", 0), 
                "ppp_lcp_echo" => array("PPPLCPEcho", 0), 
                "ppp_lcp_retry" => array("PPPLCPEchoRetry", 0),
                "enablePing" => array("X_DLINK_PingEnabled", 1),
                "enableNat" => array("NATEnabled", 1),
                "serviceName" => array("PPPoEServiceName", ''), 
                "enable" => array("Enable", 0), 
                "exist" => "0",
                "valueChange" => 0, 
                "numIndex" => 0,
                "interfaceType" => array("internet", "-1"),
//                "defconn" => array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.".$paramsFromModel[0]->num_index .".")
                "defconn" => array("DefaultConn","0")
                );
        }
        $toDoForPPPOE = "changePPPWan";
        $toAddConnect = 'false';

        $wanType = 1;
        $diagnostic = $modParams->getPingResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($diagnostic)) {
            $failCount = $diagnostic[0]->received;
            $successCount = $diagnostic[0]->sent;
            $lost = 0;

            if ($failCount + $successCount != 0) {
                $lost = $failCount / ($failCount + $successCount) * 100;
            }
            $min = $diagnostic[0]->minimum;
            $max = $diagnostic[0]->maximum;
            $average = $diagnostic[0]->average;
        }

        $i = 0;
        $uploadResult = $modParams->getUploadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($uploadResult)) {
            $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
            $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
            $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
            $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
            $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
            $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Upload',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }


        $downloadResult = $modParams->getDownloadResultsForWan($devID, $params['index'][1], $wanType);
        if(!empty($downloadResult)) {
            $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
            $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
            $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
            $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
            $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
            $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
            $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;

            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            } else {
                $responseThroughput = '';
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            } else {
                $interfaceThroughput = '';
            }
            $uploadDownload[$i] = array(
                'type' => 'Download',
                'handshakeRound'=> $handshakeRound,
                'responseTime' => $responseTime,
                'requestRound' => $requestRound,
                'responseThroughput' => $responseThroughput,
                'interfaceThroughput' => $interfaceThroughput
            );
            $i++;
        }

        include $_SESSION['APPPATH'] . 'views/content/admin/wanPPTP.php';
    }
}

function getWanIpoeParams($serialN) {
    include $_SESSION['APPPATH'] . 'models/modelParams.php';
    $modParams = new ModelParams();
    $getIpoeConnections = $modParams->getAllWanIpoeParams($serialN);
    if(!empty($getIpoeConnections)) {
        echo true;
    } else {
        echo false;
    }
}

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        define('BASEPATH', $_SESSION['BASEPATH']);


        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
        }

        $serialN = $_POST['serialNumber'];
        if(isset($_POST['actionName'])) {
            $actionName = $_POST['actionName'];
        }
        if(isset($_POST['wanParamID'])) {
            $wanID = $_POST['wanParamID'];
        }
        if(isset($_POST['devStatus'])) {
            $deviceStatus = $_POST['devStatus'];
        }
        if(isset($_POST['havPermissions'])) {
            $havPerms = $_POST['havPermissions'];
        }
        if(isset($_POST['deviceID'])) {
            $devID = $_POST['deviceID'];
        }

//        $_SESSION['activeWanTab'] = $actionName;
        try{
            if(isset($actionName)) {
                getWanParams($wanID, $serialN, $actionName, $deviceStatus, $havPerms,$devID);
            } else {
                getWanIpoeParams($devID);
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }  
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
