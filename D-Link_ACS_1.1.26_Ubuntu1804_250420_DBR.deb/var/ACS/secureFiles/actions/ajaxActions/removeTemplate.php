<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
if (isset($_SESSION['logged_in'])) {
    try{
        $templateID = $_POST['templateId'];
        include $_SESSION['APPPATH'] . 'models/modelTemplates.php';
        $mTemplate = new ModelTemplates();

        if(isset($_POST['delete']) && $_POST['delete'] == 'template'){
            $isAttachedToDevice = $mTemplate->getDevicesHavingTemplateId($templateID);
            $isAttachedToUnRegisterDevice = $mTemplate->getUnRegisterDevicesHavingTemplateId($templateID);

//            if(!$isAttachedToDevice){
                if (is_array($templateID)) {
                    if($isAttachedToDevice) {
                        $delTemplate = $mTemplate->updateDeviceTemplatesGroupID($templateID);
                    }
                    if($isAttachedToUnRegisterDevice) {
                        $delTemplate = $mTemplate->updateUnRegisterDeviceTemplatesGroupID($templateID);
                    }
                    $tarif = $mTemplate->getGroupOfTemplatesByIds($templateID);
                    $result = $mTemplate->removeGroupOfTemplates($templateID);
                } else {
                    if($isAttachedToDevice) {
                        $delTemplate = $mTemplate->updateDeviceTemplateID($templateID);
                    }
                    if($isAttachedToUnRegisterDevice) {
                        $delTemplate = $mTemplate->updateUnRegisterDeviceTemplateID($templateID);
                    }
                    $tarif = $mTemplate->getTemplateById($templateID);
                    $result = $mTemplate->removeTemplate($templateID);
                }
                if (!$result) {
                    echo 'false';
                } else {
                    if (is_array($tarif)) {
                        foreach($tarif as $value) {
                            unlink ($value->path);
                        }
                    } else {
                        unlink ($tarif[0]->path);
                    }
                    echo 'true';
                }
//            }else{
//                echo 'false';
//            }
        }elseif (isset($_POST['delete']) && $_POST['delete'] == 'descriptor') {
            if (is_array($templateID)) {
                $descriptor = $mTemplate->getGroupOfDescriptorsByIds($templateID);
                $result = $mTemplate->removeGroupOfDescriptors($templateID);
            } else {
                $descriptor = $mTemplate->getDescriptorById($templateID);
                $result = $mTemplate->removeDescriptor($templateID);
            }
            if (!$result) {
                echo 'false';
            } else {
                if (is_array($descriptor)) {
                    foreach($descriptor as $value) {
                        unlink ($value->path);
                    }
                } else {
                    unlink ($descriptor[0]->path);
                }
                echo 'true';
            }    

        }elseif (isset($_POST['delete']) && $_POST['delete'] == 'defDescriptor') {

            $descriptor = $mTemplate->getDefDescriptorById($templateID);
            $result = $mTemplate->removeDefDescriptor($templateID);

            if (!$result) {
                echo 'false';
            } else {
                unlink ($descriptor[0]->path);
                echo 'true';
            }    
        }
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 
} else {
    $result = "logged_out";
    echo $result;
}
} else {
    exit('No direct script access allowed');
}
