<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    function strpos_all($haystack, $needle) {
        $offset = 0;
        $allpos = array();
        while (($pos = strpos($haystack, $needle, $offset)) !== FALSE) {
            $offset   = $pos + 1;
            $allpos[] = $pos;
        }
        return $allpos;
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'].'models/modelClient.php';
            include $_SESSION['APPPATH'].'util/pagingConstants.php';
            include $_SESSION['APPPATH'].'models/device.php';
            require_once $_SESSION['APPPATH'].'util/utils.php';
            require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';

            $templ = new ModelTemplates();
            $dev = new Device();
            $devCount = $_POST['devCount'];
            $modelID = $_POST['modelID'];
            $groupID = $_POST['groupID'];
            $fwVersion = $_POST['fwVersion'];

            $permissionsArray = array();
            if (isset($_SESSION['permissions'])) {
                require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
                $permissionsArray = $_SESSION['permissions'];
                if(isset($_SESSION['group_id'])) {
                    $groupID = $_SESSION['group_id'];
                }
            }

            $page = $_POST['page'];
            $limit = PagingConstants::$clientsCountForDevices;
            $offset = ($page - 1) * $limit;

            $client = new ModelClient();
            $clientInfo = $_POST["clientInfo"];

            $indexes = strpos_all($clientInfo, "%");
            $reversed = array_reverse($indexes);
            $arrayClientInfor = str_split($clientInfo,1);

            for($i=0; $i< count($reversed); $i++) {
                array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
            }
            $stringClientInfor = implode('',$arrayClientInfor);
            $clientInfo = $stringClientInfor;

            if (strpos($clientInfo,' ') === false){
                $clientFirstName = $clientInfo;
                $clientLastName = "";

            }else{
                $clientFirstNameAndLastName = explode(" ",$clientInfo);
                $clientFirstName = $clientFirstNameAndLastName[0];
                $clientLastName = $clientFirstNameAndLastName[1];
            }


            if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
                $allSearchedClientsCount = $client->getAllClientsCountByFirstNameAndLastName($clientFirstName,$clientLastName);
            } else {
                $allSearchedClientsCount = $client->getAllClientsCountByFirstNameAndLastName($clientFirstName,$clientLastName);
            }

            if($allSearchedClientsCount[0]->count>0) {

                if ($clientLastName != "" && $clientFirstName != ""){
                    if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
                        $clientsList = $client->searchClientsHavingDevicesByFirstNameAndLastName($clientFirstName,$clientLastName,$limit,$offset);
                        $allSearchedClientsCountWithDev = $client->getClientsCountByClientFirstNameHavingDevicesByGroup($groupID, $clientFirstName,$clientLastName);
                    } else {
                        $clientsList = $client->searchClientsHavingDevicesByFirstNameAndLastName($clientFirstName,$clientLastName,$limit,$offset);
                        $allSearchedClientsCountWithDev = $client->getClientsCountByClientInfoHavingDevices($clientFirstName,$clientLastName);
                    }
                } else{
                    if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
                        $clientsList = $client->searchClientsHavingDevicesByFirstNameOrLastName($clientFirstName,$limit,$offset);
                        $allSearchedClientsCountWithDev = $client->getClientsCountByClientFirstNameHavingDevicesByGroup($groupID,$clientFirstName,"");
                    } else {
                        $clientsList = $client->searchClientsHavingDevicesByFirstNameOrLastName($clientFirstName,$limit,$offset);
                        $allSearchedClientsCountWithDev = $client->getClientsCountByClientInfoHavingDevices($clientFirstName,"");
                    }
                }

                $clientsCount = $allSearchedClientsCountWithDev[0]->count;
                if ($clientsCount < $limit) {
                    $pagesCount = 1;
                } else {
                    if ($clientsCount % $limit == 0) {
                        $pagesCount = $clientsCount / $limit;
                    } else {
                        $pagesCount = ($clientsCount / $limit - ($clientsCount % $limit) * (1 / $limit)) + 1;
                    }
                }


                function searchDevicesByClientInfo($firstName, $surName, $address, $email, $devCount, $modelID,$groupID,$templ,$fwVersion,$clientsList,$dev){
//                    include $_SESSION['APPPATH'].'models/device.php';
                    $lang = $_SESSION['lang'];
                    if ($lang == 'en') {
                        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
                    } else {
                        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
                    }
                    $sortedVal = $_POST['sortedVal'];
                    $page = 1;
                    $limit = $devCount;
                    $offset = ($page - 1) * $devCount;
                    $devicesIds = array();
                    $devicesMACs = array();

                    if ($modelID == 0) {
                        if($groupID == 0){
                            $devices = $dev->searchDevicesByClientInfo($firstName, $surName, $address, $email, $devCount, $offset,$sortedVal);
                            $allDeviceCount = $dev->getAllDevicesCountByClientInfo($firstName, $surName, $address, $email);
                        } else {
                            $devices = $dev->searchDevicesByClientInfoGroup($groupID,$firstName, $surName, $address, $email, $devCount, $offset);
                            $allDeviceCount = $dev->getAllDevicesCountByClientInfoGroup($groupID,$firstName, $surName, $address, $email);
                        }
                    } else {
                        if($groupID == 0){
                            $devices = $dev->searchDevicesByClientInfoModelID($firstName, $surName, $address, $email, $modelID, $devCount, $offset,$fwVersion);
                            $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelID($firstName, $surName, $address, $email, $modelID,$fwVersion);
                        } else {
                            $devices = $dev->searchDevicesByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelID,$groupID, $devCount, $offset,$fwVersion);
                            $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelID,$groupID,$fwVersion);
                        }
                    }
                    $groups = $dev->getAllGroups();
                    foreach ($devices as $device){
                        array_push($devicesIds, $device->id);
                        array_push($devicesMACs, $device->mac);
                    }

                    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);

                    $allDevCount = $allDeviceCount[0]->count;
                    if ($allDevCount < $devCount) {
                        $pagesCount = 0;
                    } else {

                        if ($allDevCount % $devCount == 0) {
                            $pagesCount = $allDevCount / $devCount;
                        } else {
                            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
                        }
                    }

                    $templ = new ModelTemplates();
                    $allTemplates = $templ->getAllTemplates();
                    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
                    $userSettings = json_decode($_COOKIE[$cookie_name]);
                    if(property_exists($userSettings, 'devicesTableColumns')){
                        $devicesTableColumns = $userSettings->devicesTableColumns;
                    }
                    if(count($devices)<$devCount) {
                        $data = 2;
                    } else {
                        $data = 3;
                    }

                    require_once $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
                    return true;
                }

                for($i=0; $i< count($clientsList); $i++) {
                    searchDevicesByClientInfo($clientsList[$i]->first_name,$clientsList[$i]->sur_name,$clientsList[$i]->address,$clientsList[$i]->email,$devCount, $modelID,$groupID,$templ,$fwVersion,$clientsList,$dev);
                }


//                include $_SESSION['APPPATH'].'views/content/admin/subClients.php';
            } else {
                $lang = $_SESSION['lang'];
                if ($lang == 'en') {
                    $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
                } else {
                    $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
                }
                echo $ini_array['no_searched_client'];
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = 'logged_out';
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}