<?php
function deviceConfigsByModel($modelID,$dev){
    
    $configs = $dev->getDeviceConfigsByModel($modelID);
    $deviceIDList = $dev->getDevicesIdByModel($modelID);
    unset($_SESSION['groupDevicesList']);
    $_SESSION['groupDevicesList'] = $deviceIDList;
    include  $_SESSION['APPPATH'].'views/content/admin/update_config_group.php';
}
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            require_once $_SESSION['APPPATH'].'models/device.php';
            $dev = new Device();

            $modelID = $_POST['modelID'];
            deviceConfigsByModel($modelID,$dev);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }     
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}