<?php
if(isset($_POST['fromApp'])){
    if (session_id() == ''){session_start();}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    $lang = $_SESSION['lang'];
    
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    
    function write_ini_file($assoc_arr, $path, $has_sections=FALSE) {
        $content = "";
        $key1 = '';
//    $ppoeCount=0;

        if ($has_sections) {
            foreach ($assoc_arr as $key=>$elem) {
                $key1 = strpos($key,'PPP');
                if($key1 !== false){
                    $key = 'PPP';
                }

                $key1 = strpos($key,'WI-FI');
                if($key1 !== false){
                    $key = 'WI-FI';
                }
                
                $key1 = strpos($key,'L2TP');
                if($key1 !== false){
                    $key = 'L2TP';
                } 
                
                $content .= "[".$key."]\n";
                
                foreach ($elem as $key2=>$elem2) {
                    if(is_array($elem2))
                    {
                        for($i=0;$i<count($elem2);$i++)
                        {
                            $content .= $key2."[] = \"".$elem2[$i]."\"\n";
                        }
                    }
                    else if($elem2=="") $content .= $key2." = \n";
                    else $content .= $key2." = ".$elem2."\n";
                }
            }

//        if($ppoeCount==1){
//            $content=str_replace("PPPOE1","PPPOE",$content);
//        }
        }  else {
            foreach ($assoc_arr as $key=>$elem) {
                if(is_array($elem))
                {
                    for($i=0;$i<count($elem);$i++)
                    {
                        $content .= $key."[] = \"".$elem[$i]."\"\n";
                    }
                }
                else if($elem=="") $content .= $key." = \n";
                else $content .= $key." = \"".$elem."\"\n";
            }
        }

        if (!$handle = fopen($path, 'w+')) {
            return false;
        }
        if (!fwrite($handle, $content)) {
            return false;
        }
        fclose($handle);
        return true;
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'].'models/fwConfigFile.php';

            include $_SESSION['APPPATH'] . 'models/modelTemplates.php';
            $modelTempl = new ModelTemplates();
            $configFile = new FwConfigFile();
            $id=$_POST['tarifID'];
            $configs = $_POST['configs'];
            $tarifName = $_POST['tarifName'];
            $tarifDesc = $_POST['description'];
            $DIRECTORY_SEPARATOR = "/";
            $foldername = $_SESSION['REALPATH'] . '/tarif';
            if(!is_dir($foldername)){mkdir($foldername, 0777, true);}

            $oldPath = '';
            $templ = $modelTempl->getTemplateById($id);
            $oldPath = $templ[0]->path;

            if($tarifName != 'null'){
                $fileName = $foldername.$DIRECTORY_SEPARATOR .$tarifName.'.ini'; 
            }else {
                $fileName = $oldPath;
            }

            $nArray = array();
            $ppCount = 0;
            $l2tpCount = 0;
            $wifiCount = 0;

            foreach($configs as $config){
                $arr = array();
                if($config['conType'] == 'lan' /*|| $config['conType'] == 'wifi'*/ ){
                    $paramNames = $config['conObj']['names'];
                    $paramValues = $config['conObj']['values'];
                    for($i = 0; $i < count($paramNames); $i++){
                        $arr[$paramNames[$i]] = $paramValues[$i];
                    }
                } else if($config['conType'] == 'wan'){
                    $wanArr = $config['conObj'];
                    for($ij = 0; $ij < count($wanArr); $ij++){
                        $paramNames = $wanArr[$ij]['names'];
                        $paramValues = $wanArr[$ij]['values'];
                        for($i = 0; $i < count($paramNames); $i++){
                            $arr[$paramNames[$i]] = $paramValues[$i];
                        }
                        if(isset($wanArr) && $wanArr[$ij]['conT'] == 'ppp'){
                            $ppCount++;
                            $nArray['PPP'.$ppCount]=$arr;
                            $arr = array();

                        }elseif($wanArr[$ij]['conT'] == 'l2tp'){
                            $l2tpCount++;
                            $nArray['L2TP'.$l2tpCount] = $arr;
                            $arr = array();

                        }elseif($wanArr[$ij]['conT'] == 'dynamic'){
                            $nArray['DYNAMIC-IP'] = $arr;
                            $arr = array();
                        }
                        elseif($wanArr[$ij]['conT'] == 'static'){
                            $nArray['STATIC-IP'] = $arr;
                            $arr = array();
                        }
                    }
                } else if($config['conType'] == 'wifi') {
                    $wifiArr = $config['conObj'];
                    for($ij = 0; $ij < count($wifiArr); $ij++) {
                        $paramNames = $wifiArr[$ij]['names'];
                        $paramValues = $wifiArr[$ij]['values'];
                        for($i = 0; $i < count($paramNames); $i++){
                            $arr[$paramNames[$i]] = $paramValues[$i];
                        }
                        $wifiCount++;
                        $nArray['WI-FI'.$wifiCount] = $arr;
                        $arr = array();
                    }
                }

                if($config['conType'] == 'lan'){
                    $nArray['LAN'] = $arr;
                } /*else if($config['conType'] == 'wifi'){
                    $nArray['WI-FI'] = $arr;
                }*/
            }

            $res = '';

            if(write_ini_file($nArray,$fileName,true)){
                if($tarifName == 'null' && $tarifDesc == 'null'){
                    $res = true;
                } else {
                    $res = $modelTempl->updateTarifById( $id,$tarifName,$fileName,$tarifDesc);
                    if($tarifName != 'null'){
                        unlink($oldPath);
                    }
                }
    //            $countTarif=$configFile->getTarifCountByPath(trim($fileName));
    //            if($countTarif[0]->count>0){
    //                $res = $configFile->updateTarifById( $fileName,$tarifDesc);
    //            } else {
    //                $res = $configFile->addTarif( $fileName, $tarifName,$tarifDesc);
    //            }

                if($res){
                    echo $ini_array['connect_succeed'];
                } else {
                    echo $ini_array['connect_failed'];
                }
            } else {
                echo $ini_array['connect_failed'];
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}