<?php
if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }
            include $_SESSION['APPPATH'].'models/device.php';
            $gName = trim($_POST['groupName']);
            $dev = new Device();
            $existsCount = $dev->checkGroupExists($gName);
            if ($existsCount[0]->count != 0) {
                echo $ini_array['gName_exist'];
            } else {
                echo '';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
