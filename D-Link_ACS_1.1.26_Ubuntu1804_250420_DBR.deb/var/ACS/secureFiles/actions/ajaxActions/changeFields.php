<?php

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    if (isset($_SESSION['logged_in'])) {
        try{
            $cookie = $_POST['cooki_array'];
            $n = $cookie[0];
            $sN = $cookie[1];
            $mF = $cookie[2];
            $port = $cookie[3];
            $ip = $cookie[4];
            $mN = $cookie[5];
            $mac = $cookie[6];
	    $clientName = $cookie[7];
	    $devId = $cookie[8];
            $fields = array('n' => $n, 'sN' => $sN, 'mF' => $mF, 'port' => $port, 'ip' => $ip, 'mN' => $mN,'mac' => $mac,'clientName'=>$clientName, 'dI' => $devId);
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->devicesTableColumns = $fields;
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
       exit('No direct script access allowed');
}



