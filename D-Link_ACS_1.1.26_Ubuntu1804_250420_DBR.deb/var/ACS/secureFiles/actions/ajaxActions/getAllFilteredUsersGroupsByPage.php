<?php
function getAllFilteredUsersGroupsByPage($page)
{
    include $_SESSION['APPPATH'].'models/modelUser.php';
    include $_SESSION['APPPATH'].'util/pagingConstants.php';

    $limit = PagingConstants::$activityCount;
    $offset = ($page - 1) * $limit;

    $user = new ModelUser();
    $adminGroupCount = $user->getAdminGroupsCount()[0]->count;
    $usersGroups = $user->getAllUsersGroupsByPage($limit, $offset);

    for($i=0;$i<count($usersGroups);$i++){
        $permissionsList=$user->getPermissionsByGroupId($usersGroups[$i]->id);
        if(!$permissionsList){
            $permissionsList=array();
        }
        $usersGroups[$i] = (object) array_merge((array)$usersGroups[$i], array( 'permissionsList' => $permissionsList));

    }

    $allUsersGroupsCount = $user->getAllUsersGroupsCount();
    $usersGroupsCount = $allUsersGroupsCount[0]->count;

    if ($usersGroupsCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($usersGroupsCount % $limit == 0) {
            $pagesCount = $usersGroupsCount / $limit;
        } else {
            $pagesCount = ($usersGroupsCount / $limit - ($usersGroupsCount % $limit) * (1 / $limit)) + 1;
        }
    }
    include $_SESSION['APPPATH'].'views/content/admin/filteredUsersGroups.php';
    return true;
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    if (isset($_SESSION['logged_in'])) {
        try{
            $page = $_POST['page'];
            define('BASEPATH', $_SESSION['BASEPATH']);
            getAllFilteredUsersGroupsByPage($page);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}