<?php

if(isset($_POST['fromApp'])){
    if (session_id() == ''){ session_start(); }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            require_once $_SESSION['APPPATH'].'models/modelParams.php';
            $modParams = new ModelParams();
            $deviceID = $_POST['deviceID'];
            $connVlanId = $_POST['connVlanId'];

            $connByVlanId = $modParams->checkConnectionByVlanId($deviceID, $connVlanId);
            if($connByVlanId && !empty($connByVlanId)){
                echo $connByVlanId[0]->name;
            } else {
                echo '';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $status = "logged_out";
        echo $status;
    }
} else {
    exit('No direct script access allowed');
}

