<?php
$generatedPass = '';
$m_w=10;
$m_z=20;

function get_random() {
    global $m_w;
    global $m_z;
    srand(mktime());
    $m_z = (rand() % 36969) * ($m_z & 65535) + ($m_z >> 16);

    $m_w = (rand() % 18000) * ($m_w & 65535) + ($m_w >> 16);

    return ($m_z << 16) + $m_w;
}

function gen_onlime_pass($iBuf, $lengthGen) {
    $counter = 0;
    $randNum = 0;

    $arrayGen = array("2", "3", "4", "5", "6", "7", "8", "9", "a",
        "b", "c", "d", "e", "f", "h", "i", "j", "k",
        "m", "n", "o", "p", "q", "r", "s", "t", "u",
        "v", "w", "x", "y", "z", "A", "B", "C", "D",
        "E", "F", "G", "H", "J", "K", "L", "M", "N",
        "P", "Q", "R", "S", "T", "U", "V", "W", "X",
        "Y", "Z"
    );

    for ($counter = 0; $counter < $lengthGen; $counter++) {
        $num = get_random();
        $randNum = $num % sizeof($arrayGen);
        $iBuf[$counter] = $arrayGen[$randNum];
    }

    return $iBuf;
}

function create_pass($str, $str2, $num) {
    $mac = $str;

    if($str2=="username") {
        $mac = substr($mac, -$num);
        $mac = str_shuffle($mac);
    } else {
        $mac = substr($mac, -$num);
    }
    $mac.=$str2;
//echo ($mac)."<br>";
    return gen_onlime_pass($mac, strlen($mac));
}

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
    
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            if (isset($_POST['mac']) && isset($_POST['action']) && $_POST['action'] == 'genPassword') {
                $mac = $_POST['mac'];
                $generatedPass = create_pass($mac, "password", 4);
                //$_SESSION['genPass']= $generatedPass;
                echo $generatedPass ;
            } 

            if(isset($_POST['mac']) && isset($_POST['action']) && $_POST['action'] == 'genUsername'){
                require_once  $_SESSION['APPPATH'].'models/device.php';
                $mac = $_POST['mac'];
                $dev = new Device();
                $device =  devInfoByMAC($mac, $dev);
                $rss =   $device[0]->first_name. " " . $device[0]->sur_name;    
                echo $rss;
            }

            if(isset($_POST['mac']) && isset($_POST['action']) && $_POST['action'] == 'genPPPUserName'){
                $mac = $_POST['mac'];
                $userName = create_pass($mac, "usernamepppconnection", 4);
                echo $userName;
            }

            if(isset($_POST['clientId']) && isset($_POST['action']) && $_POST['action'] == 'genUsernameUnknown'){
                require_once  $_SESSION['APPPATH'].'models/modelClient.php';
                $clientId = $_POST['clientId'];
                $client = new ModelClient();
                $clientInfoUnk =  $client->getClientById($clientId);
                $rss =   $clientInfoUnk[0]->first_name. " " . $clientInfoUnk[0]->sur_name;    
                echo $rss;
            }
        }catch (\Exception $e){
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        echo "logged_out";
    }
    
} else {
    exit('No direct script access allowed');
}

function devInfoByMAC($mac,$dev) {
    $info = $dev->devInfoByMAC($mac);
    return $info;
}
?>

