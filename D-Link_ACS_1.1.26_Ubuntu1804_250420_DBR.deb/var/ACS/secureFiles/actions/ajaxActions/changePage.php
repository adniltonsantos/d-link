<?php

function cidrToRange($cidr) {
    $range = array();
    $pos = strpos($cidr, "/");
    if($pos) {
        $count = substr_count($cidr, '/');
        if($count > 1) {
            return false;
        } else {
            $cidr = explode('/', $cidr);
            if($cidr[1] > 32) {
                return false;
            }
            $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
            $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
            return $range;
        }
    } else {
        return $pos;
    }
}

function devicesByPageClientInfo($page, $devCount, $modelId,$groupId,$fwVersion, $firstName, $surName, $address, $email,$dev,$templ,$sortedVal,$clientId){
    require_once $_SESSION['APPPATH'].'models/device.php';
    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupName = $_SESSION['group_id'];
        }
    }
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $offset = ($page - 1) * $devCount;
    $limit = $devCount;
    $devicesIds = array();
    $devicesMACs = array();

    if($groupName == 'Group manager' || $groupName == 'Group Viewer') {
        $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//        echo count($groupList)." ";
        $countGroups=count($groupList);
        if ($modelId == 0) {
            if($groupId == 0){
                if ($firstName != '' && $surName != '') {
                    $devices = $dev->searchDevicesByClientInfoByGroups($groupList, $countGroups, $firstName, $surName, $address, $email, $limit, $offset,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByClientInfo($firstName, $surName, $address, $email);
                    $allDevCount = $allDeviceCount[0]->count;
                } else {
                    $devices = $dev->getDevicesByGroups($groupList, $countGroups,$limit,$offset,$sortedVal);
                    $allDevCount = $dev->getAllDevicesCountByGroups($groupList, $countGroups);
//                    $allDevCount = $allDeviceCount[0]->count;
//                    if ($allDevCount > $limit) {
//                        for($i=0; $i<$limit; $i++) {
//                            if($i+$offset==$allDevCount){
//                                break;
//                            }
//                            $devices[$i] = $devices1[$i+$offset];
//                        }
//                    }
                }
            } else {
                if ($firstName != '' && $surName != '') {
                    $devices = $dev->searchDevicesByClientInfoGroup($groupId,$firstName, $surName, $address, $email, $limit, $offset,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByClientInfoGroup($groupId,$firstName, $surName, $address, $email);
                    $allDevCount = $allDeviceCount[0]->count;
                } else {
                    $devices = $dev->getDevicesByGroup($groupId,$limit, $offset,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByGroup($groupId);
                    $allDevCount = $allDeviceCount[0]->count;
                }
            }
        } else {
            if($groupId == 0){
                if ($firstName != '' && $surName != '') {
                    $devices = $dev->searchDevicesByClientInfoModelID($firstName, $surName, $address, $email, $modelId,$limit, $offset, $fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelID($firstName, $surName, $address, $email, $modelId,$fwVersion);
                    $allDevCount = $allDeviceCount[0]->count;
                } else {
                    $devices = $dev->getDevicesByModel($modelId, $limit, $offset,$fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByModel($modelId,$fwVersion);
                    $allDevCount = $allDeviceCount[0]->count;
                }
            } else {

                //need to add soretd Val
                if ($firstName != '' && $surName != '') {
                    $devices = $dev->searchDevicesByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelId, $groupId, $limit, $offset,$fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelId,$groupId,$fwVersion);
                    $allDevCount = $allDeviceCount[0]->count;
                } else {
                    $devices = $dev->getDevicesByModelGroup($modelId,$groupId, $limit, $offset,$fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByModelGroup($modelId,$groupId,$fwVersion);
                    $allDevCount = $allDeviceCount[0]->count;
                }
            }
        }
        $groups = $groupList;
    } else {
        if ($modelId == 0) {
            if($groupId == 0){
                if ($firstName != '' && $surName != '') {

                    $devices = $dev->searchDevicesByClientInfo($firstName, $surName, $address, $email, $limit, $offset,$sortedVal);

                    $allDeviceCount = $dev->getAllDevicesCountByClientInfo($firstName, $surName, $address, $email);
                } else {
                    if($clientId!=0){
                        $devices = $dev->searchDevicesByClientId($clientId, $limit, $offset,$sortedVal);
                        $allDeviceCount = $dev->getAllActiveDevicesByClientId($clientId);
                    }else {
                        $devices = $dev->getDevices($limit, $offset, $sortedVal);
                        $allDeviceCount = $dev->getAllDevicesCount();
                    }
                }
            } else {
                if ($firstName != '' && $surName != '') {
                    $devices = $dev->searchDevicesByClientInfoGroup($groupId,$firstName, $surName, $address, $email, $limit, $offset,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByClientInfoGroup($groupId,$firstName, $surName, $address, $email);
                } else {
                    $devices = $dev->getDevicesByGroup($groupId,$limit, $offset,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByGroup($groupId);
                }
            }
        } else {
            if($groupId == 0){
                if ($firstName != '' && $surName != '') {
                    $devices = $dev->searchDevicesByClientInfoModelID($firstName, $surName, $address, $email, $modelId,$limit, $offset, $fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelID($firstName, $surName, $address, $email, $modelId,$fwVersion);
                } else {
                    $devices = $dev->getDevicesByModel($modelId, $limit, $offset,$fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByModel($modelId,$fwVersion);
                }
            } else {
                if ($firstName != '' && $surName != '') {
                    $devices = $dev->searchDevicesByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelId, $groupId, $limit, $offset,$fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelId,$groupId,$fwVersion);
                } else {
                    $devices = $dev->getDevicesByModelGroup($modelId,$groupId, $limit, $offset,$fwVersion,$sortedVal);
                    $allDeviceCount = $dev->getAllDevicesCountByModelGroup($modelId,$groupId,$fwVersion);
                }
            }
        }
        $allDevCount = $allDeviceCount[0]->count;
        $groups = $dev->getAllGroups();
    }
    
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    

    if ($allDevCount < $devCount || $devCount == 0) {
        $pagesCount = 1;
    } else {

        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }
    $allTemplates = $templ->getAllTemplates();



    if(empty($devices)) {
        $data = 1;
        echo $data;
        return false;
    } else {

        if ($sortedVal != '') {
            $sortedValVar = trim(explode(":", $sortedVal)[0]);
            $sortBy = trim(explode(":", $sortedVal)[1]);
        } else {
            $sortedValVar = "last_inform_time";
            $sortBy = "DESC";
        }
        if ($sortedValVar == 'ip') {
            $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
            if(empty($devices)) {
                $data = 1;
                echo $data;
                return false;
            } else {
                if(count($devices)<$devCount) {
                    $data = 2;
                } else {
                    $data = 3;
                }
                include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
                return true;
            }
        } else {
            if(count($devices)<$devCount) {
                $data = 2;
            } else {
                $data = 3;
            }
            include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
            return true;
        }
    }

}

function devicesByPageIp($page, $devCount, $modelID,$groupID, $fwVersion,$ip,$dev,$templ,$sortedVal)
{
    require_once $_SESSION['APPPATH'].'models/device.php';
    $lang = $_SESSION['lang'];

    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupName = $_SESSION['group_id'];
        }
    }

    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();
    if($ip != '') {
        $ipMask = cidrToRange($ip);
        if($ipMask) {
            $ipMaskStart = $ipMask[0];
            $ipMaskEnd = $ipMask[1];
        } else {
            $ipMaskStart = 0;
            $ipMaskEnd = 0;
        }
    } else {
        $ipMaskStart = 0;
        $ipMaskEnd = 0;
    }
//    echo $groupName." ".$modelID." ".$groupID;
    if($groupName == 'Group manager' || $groupName == 'Group Viewer') {
        $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
        $countGroups = count($groupList);
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByIpByGroups($groupList, $countGroups, $ip, $devCount, $offset,$sortedVal);
                $allDevCount = $dev->getAllDevicesCountByIpByGroup($groupList, $countGroups,$ip);
//                if ($allDevCount > $limit) {
//                    for($i=0; $i<$limit; $i++) {
//                        if($i+$offset==$allDevCount){
//                            break;
//                        }
//                        $devices[$i] = $devices1[$i+$offset];
//                    }
//                }
//                $allDeviceCount = $dev->getAllDevicesCountByIpByGroups($ip);

            } else {
                $devices = $dev->searchDevicesByIpGroup($groupID, $ip, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByIpGroup($groupID, $ip);
                $allDevCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByIpModelID($ip, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByIpModelID($ip, $modelID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesByIpModelIDGroupID($ip, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByIpModelIDGroupID($ip, $modelID, $groupID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $groupList;
    } else {
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByIp($ip, $devCount, $offset,$sortedVal, $ipMaskStart, $ipMaskEnd);
                $allDeviceCount = $dev->getAllDevicesCountByIp($ip, $ipMaskStart, $ipMaskEnd);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesByIpGroup($groupID, $ip, $devCount, $offset, $sortedVal, $ipMaskStart, $ipMaskEnd);
                $allDeviceCount = $dev->getAllDevicesCountByIpGroup($groupID, $ip, $ipMaskStart, $ipMaskEnd);
                $allDevCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByIpModelID($ip, $modelID, $devCount, $offset, $fwVersion,$sortedVal, $ipMaskStart, $ipMaskEnd);
                $allDeviceCount = $dev->getAllDevicesCountByIpModelID($ip, $modelID, $fwVersion, $ipMaskStart, $ipMaskEnd);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesByIpModelIDGroupID($ip, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal, $ipMaskStart, $ipMaskEnd);
                $allDeviceCount = $dev->getAllDevicesCountByIpModelIDGroupID($ip, $modelID, $groupID, $fwVersion, $ipMaskStart, $ipMaskEnd);
                $allDevCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $dev->getAllGroups();
    }
    
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    

    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {

        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }
    $allTemplates = $templ->getAllTemplates();
    if(empty($devices)) {
        $data = 1;
        echo $data;
        return false;
    } else {

        //added  custom sort by ip
//        echo count($devices)."  ".$offset." ".$limit." ".$sortedVal;
        if ($sortedVal != '') {
            $sortedValVar = trim(explode(":", $sortedVal)[0]);
            $sortBy = trim(explode(":", $sortedVal)[1]);
        } else {
            $sortedValVar = "last_inform_time";
            $sortBy = "DESC";
        }
        //  include $_SESSION['APPPATH'] . 'util/utils.php';
        if ($sortedValVar == 'ip') {
            $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
            if(empty($devices)) {
                $data = 1;
                echo $data;
                return false;
            } else {
                if(count($devices)<$devCount) {
                    $data = 2;
                } else {
                    $data = 3;
                }
                include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
                return true;
            }
        } else {
        if(count($devices)<$devCount) {
            $data = 2;
        } else {
            $data = 3;
        }
        include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
        return true;
        }
    }

}

function devicesByPageMac($page, $devCount, $modelID,$groupID,$fwVersion,$mac,$dev,$templ,$sortedVal)
{
    require_once $_SESSION['APPPATH'].'models/device.php';
    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupName = $_SESSION['group_id'];
        }
    }

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();

    if($groupName == 'Group manager' || $groupName == 'Group Viewer') {
        $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
//        var_dump($groupList);
        $countGroups = count($groupList);
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMacByGroups($groupList, $countGroups, $mac,$devCount, $offset,$sortedVal);
                $allDevCount = $dev->getAllDevicesCountByMacByGroups($groupList, $countGroups, $mac);
//                var_dump($allDeviceCount);

//                if ($allDeviceCount > $limit) {
//                    for($i=0; $i<$limit; $i++) {
//
//                        if($i+$offset>=$allDeviceCount){
//                            var_dump(($i+$offset));
//                            break;
//                        }
//                        $devices[$i] = $devices1[$i+$offset];
//                    }
//                }

//                $allDevCount=$allDeviceCount[0]->count;
//                var_dump($allDevCount);
            } else {
                $devices = $dev->searchDevicesByMacGroup($groupID, $mac, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacGroup($groupID, $mac);
                $allDevCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMacModelID($mac, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelID($mac, $modelID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
//            $devices = $dev->searchDevicesByIpModelIDGroupID($mac, $modelID,$groupID, $devCount, $offset, $fwVersion);
                $devices = $dev->searchDevicesByMacModelIDGroupID($mac, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelIDGroupID($mac, $modelID, $groupID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $groupList;
//        $allDevCount = $allDeviceCount[0]->count;
    } else {
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMac($mac, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMac($mac);
            } else {
                $devices = $dev->searchDevicesByMacGroup($groupID, $mac, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacGroup($groupID, $mac);
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMacModelID($mac, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelID($mac, $modelID, $fwVersion);
            } else {
//            $devices = $dev->searchDevicesByIpModelIDGroupID($mac, $modelID,$groupID, $devCount, $offset, $fwVersion);
                $devices = $dev->searchDevicesByMacModelIDGroupID($mac, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelIDGroupID($mac, $modelID, $groupID, $fwVersion);
            }
        }
        $allDevCount = $allDeviceCount[0]->count;
        $groups = $dev->getAllGroups();
    }
    
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    
//    $allDevCount = $allDeviceCount[0]->count;
    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {
        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }
    $allTemplates = $templ->getAllTemplates();
    if(empty($devices)) {
        $data = 1;
        echo $data;
        return false;
    } else {

        //added  custom sort by ip
//        echo count($devices)."  ".$offset." ".$limit." ".$sortedVal;
        if ($sortedVal != '') {
            $sortedValVar = trim(explode(":", $sortedVal)[0]);
            $sortBy = trim(explode(":", $sortedVal)[1]);
        } else {
            $sortedValVar = "last_inform_time";
            $sortBy = "DESC";
        }
        //  include $_SESSION['APPPATH'] . 'util/utils.php';
        if ($sortedValVar == 'ip') {
            $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
            if(empty($devices)) {
                $data = 1;
                echo $data;
                return false;
            } else {
                if(count($devices)<$devCount) {
                    $data = 2;
                } else {
                    $data = 3;
                }
                include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
                return true;
            }
        } else {
            if(count($devices)<$devCount) {
                $data = 2;
            } else {
                $data = 3;
            }
            include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
            return true;
        }
    }
}

function devicesByPageSerial($page, $devCount, $modelID,$groupID,$fwVersion,$serial,$dev,$templ,$sortedVal)
{
    require_once $_SESSION['APPPATH'].'models/device.php';
    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupName = $_SESSION['group_id'];
        }
    }

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();
    if($groupName == 'Group manager' || $groupName == 'Group Viewer') {
        $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
        $countGroups = count($groupList);
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesBySerialByGroups($groupList, $countGroups, $serial,$limit,$offset,$sortedVal);

                $allDevCount= $dev->getAllDevicesCountBySerialByGroups($groupList, $countGroups, $serial);
//                if ($allDevCount > $limit) {
//                    for($i=0; $i<$limit; $i++) {
//                        if($i+$offset==$allDevCount){
//                            break;
//                        }
//                        $devices[$i] = $devices1[$i+$offset];
//                    }
//                }
            } else {
                $devices = $dev->searchDevicesBySerialGroup($groupID, $serial, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountBySerialGroup($groupID, $serial);
                $allDevCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesBySerialModelID($serial, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountBySerialModelID($serial, $modelID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesBySerialModelIDGroupID($serial, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountBySerialModelIDGroupID($serial, $modelID, $groupID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $groupList;
    } else {
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesBySerial($serial, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountBySerial($serial);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesBySerialGroup($groupID, $serial, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountBySerialGroup($groupID, $serial);
                $allDevCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesBySerialModelID($serial, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountBySerialModelID($serial, $modelID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesBySerialModelIDGroupID($serial, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountBySerialModelIDGroupID($serial, $modelID, $groupID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $dev->getAllGroups();
    }
    
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    

    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {

        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }
    $allTemplates = $templ->getAllTemplates();
    if(empty($devices)) {
        $data = 1;
        echo $data;
        return false;
    } else {
        //added  custom sort by ip
//        echo count($devices)."  ".$offset." ".$limit." ".$sortedVal;
        if ($sortedVal != '') {
            $sortedValVar = trim(explode(":", $sortedVal)[0]);
            $sortBy = trim(explode(":", $sortedVal)[1]);
        } else {
            $sortedValVar = "last_inform_time";
            $sortBy = "DESC";
        }
        //  include $_SESSION['APPPATH'] . 'util/utils.php';
        if ($sortedValVar == 'ip') {
            $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
            if(empty($devices)) {
                $data = 1;
                echo $data;
                return false;
            } else {
                if(count($devices)<$devCount) {
                    $data = 2;
                } else {
                    $data = 3;
                }
                include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
                return true;
            }
        } else {
            if(count($devices)<$devCount) {
                $data = 2;
            } else {
                $data = 3;
            }
            include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
            return true;
        }
    }
}

function searchDevicesByUsername($page, $username, $devCount, $modelID, $fwVersion, $dev, $groupID,$templ,$sortedVal) {
    require_once $_SESSION['APPPATH'].'models/device.php';
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();

    if ($modelID == 0) {
        if($groupID == 0){
            if($username != ''){
                $devices = $dev->searchDevicesByUsername($username, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByUsername($username);
            }  else {
                $devices = $dev->getDevices($limit, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCount();
            }
        } else {
            if($username != ''){
                $devices = $dev->searchDevicesByUsernameGroup($groupID,$username, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByUsernameGroup($groupID,$username);
            }else {
                $devices = $dev->getDevicesByGroup($groupID,$limit, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByGroup($groupID);
            }
        }
    } else {
        if($groupID == 0){
            if($username != ''){
                $devices = $dev->searchDevicesByUsernameModelID($username, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByUsernameModelID($username, $modelID ,$fwVersion);
            }  else {
                $devices = $dev->getDevicesByModel($modelID, $limit, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByModel($modelID, $fwVersion);
            }
        } else {
            if($username != ''){
                $devices = $dev->searchDevicesByUsernameModelIDGroupID($username, $modelID,$groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByUsernameModelIDGroupID($username, $modelID,$groupID, $fwVersion);
            }  else {
                $devices = $dev->getDevicesByModelGroup($modelID,$groupID, $limit, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByModelGroup($modelID,$groupID, $fwVersion);
            }
        }
    }
    $groups = $dev->getAllGroups();
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    
    $allDevCount = $allDeviceCount[0]->count;
    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {
        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }
    
    $allTemplates = $templ->getAllTemplates();
    if(empty($devices)) {
        $data = 1;
        echo $data;
        return false;
    } else {

        //added  custom sort by ip
//        echo count($devices)."  ".$offset." ".$limit." ".$sortedVal;
        if ($sortedVal != '') {
            $sortedValVar = trim(explode(":", $sortedVal)[0]);
            $sortBy = trim(explode(":", $sortedVal)[1]);
        } else {
            $sortedValVar = "last_inform_time";
            $sortBy = "DESC";
        }
        //  include $_SESSION['APPPATH'] . 'util/utils.php';
        if ($sortedValVar == 'ip') {
            $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
            if(empty($devices)) {
                $data = 1;
                echo $data;
                return false;
            } else {
                if(count($devices)<$devCount) {
                    $data = 2;
                } else {
                    $data = 3;
                }
                include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
                return true;
            }
        } else {
            if(count($devices)<$devCount) {
                $data = 2;
            } else {
                $data = 3;
            }
            include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
            return true;
        }
    }
}

if(isset($_POST['fromApp'])){


    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            require_once $_SESSION['APPPATH'].'models/device.php';
            require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
            require_once $_SESSION['APPPATH'].'util/utils.php';

            $devCount = intval($_POST['devCount']);
            $modelID = $_POST['modelID'];
            $groupId = $_POST['groupId'];
            $fwVersion = $_POST['fwVersion'];

            if (!isset($_POST['sortedVal'])){
                $sortedVal = '';
            } else {
                $sortedVal = $_POST['sortedVal'];
            }

            if(isset($_POST['page'])) {
                $page = $_POST['page'];
            } else {
                $count = $_POST['count'];
                $page = $count/$devCount+1;
            }
            $dev = new Device();
            $templ = new ModelTemplates();
            if(isset($_POST['firstName']) && isset($_POST['surName'])){
                $firstName = $_POST['firstName'];
                $surName = $_POST['surName'];
                $address = $_POST['address'];
                $email = $_POST['email'];
                $clientId=$_POST['clientId'];
                devicesByPageClientInfo($page, $devCount, $modelID,$groupId,$fwVersion, $firstName, $surName, $address, $email,$dev,$templ,$sortedVal,$clientId);
            } else if(isset($_POST['ip'])){
                $ip = $_POST['ip'];
                devicesByPageIp($page,$devCount,$modelID,$groupId,$fwVersion,$ip,$dev,$templ,$sortedVal);

            } else if(isset($_POST['mac'])){
                $mac = $_POST['mac'];
                devicesByPageMac($page,$devCount,$modelID,$groupId,$fwVersion,$mac,$dev,$templ,$sortedVal);

            }else if(isset($_POST['serial'])){
                $serial = $_POST['serial'];

                devicesByPageSerial($page,$devCount,$modelID,$groupId,$fwVersion,$serial,$dev,$templ,$sortedVal);
            } else if(isset($_POST['username'])){
                $username = $_POST['username'];

                searchDevicesByUsername($page, $username, $devCount, $modelID,$fwVersion, $dev, $groupId,$templ);
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}

