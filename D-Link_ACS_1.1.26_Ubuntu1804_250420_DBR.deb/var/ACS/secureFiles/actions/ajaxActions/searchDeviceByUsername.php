<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
	    require_once $_SESSION['APPPATH'].'util/utils.php';
            define('BASEPATH', $_SESSION['BASEPATH']);
            $username = $_POST['username'];
            $devCount = $_POST['devCount'];
            $modelID = $_POST['modelID'];
            $groupID = isset($_POST['groupID']) ? $_POST['groupID'] : -1;
            $fwVersion = $_POST['fwVersion'];
            $sortedVal = $_POST['sortedVal'];
            searchDevicesByUsername($username, $devCount, $modelID,$groupID,$fwVersion,$sortedVal);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}

function searchDevicesByUsername($username, $devCount, $modelID,$groupID,$fwVersion,$sortedVal) {
    require_once $_SESSION['APPPATH'].'models/device.php';
    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    
    $dev = new Device();
    $page = 1;
    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();

    if ($modelID == 0) {
        if($groupID == 0){
            $devices = $dev->searchDevicesByUsername($username, $devCount, $offset,$sortedVal);
            $allDeviceCount = $dev->getAllDevicesCountByUsername($username);
        } else {
            $devices = $dev->searchDevicesByUsernameGroup($groupID,$username, $devCount, $offset,$sortedVal);
            $allDeviceCount = $dev->getAllDevicesCountByUsernameGroup($groupID,$username);
        }
    } else {
        if($groupID == 0){
            $devices = $dev->searchDevicesByUsernameModelID($username, $modelID, $devCount, $offset,$fwVersion,$sortedVal);
            $allDeviceCount = $dev->getAllDevicesCountByUsernameModelID($username, $modelID,$fwVersion);
        } else {
            $devices = $dev->searchDevicesByUsernameModelIDGroupID($username, $modelID,$groupID, $devCount, $offset,$fwVersion,$sortedVal);
            $allDeviceCount = $dev->getAllDevicesCountByUsernameModelIDGroupID($username, $modelID,$groupID,$fwVersion);
        }
    }
    $groups = $dev->getAllGroups();
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    
    $allDevCount = $allDeviceCount[0]->count;
    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {
        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    
    $templ = new ModelTemplates();
    $allTemplates = $templ->getAllTemplates();
    if(count($devices)<$devCount) {
        $data = 2;
    } else {
        $data = 3;
    }

    //added  custom sort by ip
    if ($sortedVal != '') {
        $sortedValVar = trim(explode(":", $sortedVal)[0]);
        $sortBy = trim(explode(":", $sortedVal)[1]);
    } else {
        $sortedValVar = "last_inform_time";
        $sortBy = "ASC";
    }
    //   include $_SESSION['APPPATH'] . 'util/utils.php';
    if ($sortedValVar == 'ip') {
        $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
    }

    require_once $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
    return true;
}
