<?php

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
            }
            include $_SESSION['APPPATH'] . 'models/modelClient.php';
            $mac = $_POST['mac'];
            $email = $_POST['email'];
            $client = new ModelClient();

            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

                $existsCount = $client->checkEmailExist($email);

                if ($existsCount && $existsCount[0]->status == 1) {
                    echo $ini_array['email_exist'];
                }elseif($existsCount && $existsCount[0]->status == 2) {
                    echo $ini_array['email_exist_del_status'];
                }else {

                    $macExistsCount = $client->checkMacExist($mac);
                    $maxExistInDevices = $client->checkMacExistInDevices($mac);

                    if ($macExistsCount[0]->count != 0 || $maxExistInDevices[0]->count != 0) {
                        echo $ini_array['mac_exist'];
                    } else {
                        echo '';
                    } 
                }

            }else{
//               echo $ini_array['invalid_email'];
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    }else {
        $result = "logged_out";
        echo $result;
    }
}else{
    exit('No direct script access allowed');
}