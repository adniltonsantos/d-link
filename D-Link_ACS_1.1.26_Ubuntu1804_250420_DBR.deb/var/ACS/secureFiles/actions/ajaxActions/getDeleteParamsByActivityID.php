<?php
function getRec($childCou, $itemName, $chiItem, $type)
{
    $itemNodeName = $chiItem->nodeName;
    if ($childCou->length <= 1) {
        $itemNodeValue = $chiItem->nodeValue;
        if ($itemNodeName == "cwmp:ID") {
        } else {
            $arrr = array();
            if ($itemName == 'ObjectName') {
                $serialN = strstr($itemNodeValue, "InternetGatewayDevice.");

                while (strpos($serialN, ".")) {
                    $serialN = substr($serialN, strpos($serialN, ".") + 1, strlen($serialN) - strpos($serialN, "."));
                }

                $lastPartOfTheName = $serialN;

                if ($type == 'nameVal') {

                    $arrr['name'] = $lastPartOfTheName;
                    $GLOBALS['myArr'][] = $arrr;
                } else {
                    if ($GLOBALS['names'] == '') {
                        $GLOBALS['names'] = $lastPartOfTheName;
                    } else {
                        $GLOBALS['names'] = $GLOBALS['names'] . ' , ' . $lastPartOfTheName;
                    }
                }


            } else if ($itemName == 'Value') {
                if ($type == 'nameVal') {
                    $GLOBALS['myArr'][count($GLOBALS['myArr']) - 1]['value'] = $itemNodeValue;
                }
            }
        }
    }
}

function simpleParse($xml){
    $xml = simplexml_load_string($xml);
    if ($xml === false) {
        echo "Failed loading XML: ";
        foreach(libxml_get_errors() as $error) {
            echo "<br>", $error->message;
        }
    } else {
        var_dump(xml);
    }
}
function getDeleteParamsByWebTask($activityID){
    include $_SESSION['APPPATH'].'models/modelWebTask.php';

    $webTask = new ModelWebTask();
    $xml = $webTask->getXmlOfTheWebTaskByTaskID($activityID);



    $pos = strpos($xml[0]->xml, "DeleteObject");
    $notif = false;
    if ($pos) {
      //  $startPart = substr($xml[0]->xml, strlen("<cwmp:DeleteObject"), strlen($xml[0]->xml));
      //  $endVersion = '<cwmp:DeleteObject instance" ' . $startPart;

        $xmlDoc = new DOMDocument();
        $xmlDoc->loadXML($xml);
var_dump($xmlDoc);
        $xmlDoc->formatOutput = true;
        $x = $xmlDoc->documentElement;
        $GLOBALS['myArr'] = array();
        if ($x != '' && $x->nodeName != '') {
            foreach ($x->attributes as $attr) {
                $name = $attr->nodeName;
                $value = $attr->nodeValue;
            }
            foreach ($x->childNodes AS $item) {
                $itemName = $item->nodeName;
                if ($itemName != "#text") {
                    $childCo = $item->childNodes;
                    foreach ($childCo AS $chiItem) {
                        $chNodName = $chiItem->nodeName;
                        if ($chNodName != "#text") {
                            $childCou = $chiItem->childNodes;
                            if ($childCou->length <= 1) {
                                foreach ($chiItem->attributes as $attr) {
                                    $name = $attr->nodeName;
                                    $value = $attr->nodeValue;
                                }
                            } else {
                                foreach ($chiItem->attributes as $attr) {
                                    $name = $attr->nodeName;
                                    $value = $attr->nodeValue;
                                }
                            }
                            getRec($childCou, $itemName, $chiItem, 'nameVal');
                            if ($chNodName == "cwmp:GetParameterValuesResponse") {
                            }
                        }
                    }
                }
            }
        }

        $params = $GLOBALS['myArr'];
        $count = count($GLOBALS['myArr']);
    }  else {
        $params = false;
    }
    include $_SESSION['APPPATH'].'views/content/admin/activityParamsValues.php';

}
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    if (isset($_SESSION['logged_in'])) {
        try{
            $activityID = $_POST['activityID'];
            define('BASEPATH', $_SESSION['BASEPATH']);
            getDeleteParamsByWebTask($activityID);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}