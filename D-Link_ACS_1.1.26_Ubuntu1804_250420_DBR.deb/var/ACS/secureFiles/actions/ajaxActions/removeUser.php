<?php
if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }
            include $_SESSION['APPPATH'].'models/modelUser.php';
            include $_SESSION['APPPATH'].'util/usersConstants.php';
            $user = new ModelUser();
            $userId = $_POST["userID"];
            $needRemove = false;
            if(isset($_POST['actionName']) && $_POST['actionName']=="ActivateUsers") {
                if (is_array($userId)){
                        $result = $user->ActivateGroupOfUsers($userId);
                }
            } else {
                if (!is_array($userId)) {
                    $checking = $user->checkIsAdminById($userId, UsersConstants::$permissionsCount);

                    if ($checking[0]->res == 'true') {
                        $usersCount = $user->checkExistAnotherAdminById($userId);
                        if ($usersCount[0]->count >= 1) {
                            $result = $user->removeUser($userId);
                        } else {
                            echo $ini_array['last_user_msg'];
                        }
                    } else {
                        if (is_array($userId)) {
                            if ($user->checkLastAdminUser($userId)) {
                                $result = $user->removeGroupOfUsers($userId);
                            } else {
                                echo $ini_array['last_user_msg'];
                            }
                        } else {
                            $result = $user->removeUser($userId);
                        }
                    }
                } else {
                    if (is_array($userId)) {
                        if ($user->checkLastAdminUser($userId)) {
                            $result = $user->removeGroupOfUsers($userId);
                        } else {
                            echo $ini_array['last_user_msg'];
                        }
                    } else {
                        $result = $user->removeUser($userId);
                    }
                }
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
