<?php
function cidrToRange($cidr) {
    $range = array();
    $pos = strpos($cidr, "/");
    if($pos) {
        $count = substr_count($cidr, '/');
        if($count > 1) {
            return false;
        } else {
            $cidr = explode('/', $cidr);
            if($cidr[1] > 32) {
                return false;
            }
            $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
            $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
            return $range;
        }
    } else {
        return $pos;
    }
}

function getAllFilteredWebTasksByPage($model, $mac, $task, $status, $page, $taskInfo, $searchType, $createTime, $selectTime){
    include $_SESSION['APPPATH'].'models/modelWebTask.php';
    include $_SESSION['APPPATH'].'util/pagingConstants.php';
    include $_SESSION['APPPATH'].'models/device.php';
    include $_SESSION['APPPATH'].'util/utils.php';
    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupID = $_SESSION['group_id'];
        }
    }
    $userID = $_SESSION['userID'];

    $limit = PagingConstants::$activityCount;
    $offset = ($page - 1) * $limit;

    $webTask = new ModelWebTask();
    if($searchType == "ip") {
        if($taskInfo != '') {
            $ipMask = cidrToRange($taskInfo);
            if($ipMask) {
                $searchType = "ipmask";
                $taskInfo = array();
                $taskInfo[0] = $ipMask[0];
                $taskInfo[1] = $ipMask[1];
            }
        }
    }

    if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
        $dev = new Device();
        $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
        $countGroups=count($groupList);
        $devices = $dev->getDevicesByGroups($groupList, $countGroups,"");
        $devCount = $dev->getAllDevicesCountByGroups($groupList, $countGroups);
        $activities1 = $webTask->getAllFilteredWebTaskByStatusPageByGroups($devices, $devCount,$userID, $model, $mac, $task, $status, $createTime, $selectTime, $taskInfo, $searchType, "'createPort', 'selectInterface'");
        $activitiesCount = count($activities1);

        if ($activitiesCount > $limit) {
            for($i=0; $i<$limit; $i++) {
                if($i+$offset==$activitiesCount){
                    break;
                }
                $activities[$i] = $activities1[$i+$offset];
            }
        } else {
            $activities = $activities1;
        }
    } else {
//    $activities = $webTask->getAllFilteredWebTaskByStatusPage($model, $mac, $task, $status, $limit, $offset);
        $activities = $webTask->getAllFilteredWebTaskByStatusPage($model, $mac, $task, $status, $createTime, $selectTime, $taskInfo, $searchType, $limit, $offset, "'createPort', 'selectInterface'");

        $allActivitiesCount = $webTask->getAllFilteredWebTasksCount($model, $mac, $task, $status, $createTime, $selectTime, $taskInfo, $searchType, "'createPort', 'selectInterface'");

        $activitiesCount = $allActivitiesCount[0]->count;
    }
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    $userSettings->activityFilter = array('mac' => $mac, 'model' => $model, 'task' => $task, 'status' => $status, 'createTime' => $createTime, 'selectTime' => $selectTime);
    setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7), '/');

    if ($activitiesCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($activitiesCount % $limit == 0) {
            $pagesCount = $activitiesCount / $limit;
        } else {
            $pagesCount = ($activitiesCount / $limit - ($activitiesCount % $limit) * (1 / $limit)) + 1;
        }
    }


    foreach ($activities as  $activity){
        if(trim($activity->type_name)=='getSelectedParams'){
            $tabName=Utils::getTabnameINActivity($activity->xml);
            $tabN=array($activity->type_name,$tabName);
            $activity->type_name=$tabN;

        }
    }

    include $_SESSION['APPPATH'].'views/content/admin/filteredActivities.php';

}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
//            if (isset($_POST['action']) && $_POST['action'] == "searchActivity") {
//                $taskInfo = $_POST['taskInfo'];
//                $searchType = $_POST['searchType'];
//                getSearchedWebTasks($taskInfo, $searchType);
//            } else {
                $page = $_POST['page'];
                $model = $_POST['model'];
                if (isset($_POST['mac'])) {
                    $mac = $_POST['mac'];
                } else {
                    $mac = 0;
                }
                $task = $_POST['task'];
                $status = $_POST['status'];
                if(isset($_POST['taskInfo'])){
                    $taskInfo = $_POST['taskInfo'];
                } else {
                    $taskInfo = '';
                }
                if(isset($_POST['searchType'])) {
                    $searchType = $_POST['searchType'];
                } else {
                    $searchType = '';
                }

                if(isset($_POST['createTime'])) {
                    $createTime = $_POST['createTime'];
                } else {
                    $createTime = '';
                }
                if(isset($_POST['selectTime']) || $_POST['selectTime'] != 0) {
                    $selectTime = $_POST['selectTime'];
                } else {
                    $selectTime = '';
                }

                getAllFilteredWebTasksByPage($model, $mac, $task, $status, $page, $taskInfo, $searchType, $createTime, $selectTime);
//            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}


