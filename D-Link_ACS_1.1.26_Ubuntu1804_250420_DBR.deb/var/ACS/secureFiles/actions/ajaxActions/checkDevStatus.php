<?php
    if(isset($_POST['fromApp'])){
        if (session_id() == '') {
            session_start();
        }
//        if(isset($_COOKIE['timeOut'])){
//            if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//                echo "logged_out";
//                exit();
//            }
//        }
        
        if (isset($_SESSION['logged_in'])) {
            try{
                include $_SESSION['APPPATH'].'sockets/createXML.php';
                include $_SESSION['APPPATH'].'sockets/connectTCP.php';
                include $_SESSION['APPPATH'].'util/actionNamesConstants.php';
                $devID=$_POST['deviceID'];
                $xml = CreateXML::createTheXML(ActionNamesConstants::$connection,$devID,"","NoName");
                $deviceStatus = ConnectTCP::connectToCheckConnection($xml);
                echo $deviceStatus;
            }catch (\Exception $e){
                error_log($e->getMessage());
                header('HTTP/1.1 500 Internal Server Error');
                header("Status: 500 Internal Server Error");
                exit();
            }  
        } else {
            $status = "logged_out";
            echo $status;
        }
    } else {
        exit('No direct script access allowed');
}

