<?php
if(isset($_POST['fromApp']))  {
    if (session_id() == '') {
        session_start();
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            if(isset($_POST['actionName']) && $_POST['actionName']=="AutoCreateClient") {
                $autoCrCl = $_POST['autoCreateCl'];
                include $_SESSION['APPPATH'] . 'models/modelUser.php';
                $clientParams = new modelUser();
                $clientType = $clientParams->updateAutoCreatClinet($autoCrCl);

            } else if(isset($_POST['actionName']) && $_POST['actionName']=="DefaultParameters") {
                $UnknownValues =array();
                $UnknownInfTime = $_POST['UnknownInfTime'];
                $UnknownRemoteAccessInput = $_POST['UnknownRemoteAccessInput'];
                $UnknownDevUsname = $_POST['UnknownDeviceUsernameInput'];
                $UnknownDevPass = $_POST['UnknownDevPass'];
                $UnknownPass = $_POST['UnknownPass'];
                $UnknownremoteAccessEnable = $_POST['UnknownremoteAccessEnable'];
                $UnknownStunEnable = $_POST['UnknownStunEnable'];
                $UnknownPeriodicEnable = $_POST['UnknownPeriodicEnable'];
                $UnknownDevParamsEnable = $_POST['UnknownDevParamsEnable'];
                $UnknownPasswordEnable = $_POST['UnknownPasswordEnable'];

                include $_SESSION['APPPATH'].'models/modelUser.php';
                $clientParams = new modelUser();
                if ($UnknownPeriodicEnable == 1) {
                    $InfTime = $clientParams->UnknownInfTime($UnknownInfTime);
                } else {
                    $InfTime = $clientParams->RemoveUnknownInfTime();
                }
                if ($UnknownremoteAccessEnable == 1) {
                    $RemEnable = $clientParams->UnknownRemoteAccessEn($UnknownremoteAccessEnable);
                    $RemInput = $clientParams->UnknownRemoteAccessInp($UnknownRemoteAccessInput);
                } else {
                    $RemInput = $clientParams->RemoveUnknownRemoteAccessEn();
                }
                if ($UnknownStunEnable == 1) {
                    $StunEnable = $clientParams->UnknownStunEn($UnknownStunEnable);
                } else {
                    $StunEnable = $clientParams->RemoveUnknownStunEn();
                }
                if ($UnknownDevParamsEnable == 1) {
                    $DevUsNameInput = $clientParams->UnknownDevUsernameInp($UnknownDevUsname);
                    $DevUsPasswordInput = $clientParams->UnknownDevPasswordInp($UnknownDevPass);
                    if($UnknownDevUsname == "") {
                        $DevUsNameInput = $clientParams->RemoveUnknownDevUsername();
                    }
                    if ($UnknownDevPass == "") {
                        $DevUsPasswordInput = $clientParams->RemoveUnknownDevPassword();
                    }
                } else {
                    $DevUsNameInput = $clientParams->RemoveUnknownDevUsername();
                    $DevUsPasswordInput = $clientParams->RemoveUnknownDevPassword();
                }
                if ($UnknownPasswordEnable == 1) {
                    $Password = $clientParams->UnknownPassword($UnknownPass);
                } else {
                    $Password = $clientParams->RemoveUnknownPass();
                }

            }

        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
