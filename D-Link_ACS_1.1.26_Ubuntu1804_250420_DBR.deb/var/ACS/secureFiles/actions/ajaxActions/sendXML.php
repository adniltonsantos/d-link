<?php

function devInfoByID($deviceID) {
    include $_SESSION['APPPATH'] . 'models/device.php';

    $dev = new Device();
    $device = $dev->devInfoByID($deviceID);

    return $device;
}
function createSetXML($getAllXml, $actionName){
	$deviceId = $_POST['deviceID'];
	include $_SESSION['APPPATH'] . 'models/modelParams.php';
	$modelParams = new ModelParams();
	$resForInsert = $modelParams->setLanWlanParams($getAllXml);
	if ($resForInsert != 0) {
		$getAllXml = CreateXML::createTheXMLForSet($actionName, $deviceId, $resForInsert, '', 0);
		$result = ConnectTCP::connectToGetData($getAllXml);
		return $result;
	}
	else {
		return false;
	}
}
function createPort($modelParams, $deviceId, $bridgePort,$bridgeType,$availableIndex) {
    if(!is_array($bridgePort)){
        $xml = CreateXML::createTheSETXMLForCreatePort($bridgePort,$bridgeType);
        $resForInsert = $modelParams->setLanWlanParams($xml);
    }else if (is_array($bridgePort) && !empty ($bridgePort)) {
        $xmlList = array();
        for ($i = 0; $i < count($bridgePort); $i++){
            $xmll = CreateXML::createTheSETXMLForCreatePort($bridgePort[$i],$bridgeType,$availableIndex[$i]);
            array_push($xmlList, $xmll);
        }
        $resForInsert = $modelParams->setLanWlanParams($xmlList);
    }
    
    if (!is_array($resForInsert) && $resForInsert != 0) {
        if($bridgeType == 'bridge'){
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$createPort, $deviceId, $resForInsert, '', 0);
        }elseif ($bridgeType == 'taggedNat') {
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$taggedNatParam, $deviceId, $resForInsert, '', 0);
        }elseif ($bridgeType == 'untaggedBridge'){
             $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$untaggedBridge, $deviceId, $resForInsert, '', 0);
        }
        
        $result = ConnectTCP::connectToGetData($getAllXml);
        return $result;
        
    }elseif (is_array($resForInsert) && !empty($resForInsert)) {
        if($bridgeType == 'bridge'){
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$createPort, $deviceId, $resForInsert, '', 0);
        }elseif ($bridgeType == 'taggedNat') {
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$taggedNat, $deviceId, $resForInsert, '', 0);
        }elseif ($bridgeType == 'untaggedBridge'){
             $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$untaggedBridge, $deviceId, $resForInsert, '', 0);
        }
        
        $result = ConnectTCP::connectToGetData($getAllXml);
        return $result;
    }
    
    return false;
}

function selectInterface($modelParams, $deviceId, $bridgeIndex) {
    $xml = CreateXML::createTheSETXMLForSelectInterface($bridgeIndex);
    $resForInsert = $modelParams->setLanWlanParams($xml);
    if ($resForInsert != 0) {
	$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$selectInterface, $deviceId, $resForInsert, '', 0);
	$result = ConnectTCP::connectToGetData($getAllXml);
        return $result;
    }
    return false;
}

function setDefaultConnection($modelParams,$conIndex, $index, $conn_type, $deviceId) {
    $xml = CreateXML::createDefGatewayXML($conIndex, $index, $conn_type);
    $resForInsert = $modelParams->setParams($xml);
    if ($resForInsert != 0) {
        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$defConnection, $deviceId, $resForInsert, '', 0);
        $result = ConnectTCP::connectToGetData($getAllXml);
        echo $result;
    } else {
        echo false;
    }
}

function addVlanPort($bridgeIndex,$checkedPorts,$modelParams,$deviceId,$availableIndex){
    $xmlList = array();
    for ($i = 0; $i < count($checkedPorts); $i++){
        $xmll = CreateXML::createTheAddPortXMLForVlan($bridgeIndex, $checkedPorts[$i], $availableIndex[$i]);
        array_push($xmlList, $xmll);
    }
    $resForInsert = $modelParams->setLanWlanParams($xmlList);

    if (is_array($resForInsert) && !empty($resForInsert)) {
        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$addVlanPort, $deviceId, $resForInsert, '', 0);
        $result = ConnectTCP::connectToGetData($getAllXml);
        return $result;
    }
}

function deleteVlanPort($bridgeIndex,$uncheckedPorts,$modelParams,$deviceId){
    $xmlList = array();
//    for ($i = 0; $i < count($uncheckedPorts); $i++){
//        $xmll = CreateXML::createTheDeletePortXMLForVlan($bridgeIndex,$uncheckedPorts[$i]);
//        array_push($xmlList, $xmll);
//    }
    foreach ($uncheckedPorts as $key => $val){
        $xmll = CreateXML::createTheDeletePortXMLForVlan("marking",$val["markingId".substr($key, 2)],$val["filterId".substr($key, 2)]);
        array_push($xmlList, $xmll);
        $xmll = CreateXML::createTheDeletePortXMLForVlan("filter",$val["markingId".substr($key, 2)],$val["filterId".substr($key, 2)]);
        array_push($xmlList, $xmll);
    }
    $resForInsert = $modelParams->setLanWlanParams($xmlList);

    if (is_array($resForInsert) && !empty($resForInsert)) {
        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$deleteVlanPort, $deviceId, $resForInsert, '', 0);
        $result = ConnectTCP::connectToGetData($getAllXml);
        return $result;
    }
}

function addTemplateToDevice($modelParams, $deviceId, $templateId) {

    $resForUpdate = $modelParams->setTemplateId($deviceId, $templateId);

    if ($resForUpdate) {
        $xml = CreateXML::createTheXML(ActionNamesConstants::$setTemplate, $deviceId, '', "0", '');
        $result = ConnectTCP::connectToGetData($xml);
        echo $result;
    }
    
    return false;
}

function readVersionInfoSettings()
{
	$fileName = '/etc/acs/config/public-ipv4';
	$fileExist = file_exists($fileName);
	if ($fileExist && filesize($fileName)>7) {
        $handle = fopen($fileName, 'r');
        $data = fread($handle,filesize($fileName));
    } else {
	    return false;
    }

	return $data;
}

function readAcsSettings()
{
    $settingsFile = '/etc/acs/config/acs.conf';
    $content = file_get_contents($settingsFile);
    $contentArray = explode("\n", $content);
    $settingsArray = array();
    foreach($contentArray as $setting)
    {
        list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
        if ($value !== NULL)
        {
            $settingsArray[trim($key)] = trim($value);
        }
    }
    return $settingsArray;
}


try{
    if (isset($_POST['fromApp'])) {
	if (session_id() == '') {
	    session_start();
	}
//        if(isset($_COOKIE['timeOut'])){
//            if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//                echo "logged_out";
//                exit();
//            }
//        }
	if (isset($_SESSION['logged_in'])) {

	    include $_SESSION['APPPATH'] . 'sockets/createXML.php';
	    include $_SESSION['APPPATH'] . 'sockets/connectTCP.php';
	    include $_SESSION['APPPATH'] . 'util/actionNamesConstants.php';
	    $action = $_POST['actionName'];
	    $xml = "";
        if(isset($_SESSION['group_id'])) {
            $groupName = $_SESSION['group_id'];
        }
	    if($action == 'UploadCSV') {
            $xml = CreateXML::createTheXML($action, '', '', '', 0, '');
            $result = ConnectTCP::connectToGetData($xml);
            echo $result;
        } else if ($action == 'config') {
            include $_SESSION['APPPATH'].'models/device.php';
            include $_SESSION['APPPATH'] . 'models/modelUser.php';
            $fileId = $_POST['fileID'];
            $devId = $_POST['deviceID'];
            $token = $_POST['token'];
            $fileType = "3 Vendor Configuration File";
            $filePath  = "index.php";

            $device = new Device();
            $user = new ModelUser();

            $config = $device->getConfig($fileId);
            if(!isset($config[0]->config_path)) {
                $fName = $_POST['fileName'];
                $fSize = $_POST['fileSize'];
                $tokenAndFileId = $token ."/". $fName;
            } else {
                $fName = $config[0]->config_path;
                $fSize = $config[0]->file_size;
                $tokenAndFileId = $token . "/" . $fileId;
            }
            $stunSettings = readVersionInfoSettings();
            if ($stunSettings != false){
                $configUrl = $stunSettings . $filePath  . "?authorization=" . $tokenAndFileId;
            }else{
                $ip = $user->getIp()[0];
                $port = $user->getPort()[0];
                $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . "?authorization=" . $tokenAndFileId;
//                $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . "/" . $filePath . "?authorization=" . $tokenAndFileId ;
            }

            $xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($configUrl, $fSize, $fileType);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setLanWlanParams($xml);
            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$configUpdate, $devId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }

//		$deviceId = $_POST['deviceID'];
//		$fileId = $_POST['fileID'];
//		$xml = CreateXML::createTheXML(ActionNamesConstants::$configUpdate, $deviceId, $fileId, "NoName", '');
//		$result = ConnectTCP::connectToGetData($xml);
//		echo $result;
	    } else if ($action == 'firmware') {

            include $_SESSION['APPPATH'].'models/device.php';
            include $_SESSION['APPPATH'] . 'models/modelUser.php';
            $fileId = $_POST['fileID'];
            $devId = $_POST['deviceID'];
            $token = $_POST['token'];
            $fileType = "1 Firmware Upgrade Image";

            $device = new Device();
            $user = new ModelUser();

            $firmware = $device->getFirmware($fileId);

            $fName = $firmware[0]->firmware_path;
            $fSize = $firmware[0]->file_size;

            $stunSettings = readVersionInfoSettings();
            if ($stunSettings != false){
                $firmwareUrl = $stunSettings . $fName  . "?authorization=" . $token;
            }else{
                $ip = $user->getIp()[0];
                $port = $user->getPort()[0];
                $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                $firmwareUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . $fName . "?authorization=" . $token;
            }

            $xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($firmwareUrl, $fSize, $fileType);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setLanWlanParams($xml);
            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$firmwareUpgrade, $devId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }

//		$deviceId = $_POST['deviceID'];
//		$fileId = $_POST['fileID'];
//		$xml = CreateXML::createTheXML(ActionNamesConstants::$firmwareUpgrade, $deviceId, $fileId, "NoName", '');
//		$result = ConnectTCP::connectToGetData($xml);
//		echo $result;
	    } else if ($action == 'groupConfig') {
		$modelID = $_POST['modelID'];
		$groupId = $_POST['groupId'];
		$fileId = $_POST['fileID'];
            $filePath  = "index.php";
		include $_SESSION['APPPATH'] . 'models/device.php';
        include $_SESSION['APPPATH'] . 'models/modelUser.php';

            $dev = new Device();

            if(isset($_POST['taskName']) && isset($_POST['taskTime'])) {
                $devicesForTask=array();
                if($groupId > 0 || $groupId == -2) {
                    $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId, $modelID);
                } else if ($groupId == 0) {
                    if ($groupName == 'Group manager') {
                        $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                        $countGroups = count($groupList);
                        $devicesForTask = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
                    } else {
                        $devicesForTask = $dev->getDevicesIdByModel($modelID);
                    }
                }
                $token = $_POST['token'];
                $fileType = "3 Vendor Configuration File";

                $device = new Device();
                $user = new ModelUser();

                $config = $device->getConfig($fileId);

                $fName = $config[0]->config_path;
                $fSize = $config[0]->file_size;
                $tokenAndFileId = $token . "/" . $fileId;

                $stunSettings = readVersionInfoSettings();
                if ($stunSettings != false){
                    $configUrl = $stunSettings . $filePath  . "?authorization=" . $tokenAndFileId;
//                    $configUrl = $stunSettings . $fName  . "?authorization=" . $token;
                }else{
                    $ip = $user->getIp()[0];
                    $port = $user->getPort()[0];
                    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                    $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . "?authorization=" . $tokenAndFileId;
//                    $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . $fName . "?authorization=" . $token;
                }

                $xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($configUrl, $fSize, $fileType);
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $modelParams = new ModelParams();
                $resForInsert = $modelParams->setLanWlanParams($xml);
//                $devicesForTask = $dev->getDevicesIdByModel($modelID);
                $confUpdate = $dev->getOperationType(ActionNamesConstants::$configUpdate);
                $taskName = $_POST['taskName'];
                $taskTime = $_POST['taskTime'];
                foreach($devicesForTask as $devicesForTasks) {
                    $insertTaskTime = $dev->addTaskScheduler($devicesForTasks, $taskName, $taskTime, $confUpdate[0]->id, $resForInsert);
                }
                $result = 'true';

            } else {
                $token = $_POST['token'];
                $fileType = "3 Vendor Configuration File";

                $device = new Device();
                $user = new ModelUser();

                $config = $device->getConfig($fileId);

                $fName = $config[0]->config_path;
                $fSize = $config[0]->file_size;
                $tokenAndFileId = $token . "/" . $fileId;

                $stunSettings = readVersionInfoSettings();
                if ($stunSettings != false){
                    $configUrl = $stunSettings . $filePath  . "?authorization=" . $tokenAndFileId;
//                    $configUrl = $stunSettings . $fName  . "?authorization=" . $token;
                }else{
                    $ip = $user->getIp()[0];
                    $port = $user->getPort()[0];
                    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                    $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . "?authorization=" . $tokenAndFileId;
//                    $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . $fName . "?authorization=" . $token;
                }

                $xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($configUrl, $fSize, $fileType);
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $modelParams = new ModelParams();
                $resForInsert = $modelParams->setLanWlanParams($xml);
                if ($resForInsert != 0) {
//                    if (is_array($devices) && count($devices) > 0) {
//                        if(count($devices) > 50) {
//                            for($i = 0; $i < count($devices); $i = $i + 50) {
//                                $arr = array_slice($devices, $i, 50);
//                                $getAllXml = CreateXML::createGroupXML(ActionNamesConstants::$configUpdate, $arr, $resForInsert);
//                                $result = ConnectTCP::connectToGetData($getAllXml);
//                            }
//                        } else {
//                            $getAllXml = CreateXML::createGroupXML(ActionNamesConstants::$configUpdate, $devices, $resForInsert);
//                    $result = ConnectTCP::connectToGetData($getAllXml);
//                        }
//                    }else {
//                        $result = 'false';
//                    }
                    $getAllXml = CreateXML::createGroupTaskXML(ActionNamesConstants::$configUpdate, $groupId, $modelID, 0, $resForInsert);
                    $resForInsertTask = $modelParams->setLanWlanParams($getAllXml);
                    if ($resForInsertTask != 0) {
                        $deviceId = array(0);
                        $getXml = CreateXML::createTheXML(ActionNamesConstants::$groupTask, $deviceId, $resForInsertTask, "0", "");
                        $result = ConnectTCP::connectToGetData($getXml);
                    } else {
                        $result = 'false';
                    }
                } else {
                    $result = 'false';
                }
//                if (is_array($devices) && count($devices) > 0) {
//                    $xml = CreateXML::createGroupXML(ActionNamesConstants::$configUpdate, $devices, $fileId);
//                    $result = ConnectTCP::connectToGetData($xml);
//                } else {
//                    $result = 'false';
//                }
            }

		echo $result;
	    } else if ($action == 'groupFW') {
		$modelID = $_POST['modelID'];
		$fwVersion = $_POST['fwVersion'];
		$groupId = $_POST['groupId'];
		$fileId = $_POST['fileID'];
		include $_SESSION['APPPATH'] . 'models/device.php';
        include $_SESSION['APPPATH'] . 'models/modelUser.php';

        $dev = new Device();
//		$devices = array();
//		if($fwVersion == '0'){
//		    if($groupId > 0 || $groupId == -2){
//			$devices = $dev->getDevicesIdByGroupAndModel($groupId,$modelID);
//		    }else if ($groupId == 0){
//                if($groupName == 'Group manager') {
//                    $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                    $countGroups=count($groupList);
//                    $devices = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
//                } else {
//                    $devices = $dev->getDevicesIdByModel($modelID);
//                }
//		    }
//		}else{
//		    if($groupId > 0 || $groupId == -2){
//			$devices = $dev->getDevicesIdByGroupAndFwVersion($groupId,$modelID,$fwVersion);
//		    }else if ($groupId == 0){
//                if($groupName == 'Group manager') {
//                    $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                    $countGroups=count($groupList);
//                    $devices = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
//                } else {
//                    $devices = $dev->getDevicesIdByFwVersion($modelID,$fwVersion);
//                }
//		    }
//		}

            if(isset($_POST['taskName']) && isset($_POST['taskTime'])) {
//                $devicesForTask = $dev->getDevicesIdByModel($modelID);
                $devicesForTask = array();
		        if($fwVersion == '0') {
                    if ($groupId > 0 || $groupId == -2) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId, $modelID);
                    } else if ($groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByModel($modelID);
                        }
                    }
                }else {
                    if ($groupId > 0 || $groupId == -2) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndFwVersion($groupId, $modelID, $fwVersion);
                    } else if ($groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByFwVersion($modelID, $fwVersion);
                        }
                    }
                }
                $token = $_POST['token'];
                $fileType = "1 Firmware Upgrade Image";

                $device = new Device();
                $user = new ModelUser();
                $firmware = $device->getFirmware($fileId);

                $fName = $firmware[0]->firmware_path;
                $fSize = $firmware[0]->file_size;
//                $config = $device->getConfig($fileId);

//                $fName = $config[0]->config_path;
//                $fSize = $config[0]->file_size;
//
                $stunSettings = readVersionInfoSettings();
                if ($stunSettings != false){
                    $configUrl = $stunSettings . $fName  . "?authorization=" . $token;
                }else{
                    $ip = $user->getIp()[0];
                    $port = $user->getPort()[0];
                    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                    $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . $fName . "?authorization=" . $token;
                }

                $xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($configUrl, $fSize, $fileType);
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $modelParams = new ModelParams();
                $resForInsert = $modelParams->setLanWlanParams($xml);
                $confUpdate = $dev->getOperationType(ActionNamesConstants::$firmwareUpgrade);
                $taskName = $_POST['taskName'];
                $taskTime = $_POST['taskTime'];
                foreach($devicesForTask as $devicesForTasks) {
                    $insertTaskTime = $dev->addTaskScheduler($devicesForTasks, $taskName, $taskTime, $confUpdate[0]->id, $resForInsert);
                }
                $result = 'true';
            } else {
                $token = $_POST['token'];
                $fileType = "1 Firmware Upgrade Image";

                $device = new Device();
                $user = new ModelUser();
                $firmware = $device->getFirmware($fileId);

                $fName = $firmware[0]->firmware_path;
                $fSize = $firmware[0]->file_size;
//                $config = $device->getConfig($fileId);

//                $fName = $config[0]->config_path;
//                $fSize = $config[0]->file_size;
//
                $stunSettings = readVersionInfoSettings();
                if ($stunSettings != false){
                    $configUrl = $stunSettings . $fName  . "?authorization=" . $token;
                }else{
                    $ip = $user->getIp()[0];
                    $port = $user->getPort()[0];
                    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                    $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . $fName . "?authorization=" . $token;
                }

                $xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($configUrl, $fSize, $fileType);
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $modelParams = new ModelParams();
                $resForInsert = $modelParams->setLanWlanParams($xml);
                if ($resForInsert != 0) {
//                    if (is_array($devices) && count($devices) > 0) {
//                        if(count($devices) > 50) {
//                            for($i = 0; $i < count($devices); $i = $i + 50) {
//                                $arr = array_slice($devices, $i, 50);
//                                $getAllXml = CreateXML::createGroupXML(ActionNamesConstants::$firmwareUpgrade, $arr, $resForInsert);
//                                $result = ConnectTCP::connectToGetData($getAllXml);
//                            }
//                        } else {
//                            $getAllXml = CreateXML::createGroupXML(ActionNamesConstants::$firmwareUpgrade, $devices, $resForInsert);
//                            $result = ConnectTCP::connectToGetData($getAllXml);
//                        }
//                    }else {
//                        $result = 'false';
//                    }
                    $getAllXml = CreateXML::createGroupTaskXML(ActionNamesConstants::$firmwareUpgrade, $groupId, $modelID, $fwVersion, $resForInsert);
                    $resForInsertTask = $modelParams->setLanWlanParams($getAllXml);
                    if ($resForInsertTask != 0) {
                        $deviceId = array(0);
                        $getXml = CreateXML::createTheXML(ActionNamesConstants::$groupTask, $deviceId, $resForInsertTask, "0", "");
                        $result = ConnectTCP::connectToGetData($getXml);
                    } else {
                        $result = 'false';
                    }
//                    $getAllXml = CreateXML::createGroupTaskXML(ActionNamesConstants::$firmwareUpgrade, $groupId, $modelID, $fwVersion, $resForInsert);
//                    $result = ConnectTCP::connectToGetData($getAllXml);
                } else {
                    $result = 'false';
                }

//                if (is_array($devices) && count($devices) > 0) {
//                    $xml = CreateXML::createGroupXML(ActionNamesConstants::$firmwareUpgrade, $devices, $fileId);
//                    $result = ConnectTCP::connectToGetData($xml);
//                } else {
//                    $result = 'false';
//                }
            }

		echo $result;
	    } else if ($action == "groupReboot") {
            $model = 0;
            if(isset($_POST['modelID'])) {
                $modelID = $_POST['modelID'];
                if ($modelID != 'all') {
                    $model = $modelID;
                }
            }
            if(isset($_POST['groupId'])) {
                $groupId = $_POST['groupId'];
            } else {
                $groupId = '';
            }
            if(isset($_POST['fwVersion'])) {
                $fwVersion = $_POST['fwVersion'];
            } else {
                $fwVersion = '';
            }
		    include $_SESSION['APPPATH'] . 'models/device.php';
		    $dev = new Device();
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
//                if($fwVersion == '0'){
//                    if($modelID == 'all' && $groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroups($groupList, $countGroups);
//                        } else {
//                            $devices = $dev->getAllActiveDevicesId();
//                        }
//                    }else if(($groupId > 0 || $groupId == -2)  && $modelID == 'all'){
//                        $devices = $dev->getDevicesIdByGroup($groupId);
//                    }else if(($groupId > 0 || $groupId == -2) && $modelID != 'all'){
//                        $devices = $dev->getDevicesIdByGroupAndModel($groupId,$modelID);
//                    }else if($groupId == 0 && $modelID != 'all'){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
//                        } else {
//                            $devices = $dev->getDevicesIdByModel($modelID);
//                        }
//                    }
//                } else {
//                    if($groupId > 0 || $groupId == -2){
//			$devices = $dev->getDevicesIdByGroupAndFwVersion($groupId,$modelID,$fwVersion);
//		    }else if ($groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
//                        } else {
//                            $devices = $dev->getDevicesIdByFwVersion($modelID,$fwVersion);
//                        }
//                    }
//                }

            if(isset($_POST['taskName']) && isset($_POST['taskTime'])) {
                $devicesForTask = array();
                if($fwVersion == '0') {
                    if ($modelID == 0 && $groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroups($groupList, $countGroups,"");
                        } else {
                            $devicesForTask = $dev->getAllActiveDevicesId();
                        }
                    } else if (($groupId > 0 || $groupId == -2) && $modelID == 0) {
                        $devicesForTask = $dev->getDevicesIdByGroup($groupId);
                    } else if (($groupId > 0 || $groupId == -2) && $modelID != 0) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId, $modelID);
                    } else if ($groupId == 0 && $modelID != 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
                        } else {
                            $devices = $dev->getDevicesIdByModel($modelID);
                        }
                    }
                } else {
                    if($groupId > 0 || $groupId == -2) {
                        $devices = $dev->getDevicesIdByGroupAndFwVersion($groupId, $modelID, $fwVersion);
                    }else if ($groupId == 0){
                        if($groupName == 'Group manager') {
                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups=count($groupList);
                            $devices = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByFwVersion($modelID,$fwVersion);
                        }
                    }
                }
//                $devicesForTask = $dev->getDevicesIdByModel($modelID);
                $confUpdate = $dev->getOperationType(ActionNamesConstants::$reboot);
                $taskName = $_POST['taskName'];
                $taskTime = $_POST['taskTime'];
                foreach($devicesForTask as $devicesForTasks) {
                    $insertTaskTime = $dev->addTaskScheduler($devicesForTasks, $taskName, $taskTime, $confUpdate[0]->id, NULL);
                }
                $result = 'true';
            } else if(isset($_POST['deviseId'])) {
                $devices = $_POST['deviseId'];
                $xml = CreateXML::createGroupXML(ActionNamesConstants::$reboot, $devices, "NoName");
                $result = ConnectTCP::connectToGetData($xml);
            } else {
//                if (is_array($devices) && count($devices) > 0) {
//                    if(count($devices) > 50) {
//                        for($i = 0; $i < count($devices); $i = $i + 50) {
//                            $arr = array_slice($devices, $i, 50);
//                            $xml = CreateXML::createGroupXML(ActionNamesConstants::$reboot, $arr, "NoName");
//                            $result = ConnectTCP::connectToGetData($xml);
//                        }
//                    } else {
//                        $xml = CreateXML::createGroupXML(ActionNamesConstants::$reboot, $devices, "NoName");
//                        $result = ConnectTCP::connectToGetData($xml);
//                    }
//                } else {
//                    $result = 'false';
//                }

                $getAllXml = CreateXML::createGroupTaskXML(ActionNamesConstants::$reboot, $groupId, $model, $fwVersion, '');
                $resForInsert = $modelParams->setLanWlanParams($getAllXml);
                if ($resForInsert != 0) {
                    $deviceId = array(0);
                    $getXml = CreateXML::createTheXML(ActionNamesConstants::$groupTask, $deviceId, $resForInsert, "0", "");
                    $result = ConnectTCP::connectToGetData($getXml);
                } else {
                    $result = 'false';
                }
            }
		echo $result;
		
	    } else if ($action == "groupReset") {
            $model = 0;
            if(isset($_POST['modelID'])) {
                $modelID = $_POST['modelID'];
                if ($modelID != 'all') {
                    $model = $modelID;
                }
            }
            if(isset($_POST['groupId'])) {
                $groupId = $_POST['groupId'];
            } else {
                $groupId = '';
            }
            if(isset($_POST['fwVersion'])) {
                $fwVersion = $_POST['fwVersion'];
            } else {
                $fwVersion = '';
            }

            include $_SESSION['APPPATH'] . 'models/device.php';
            $dev = new Device();
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
//		if($fwVersion == '0'){
//                    if($modelID == 'all' && $groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroups($groupList, $countGroups);
//                        } else {
//                            $devices = $dev->getAllActiveDevicesId();
//                        }
//                    }else if(($groupId > 0 || $groupId == -2)  && $modelID == 'all'){
//                        $devices = $dev->getDevicesIdByGroup($groupId);
//                    }else if(($groupId > 0 || $groupId == -2) && $modelID != 'all'){
//                        $devices = $dev->getDevicesIdByGroupAndModel($groupId,$modelID);
//                    }else if($groupId == 0 && $modelID != 'all'){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
//                        } else {
//                            $devices = $dev->getDevicesIdByModel($modelID);
//                        }
//                    }
//                } else {
//                    if($groupId > 0 || $groupId == -2){
//			$devices = $dev->getDevicesIdByGroupAndFwVersion($groupId,$modelID,$fwVersion);
//		    }else if ($groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
//                        } else {
//                            $devices = $dev->getDevicesIdByFwVersion($modelID,$fwVersion);
//                        }
//                    }
//                }

            if(isset($_POST['taskName']) && isset($_POST['taskTime'])) {
//                $devicesForTask = $dev->getDevicesIdByModel($modelID);
                $devicesForTask = array();
                if($fwVersion == '0') {
                    if ($modelID == 0 && $groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroups($groupList, $countGroups,"");
                        } else {
                            $devicesForTask = $dev->getAllActiveDevicesId();
                        }
                    } else if (($groupId > 0 || $groupId == -2) && $modelID == 0) {
                        $devicesForTask = $dev->getDevicesIdByGroup($groupId);
                    } else if (($groupId > 0 || $groupId == -2) && $modelID != 0) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId, $modelID);
                    } else if ($groupId == 0 && $modelID != 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByModel($modelID);
                        }
                    }
                } else {
                    if ($groupId > 0 || $groupId == -2) {
                        $devices = $dev->getDevicesIdByGroupAndFwVersion($groupId, $modelID, $fwVersion);
                    } else if ($groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devices = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
                        } else {
                            $devices = $dev->getDevicesIdByFwVersion($modelID, $fwVersion);
                        }
                    }
                }
                $confUpdate = $dev->getOperationType(ActionNamesConstants::$reset);
                $taskName = $_POST['taskName'];
                $taskTime = $_POST['taskTime'];
                foreach($devicesForTask as $devicesForTasks) {
                    $insertTaskTime = $dev->addTaskScheduler($devicesForTasks, $taskName, $taskTime, $confUpdate[0]->id, NULL);
                }
                $result = 'true';
            }  else if(isset($_POST['deviseId'])) {
                $devices = $_POST['deviseId'];
                $xml = CreateXML::createGroupXML(ActionNamesConstants::$reset, $devices, "NoName");
                $result = ConnectTCP::connectToGetData($xml);
            } else {
//                if (is_array($devices) && count($devices) > 0) {
//                    if(count($devices) > 50) {
//                        for($i = 0; $i < count($devices); $i = $i + 50) {
//                            $arr = array_slice($devices, $i, 50);
//                            $xml = CreateXML::createGroupXML(ActionNamesConstants::$reset, $arr, "NoName");
//                            $result = ConnectTCP::connectToGetData($xml);
//                        }
//                    } else {
//                        $xml = CreateXML::createGroupXML(ActionNamesConstants::$reset, $devices, "NoName");
//                        $result = ConnectTCP::connectToGetData($xml);
//                    }
//                } else {
//                    $result = 'false';
//                }
                $getAllXml = CreateXML::createGroupTaskXML(ActionNamesConstants::$reset, $groupId, $model, $fwVersion, '');
                $resForInsert = $modelParams->setLanWlanParams($getAllXml);
                if ($resForInsert != 0) {
                    $deviceId = array(0);
                    $getXml = CreateXML::createTheXML(ActionNamesConstants::$groupTask, $deviceId, $resForInsert, "0", "");
                    $result = ConnectTCP::connectToGetData($getXml);
                } else {
                    $result = 'false';
                }
            }
		echo $result;
	    } else if ($action == "groupRefresh") {
            $model = 0;
            if(isset($_POST['modelID'])) {
                $modelID = $_POST['modelID'];
                if ($modelID != 'all') {
                    $model = $modelID;
                }
            }
            if(isset($_POST['groupId'])) {
                $groupId = $_POST['groupId'];
            } else {
                $groupId = '';
            }
            if(isset($_POST['fwVersion'])) {
                $fwVersion = $_POST['fwVersion'];
            } else {
                $fwVersion = '';
            }
		    include $_SESSION['APPPATH'] . 'models/device.php';
		    $dev = new Device();
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
//		    if($fwVersion == '0'){
//                    if($modelID == 'all' && $groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroups($groupList, $countGroups);
//                        } else {
//                            $devices = $dev->getAllActiveDevicesId();
//                        }
//                    }else if(($groupId > 0 || $groupId == -2)  && $modelID == 'all'){
//                        $devices = $dev->getDevicesIdByGroup($groupId);
//                    }else if(($groupId > 0 || $groupId == -2) && $modelID != 'all'){
//                        $devices = $dev->getDevicesIdByGroupAndModel($groupId,$modelID);
//                    }else if($groupId == 0 && $modelID != 'all'){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
//                        } else {
//                            $devices = $dev->getDevicesIdByModel($modelID);
//                        }
//                    }
//                } else {
//                    if($groupId > 0 || $groupId == -2){
//			$devices = $dev->getDevicesIdByGroupAndFwVersion($groupId,$modelID,$fwVersion);
//		    }else if ($groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
//                        } else {
//                            $devices = $dev->getDevicesIdByFwVersion($modelID,$fwVersion);
//                        }
//                    }
//                }

            if(isset($_POST['taskName']) && isset($_POST['taskTime'])) {
//		        if ($modelID == 'all') {
//                    $devicesForTask = $dev-> getDevicesIdByGroup($groupId);
//                } else if ($groupId == 0) {
//                    $devicesForTask = $dev->getDevicesIdByModel($modelID);
//                } else {
//                    $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId,$modelID);
//                }
                $devicesForTask =array();
                if($fwVersion == '0') {
                    if ($modelID == 0 && $groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroups($groupList, $countGroups,"");
                        } else {
                            $devicesForTask = $dev->getAllActiveDevicesId();
                        }
                    } else if (($groupId > 0 || $groupId == -2) && $modelID == 0) {
                        $devicesForTask = $dev->getDevicesIdByGroup($groupId);
                    } else if (($groupId > 0 || $groupId == -2) && $modelID != 0) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId, $modelID);
                    } else if ($groupId == 0 && $modelID != 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByModel($modelID);
                        }
                    }
                } else {
                    if ($groupId > 0 || $groupId == -2) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndFwVersion($groupId, $modelID, $fwVersion);
                    } else if ($groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByFwVersion($modelID, $fwVersion);
                        }
                    }
                }
                $confUpdate = $dev->getOperationType(ActionNamesConstants::$refresh);
                $taskName = $_POST['taskName'];
                $taskTime = $_POST['taskTime'];
                foreach($devicesForTask as $devicesForTasks) {
                    $insertTaskTime = $dev->addTaskScheduler($devicesForTasks, $taskName, $taskTime, $confUpdate[0]->id, NULL);
                }
                $result = 'true';
            } else if(isset($_POST['deviseId'])) {
                $devices = $_POST['deviseId'];
                $xml = CreateXML::createGroupXML(ActionNamesConstants::$refresh, $devices, "NoName");
                $result = ConnectTCP::connectToGetData($xml);
            } else {
//                if (is_array($devices) && count($devices) > 0) {
//                    if(count($devices) > 50) {
//                        for($i = 0; $i < count($devices); $i = $i + 50) {
//                            $arr = array_slice($devices, $i, 50);
//                            $xml = CreateXML::createGroupXML(ActionNamesConstants::$refresh, $arr, "NoName");
//                            $result = ConnectTCP::connectToGetData($xml);
//                        }
//                    } else {
                $xml = CreateXML::createGroupTaskXML(ActionNamesConstants::$refresh, $groupId, $model, $fwVersion, '');
                $resForInsert = $modelParams->setLanWlanParams($xml);
                if ($resForInsert != 0) {
                    $deviceId = array(0);
                    $getXml = CreateXML::createTheXML(ActionNamesConstants::$groupTask, $deviceId, $resForInsert, "0", "");
                    $result = ConnectTCP::connectToGetData($getXml);
                } else {
                    $result = 'false';
                }
//                    }
//                } else {
//                    $result = 'false';
//                }
            }
		echo $result;
	    } else if ($action == "reset") {
		$deviceId = $_POST['deviceID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$reset, $deviceId, "", "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == "reboot") {
		$deviceId = $_POST['deviceID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$reboot, $deviceId, "", "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == "refresh") {
		$deviceId = $_POST['deviceID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$refresh, $deviceId, "", "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == "resend") {
		$deviceId = $_POST['deviceID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$resend, $deviceId, "", "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == "auto_refresh") {
		$_SESSION["Refresh"] = "false";
		$deviceId = $_POST['deviceID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$aut_refresh, $deviceId, "", "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == "connection") {
		$deviceId = $_POST['deviceID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$connection, $deviceId, "", "0", '');
		$result = ConnectTCP::connectToCheckConnection($xml);
		echo $result;
	    } else if ($action == 'getAllParams') {
		$deviceId = $_POST['deviceID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$getAllParams, $deviceId, "", "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		if (isset($_SESSION["waitInfo"])) {
		    $waitDev = $_SESSION["waitInfo"];
		} else {
		    $waitDev = array();
		}
		//$serialN = $_POST["serialNumber"];
		//$waitDev[] = $serialN;
		unset($_SESSION["waitInfo"]);
		$_SESSION["waitInfo"] = $waitDev;
		echo $result;
	    } else if ($action == 'setLan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
		$serialN = $_POST['serialN'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
		$xml = CreateXML::createTheSETXML1(ActionNamesConstants::$lanSet, $deviceId, $paramNames, $paramVales, $paramTypes,'');
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {

    //                    $xml1 = CreateXML::createTheXML(ActionNamesConstants::$reboot, $deviceId, "NoName", '');
    //                    $result1 = ConnectTCP::connectToGetData($xml1);

		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$setLan, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
		
	    } else if($action == 'setLanIPv6'){
            $_SESSION["Refresh"] = "true";
            $deviceId = $_POST['deviceID'];
            $serialN = $_POST['serialN'];
            $paramNames = $_POST['changedParamNames'];
            $paramVales = $_POST['changedParamValues'];
            $paramTypes = $_POST['changedParamTypes'];
            $xml = CreateXML::createTheSETXML1(ActionNamesConstants::$lanIPv6Set, $deviceId, $paramNames, $paramVales, $paramTypes,'');
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setLanWlanParams($xml);
            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$lanIPv6Set, $deviceId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }
        } else if ($action == 'setWLan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
//		$serialN = $_POST['serialN'];
		$index = $_POST['index'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
                if(!is_array($index)){
                    $xml = CreateXML::createTheSETXML1(ActionNamesConstants::$wlanSet, $deviceId, $paramNames, $paramVales, $paramTypes, $index);
                }elseif (is_array($index)) {
                    $xml = CreateXML::createTheSETXMLForMBSSIDToggle(ActionNamesConstants::$wlanSet, $deviceId, $paramNames, $paramVales, $paramTypes, $index);
                }
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$setwLan, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
		
	    } else if ($action == 'setDefaultGateway') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
//		$serialN = $_POST['serialN'];
		$conn_type = $_POST['connectType'];
		$index = $_POST["index"];
		$conIndex = $_POST['connectIndex'];
		$xml = CreateXML::createDefGatewayXML($conIndex, $index, $conn_type);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setParams($xml);

		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
		
	    } else if ($action == 'setIGMP') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
		$version = $_POST['version'];
		$xml = CreateXML::createIGMPXml($version);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setParams($xml);

		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
		
	    } else if ($action == 'setIGMPoff') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
		$version = $_POST['version'];
		$xml = CreateXML::createIGMPOffXml($version);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setParams($xml);

		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
		
	    } else if ($action == "groupInfTime") {
	        $model = 0;
		    $modelID = $_POST['modelID'];
		    if($modelID != 'all') {
                $model = $modelID;
            }
		$groupId = isset($_POST['groupID']) ? $_POST['groupID'] : '';
		$interval = $_POST['informTime'];
                $fwVersion = $_POST['fwVersion'];
		include $_SESSION['APPPATH'] . 'models/device.php';
		$dev = new Device();
//		if($fwVersion == '0'){
//                    if($modelID == 'all' && $groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroups($groupList, $countGroups);
//                        } else {
//                            $devices = $dev->getAllActiveDevicesId();
//                        }
//                    }else if(($groupId > 0 || $groupId == -2)  && $modelID == 'all'){
//                        $devices = $dev->getDevicesIdByGroup($groupId);
//                    }else if(($groupId > 0 || $groupId == -2) && $modelID != 'all'){
//                        $devices = $dev->getDevicesIdByGroupAndModel($groupId,$modelID);
//                    }else if($groupId == 0 && $modelID != 'all'){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
//                        } else {
//                            $devices = $dev->getDevicesIdByModel($modelID);
//                        }
//                    }
//                } else {
//                    if($groupId > 0 || $groupId == -2){
//			$devices = $dev->getDevicesIdByGroupAndFwVersion($groupId,$modelID,$fwVersion);
//		    }else if ($groupId == 0){
//                        if($groupName == 'Group manager') {
//                            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//                            $countGroups=count($groupList);
//                            $devices = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
//                        } else {
//                            $devices = $dev->getDevicesIdByFwVersion($modelID,$fwVersion);
//                        }
//                    }
//                }
		
		$xml = CreateXML::createInformTimeXML($interval);
		$result = ConnectTCP::connectToGetData($xml);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setParams($xml);
		if ($resForInsert != 0) {
            if(isset($_POST['taskName']) && isset($_POST['taskTime'])) {
                $devicesForTask = array();
                if($fwVersion == '0') {
                    if ($modelID == 0 && $groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroups($groupList, $countGroups,"");
                        } else {
                            $devicesForTask = $dev->getAllActiveDevicesId();
                        }
                    } else if (($groupId > 0 || $groupId == -2) && $modelID == 0) {
                        $devicesForTask = $dev->getDevicesIdByGroup($groupId);
                    } else if (($groupId > 0 || $groupId == -2) && $modelID != 0) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId, $modelID);
                    } else if ($groupId == 0 && $modelID != 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByModel($modelID);
                        }
                    }
                } else {
                    if ($groupId > 0 || $groupId == -2) {
                        $devicesForTask = $dev->getDevicesIdByGroupAndFwVersion($groupId, $modelID, $fwVersion);
                    } else if ($groupId == 0) {
                        if ($groupName == 'Group manager') {
                            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                            $countGroups = count($groupList);
                            $devicesForTask = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
                        } else {
                            $devicesForTask = $dev->getDevicesIdByFwVersion($modelID, $fwVersion);
                        }
                    }
                }
//                $devicesForTask = $dev->getDevicesIdByModel($modelID);
                $confUpdate = $dev->getOperationType(ActionNamesConstants::$set);
                $taskName = $_POST['taskName'];
                $taskTime = $_POST['taskTime'];
                foreach($devicesForTask as $devicesForTasks) {
                    $insertTaskTime = $dev->addTaskScheduler($devicesForTasks, $taskName, $taskTime, $confUpdate[0]->id, $resForInsert);
                }
                $result = 'true';
            } else {
//                if (is_array($devices) && count($devices) > 0) {
//                    if(count($devices) > 50) {
//                        for($i = 0; $i < count($devices); $i = $i + 50) {
//                            $arr = array_slice($devices, $i, 50);
//                            $xml = CreateXML::createGroupXML(ActionNamesConstants::$set, $arr, $resForInsert);
//                            $result = ConnectTCP::connectToGetData($xml);
//                        }
//                    } else {
//                        $xml = CreateXML::createGroupXML(ActionNamesConstants::$set, $devices, $resForInsert);
//                        $result = ConnectTCP::connectToGetData($xml);
//                    }
//                } else {
//                    $result = 'false';
//                }
                $getAllXml = CreateXML::createGroupTaskXML(ActionNamesConstants::$periodic, $groupId, $model, $fwVersion, $resForInsert);
                $resForInsertTask = $modelParams->setLanWlanParams($getAllXml);
                if ($resForInsertTask != 0) {
                    $deviceId = array(0);
                    $getXml = CreateXML::createTheXML(ActionNamesConstants::$groupTask, $deviceId, $resForInsertTask, "0", "");
                    $result = ConnectTCP::connectToGetData($getXml);
                } else {
                    $result = 'false';
                }
            }

	       } else {
            $result =  'false';
		}
            echo $result;
	    } else if ($action == "setPasswordGroupTask") {
            $model = 0;
            $modelID = $_POST['modelID'];
            if($modelID != 'all') {
                $model = $modelID;
            }
            $pass = $_POST['password'];
            $groupId = isset($_POST['groupID']) ? $_POST['groupID'] : '';
            $fwVersion = $_POST['fwVersion'];
            include $_SESSION['APPPATH'] . 'models/device.php';
            $dev = new Device();

            $xml = CreateXML::createSetPassXML($pass);
            $result = ConnectTCP::connectToGetData($xml);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setParams($xml);
            if ($resForInsert != 0) {
                if(isset($_POST['taskName']) && isset($_POST['taskTime'])) {
                    $devicesForTask = array();
                    if($fwVersion == '0') {
                        if ($modelID == 0 && $groupId == 0) {
                            if ($groupName == 'Group manager') {
                                $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                                $countGroups = count($groupList);
                                $devicesForTask = $dev->getDevicesByGroups($groupList, $countGroups,"");
                            } else {
                                $devicesForTask = $dev->getAllActiveDevicesId();
                            }
                        } else if (($groupId > 0 || $groupId == -2) && $modelID == 0) {
                            $devicesForTask = $dev->getDevicesIdByGroup($groupId);
                        } else if (($groupId > 0 || $groupId == -2) && $modelID != 0) {
                            $devicesForTask = $dev->getDevicesIdByGroupAndModel($groupId, $modelID);
                        } else if ($groupId == 0 && $modelID != 0) {
                            if ($groupName == 'Group manager') {
                                $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                                $countGroups = count($groupList);
                                $devicesForTask = $dev->getDevicesByGroupsByModel($groupList, $countGroups, $modelID);
                            } else {
                                $devicesForTask = $dev->getDevicesIdByModel($modelID);
                            }
                        }
                    } else {
                        if ($groupId > 0 || $groupId == -2) {
                            $devicesForTask = $dev->getDevicesIdByGroupAndFwVersion($groupId, $modelID, $fwVersion);
                        } else if ($groupId == 0) {
                            if ($groupName == 'Group manager') {
                                $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
                                $countGroups = count($groupList);
                                $devicesForTask = $dev->getDevicesByGroupsByFWversion($groupList, $countGroups, $modelID, $fwVersion);
                            } else {
                                $devicesForTask = $dev->getDevicesIdByFwVersion($modelID, $fwVersion);
                            }
                        }
                    }
//                $devicesForTask = $dev->getDevicesIdByModel($modelID);
                    $confUpdate = $dev->getOperationType(ActionNamesConstants::$set);
                    $taskName = $_POST['taskName'];
                    $taskTime = $_POST['taskTime'];
                    foreach($devicesForTask as $devicesForTasks) {
                        $insertTaskTime = $dev->addTaskScheduler($devicesForTasks, $taskName, $taskTime, $confUpdate[0]->id, $resForInsert);
                    }
                    $result = 'true';
                } else {
//                if (is_array($devices) && count($devices) > 0) {
//                    if(count($devices) > 50) {
//                        for($i = 0; $i < count($devices); $i = $i + 50) {
//                            $arr = array_slice($devices, $i, 50);
//                            $xml = CreateXML::createGroupXML(ActionNamesConstants::$set, $arr, $resForInsert);
//                            $result = ConnectTCP::connectToGetData($xml);
//                        }
//                    } else {
//                        $xml = CreateXML::createGroupXML(ActionNamesConstants::$set, $devices, $resForInsert);
//                        $result = ConnectTCP::connectToGetData($xml);
//                    }
//                } else {
//                    $result = 'false';
//                }
                    $getAllXml = CreateXML::createGroupTaskXML(ActionNamesConstants::$periodic, $groupId, $model, $fwVersion, $resForInsert);
                    $resForInsertTask = $modelParams->setLanWlanParams($getAllXml);
                    if ($resForInsertTask != 0) {
                        $deviceId = array(0);
                        $getXml = CreateXML::createTheXML(ActionNamesConstants::$groupTask, $deviceId, $resForInsertTask, "0", "");
                        $result = ConnectTCP::connectToGetData($getXml);
                    } else {
                        $result = 'false';
                    }
                }

            } else {
                $result =  'false';
            }
            echo $result;
        }


	    else if ($action == "informTimeDev") {
		$deviceId = $_POST['deviceID'];
		$interval = $_POST['informTime'];
		$xml = CreateXML::createInformTimeXML($interval);
		$result = ConnectTCP::connectToGetData($xml);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setParams($xml);

		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
		
	    } else if ($action == 'log') {
            $deviceId = $_POST['deviceID'];
            $xml = CreateXML::createTheXML(ActionNamesConstants::$backup_log, $deviceId, "", "0", '');
            $result = ConnectTCP::connectToGetData($xml);
            echo $result;
	    } else if ($action == 'configUp') {
             $deviceId = $_POST['deviceID'];
             $xml = CreateXML::createTheXML(ActionNamesConstants::$backup_config, $deviceId, "", "0", '');
             $result = ConnectTCP::connectToGetData($xml);
            echo $result;
	    } else if  ($action == 'custom') {
             $deviceId = $_POST['deviceID'];
             $xml = CreateXML::createTheXML(ActionNamesConstants::$backup_custom, $deviceId, "", "0", '');
             $result = ConnectTCP::connectToGetData($xml);
            echo $result;
        } else if ($action == 'setStaticWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
    //            $serialN = $_POST['serialN'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$having = $_POST["having"];
		$xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$staticWanSet, $deviceId, $paramNames, $paramVales, $paramTypes, $index, $connectIndex, $having);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
	    } else if ($action == 'setDynamicWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
    //            $serialN = $_POST['serialN'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$having = $_POST["having"];
		$xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$dynamicWanSet, $deviceId, $paramNames, $paramVales, $paramTypes, $index, $connectIndex, $having);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
	    } else if ($action == 'changePPPWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
    //            $serialN = $_POST['serialN'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$pppoeWanSet, $deviceId, $paramNames, $paramVales, $paramTypes, $index, $connectIndex, 0);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
	    } else if ($action == 'changePPPIPv6Wan') {
            $_SESSION["Refresh"] = "true";
            $deviceId = $_POST['deviceID'];
            //            $serialN = $_POST['serialN'];
            $paramNames = $_POST['changedParamNames'];
            $paramVales = $_POST['changedParamValues'];
            $paramTypes = $_POST['changedParamTypes'];
            $index = $_POST["index"];
            $connectIndex = $_POST['connectIndex'];
            $xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$pppoeWanIPv6Set, $deviceId, $paramNames, $paramVales, $paramTypes, $index, $connectIndex, 0);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setLanWlanParams($xml);
            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }
        }
	    else if ($action == 'addPPPWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
    //            $serialN = $_POST['serialN'];
		$isDefConn = $_POST['defConnection'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$type = $_POST['type'];
		$xml = CreateXML::createTheSETXMLForWanToAdd($type, $deviceId, $paramNames, $paramVales, $paramTypes, $index, $connectIndex);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$addPPP, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    if ($result) {
			if($isDefConn == 'true'){
			    $result = setDefaultConnection($modelParams, $connectIndex, $index, '', $deviceId);
			}
			
			$interface_type = $_POST["interface_type"]; 
			if ($interface_type != '-1') {
			    $result = selectInterface($modelParams, $deviceId, $interface_type);
			}
			    echo $result;
		    } else {
			echo 'false';
		    }
		} else {
		    echo 'false';
		}
	    }
		else if ($action == 'setTrTree') {
			$_SESSION["Refresh"] = "true";
			$deviceId = $_POST['deviceID'];
			$serialN = $_POST['serialN'];
			$paramNames = $_POST['changedParamNames'];
			$paramVales = $_POST['changedParamValues'];
			$paramTypes = $_POST['changedParamTypes'];
			$xml = CreateXML::createTheSETXMLForTrTree(ActionNamesConstants::$set, $deviceId, $paramNames, $paramVales, $paramTypes,'');
			include $_SESSION['APPPATH'] . 'models/modelParams.php';
			$modelParams = new ModelParams();
			$resForInsert = $modelParams->setLanWlanParams($xml);
			if ($resForInsert != 0) {
				$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml);
				echo $result;
			} else {
				echo 'false';
			}

		}
		//create filter function
		else if($action == ActionNamesConstants::$addTRConn){
			$_SESSION["Refresh"] = "true";
			$deviceId = $_POST['deviceID'];
			$trName = $_POST["trName"];
			$getAllXml = CreateXML::createTRConn($trName);
			echo createSetXML($getAllXml,ActionNamesConstants::$set);
		}
		else if($action == ActionNamesConstants::$deleteTRConn){
			$_SESSION["Refresh"] = "true";
			$deviceId = $_POST['deviceID'];
			$trName = $_POST["trName"];
			$getAllXml = CreateXML::deleteTRConn($trName);
			echo createSetXML($getAllXml,ActionNamesConstants::$set);
		}
		else if($action == ActionNamesConstants::$deleteTRConn){
			$_SESSION["Refresh"] = "true";
			$deviceId = $_POST['deviceID'];
			$trName = $_POST["index"];
			$connectIndex = $_POST['connectIndex'];
			$number = $_POST["number"];
			$getAllXml = CreateXML::createTRConn($connectIndex, $index, $number);
			echo createSetXML($getAllXml,ActionNamesConstants::$set);
		}
		else if ($action == 'addDynamicWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
    //            $serialN = $_POST['serialN'];
		$isDefConn = $_POST['defConnection'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$type = $_POST['type'];
		$xml = CreateXML::createTheSETXMLForWanToAdd($type, $deviceId, $paramNames, $paramVales, $paramTypes, $index, $connectIndex);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$addPPP, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		   if ($result) {
			if($isDefConn == 'true'){
			    $result = setDefaultConnection($modelParams, $connectIndex, $index, 'dynamicIP', $deviceId);
			}
			
			$interface_type = $_POST["interface_type"]; 
			if ($interface_type != '-1') {
			    $result = selectInterface($modelParams, $deviceId, $interface_type);
			}
			    echo $result;
		    } else {
			echo 'false';
		    }
		} else {
		    echo 'false';
		}
	    
	    } else if ($action == 'addStaticWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
    //            $serialN = $_POST['serialN'];
		$isDefConn = $_POST['defConnection'];
		$paramNames = $_POST['changedParamNames'];
		$paramVales = $_POST['changedParamValues'];
		$paramTypes = $_POST['changedParamTypes'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$type = $_POST['type'];
		$xml = CreateXML::createTheSETXMLForWanToAdd($type, $deviceId, $paramNames, $paramVales, $paramTypes, $index, $connectIndex);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$addPPP, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    if ($result) {
			if($isDefConn == 'true'){
			    $result = setDefaultConnection($modelParams, $connectIndex, $index, 'staticIP', $deviceId);
			}
			
			$interface_type = $_POST["interface_type"]; 
			if ($interface_type != '-1') {
			    $result = selectInterface($modelParams, $deviceId, $interface_type);
			}
			    echo $result;
		    } else {
			echo 'false';
		    }
		} else {
		    echo 'false';
		}
	    } else if ($action == 'delPPPWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
		$serialN = $_POST['serialN'];
		$index = $_POST["index"];
		$conIndex = $_POST['connectIindex'];
		$xml = CreateXML::createTheDELXMLForWan($conIndex, $index);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$delPPP, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
	    } else if ($action == 'delStatWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
		$serialN = $_POST['serialN'];
		$index = $_POST["index"];
		$conIndex = $_POST['connectIindex'];
		$xml = CreateXML::createTheDELXMLForWanDyn($conIndex, $index);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$delPPP, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
	    } else if ($action == 'delDynWan') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
		$serialN = $_POST['serialN'];
		$index = $_POST["index"];
		$conIndex = $_POST['connectIindex'];
		$xml = CreateXML::createTheDELXMLForWanDyn($conIndex, $index);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$delPPP, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		    }
	    } else if ($action == 'delStatWanIpv6') {
            $_SESSION["Refresh"] = "true";
            $deviceId = $_POST['deviceID'];
            $serialN = $_POST['serialN'];
            $index = $_POST["index"];
            $conIndex = $_POST['connectIindex'];
            $xml = CreateXML::createTheDELXMLForWanDynIPv6($conIndex, $index);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setLanWlanParams($xml);
            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$delPPP, $deviceId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }
        }
        else if ($action == 'delDynWanIPv6') {
            $_SESSION["Refresh"] = "true";
            $deviceId = $_POST['deviceID'];
            $serialN = $_POST['serialN'];
            $index = $_POST["index"];
            $conIndex = $_POST['connectIindex'];
            $xml = CreateXML::createTheDELXMLForWanDynIPv6($conIndex, $index);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setLanWlanParams($xml);
            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$delPPP, $deviceId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }
        }
        else if ($action == 'delPPPIPv6Wan') {
            $_SESSION["Refresh"] = "true";
            $deviceId = $_POST['deviceID'];
            $serialN = $_POST['serialN'];
            $index = $_POST["index"];
            $conIndex = $_POST['connectIindex'];
            $xml = CreateXML::createTheDELXMLForWanPPPIPv6($conIndex, $index);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setLanWlanParams($xml);
            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$delPPP, $deviceId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }
        } else if ($action == 'refresh') {
		define('BASEPATH', $_SESSION['BASEPATH']);
		$devID = $_POST['deviceID'];
		$xml = CreateXML::createXMLForRefresh();
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$setwLan, $devID, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    if (isset($_SESSION['lang'])) {
			$lang = $_SESSION['lang'];
			if ($lang == 'en') {
			    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
			} else {
			    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
			}
		    }
		    $device = devInfoByID($devID);
		    include $_SESSION['APPPATH'] . 'views/content/admin/infoPageForDevice.php';
		} else {
		    echo 'false';
		}
	    } else if ($action == "repeatTask") {
            $activityID = $_POST['activityId'];
            include $_SESSION['APPPATH'] . 'models/modelWebTask.php';
            $webTask = new ModelWebTask();
            $status = $webTask->getStatusOfTheActivity($activityID);
            if ($status[0]->operation_status == 0 || $status[0]->operation_status == 4 || $status[0]->operation_status == 1) {
                $devID = $_POST['deviceID'];

                $xml = CreateXML::createTheXML(ActionNamesConstants::$repeat, $devID, "", "0", '');

               $result = ConnectTCP::connectToSendRepeat($xml);
                echo $result;
            } else {
                echo 'cannotSend';
            }
	    } else if ($action == "deleteTask") {
		$activityID = $_POST['activityID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$delete, $activityID, "", "0", '');
		$result = ConnectTCP::connectToCheckConnection($xml);
		echo $result;
	    } else if ($action == "removeClient") {
		$clientId = $_POST['clientID'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$deleteClient, $clientId, "", "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
		
	    } else if ($action == "notification") {
		$notifStatus = $_POST['notificationType'];
		$deviceId = $_POST['deviceID'];
		$interface = $_POST['conType'];
		$connId = $_POST['numIn'];
		$notifXml = CreateXML::createNotifXml($notifStatus, $connId, $interface);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($notifXml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$valueChange, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}

	    }else if ($action == "notificationTree") {
			$notifStatus = $_POST['notificationStatus'];
			$deviceId = $_POST['deviceID'];
			$name = $_POST['name'];
			$notifXml = CreateXML::createNotifXmlTree($notifStatus, $name);
			include $_SESSION['APPPATH'] . 'models/modelParams.php';
			$modelParams = new ModelParams();
			$resForInsert = $modelParams->setLanWlanParams($notifXml);
			if ($resForInsert != 0) {
				$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml);
				echo $result;
			} else {
				echo 'false';
			}

		}else if ($action == "notificationReset") {
			$valueFile = '/var/ACS/tmp/'.$_POST['valueFile'];
			$valueFileNew = '/var/ACS/tmp/' . $_POST['valueFileNew'];
			if(file_exists($valueFile) && file_exists($valueFileNew)) {
                		//unlink($valueFileNew);
                file_put_contents($valueFileNew, "");
			}
            echo 'true';
		} else if ($action == "diagnostic") {
		$deviceId = $_POST['deviceID'];
		$host = $_POST['host'];
    //            $serialN = $_POST['serialN'];
		$page = $_POST['fromPage'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$pingType = $_POST['pingType'];
		if(isset($_POST['numberRepetition'])) {
            $numberRepetition = $_POST['numberRepetition'];
        } else {
            $numberRepetition = 4;
        }

		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		
		if($pingType != 'PPPoE' && $pingType != 'L2TP' && $pingType != 'LTE'){
		    //get gateway and dnsservers
		    $params = $modelParams->getDnsGateway($pingType, $deviceId);
	//            $gateway = $params[0]->default_gateway;
		    $dnsservers = $params[0]->dns_servers;

		    if (($ind = strpos($dnsservers, ",")) !== false) {
			$dnsservers = substr($dnsservers, 0, $ind);
		    }
		}
		
		if($page == 'wan'){
		    $xmll = CreateXML::createDiagnosticFirstXML($connectIndex, $index, $host, $pingType, $numberRepetition);
		    $resForInsert = $modelParams->setLanWlanParams($xmll);
		    
		}else {
		    if(is_array($host) && !empty($host)){
			$xmlList = array();
			for ($i = 0; $i < count($host); $i++){
			    $xmll = CreateXML::createDiagnosticFirstXML($connectIndex, $index, $host[$i], $pingType, $numberRepetition);
			    array_push($xmlList, $xmll);
			}
			$resForInsert = $modelParams->setLanWlanParams($xmlList);
		    }
		}

		if (!is_array($resForInsert) && $resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$diagnostic, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		    //create and send 2-nd xml

    //                $xml = CreateXML::createDiagnosticFirstXML($connectIndex, $index, $dnsservers);
    //                $resForInsert1 = $modelParams->setLanWlanParams($xml);
    //                if ($resForInsert1 != 0) {
    //                    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$diagnostic, $deviceId, $resForInsert1);
    //                    $result = ConnectTCP::connectToGetData($getAllXml);
    //                    echo $result;
    //                } else {
    //                    echo 'false';
    //                }
		}else if(is_array($resForInsert) && !empty ($resForInsert)) {
			$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$diagnostic, $deviceId, $resForInsert, '', 0);
			$result = ConnectTCP::connectToGetData($getAllXml);
			echo $result;
		}else {
		    echo 'false';
		}
		
	    } else if ($action == "tracert") {
		$deviceId = $_POST['deviceID'];
		$page = $_POST['fromPage'];
		$host = $_POST['host'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$pingType = $_POST['pingType'];
		$maxHopCount = $_POST['maxHopCount'];
		$timeOut = $_POST['timeOut'];

		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		
		if($page == 'wan'){
		    $xmll = CreateXML::createDiagnosticFirstXMLForTracert($connectIndex, $index, $host,$pingType,$maxHopCount, $timeOut);
		    $resForInsert = $modelParams->setLanWlanParams($xmll);
		    
		}else {
		    if(is_array($host) && !empty($host)){
			$xmlList = array();
			for ($i = 0; $i < count($host); $i++){
			    $xmll = CreateXML::createDiagnosticFirstXMLForTracert($connectIndex, $index, $host[$i],$pingType,$maxHopCount, $timeOut);
			    array_push($xmlList, $xmll);
			}
			$resForInsert = $modelParams->setLanWlanParams($xmlList);
		    }
		}
		
		if (!is_array($resForInsert) && $resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$tracert, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		    
		}else if(is_array($resForInsert) && !empty ($resForInsert)) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$tracert, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		}else {
		    echo 'false';
		}
		
	    } else if ($action == "changeClient") {

		$clientId = $_POST['clientID'];
		$deviceIDString = $_POST['deviceID'];
		if (strpos($deviceIDString, ",") != false) {
		    $deviceIDArray = explode(',', $deviceIDString);
		    $devArray = array();
		    $devArray = $deviceIDArray;
		} else {
		    $devArray = $deviceIDString;
		}
		$xml = CreateXML::createTheXML(ActionNamesConstants::$changeClient, $devArray, $clientId, "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == 'removeDevice') {
		$devId = $_POST['deviceId'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$deleteDevice, $devId, '', "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == 'removeUnknownDevice') {
		$devId = $_POST['devId'];
		$xml = CreateXML::createTheXML(ActionNamesConstants::$removeUnknownDevice, $devId, '', "0", '');
		$result = ConnectTCP::connectToGetData($xml);
		echo $result;
	    } else if ($action == 'configBackup') {
		$devId = $_POST['deviceID'];
		$fName = $_POST['fileName'];
		$fSize = $_POST['fileSize'];
		$token = $_POST['token'];
		$filePath  = "index.php";
		$fileType = "3 Vendor Configuration File";
		include $_SESSION['APPPATH'] . 'models/modelUser.php';
            $user = new ModelUser();
            $tokenAndFileName = $token ."/". $fName;
            $stunSettings = readVersionInfoSettings();
            if ($stunSettings != false){
                $configUrl = $stunSettings . $filePath  . "?authorization=" . $tokenAndFileName;
            }else{
                $ip = $user->getIp()[0];
                $port = $user->getPort()[0];
                $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . "/" . $filePath . "?authorization=" . $tokenAndFileName ;
            }

//            $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
//		$configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . "/putConfigs" . "/" . $fName;
		$xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($configUrl, $fSize, $fileType);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$updateBackupConfig, $devId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
	    } else if ($action == 'createBridge') {
		$devId = $_POST['deviceID'];
		$bridgeName = $_POST['bridgeName'];
		$bridgeType = $_POST['bridgeType'];
		$vlanID = $_POST['vlanID'];
		$bridgePort = $_POST['bridgePort'];
		$VlanInterfaceType = $_POST['VlanInterfaceType'];

		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$availableIndex = array();

        if ($bridgePort != "") {
            for ($i = 0; $i < count($bridgePort); $i++) {
                if ($VlanInterfaceType[$i] == "LANETH") {
                    $availableIndexLAN = $modelParams->setAvailableIndexLanForAPI($bridgePort[$i], $devId);
                    if (isset($availableIndexLAN[0]->available_index)) {
                        array_push($availableIndex, $availableIndexLAN[0]->available_index);
                    } else {
                        array_push($availableIndex, '');
                    }
                } else if ($VlanInterfaceType[$i] == "WAN") {
                    array_push($availablePorts, 1);
                    $availableIndexWAN = $modelParams->setAvailableIndexWanForAPI($availablePorts[$i], $devId);
                    if (isset($availableIndexWAN[0]->available_index)) {
                        array_push($availableIndex, $availableIndexWAN[0]->available_index);
                    } else {
                        array_push($availableIndex, '');
                    }
                } else if ($VlanInterfaceType[$i] == "WLAN") {
                    $availableIndexWLAN = $modelParams->setAvailableIndexWlanForAPI($bridgePort[$i] - 5, $devId);
                    if (isset($availableIndexWLAN[0]->available_index)) {
                        array_push($availableIndex, $availableIndexWLAN[0]->available_index);
                    } else {
                        array_push($availableIndex, '');
                    }
                }
            }
        }

		if($bridgeType == 'bridge'){
		    $xml = CreateXML::createTheSETXMLForCreateBridge($bridgeName, $vlanID);
		    $resForInsert = $modelParams->setLanWlanParams($xml);
		    if ($resForInsert != 0) {
			$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$createBridge, $devId, $resForInsert, '', 0);
			$result = ConnectTCP::connectToGetData($getAllXml);
			if ($result) {
			    $result = createPort($modelParams, $devId, $bridgePort,$bridgeType,$availableIndex);
			    echo $result;
			} else {
			    echo 'false';
			} 
		    } else {
			echo 'false';
		    }
		}else if($bridgeType == 'taggedNat'){
                        $xml = CreateXML::createTheSETXMLForCreateBridge($bridgeName, $vlanID);
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$taggedNat, $devId, $resForInsert, '', 0);
                            $result = ConnectTCP::connectToGetData($getAllXml);
                            if ($result) {
                                $result = createPort($modelParams, $devId, $vlanID,$bridgeType,$availableIndex);
                                echo $result;
                            } else {
                                echo 'false';
                            } 
                        } else {
                            echo 'false';
                        }
//			$result = createPort($modelParams, $devId, $vlanID,$bridgeType);
//			echo $result;
		    
		}else if($bridgeType == 'untaggedBridge'){
			$result = createPort($modelParams, $devId, $bridgePort,$bridgeType,$availableIndex);
			echo $result;
		}
	    }else if ($action == 'editBridge') {
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
            $availableIndex = array();

		$devId = $_POST['deviceID'];
		$bridgeIndex = $_POST['bridgeIndex'];
		$bridgeType = $_POST['bridgeType'];
		$brigdeParams = $_POST['brigdeParams'];
		$brigdeParamsValue = $_POST['brigdeParamsValue'];
		$brigdeParamsType = $_POST['brigdeParamsType'];
		$checkedPorts = $_POST['checkedPorts'];
		$VlanInterfaceType = $_POST['VlanInterfaceType'];
		$uncheckedPorts = json_decode($_POST['uncheckedPorts'],true);
		if ($checkedPorts != "") {
            for ($i = 0; $i < count($checkedPorts); $i++) {
                if ($VlanInterfaceType[$i] == "LANETH") {
                    $availableIndexLAN = $modelParams->setAvailableIndexLanForAPI($checkedPorts[$i], $devId);
                    if (isset($availableIndexLAN[0]->available_index)) {
                        array_push($availableIndex, $availableIndexLAN[0]->available_index);
                    } else {
                        array_push($availableIndex, '');
                    }
                } else if ($VlanInterfaceType[$i] == "WAN") {
                    array_push($availablePorts, 1);
                    $availableIndexWAN = $modelParams->setAvailableIndexWanForAPI($availablePorts[$i], $devId);
                    if (isset($availableIndexWAN[0]->available_index)) {
                        array_push($availableIndex, $availableIndexWAN[0]->available_index);
                    } else {
                        array_push($availableIndex, '');
                    }
                } else if ($VlanInterfaceType[$i] == "WLAN") {
                    $availableIndexWLAN = $modelParams->setAvailableIndexWlanForAPI($checkedPorts[$i] - 5, $devId);
                    if (isset($availableIndexWLAN[0]->available_index)) {
                        array_push($availableIndex, $availableIndexWLAN[0]->available_index);
                    } else {
                        array_push($availableIndex, '');
                    }
                }
            }
        }



		if(!empty($brigdeParams) && empty($checkedPorts) && empty($uncheckedPorts)){
		    $xml = CreateXML::createTheSETXMLForEditBridge($brigdeParams,$brigdeParamsValue,$brigdeParamsType,$bridgeIndex);
		    $resForInsert = $modelParams->setLanWlanParams($xml);
		    if ($resForInsert != 0) {
			$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $devId, $resForInsert, '', 0);
			$result = ConnectTCP::connectToGetData($getAllXml);
			if ($result) {
			    echo $result;
			} else {
			    echo 'false';
			}
		    } else {
			echo 'false';
		    }
		}elseif (!empty($brigdeParams) && (!empty($checkedPorts) || !empty($uncheckedPorts))) {
		    $xml = CreateXML::createTheSETXMLForEditBridge($brigdeParams,$brigdeParamsValue,$brigdeParamsType,$bridgeIndex);
		    $resForInsert = $modelParams->setLanWlanParams($xml);
		    if ($resForInsert != 0) {
			$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $devId, $resForInsert, '', 0);
			$resultSet = ConnectTCP::connectToGetData($getAllXml);
		    }else {
			$resultSet = $resForInsert;
		    }

		    if(!empty($checkedPorts) && empty($uncheckedPorts)){
			$result = addVlanPort($bridgeIndex, $checkedPorts,$modelParams,$devId,$availableIndex);

		    }else if(empty($checkedPorts) && !empty($uncheckedPorts)){
			$result = deleteVlanPort($bridgeIndex, $uncheckedPorts,$modelParams,$devId);

		    }else if(!empty($checkedPorts) && !empty($uncheckedPorts)){
			$resultAdd = addVlanPort($bridgeIndex, $checkedPorts,$modelParams,$devId,$availableIndex);

			$resultDel = deleteVlanPort($bridgeIndex, $uncheckedPorts,$modelParams,$devId);

			$result = $resultAdd & $resultDel;
		    }

		    echo $result & $resultSet;

		}elseif (empty($brigdeParams) && (!empty($checkedPorts) || !empty($uncheckedPorts))) {

		    if(!empty($checkedPorts) && empty($uncheckedPorts)){
			$result = addVlanPort($bridgeIndex, $checkedPorts,$modelParams,$devId,$availableIndex);
			echo $result;

		    }else if(empty($checkedPorts) && !empty($uncheckedPorts)){
			$result = deleteVlanPort($bridgeIndex, $uncheckedPorts,$modelParams,$devId);
			echo $result;

		    }else if(!empty($checkedPorts) && !empty($uncheckedPorts)){
			$resultAdd = addVlanPort($bridgeIndex, $checkedPorts,$modelParams,$devId,$availableIndex);

			$resultDel = deleteVlanPort($bridgeIndex, $uncheckedPorts,$modelParams,$devId);

			echo $resultAdd & $resultDel;
		    }
		}
	    }else if ($action == 'deleteBridge') {
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		
		$devId = $_POST['deviceID'];
		$bridgeIndex = $_POST['bridgeIndex'];
		
		$xml = CreateXML::createTheDELXMLForBridge($bridgeIndex);
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$deleteVlan, $devId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		}else {
		    echo 'false';
		}
	    }else if ($action == 'editVoip') {
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		
		$devId = $_POST['deviceID'];
		$voipParams = $_POST['voipParams'];
		$voipParamsValue = $_POST['voipParamsValue'];
		$voipParamsType = $_POST['voipParamsType'];
		$index = $_POST['voipnumIndex'];
		
		$xml = CreateXML::createTheUpdateSetXMLForVoip($voipParams, $voipParamsValue, $voipParamsType, $index);
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $devId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		}else {
		    echo 'false';
		}
	    }else if ($action == 'editVoipLine') {
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$devId = $_POST['deviceID'];
		$voipLineNumber = $_POST['voipLineNumber'];
		$voipIndex = $_POST['voipIndex'];
        $voipLineIndex = $_POST['voipLineIndex'];
		$voipLineParams = $_POST['voipLineParams'];
		$voipLineParamsValue = $_POST['voipLineParamsValue'];
		$voipLineParamsType = $_POST['voipLineParamsType'];
		
		$xml = CreateXML::createTheUpdateSetXMLForVoipLine($voipLineNumber, $voipLineParams,$voipLineParamsValue, $voipLineParamsType, $voipIndex, $voipLineIndex);
		$resForInsert = $modelParams->setLanWlanParams($xml);
		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $devId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		}else {
		    echo 'false';
		}
	    }else if ($action == 'setTemplate') {
		require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
		require_once $_SESSION['APPPATH'].'models/device.php';
		$dev = new Device();
		$modelParams = new ModelParams();
		
		$deviceId = $_POST['deviceId'];
		$templateId = $_POST['templateId'];
		$groupId = '';
		
		if(isset($_POST['groupID'])){
		    $groupId = $_POST['groupID'];
		}
		
		if(!is_array($groupId) && $groupId != ''){
		    $group = $dev->getGroupById($groupId);
		    $templateId = $group[0]->template_id;
		}
		
		
		if(isset($_POST['fromDevices']) && $_POST['fromDevices'] == 'false' && is_array($groupId) && $groupId != ''){
		    for($i = 0; $i < count($groupId); $i++){
			$res = $dev->addTemplateToGroup($groupId[$i], $templateId);
			if(!$res){
			   echo 'false';
			}
		    }
		}
		
		$resForUpdate = $modelParams->setTemplateId($deviceId, $templateId);

		if ($resForUpdate) {
		    $xml = CreateXML::createTheXML(ActionNamesConstants::$setTemplate, $deviceId, '', "0", '');
		    $result = ConnectTCP::connectToGetData($xml);
		    echo $result;
		}else {
		    echo 'false';
		}
	    }else if ($action == 'uplodDownloadDiagnostic') {
		require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
		require_once $_SESSION['APPPATH'].'models/device.php';
		$dev = new Device();
		$modelParams = new ModelParams();
		
		$deviceId = $_POST['deviceID'];
		$host = $_POST['host'];
		$index = $_POST["index"];
		$connectIndex = $_POST['connectIndex'];
		$connectionType = $_POST['connectionType'];
		$upDwAction = $_POST['upDwAction'];
		$fileSize = $_POST['fileSize'];
		
		$xmll = CreateXML::createUploadDownloadDiagnosticXML($connectIndex, $index, $host, $connectionType, $upDwAction,$fileSize);
		$resForInsert = $modelParams->setLanWlanParams($xmll);

		if ($resForInsert) {
		    if($upDwAction == '1'){
			$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$uploadDiagnostics, $deviceId, $resForInsert, '', 0);
		    } else {
			$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$downloadDiagnostics, $deviceId, $resForInsert, '', 0);
		    }
		    
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		}else {
		    echo 'false';
		}
	    }else if ($action == 'setConfigPassword') {
		$_SESSION["Refresh"] = "true";
		$deviceId = $_POST['deviceID'];
		$password = $_POST['password'];
		$xml = CreateXML::createConfigPasswordXml($password);
		include $_SESSION['APPPATH'] . 'models/modelParams.php';
		$modelParams = new ModelParams();
		$resForInsert = $modelParams->setParams($xml);

		if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
		
	    }else if ($action == 'deleteFilteredActivities') {
                require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
                $modelParams = new ModelParams();
                $deviceId = $_POST['deviceId'];
                $modelId = $_POST['modelId'];
                $operationTypeId = $_POST['operationTypeId'];
                $operationStatus = $_POST['operationStatus'];
                $createTime = $_POST['createTime'];
                $selectTime = $_POST['selectTime'];
                
                $xml = CreateXML::createTheDELXMLForFilteredActivities($deviceId, $modelId, $operationTypeId, $operationStatus, $createTime, $selectTime);
                $resForInsert = $modelParams->setParams($xml);
                
                if ($resForInsert != 0) {
		    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$delete, '0', $resForInsert, '', 0);
		    $result = ConnectTCP::connectToGetData($getAllXml);
		    echo $result;
		} else {
		    echo 'false';
		}
            } else if($action == 'setRemoteAccess') {
			$deviceId = $_POST['deviceID'];
			$remoteAccess = $_POST['remoteAccess'];
			$remoteAccessPort = $_POST['remoteAccessPort'];
			if ($remoteAccess == 0) {
				$xml = CreateXML::createRemoteAccessDisable($remoteAccess);
			} else {
				$xml = CreateXML::createRemoteAccess($remoteAccess, $remoteAccessPort);
			}
			include $_SESSION['APPPATH'] . 'models/modelParams.php';
			$modelParams = new ModelParams();
			$resForInsert = $modelParams->setParams($xml);

			if ($resForInsert != 0) {
				$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml);
				echo $result;
			} else {
				echo 'false';
			}
		} else if ($action == 'stunEnable') {
			$deviceId = $_POST['deviceID'];
			$acsSettings = readAcsSettings();
			$stunSettings = readVersionInfoSettings();
			if ($stunSettings != '') {
                $ip=$stunSettings;
            } else {
			    if(isset($acsSettings['stun_server_addr'])) {
                    $ip = $acsSettings['stun_server_addr'];
                } else {
                    $ip = '';
                }
            }
            if(isset($acsSettings['stun_server_port'])) {
                $port=$acsSettings['stun_server_port'];
            } else {
                $port = '';
            }
			$index = 2;
			$xml1 = CreateXML::createStunEnablePortIP($ip, $port);
			$xml2 = CreateXML::createStunDisableEnable($index);
			include $_SESSION['APPPATH'] . 'models/modelParams.php';
			$modelParams = new ModelParams();
			$resForInsert1 = $modelParams->setParams($xml1);
			$resForInsert2 = $modelParams->setParams($xml2);

			if ($resForInsert1 != 0) {
				$getAllXml1 = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert1, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml1);
				echo $result;
			} else {
				echo 'false';
			}
			if ($resForInsert2 != 0) {
				$getAllXml2 = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert2, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml2);
				echo $result;
			} else {
				echo 'false';
			}

		} else if ($action == 'stunDisable') {
			$deviceId = $_POST['deviceID'];
			$index = 0;
			$xml1 = CreateXML::createStunDisablePortIP();
			$xml2 = CreateXML::createStunDisableEnable($index);
			include $_SESSION['APPPATH'] . 'models/modelParams.php';
			$modelParams = new ModelParams();
			$resForInsert1 = $modelParams->setParams($xml1);
			$resForInsert2 = $modelParams->setParams($xml2);
			if ($resForInsert1 != 0) {
				$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert1, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml);
				echo $result;
			} else {
				echo 'false';
			}
			if ($resForInsert2 != 0) {
				$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert2, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml);
				echo $result;
			} else {
				echo 'false';
			}
		} else if ($action == 'autoConnectLte') {
			$deviceId = $_POST['deviceID'];
			$cellIndex = $_POST['cellIndex'];
			$autoconect = $_POST['autoconect'];
			$xml = CreateXML::setForLte($cellIndex, $autoconect);
			include $_SESSION['APPPATH'] . 'models/modelParams.php';
			$modelParams = new ModelParams();
			$resForInsert = $modelParams->setParams($xml);

			if ($resForInsert != 0) {
				$getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, '', 0);
				$result = ConnectTCP::connectToGetData($getAllXml);
				echo $result;
			} else {
				echo 'false';
			}
		} else if ($action == 'refreshDeviceTab') {
            $deviceId = $_POST['deviceID'];
            $tabName = $_POST['tabName'];
            if(isset($_POST['connIndex'])) {
                $connIndex = $_POST['connIndex'];
            } else {
                $connIndex = '';
            }

            $xml = CreateXML::setForRefreshTab($connIndex, $tabName);
            include $_SESSION['APPPATH'] . 'models/modelParams.php';
            $modelParams = new ModelParams();
            $resForInsert = $modelParams->setParams($xml);

            if ($resForInsert != 0) {
                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$getSelectedParams, $deviceId, $resForInsert, '', 0);
                $result = ConnectTCP::connectToGetData($getAllXml);
                echo $result;
            } else {
                echo 'false';
            }
        }else if ($action == 'deletedUser') {
	        $userID = $_POST['userID'];
            include $_SESSION['APPPATH'] . 'models/modelUser.php';
            $user = new ModelUser();
            $delUser = $user->removeDeactivatedUsers($userID);
            $getAllXml = CreateXML::createTheXMLForRemoveUser(ActionNamesConstants::$removeUser, $userID);
            $result = ConnectTCP::connectToGetData($getAllXml);
            echo $result;
        } else if ($action == "ForServer") {
//            $xml = CreateXML::createTheXML(ActionNamesConstants::$refresh, '', "", "NoName", '');
            $result = ConnectTCP::connectToGetServerStatus();
            echo $result;
        }

	} else {
	    $result = "logged_out";
	    echo $result;
	}
    } else {
	exit('No direct script access allowed');
    }

}  catch (\Exception $e){
    error_log($e->getMessage());
    header('HTTP/1.1 500 Internal Server Error');
    header("Status: 500 Internal Server Error");
    exit();
}
