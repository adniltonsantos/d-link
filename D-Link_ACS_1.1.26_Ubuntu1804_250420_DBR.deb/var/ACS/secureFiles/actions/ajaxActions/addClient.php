<?php
function addOnlyClient($firstName, $surName, $address, $email, $patronymicName, $contractNumber, $ini_array){
    include $_SESSION['APPPATH'].'models/modelClient.php';

    $result = '';

    $client = new ModelClient();
    if ($email != "") {
        $existsCount = $client->checkEmailExist($email);
        if ($existsCount[0]->count == 0) {
            $result = $client->addOnlyClient($firstName, $surName, $address, $email, $patronymicName, $contractNumber);
            if (!$result) {
                $_SESSION['failed_sale'] = $ini_array['adding_failed'];
                $_SESSION['firstName'] = $firstName;
                $_SESSION['surName'] = $surName;
                $_SESSION['address'] = $address;
                $_SESSION['email'] = $email;
                $_SESSION['patronymicName'] = $patronymicName;
                $_SESSION['contractNumber'] = $contractNumber;
            } else {
                $_SESSION['add_client_succeed'] = $ini_array['add_client_succeed'];
            }
        } else {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['email_exist'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['patronymicName'] = $patronymicName;
            $_SESSION['contractNumber'] = $contractNumber;
        }
    } else {
        $result = $client->addOnlyClient($firstName, $surName, $address, $email,$patronymicName, $contractNumber);
        if (!$result) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['patronymicName'] = $patronymicName;
            $_SESSION['contractNumber'] = $contractNumber;
        } else {

            $_SESSION['add_client_succeed'] = $ini_array['add_client_succeed'];
        }
    }
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
    
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
if (isset($_SESSION['logged_in'])) {
    try{
        define('BASEPATH', $_SESSION['BASEPATH']);
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file( $_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file( $_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
        $firstName = "";
        $surName = "";
        $address = "";
        $email = "";
        $patronymicName = "";
        $contractNumber = "";
        if(isset($_POST['firstName'])){ $firstName = $_POST['firstName'];}
        if(isset($_POST['surName'])){ $surName = $_POST['surName'];}
        if(isset($_POST['address'])){  $address = $_POST['address'];}
        if(isset($_POST['email'])){ $email = $_POST['email'];}
        if(isset($_POST['patronymicName'])){  $patronymicName = $_POST['patronymicName'];}
        if(isset($_POST['contractNumber'])){ $contractNumber = $_POST['contractNumber'];}
        $allValid = true;
        if ($firstName != "" && $surName != "") {
            if ($email != "") {
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $allValid=false;
                    $_SESSION['failed_sale'] = $ini_array['invalid_email'];
                    $_SESSION['firstName'] = $firstName;
                    $_SESSION['surName'] = $surName;
                    $_SESSION['address'] = $address;
                    $_SESSION['email'] = $email;
                    $_SESSION['patronymicName'] = $patronymicName;
                    $_SESSION['contractNumber'] = $contractNumber;
                }
            }
        } else {
            $allValid=false;
            $_SESSION['failed_sale'] = $ini_array['client_required_fields'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['patronymicName'] = $patronymicName;
            $_SESSION['contractNumber'] = $contractNumber;
        }

        if($allValid){
            addOnlyClient($firstName, $surName, $address, $email,$patronymicName, $contractNumber,$ini_array);
        }
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 
} else {
    $result = "logged_out";
    echo $result;
}
} else {
    exit('No direct script access allowed');
}
