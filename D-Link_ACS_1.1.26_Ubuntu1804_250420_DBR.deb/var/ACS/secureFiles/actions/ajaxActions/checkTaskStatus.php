<?php
function readAcsSettings()
{
    $settingsFile = '/etc/acs/config/acs.conf';
    $content = file_get_contents($settingsFile);
    $contentArray = explode("\n", $content);
    $settingsArray = array();
    foreach($contentArray as $setting)
    {
        list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
        if ($value !== NULL)
        {
            $settingsArray[trim($key)] = trim($value);
        }
    }
    return $settingsArray;
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {session_start();}

    if (isset($_SESSION['logged_in'])) {
        try{
            $deviceTaskStatuses =array();
            define('BASEPATH', $_SESSION['BASEPATH']);
            require_once $_SESSION['APPPATH'].'models/device.php';
            $dev = new Device();
            $deviceStatuses = array();
            if (isset($_POST['actionName']) && $_POST['actionName'] == 'getTaskStatuses') {
                $deviceID = $_POST['deviceID'];
                $taskStatuses = $dev->getTaskStatusDevisesByID($deviceID);
                foreach ($taskStatuses as $taskStatus){
                    if(isset($taskStatus->operation_status)) {
                        $deviceTaskStatuses[$taskStatus->device_id] = $taskStatus->operation_status;
                    } else {
                        $deviceTaskStatuses[$taskStatus] = null;
                    }
                }
            } else if(isset($_POST['actionName']) && $_POST['actionName'] == 'getTaskNames'){
                $deviceID = $_POST['deviceID'];
                $taskStatuses = $dev->getTaskStatusDevisesByID($deviceID);
                foreach ($taskStatuses as $taskStatus){
                    if(isset($taskStatus->type_name)) {
                        $deviceTaskStatuses[$taskStatus->device_id] = $taskStatus->type_name;
                    } else {
                        $deviceTaskStatuses[$taskStatus] = null;
                    }
                }
            }  else if(isset($_POST['actionName']) && $_POST['actionName'] == 'lastTaskNames') {
                $deviceID = $_POST['deviceID'];
                $taskStatuses = $dev->getDevicesLastTaskStatusesById($deviceID);
                if(!empty($taskStatuses)) {
                    if ($taskStatuses[0]->operation_type_id == 9 && ($taskStatuses[0]->operation_status == 0 || $taskStatuses[0]->operation_status == 1)) {
                        $deviceTaskStatuses = array("result" => 'false');
                    } else {
                        $deviceTaskStatuses = array("result" => 'true');
                    }
                } else {
                    $deviceTaskStatuses = array("result" => 'true');
                }
            } else if (isset($_POST['actionName']) && $_POST['actionName'] == "getHeartStatuses") {
                $deviceID = $_POST['deviceID'];
                $time = array();
                $HeartINT = $dev->getDevHeartInter();
                $HeartWAR = $dev->getDevHeartWar();
                $HeartERR = $dev->getDevHeartErr();
                if (isset($HeartINT[0]->settings_value) && isset($HeartWAR[0]->settings_value) && isset($HeartERR[0]->settings_value)) {
                    $success = $HeartINT[0]->settings_value;
                    $warning = $HeartWAR[0]->settings_value;
                    $error = $HeartERR[0]->settings_value;
                    $LastInformTime = $dev->getDeviceLastInformTime($deviceID);
                    $CurrentTime = strtotime(date("M d Y H:i:s")) / 60;

                    foreach ($LastInformTime as $LastTime) {
                        $DeviceLastInfTime = strtotime($LastTime->last_inform_time) / 60;
                        $lastInfTime = $CurrentTime - $DeviceLastInfTime;
                        if ($lastInfTime < ($success + $warning)) {
                            $deviceTaskStatuses[$LastTime->id] = 1;
                        } else if ($lastInfTime >= ($success + $warning) && $lastInfTime < ($warning + $error + $success)) {
                            $deviceTaskStatuses[$LastTime->id] = 2;
                        } else if ($lastInfTime >= ($warning + $error + $success)) {
                            $deviceTaskStatuses[$LastTime->id] = 3;
                        }
                    }
                } else {
                    $LastInformTime = $dev->getDeviceLastInformTime($deviceID);
                    foreach ($LastInformTime as $LastTime) {
                        $deviceTaskStatuses[$LastTime->id] = 0;
                    }
                }
            } else if(isset($_POST['actionName']) && $_POST['actionName'] == "getSLAForDevice") {
                $settings = readAcsSettings();
                if(isset($settings['SLAPort']) && isset($settings['SLAIP'])) {
                    $urlSLA = $settings['SLAIP'] . ':' . $settings['SLAPort'];
                    $ch = curl_init($urlSLA . "/api/macs");
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $response = curl_exec($ch);
                        if($response) {
                            $allMACs = json_decode($response);
                            $deviceMACs = $_POST['deviceMAC'];
                            for ($j = 0; $j < count($deviceMACs); $j++) {
                                for ($i = 0; $i < count($allMACs); $i++) {
                                    if (strcasecmp($deviceMACs[$j] , $allMACs[$i])==0) {
                                        $macDate = curl_init($urlSLA . "/api/timerange/" . $allMACs[$i]);
                                        curl_setopt($macDate, CURLOPT_RETURNTRANSFER, true);
                                        $responseDate = curl_exec($macDate);
                                        $date = json_decode($responseDate);
                                        $deviceTaskStatuses[$allMACs[$i]] = $date[1];
                                        break;
                                    } else {
//                                        $deviceTaskStatuses[$deviceMACs[$j]] = '';
                                    }
                                }
                            }
                        }
                } else {
                    $deviceTaskStatuses = '';
                }
            } else {
                $deviceTaskStatuses = '';
            }

            echo json_encode($deviceTaskStatuses);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $status = "logged_out";
        echo $status;
    }
} else {
    exit('No direct script access allowed');
}