<?php


if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $action = $_POST['actionName'];
            require_once $_SESSION['APPPATH'].'models/device.php';
            $dev = new Device();
            if($action == "getModelChart") {
                $models = $dev->getAllModelsId();
                $countDev = array();
                $nameModel = array();
                $hwVersionModel = array();
                $model = array();
                $x=0;
                $modelsCount = $dev->getAllModelsCount();
                for ($i = 0; $i < $modelsCount[0]->count; $i++) {
                    $a = array();
                    $index = $models[$i]->id;
                    $count = $dev->getDevicesByModels($index);
                    if ($count[0]->count > 0) {
                        $name = $dev->getAllModelsName($index);
                        $countDev[$x] = $count[0]->count;
                        $nameModel[$x] = $name[0]->name;
                        $hwVersionModel[$x] = $name[0]->hw_version;
                        $a = array($nameModel[$x] ." - ". $hwVersionModel[$x] , $countDev[$x]);
                        array_push($model, $a);
                        $x++;
                    }
                }
                $noHaveModel = $dev->getAllDevCountIsModelNull();
                if(!empty($noHaveModel)) {
                    $countDev[$x] = $noHaveModel[0]->count;
                    $nameModel[$x] = "Other";
                    $noModel = array($nameModel[$x], $countDev[$x]);
                    array_push($model, $noModel);
                }
                $result =  json_encode($model);
                echo $result;
            } else if ($action == "getHeartbeatChart") {
                $HeartINT = $dev->getDevHeartInter()[0]->settings_value;
                $HeartWAR = $dev->getDevHeartWar()[0]->settings_value;
                $HeartERR = $dev->getDevHeartErr()[0]->settings_value;
                $statusHeartbeath = array();
                $nameHeartbeath = array();
                $colorHeartbeath = array();
                $getDevLastTime = $dev->getDevWithInterval();
                $getDevicesStatusOfSuccess = 0;
                $getDevicesStatusOfWeting = 0;
                $getDevicesStatusOfError = 0;
                $CurrentTime = strtotime(date("M d Y H:i:s")) / 60;
                for($i=0; $i <count($getDevLastTime); $i++) {
                    $DeviceLastInfTime = strtotime($getDevLastTime[$i]->last_inform_time) / 60;
                    $lastInfTime = $CurrentTime - $DeviceLastInfTime;
                    if ($lastInfTime < ($HeartINT + $HeartWAR)) {
                        $getDevicesStatusOfSuccess +=1;
                    } else if ($lastInfTime >= ($HeartINT + $HeartWAR) && $lastInfTime < ($HeartWAR + $HeartERR + $HeartINT)) {
                        $getDevicesStatusOfWeting +=1;
                    } else if ($lastInfTime >= ($HeartWAR + $HeartERR + $HeartINT)) {
                        $getDevicesStatusOfError +=1;
                    }
                }
                $success = array("Success", $getDevicesStatusOfSuccess);
                $weiting = array("Waiting", $getDevicesStatusOfWeting);
                $error = array("Error", $getDevicesStatusOfError);
                array_push($statusHeartbeath, $success);
                array_push($statusHeartbeath, $weiting);
                array_push($statusHeartbeath, $error);
                $result =  json_encode($statusHeartbeath);
                echo $result;
            } else if($action == "getUnknownPendingChart") {
                require_once $_SESSION['APPPATH'] . 'models/modelClient.php';
                $client = new ModelClient();
                $countDevUnkn = true;
                $UnknownPendingDevices = array();
                $getUnknownDevices = $client->getAllUnknowns();
                $getPendingDevices = $client->getAllPending();
                $getUnknownDevicesCount = count($getUnknownDevices);
                $getPendingDevicesCount = count($getPendingDevices);
                if($getUnknownDevicesCount == 0 && $getPendingDevicesCount==0) {
                    $countDevUnkn = false;
                } else {
                    $countDevUnkn = true;
                }
                array_push($UnknownPendingDevices, array("Unknown", $getUnknownDevicesCount));
                array_push($UnknownPendingDevices, array("Pending", $getPendingDevicesCount));
                $result =  json_encode($UnknownPendingDevices);
                echo $result;
            }

        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
