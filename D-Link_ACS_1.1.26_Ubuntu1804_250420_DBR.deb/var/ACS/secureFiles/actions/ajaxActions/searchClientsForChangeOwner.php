<?php
if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    function strpos_all($haystack, $needle) {
        $offset = 0;
        $allpos = array();
        while (($pos = strpos($haystack, $needle, $offset)) !== FALSE) {
            $offset   = $pos + 1;
            $allpos[] = $pos;
        }
        return $allpos;
    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'].'models/modelClient.php';
            include $_SESSION['APPPATH'].'util/pagingConstants.php';
            $firstName = '';
            $surName = '';
            $page = 0;
            $deviceId=0;
            if (isset($_POST['firstName'])) {
                $firstName = $_POST['firstName'];
                $indexes = strpos_all($firstName, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($firstName,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);
                $firstName = $stringClientInfor;
            }
            if (isset($_POST['surName'])) {
                $surName = $_POST['surName'];
                $indexes = strpos_all($surName, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($surName,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);
                $surName = $stringClientInfor;
            }
            if (isset($_POST['page'])) {
                $page = $_POST['page'];
            }
            if(isset($_POST['deviceId'])){
                $deviceId=$_POST['deviceId'];
            }
            $limit = PagingConstants::$clientsCount;
            $offset = ($page - 1) * $limit;
            $client = new ModelClient();
            $clients = $client->searchClientByFirstSurWithDeviceOwner($deviceId,$firstName, $surName, $limit, $offset);

            $allClientsCount = $client->getAllClientsCountByFirstNSurN($firstName, $surName);
            $clientsCount = $allClientsCount[0]->count;
            if ($clientsCount < $limit) {
                $pagesCount = 1;
            } else {
                if ($clientsCount % $limit == 0) {
                    $pagesCount = $clientsCount / $limit;
                } else {
                    $pagesCount = ($clientsCount / $limit - ($clientsCount % $limit) * (1 / $limit)) + 1;
                }
            }

            include $_SESSION['APPPATH'].'views/content/admin/searchedClientsForChangeOwner.php';
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}