<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out"; exit();
//        }
//    }
    if (isset($_SESSION['logged_in'])) {
        try{ define('BASEPATH', $_SESSION['BASEPATH']);
            $mac = '0';
            $model = '0';
            $task = '0';
            $status = '-1';
            $createTime = '';
            $selectTime = '0';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter = array('mac'=> $mac, 'model' => $model, 'task' => $task, 'status' => $status, 'createTime' => $createTime, 'selectTime' => $selectTime);
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }  catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out"; echo $result;
    }
} else {
    exit('No direct script access allowed');
}
?>

