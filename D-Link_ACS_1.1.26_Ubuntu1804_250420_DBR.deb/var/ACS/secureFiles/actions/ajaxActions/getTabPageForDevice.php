<?php
function changeParamNameForHosts($param){
    $changedParamName='';
    $nameParts = explode(".Hosts.", $param);
    if(strpos($nameParts[0],'LANDevice')>0){
            $changedParamName=" LAN interface ";

    }  else {
        $changedParamName=$nameParts[0];
    }

        $changedParamName.=str_replace("."," ",$nameParts[1]);




    return $changedParamName;
}

function changeParamNameForStats($param){
    $changedParamName='';
    $nameParts = explode(".Stats.", $param);
    $nameParts1=explode(".", $nameParts[0]);
    if($nameParts1[1]=='LANDevice'){
        if($nameParts1[3]=='LANEthernetInterfaceConfig'){
            $changedParamName="Ethernet LAN interface ".' Port '.$nameParts1[4]." ".$nameParts[1];
        } elseif ($nameParts1[3]=='WLANConfiguration'){
            $changedParamName=' LAN interface WiFi SSID '.$nameParts1[4]." ".$nameParts[1];
        } elseif ($nameParts1[3]=='LANUSBInterfaceConfig'){
            $changedParamName=" USB LAN interface".' Port '.$nameParts1[4]." ".$nameParts[1];
        } else {
            $changedParamName=$nameParts[0];
        }

    } elseif ($nameParts1[1]=='WANDevice'){
        if($nameParts1[3]=='WANEthernetInterfaceConfig'){
            $changedParamName="Ethernet WAN interface ".$nameParts[1];
        } elseif ($nameParts1[3]=='WANConnectionDevice' ){
            if( $nameParts1[5]=='WANIPConnection'){
                $changedParamName=' IP connection WAN interface Port '.$nameParts1[4]." ".$nameParts[1];
            } elseif ( $nameParts1[5]=='WANPPPConnection') {
                $changedParamName=' PPP connection WAN interface Port '.$nameParts1[4]." ".$nameParts[1];
            } else {
                $changedParamName=$nameParts[0];
            }
        } elseif ($nameParts1[3]=='WANDSLInterfaceConfig'){
            $changedParamName=' WAN interface DSL '." ".$nameParts[1];
        }  else {
            $changedParamName=$nameParts[0];
        }
    }  else {
        $changedParamName=$nameParts[0];
    }
    return $changedParamName;
}

function toGetRecData($itemName, $parentItem,$neededString)
{


    foreach ($itemName AS $chiItem) {
        $chNodName = $chiItem->nodeName;

        if ($chNodName != "#text") {
            $childCou = $chiItem->childNodes;
            toGetRecData($childCou, $chiItem,$neededString);

        } else {
            $arrr = array();
            if ($parentItem->nodeName == "Name") {
                $value = $parentItem->nodeValue;
                if (strpos($value, $neededString)) {
                    //   $GLOBALS['isNeeded']=true;
                    $parent = $parentItem->parentNode;
                    $childCou = $parent->childNodes;
                    foreach ($childCou AS $chiItem) {
                        $chNodName = $chiItem->nodeName;
                        if ($chNodName == "Value") {
                            $value1 = $chiItem->nodeValue;
                            if ($neededString == "Stats"){
                                if ($value1 != 0) {
                                    $value=changeParamNameForStats($value);
                                    $arrr['name'] = $value;
                                    $arrr['value'] = $value1;
                                    $GLOBALS['myArr'][] = $arrr;
                                }
                            } else {
                                $value=changeParamNameForHosts($value);
                                $arrr['name'] = $value;
                                $arrr['value'] = $value1;
                                $GLOBALS['myArr'][] = $arrr;
                            }
                        }
                    }

                }
            }
        }
    }
}

function parseXmlInterfaces($serialNumber, $devId, $page)
{

    $GLOBALS['myArr'] = array();

    $xmlFile = $_SESSION['REALPATH'] . "tmp" . "/" . $serialNumber . "_value.xml";

    if (file_exists($xmlFile)) {
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $xmlDoc = new DOMDocument();
        $xmlDoc->load($xmlFile);
        $xmlDoc->formatOutput = true;
        $x = $xmlDoc->documentElement;

        $GLOBALS['myArr'] = array();
        //$GLOBALS['isNeeded']=false;

        if ($x != '' && $x->nodeName != '') {
            foreach ($x->attributes as $attr) {
                $name = $attr->nodeName;
                $value = $attr->nodeValue;

            }
            foreach ($x->childNodes AS $item) {
                $itemName = $item->nodeName;
                //    var_dump($itemName);echo "          ";

                if ($itemName != "#text" && $itemName != "SOAP-ENV:Header") {
                    $childCo = $item->childNodes;
                    toGetRecData($childCo, $item, "Stats");
                }
            }
        } else {
            //var_dump($x);
        }

//
//
//
//        $fieldsArray = array();
//        $fieldsVals = array();
//        $GLOBALS['nArr'] = array();
//        $fieldsArray[] = 'Name';
//        $prevElem = '';
//        foreach ($GLOBALS['myArr'] as $arr) {
//            $nameParts = explode(".Stats.", $arr['name']);
//            //  echo " next myArr " . $nameParts[0] . " " . $nameParts[1] . '    ';
//            $lastIndex = count($fieldsVals) - 1;
//
//            if ($prevElem == "") {
//                //  echo "started the first element  " . $nameParts[0] . " ";
//                array_push($fieldsVals, $nameParts[0]);
//            } else {
//
//                if ($prevElem != "" && $prevElem != $nameParts[0]) {
//                    //   echo "finded new element  " . $nameParts[0] . " ";
//
//                    // if(isArrayElementEmpty($fieldsVals)) {
//                    array_push($GLOBALS['nArr'], $fieldsVals);
//
//                    unset($fieldsVals);
//                    $fieldsVals = array();
//                    array_push($fieldsVals, $nameParts[0]);
//                }
//            }
//            if (!in_array($nameParts[1], $fieldsArray)) {
//                $pos = strpos($nameParts[1], "Ethernet");
//                if ($pos === false) {
//                    $fieldsArray[] = $nameParts[1];
//                }
//            }
//            array_push($fieldsVals, $arr['value']);
//            $prevElem = $nameParts[0];
//        }

        $params = $GLOBALS['myArr'];
        $allCount = count($params);
        $params = array_slice($params, $offset, $limit);
        $count = count($params);

        if ($allCount % $limit == 0) {
            $pagesCount = $allCount / $limit;
        } else {
            $pagesCount = ($allCount / $limit - ($allCount % $limit) * (1 / $limit)) + 1;
        }
    } else {
        $params=false;
        $allCount=0;
        $count=0;
    }

    ////for testing

    include $_SESSION['APPPATH'] . 'views/content/admin/statisticInterfacesForDevice.php';
}

function parseXmlHosts($serialNumber, $devId, $page)
{

    $GLOBALS['myArr'] = array();

    $xmlFile = $_SESSION['REALPATH'] . "tmp" . "/" . $serialNumber . "_value.xml";

    if (file_exists($xmlFile)) {
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $xmlDoc = new DOMDocument();
        $xmlDoc->load($xmlFile);
        $xmlDoc->formatOutput = true;
        $x = $xmlDoc->documentElement;

        $GLOBALS['myArr'] = array();
        //$GLOBALS['isNeeded']=false;

        if ($x != '' && $x->nodeName != '') {
            foreach ($x->attributes as $attr) {
                $name = $attr->nodeName;
                $value = $attr->nodeValue;

            }
            foreach ($x->childNodes AS $item) {
                $itemName = $item->nodeName;
                //    var_dump($itemName);echo "          ";

                if ($itemName != "#text" && $itemName != "SOAP-ENV:Header") {
                    $childCo = $item->childNodes;
                    toGetRecData($childCo, $item,"Hosts");
                }
            }
        } else {
        }

        $params = $GLOBALS['myArr'];
        $allCount = count($params);
        $params = array_slice($params, $offset, $limit);
        $count = count($params);

        if ($allCount % $limit == 0) {
            $pagesCount = $allCount / $limit;
        } else {
            $pagesCount = ($allCount / $limit - ($allCount % $limit) * (1 / $limit)) + 1;
        }


    }else {
        $params=false;
        $allCount=0;
        $count=0;
    }
    include $_SESSION['APPPATH'] . 'views/content/admin/statisticClientsForDevice.php';
}

function readAcsSettings()
{
    $settingsFile = '/etc/acs/config/acs.conf';
    $content = file_get_contents($settingsFile);
    $contentArray = explode("\n", $content);
    $settingsArray = array();
    foreach ($contentArray as $setting) {
        list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
        if ($value !== NULL) {
            $settingsArray[trim($key)] = trim($value);
        }
    }
    return $settingsArray;
}

function convertUnixTimestamp($time)
{
    date_default_timezone_set("UTC");

    $date = DateTime::createFromFormat('Y-m-d\TH:i:s.u', $time);
    if($date) {
        $seconds = $date->getTimestamp() * 1000000 + intval($date->format("u"));
        return $seconds;
    } else {
        return false;
    }
}

function getStatisticByID($deviceID, $dev)
{
    $statistic = $dev->getStatisticByID($deviceID);
    return $statistic;
}

function getStatistics($deviceID, $dev)
{
    $statistic = $dev->getStatistics($deviceID);
    return $statistic;
}

function devInfoByID($deviceID, $dev)
{
    $device = $dev->devInfoByID($deviceID);

    return $device;
}

function devLteByID($deviceID, $dev)
{
    $device = $dev->devLTEByID($deviceID);

    return $device;
}

function getLanParams($deviceSerial)
{

//    include $_SESSION['APPPATH'].'models/modelParams.php';
    $modParams = new ModelParams();
    $params = $modParams->getLanParams($deviceSerial);
    return $params;
}

function getLanV6Params($deviceSerial)
{

//    include $_SESSION['APPPATH'].'models/modelParams.php';
    $modParams = new ModelParams();
    $params = $modParams->getLanV6Params($deviceSerial);
    return $params;
}


function getConnectedDevices($deviceId, $type)
{
    if (!class_exists("ModelParams")) {
        require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
    }
    $modParams = new ModelParams();
    $params = $modParams->getDevicesToConnectInRouter($deviceId, $type);
    return $params;
}

function getWlanBSSIDs($deviceId)
{
    if (!class_exists("ModelParams")) {
        require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
    }
    $modParams = new ModelParams();
    $params = $modParams->getWlanBSSIDs($deviceId);
    return $params;
}

function getVlanParams($deviceSerial)
{
    include $_SESSION['APPPATH'] . 'models/modelParams.php';
    $modParams = new ModelParams();
    $params = $modParams->getVlanParams($deviceSerial);
    return $params;
}

function getVoipParams($deviceSerial)
{
    include_once $_SESSION['APPPATH'] . 'models/modelParams.php';
    $modParams = new ModelParams();
    $params = $modParams->getVoipParams($deviceSerial);
    return $params;
}


//function getVoipLineParams($deviceSerial, $voipnumIndex)
//{
//    include_once $_SESSION['APPPATH'].'models/modelParams.php';
//    $modParams = new ModelParams();
//    $params = $modParams->getVoipLineParams($deviceSerial, $voipnumIndex);
//    return array_reverse($params);
//}

function getAllWanParams($serialN)
{
    if (!class_exists('ModelParams')) {
        require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
    }
    $modParams = new ModelParams();
    $params = $modParams->getAllWanParams($serialN);
    return $params;
}

function getAllHostAndTracert()
{

    if (!class_exists('ModelParams')) {
        require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
    }

    $modParams = new ModelParams();
    $allHosts = $modParams->getAllHostsAndTracerts();
    return $allHosts;
}

function getWLanParams($deviceSerial)
{
    include $_SESSION['APPPATH'] . 'models/modelParams.php';

    $modParams = new ModelParams();
    $params = $modParams->getWLanParams($deviceSerial);
    return $params;
}

function getWLanParamsByFrequencyBand($deviceSerial, $frequencyBand)
{
//    include $_SESSION['APPPATH'].'models/modelParams.php';

    $modParams = new ModelParams();
    $params = $modParams->getWLanParamsByFrequencyBand($deviceSerial, $frequencyBand);
    return $params;
}

function getWirelessParam($wlanId)
{
    require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
    $modParams = new ModelParams();
    $params = $modParams->getWirelessParam($wlanId);
    return $params;
}

function getWirelessStandartParam($wlanId)
{
    require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
    $modParams = new ModelParams();
    $params = $modParams->getWLanStandartParams($wlanId);
    return $params;
}

function getAvailablePorts($deviceID, $dev)
{

    $lanPortsCount = $dev->getLanPorts($deviceID);
    $wlanPortsCount = $dev->getWlanPorts($deviceID);
    $availablePorts = array();
    $lanPorts = array();
    $wlanPorts = array();
    if (isset($lanPortsCount[0]->count)) {
        if ($lanPortsCount[0]->count && $lanPortsCount[0]->count > 0) {
            for ($i = 1; $i <= $lanPortsCount[0]->count; $i++) {
                $lanPorts['LAN' . $i] = $i;
            }
        }
    }

    if (isset($wlanPortsCount[0]->count)) {
        if ($wlanPortsCount[0]->count && $wlanPortsCount[0]->count > 0) {
            for ($i = 1; $i <= $wlanPortsCount[0]->count; $i++) {
                $wlanPorts['WLAN' . $i] = $i;
            }
        }
    }

    $allPorts = array_merge($lanPorts, $wlanPorts);
    $ports = $dev->getAllVlanPorts($deviceID);

    if (is_array($ports) && !empty($ports)) {
        foreach ($ports as $port) {
            $portsArray[$port->vlan_port_name . $port->vlan_port_number] = (int)$port->vlan_port_number;
        }
        $availablePorts = array_diff_key($allPorts, $portsArray);
        return $availablePorts;

    } else {
        return $allPorts;
    }
}


if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }


    if (isset($_SESSION['logged_in'])) {
        try {
            $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
            if (isset($_SESSION['lang'])) {
                $lang = $_SESSION['lang'];
                if ($lang == 'en') {
                    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
                } else {
                    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
                }
            }

            define('BASEPATH', $_SESSION['BASEPATH']);
            $deviceID = $_POST['deviceID'];
            $serialN = $_POST['serialNumber'];
            $actionName = $_POST['actionName'];
            $deviceStatus = $_POST['devStatus'];
            $isRunningRefresh = 'false';
            $havePerms = $_POST['havePermissions'];
            $_SESSION['activeTab'] = $actionName;
            if (isset($_POST['isRunningRefresh'])) {
                $isRunningRefresh = $_POST['isRunningRefresh'];
            }
            include $_SESSION['APPPATH'] . 'util/usersConstants.php';

            //        if($actionName == 'wan'){
            //            if(!isset( $_SESSION['activeWanTab'])){
            //                $_SESSION['activeWanTab'] = "staticIP";
            //            }
            //        }


            if ($actionName == 'info') {
                if (!class_exists("ModelParams")) {
                    require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
                }
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                $dev = new Device();
                $settings = readAcsSettings();
                $macDateSLA = '';
                $lanPorts = $dev->getLanPorts($deviceID);
                $clientCount = $dev->getClientCount($deviceID);
                $device = devInfoByID($deviceID, $dev);
                $statistic = getStatisticByID($deviceID, $dev);
                $modParams = new ModelParams();
                $params = $modParams->readIGMP($serialN);
                $remote = $modParams->getRemoteAccess($serialN);
                $devID = $_POST['deviceID'];
                $macAddress = $_POST['macAddress'];
                $statusSLA = false;
                $serialSLA = '';
                if (isset($settings['SLAPort']) && isset($settings['SLAIP'])) {
                    $urlSLA = $settings['SLAIP'] . ':' . $settings['SLAPort'];
                    $ch = curl_init($urlSLA . "/api/macs");
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $response = curl_exec($ch);
                    if ($response) {
                        $allMACs = json_decode($response);
                        for ($i = 0; $i < count($allMACs); $i++) {
                            if (strcasecmp($allMACs[$i], $macAddress) == 0) {
                                $statusSLA = true;
                                $macDate = curl_init($urlSLA . "/api/timerange/" . $allMACs[$i]);
                                curl_setopt($macDate, CURLOPT_RETURNTRANSFER, true);
                                $responseDate = curl_exec($macDate);
                                $date = json_decode($responseDate);
                                $serialSLA = $allMACs[$i];
                                $macDateSLA = $date[1];
                                break;
                            } else {
                                $statusSLA = false;
                            }
                        }
                    }
                }
                $lteParams = $modParams->getLTE($devID);
                if ($lanPorts) {
                    $remote_access = array("remoteAccessEnable" => $remote[0]->remote_access_enable, "remoteAccessPort" => $remote[0]->remote_access_port);
                }

                if ($actionName == 'info' && !empty($lteParams)) {
                    $lteDevice = devLteByID($deviceID, $dev);
                }

                require_once $_SESSION['APPPATH'] . 'views/content/admin/infoPageForDevice.php';

            } else if ($actionName == 'lan') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                $dev = new Device();
                $device = devInfoByID($deviceID, $dev);
                include $_SESSION['APPPATH'] . 'models/modelParams.php';

                $paramsFromModel = getLanParams($serialN);
                $paramsFromModelV6 = getLanV6Params($serialN);

                if ($paramsFromModel) {
                    $connectedDevices = getConnectedDevices($paramsFromModel[0]->device_id, 'LAN');

                    $params = array("ipAddr" => array("IPRouters", $paramsFromModel[0]->ip_routers),
                        "netmask" => array("SubnetMask", $paramsFromModel[0]->subnet_mask),
                        "mode" => array("DHCPServerEnable", $paramsFromModel[0]->dhcp_server_enable),
                        "dns-relay" => array("DHCPRelay", $paramsFromModel[0]->dhcp_relay),
                        "startIp" => array("MinAddress", $paramsFromModel[0]->min_address),
                        "endIP" => array("MaxAddress", $paramsFromModel[0]->max_address),
                        "leaseTime" => array("DHCPLeaseTime", ($paramsFromModel[0]->dhcp_lease_time)),
                        "externalDHCP" => array("X_DLINK_DHCPExternalServerIPAddress", ($paramsFromModel[0]->ext_dhcp_server_ip)),
                        "valueChange" => $paramsFromModel[0]->value_change);
                } else {
                    $connectedDevices = array();
                    $params = array("ipAddr" => array("IPRouters", ''),
                        "netmask" => array("SubnetMask", ''),
                        "mode" => array("DHCPServerEnable", ''),
                        "dns-relay" => array("DHCPRelay", ''),
                        "startIp" => array("MinAddress", ''),
                        "endIP" => array("MaxAddress", ''),
                        "externalDHCP" => array("X_DLINK_DHCPExternalServerIPAddress", ''),
                        "leaseTime" => array("DHCPLeaseTime", 0), "valueChange" => 0,
                        "valueChange" => '');
                }

                require_once $_SESSION['APPPATH'] . 'views/content/admin/lanPageForDevice.php';


            } else if ($actionName == 'wan') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                include $_SESSION['APPPATH'] . 'models/modelParams.php';

                $modParams = new ModelParams();
                $dev = new Device();
                $wanParamsInDualIfac = $modParams->getAllWanIpoeParamsInDualIfac($deviceID);
                $dualIfacs = array();
                foreach ($wanParamsInDualIfac as $dualIfac) {
                    array_push($dualIfacs, trim(str_replace(":", "", $dualIfac->dual_ifac)));
                }

                $device = devInfoByID($deviceID, $dev);
                $wanParamsIPv4Array = $modParams->getAllWanParamsIPv4($serialN, $dualIfacs);
                $wanParamsIPv6Array = $modParams->getAllWanParamsIPv6($serialN, $dualIfacs);

                require_once $_SESSION['APPPATH'] . 'views/content/admin/wanPageForDevice1.php';

            } else if ($actionName == 'vlan') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                $dev = new Device();
                $device = devInfoByID($deviceID, $dev);
                $vlanParamsArray = getVlanParams($serialN);
                $port_count = getAvailablePorts($deviceID, $dev);

                require_once $_SESSION['APPPATH'] . 'views/content/admin/vlanPageForDevice.php';

            } else if ($actionName == 'statisticRouting') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $devID = $_POST['deviceID'];
                $dev = new Device();
                $device = devInfoByID($devID, $dev);
                $statistics = getStatistics($deviceID, $dev);
                require_once $_SESSION['APPPATH'] . 'views/content/admin/statisticsPageForDevice.php';
            } else if ($actionName == 'statisticInterfaces') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $devID = $_POST['deviceID'];
                $dev = new Device();
                $device = devInfoByID($devID, $dev);
                if (!isset($_POST['page'])) {
                    $page = 1;
                } else {
                    $page = $_POST['page'];
                }
                parseXmlInterfaces($device[0]->serial_number, $device[0]->id, $page);
            } else if ($actionName == 'statisticClients') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $devID = $_POST['deviceID'];
                $dev = new Device();
                $device = devInfoByID($deviceID, $dev);
                if (!isset($_POST['page'])) {
                    $page = 1;
                } else {
                    $page = $_POST['page'];
                }
                parseXmlHosts($device[0]->serial_number ,$device[0]->id, $page);


               // require_once $_SESSION['APPPATH'] . 'views/content/admin/statisticClientsForDevice.php';
            } else if ($actionName == 'voip') {
                $editVoip = 0;
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                $dev = new Device();
                $device = devInfoByID($deviceID, $dev);
                $voipParams = getVoipParams($serialN);
                if (!empty($voipParams)) {
                    require_once $_SESSION['APPPATH'] . 'views/content/admin/voipPageForDevice.php';
                }

            } else if ($actionName == 'lte') {
                include $_SESSION['APPPATH'] . 'models/device.php';
                include $_SESSION['APPPATH'] . 'models/modelParams.php';
                $dev = new Device();
                $lteDevice = devLteByID($deviceID, $dev);
                $device = devInfoByID($deviceID, $dev);
                $modParams = new ModelParams();
                $uploadDownload = array();
//                $connIndexArr = $modParams->getConnIndexOfDeviceBySerial($serialN);
//                $connIndex = 1;
//                if (!empty($connIndexArr)) {
//                    $connIndex = $connIndexArr[0]->conn_index;
//                } else {
//                    $connIndex = 1;
//                }
//                $index = 1;

                $wanType = 2;
                $diagnostic = $modParams->getPingResultsForWan($deviceID, $lteDevice[0]->dev_index, $wanType);
                if (!empty($diagnostic)) {
                    $failCount = $diagnostic[0]->received;
                    $successCount = $diagnostic[0]->sent;
                    $lost = 0;

                    if ($failCount + $successCount != 0) {
                        $lost = $failCount / ($failCount + $successCount) * 100;
                    }
                    $min = $diagnostic[0]->minimum;
                    $max = $diagnostic[0]->maximum;
                    $average = $diagnostic[0]->average;
                }

                $i = 0;
                $uploadResult = $modParams->getUploadResultsForWan($deviceID, $lteDevice[0]->dev_index, $wanType);
                if (!empty($uploadResult)) {
                    foreach ($uploadResult as $uploadRes) {
                        $rom_time = $uploadRes->rom_time == NULL ? 0 : convertUnixTimestamp($uploadRes->rom_time);
                        $bom_time = $uploadRes->bom_time == NULL ? 0 : convertUnixTimestamp($uploadRes->bom_time);
                        $eom_time = $uploadRes->eom_time == NULL ? 0 : convertUnixTimestamp($uploadRes->eom_time);
                        $test_bytes_received = $uploadRes->test_file_length == NULL ? 0 : $uploadRes->test_file_length;
                        $total_bytes_received = $uploadRes->total_bytes_sent == NULL ? 0 : $uploadRes->total_bytes_sent;
                        $tcp_open_request_time = $uploadRes->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadRes->tcp_open_request_time);
                        $tcp_open_response_time = $uploadRes->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadRes->tcp_open_response_time);

                        $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
                        $responseTime = $eom_time - $rom_time;
                        $requestRound = $bom_time - $rom_time;

                        if (($eom_time - $bom_time) != 0) {
                            $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
                        } else {
                            $responseThroughput = '';
                        }

                        if (($eom_time - $bom_time) != 0) {
                            $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
                        } else {
                            $interfaceThroughput = '';
                        }
                        $uploadDownload[$i] = array(
                            'type' => 'Upload',
                            'handshakeRound' => $handshakeRound,
                            'responseTime' => $responseTime,
                            'requestRound' => $requestRound,
                            'responseThroughput' => $responseThroughput,
                            'interfaceThroughput' => $interfaceThroughput
                        );
                        $i++;
                    }
                }


                $downloadResult = $modParams->getDownloadResultsForWan($deviceID, $lteDevice[0]->dev_index, $wanType);
                if (!empty($downloadResult)) {
                    foreach($downloadResult as $downloadRes) {
                        $rom_time = $downloadRes->rom_time == NULL ? 0 : convertUnixTimestamp($downloadRes->rom_time);
                        $bom_time = $downloadRes->bom_time == NULL ? 0 : convertUnixTimestamp($downloadRes->bom_time);
                        $eom_time = $downloadRes->eom_time == NULL ? 0 : convertUnixTimestamp($downloadRes->eom_time);
                        $test_bytes_received = $downloadRes->test_bytes_received == NULL ? 0 : $downloadRes->test_bytes_received;
                        $total_bytes_received = $downloadRes->total_bytes_received == NULL ? 0 : $downloadRes->total_bytes_received;
                        $tcp_open_request_time = $downloadRes->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadRes->tcp_open_request_time);
                        $tcp_open_response_time = $downloadRes->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadRes->tcp_open_response_time);

                        $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
                        $responseTime = $eom_time - $rom_time;
                        $requestRound = $bom_time - $rom_time;

                        if (($eom_time - $bom_time) != 0) {
                            $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
                        } else {
                            $responseThroughput = '';
                        }

                        if (($eom_time - $bom_time) != 0) {
                            $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
                        } else {
                            $interfaceThroughput = '';
                        }
                        $uploadDownload[$i] = array(
                            'type' => 'Download',
                            'handshakeRound' => $handshakeRound,
                            'responseTime' => $responseTime,
                            'requestRound' => $requestRound,
                            'responseThroughput' => $responseThroughput,
                            'interfaceThroughput' => $interfaceThroughput
                        );
                        $i++;
                    }
                }

                require_once $_SESSION['APPPATH'] . 'views/content/admin/ltePageForDevice.php';
            } else if ($actionName == 'diagnostic') {
                $i = 0;
                if (!class_exists('ModelParams')) {
                    require_once $_SESSION['APPPATH'] . 'models/modelParams.php';
                }
                $limit = 10;
                $offset = 0;
                $modParams = new ModelParams();
                $getIp = $modParams->getIPForDiagnostic();
                $getUploadFileSize = $modParams->getUploadFileSizeForDiagnostic();
                $wanParamsArray = getAllWanParams($serialN);
                $allHostAndTracerts = getAllHostAndTracert();
                $getAllPingDiagnostic = $modParams->getPingResultsForDiagnostic($deviceID, $limit, $offset);
                $getPingDiagnosticCount = $modParams->getPingResultsCountForDiagnostic($deviceID)[0]->count;
                $results = $modParams->getTracerResults($deviceID, $limit, $offset);
                $resultTracerCount = $modParams->getAllTracerResults($deviceID)[0]->count;
                $page = 1;
//                if (is_array($getAllPingDiagnostic) && count($getAllPingDiagnostic) > 0) {
//
//                    $failCount = $getAllPingDiagnostic[0]->received;
//                    $successCount = $getAllPingDiagnostic[0]->sent;
//                    $lost = 0;
//
//                    if ($failCount + $successCount != 0) {
//                        $lost = $failCount / ($failCount + $successCount) * 100;
//                    }
//                }
                if ($getPingDiagnosticCount < $limit) {
                    $pagesCountPing = 1;
                } else {
                    if ($getPingDiagnosticCount % $limit == 0) {
                        $pagesCountPing = $getPingDiagnosticCount / $limit;
                    } else {
                        $pagesCountPing = ($getPingDiagnosticCount / $limit - ($getPingDiagnosticCount % $limit) * (1 / $limit)) + 1;
                    }
                }

                if ($resultTracerCount < $limit) {
                    $pagesCountTracert = 1;
                } else {
                    if ($resultTracerCount % $limit == 0) {
                        $pagesCountTracert = $resultTracerCount / $limit;
                    } else {
                        $pagesCountTracert = ($resultTracerCount / $limit - ($resultTracerCount % $limit) * (1 / $limit)) + 1;
                    }
                }

                $uploadResult = $modParams->getUploadDiagnosticResultsForWan($deviceID);

                if (!empty($uploadResult)) {
                    foreach ($uploadResult as $uplRes) {
                        $rom_time = $uplRes->rom_time == NULL ? 0 : convertUnixTimestamp($uplRes->rom_time);
                        $bom_time = $uplRes->bom_time == NULL ? 0 : convertUnixTimestamp($uplRes->bom_time);
                        $eom_time = $uplRes->eom_time == NULL ? 0 : convertUnixTimestamp($uplRes->eom_time);
                        $test_bytes_received = $uplRes->test_file_length == NULL ? 0 : $uplRes->test_file_length;
                        $total_bytes_received = $uplRes->total_bytes_sent == NULL ? 0 : $uplRes->total_bytes_sent;
                        $tcp_open_request_time = $uplRes->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uplRes->tcp_open_request_time);
                        $tcp_open_response_time = $uplRes->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uplRes->tcp_open_response_time);

                        $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
                        $responseTime = $eom_time - $rom_time;
                        $requestRound = $bom_time - $rom_time;

                        if (($eom_time - $bom_time) != 0) {
                            $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
                        }

                        if (($eom_time - $bom_time) != 0) {
                            $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
                        }
                        $uploadDownload[$i] = array(
                            'type' => 'Upload',
                            'handshakeRound' => $handshakeRound,
                            'responseTime' => $responseTime,
                            'requestRound' => $requestRound,
                            'responseThroughput' => $responseThroughput,
                            'interfaceThroughput' => $interfaceThroughput,
                            'createDate' => $uplRes->create_date
                        );
                        $i++;
                    }
                }

                $downloadResult = $modParams->getDownloadDiagnosticResultsForWan($deviceID);
                if (!empty($downloadResult)) {
                    foreach ($downloadResult as $downloadRes) {
                        $rom_time = $downloadRes->rom_time == NULL ? 0 : convertUnixTimestamp($downloadRes->rom_time);
                        $bom_time = $downloadRes->bom_time == NULL ? 0 : convertUnixTimestamp($downloadRes->bom_time);
                        $eom_time = $downloadRes->eom_time == NULL ? 0 : convertUnixTimestamp($downloadRes->eom_time);
                        $test_bytes_received = $downloadRes->test_bytes_received == NULL ? 0 : $downloadRes->test_bytes_received;
                        $total_bytes_received = $downloadRes->total_bytes_received == NULL ? 0 : $downloadRes->total_bytes_received;
                        $tcp_open_request_time = $downloadRes->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadRes->tcp_open_request_time);
                        $tcp_open_response_time = $downloadRes->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadRes->tcp_open_response_time);

                        $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
                        $responseTime = $eom_time - $rom_time;
                        $requestRound = $bom_time - $rom_time;

                        if (($eom_time - $bom_time) != 0) {
                            $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
                        }

                        if (($eom_time - $bom_time) != 0) {
                            $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
                        }
                        $uploadDownload[$i] = array(
                            'type' => 'Download',
                            'handshakeRound' => $handshakeRound,
                            'responseTime' => $responseTime,
                            'requestRound' => $requestRound,
                            'responseThroughput' => $responseThroughput,
                            'interfaceThroughput' => $interfaceThroughput,
                            'createDate' => $downloadRes->create_date
                        );
                        $i++;
                    }
                }


                $lost = "";

                require_once $_SESSION['APPPATH'] . 'views/content/admin/diagnostic.php';
            } else if ($actionName == 'voip') {
                require_once $_SESSION['APPPATH'] . 'views/content/admin/voipPageForDevice.php';
            } else if ($actionName == 'wireless') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                $dev = new Device();
                $device = devInfoByID($deviceID, $dev);
                if (isset($_POST['fromInnerPage']) && $_POST['fromInnerPage']) {
                    if (isset($_POST['wlanId'])) {
                        $wlanId = $_POST['wlanId'];
                    }


                    $paramsFromModel = getWirelessParam($wlanId);
                    $showConnecetdDevices = false;
                    if ($paramsFromModel) {
                        if (!class_exists("ParamNamesConstants")) {
                            require_once $_SESSION['APPPATH'] . "util/wirelessModeStandarts.php";
                        }
                        if (!class_exists("ParamNamesConstants")) {
                            require_once $_SESSION['APPPATH'] . "util/UNIIRangsFor5GHz.php";
                        }
                        $wlanStandart = getWirelessStandartParam($paramsFromModel[0]->id);
                        $connectedDevices = getConnectedDevices($paramsFromModel[0]->device_id, 'WLAN');
                        $wlanBSSIDs = getWlanBSSIDs($paramsFromModel[0]->device_id);
                        $i = 0;
                        foreach ($connectedDevices as $devParam) {
                            foreach ($wlanBSSIDs as $bssid) {
                                if ($bssid->num_index == $devParam->num_id) {
                                    $connectedDevices[$i]->bssid = $bssid->bssid;
                                }
                                if ($bssid->num_index == $devParam->num_id) {
                                    $connectedDevices[$i]->ssid = $bssid->bssid;
                                }
                            }
                            $i++;
                        }

                        $params = array("id" => array("id", $paramsFromModel[0]->id),
                            "enable" => array("Enable", $paramsFromModel[0]->enable),
                            "bssid" => array("BSSID", trim(str_replace(":", "", $paramsFromModel[0]->bssid))),
                            "ssid" => array("SSID", trim($paramsFromModel[0]->ssid)),
                            "channel" => array("Channel", trim($paramsFromModel[0]->channel)),
                            "standard" => array("Standard", trim($paramsFromModel[0]->standard)),
                            "key" => array("KeyPassphrase", ''),
                            //                                "total" => array("TotalPSKFailures", trim($paramsFromModel[0]->total_psk_failures)),
                            "total" => array("X_X_DLINK_WPA_Renewal", trim($paramsFromModel[0]->total_psk_failures)),
                            "networkAuth" => array("", trim($paramsFromModel[0]->network_authentication)),
                            "valueChange" => $paramsFromModel[0]->value_change,
                            "AutoChannelEnable" => $paramsFromModel[0]->AutoChannelEnable,
                            "wpaEncryptionModes" => $paramsFromModel[0]->wpaEncryptionModes,
                            "maxAssociatedClients" => array("MaxAssociatedClients", $paramsFromModel[0]->max_associated_clients),
                            "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                            "frequencyBand" => $paramsFromModel[0]->frequencyBand,
                            "transmitPower" => array('TransmitPower', $paramsFromModel[0]->transmit_power),
                            "transmitPowerSupported" => $paramsFromModel[0]->transmit_power_supported,
                            "channelsSupport" => $paramsFromModel[0]->possible_channels,
                            "enableBeacon" => array("BeaconAdvertisementEnabled", $paramsFromModel[0]->bssid_status),
                            "hideSSID" => array("SSIDAdvertisementEnabled", $paramsFromModel[0]->ssid_hide));
                    } else {
                        $wlanStandart = array();
                        $connectedDevices = array();
                        $params = array("enable" => array("Enable", ''),
                            "bssid" => array("BSSID", ''),
                            "ssid" => array("SSID", ''),
                            "channel" => array("Channel", ''),
                            "standard" => array("Standard", ''),
                            "key" => array("PreSharedKey", ''),
                            //                                "total" => array("TotalPSKFailures", 0),
                            "total" => array("X_X_DLINK_WPA_Renewal", 0),
                            "networkAuth" => array("", "None"), "valueChange" => 0,
                            "AutoChannelEnable" => '',
                            "wpaEncryptionModes" => '',
                            "maxAssociatedClients" => array("MaxAssociatedClients", ''),
                            "numIndex" => 0,
                            "frequencyBand" => '',
                            "transmitPower" => '',
                            "transmitPowerSupported" => '0,25,50,75,100',
                            "channelsSupport" => '',
                            "enableBeacon" => array("BeaconAdvertisementEnabled", ''),
                            "hideSSID" => array("SSIDAdvertisementEnabled", ''));
                    }
                } else {
                    if (!class_exists("ParamNamesConstants")) {
                        require_once $_SESSION['APPPATH'] . "util/wirelessModeStandarts.php";
                    }
                    if (!class_exists("ParamNamesConstants")) {
                        require_once $_SESSION['APPPATH'] . "util/UNIIRangsFor5GHz.php";
                    }

                    $paramsFromModel = getWLanParams($serialN);
                    $frequencyBand1 = "5GHz";
                    $frequencyBand2 = "2.4GHz";
                    $radioEnabled5GH = false;
                    $radioEnabled2_4GH = false;
                    $params1 = getWLanParamsByFrequencyBand($serialN, $frequencyBand1);
                    $params2 = getWLanParamsByFrequencyBand($serialN, $frequencyBand2);

                    if ($paramsFromModel) {
                        $bssids1 = array();
                        $bssids2 = array();
                        foreach ($params1 as $wifiparam) {
                            if ($wifiparam->bssid != null) {
                                array_push($bssids1, trim(str_replace(":", "", $wifiparam->bssid)));
                            }
                            if ($wifiparam->radio_enabled == 1) {
                                $radioEnabled5GH = true;
                            } else {
                                $radioEnabled5GH = false;
                            }

                        }

                        foreach ($params2 as $wifiparam) {
                            if ($wifiparam->bssid != null) {
                                array_push($bssids2, trim(str_replace(":", "", $wifiparam->bssid)));
                            }
                            if ($wifiparam->radio_enabled == 1) {
                                $radioEnabled2_4GH = true;
                            } else {
                                $radioEnabled2_4GH = false;
                            }

                        }
                        $showConnecetdDevices = true;
                        $wlanStandart = getWirelessStandartParam($paramsFromModel[0]->id);
                        $connectedDevices = getConnectedDevices($paramsFromModel[0]->device_id, 'WLAN');
                        $wlanBSSIDs = getWlanBSSIDs($paramsFromModel[0]->device_id);
                        $i = 0;
                        foreach ($connectedDevices as $devParam) {
                            foreach ($wlanBSSIDs as $bssid) {
                                if ($bssid->num_index == $devParam->num_id) {
                                    $connectedDevices[$i]->bssid = $bssid->bssid;
                                }
                                if ($bssid->num_index == $devParam->num_id) {
                                    $connectedDevices[$i]->ssid = $bssid->bssid;
                                }
                            }
                            $i++;
                        }

                        $params = array("id" => array("id", $paramsFromModel[0]->id),
                            "enable" => array("Enable", $paramsFromModel[0]->enable),
                            "bssid" => array("BSSID", trim(str_replace(":", "", $paramsFromModel[0]->bssid))),
                            "ssid" => array("SSID", trim($paramsFromModel[0]->ssid)),
                            "channel" => array("Channel", trim($paramsFromModel[0]->channel)),
                            "standard" => array("Standard", trim($paramsFromModel[0]->standard)),
                            "key" => array("KeyPassphrase", ''),
                            //                                "total" => array("TotalPSKFailures", trim($paramsFromModel[0]->total_psk_failures)),
                            "total" => array("X_X_DLINK_WPA_Renewal", trim($paramsFromModel[0]->total_psk_failures)),
                            "networkAuth" => array("", trim($paramsFromModel[0]->network_authentication)),
                            "valueChange" => $paramsFromModel[0]->value_change,
                            "AutoChannelEnable" => $paramsFromModel[0]->autochannelenable,
                            "wpaEncryptionModes" => $paramsFromModel[0]->wpaEncryptionModes,
                            "maxAssociatedClients" => array("MaxAssociatedClients", $paramsFromModel[0]->max_associated_clients),
                            "numIndex" => $paramsFromModel[0]->num_index == null ? 0 : $paramsFromModel[0]->num_index,
                            "frequencyBand" => $paramsFromModel[0]->frequencyBand,
                            "transmitPower" => array("TransmitPower", $paramsFromModel[0]->transmit_power),
                            "transmitPowerSupported" => $paramsFromModel[0]->transmit_power_supported,
                            "channelsSupport" => $paramsFromModel[0]->possible_channels,
                            "enableBeacon" => array("BeaconAdvertisementEnabled", $paramsFromModel[0]->bssid_status),
                            "hideSSID" => array("SSIDAdvertisementEnabled", $paramsFromModel[0]->ssid_hide));
                    } else {
                        $showConnecetdDevices = false;
                        $wlanStandart = array();
                        $connectedDevices = array();
                        $params = array("enable" => array("Enable", ''),
                            "bssid" => array("BSSID", ''),
                            "ssid" => array("SSID", ''),
                            "channel" => array("Channel", ''),
                            "standard" => array("Standard", ''),
                            "key" => array("PreSharedKey", ''),
                            //                                "total" => array("TotalPSKFailures", 0),
                            "total" => array("X_X_DLINK_WPA_Renewal", 0),
                            "networkAuth" => array("", "None"), "valueChange" => 0,
                            "AutoChannelEnable" => '',
                            "wpaEncryptionModes" => '',
                            "maxAssociatedClients" => array("MaxAssociatedClients", ''),
                            "numIndex" => 0,
                            "frequencyBand" => '',
                            "transmitPower" => '',
                            "transmitPowerSupported" => '0,25,50,75,100',
                            "channelsSupport" => '',
                            "enableBeacon" => array("BeaconAdvertisementEnabled", ''),
                            "hideSSID" => array("SSIDAdvertisementEnabled", ''));
                    }
                }


                require_once $_SESSION['APPPATH'] . 'views/content/admin/wirelessPageForDevice.php';

            } else if ($actionName == 'update') {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                $dev = new Device();
                $device = devInfoByID($deviceID, $dev);
                require_once $_SESSION['APPPATH'] . 'views/content/admin/updatePageForDevice.php';

            } else if ($actionName == 'monitoring') {
//                echo '<h3 style="text-align: center;margin-top: 100px;"> COMING SOON </h3>';
                require_once $_SESSION['APPPATH'] . '../.././ACS/snmp/snmp.php';
            } else /*if ($actionName == 'tree')*/ {
                require_once $_SESSION['APPPATH'] . 'models/device.php';
                $dev = new Device();
                $device = devInfoByID($deviceID, $dev);
                require_once $_SESSION['APPPATH'] . 'views/content/admin/treePageForDevice.php';
            }
        } catch (\Exception $e) {
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
