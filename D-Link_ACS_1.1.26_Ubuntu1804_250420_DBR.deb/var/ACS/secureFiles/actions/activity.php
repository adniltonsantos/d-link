<?php
if (session_id() == '') {
    session_start();
}



if (isset($_SESSION['logged_in'])) {
    try{
        include $_SESSION['APPPATH'].'models/modelHistory.php';
        include $_SESSION['APPPATH'].'models/modelWebTask.php';
        include $_SESSION['APPPATH'].'models/device.php';
        include $_SESSION['APPPATH'].'util/pagingConstants.php';
        $permissionsArray = array();
        if (isset($_SESSION['permissions'])) {
            require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
            $permissionsArray = $_SESSION['permissions'];
            if(isset($_SESSION['group_id'])) {
                $groupID = $_SESSION['group_id'];
            }
        }
        $userID = $_SESSION['userID'];
        $dev = new Device();
        $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
        $countGroups=count($groupList);
        $devices = $dev->getDevicesByGroups($groupList, $countGroups,"",0,"");
        $devCount = $dev->getAllDevicesCountByGroups($groupList, $countGroups);
        $page = 1;
        $limit = PagingConstants::$activityCount;
        $offset = ($page - 1) * $limit;
        if (isset($userSettings->activityFilter)) {
            $mac = $userSettings->activityFilter->mac;
            $model = $userSettings->activityFilter->model;
            $task = $userSettings->activityFilter->task;
            $status = $userSettings->activityFilter->status;
            $createTime = $userSettings->activityFilter->createTime;
            $selectTime = $userSettings->activityFilter->selectTime;
        } else {
            $mac = '0';
            $model = '0';
            $task = '0';
            $status = '-1';
            $createTime = '';
            $selectTime = '0';
        }
        $webTask = new ModelWebTask();
    //    $activities = $webTask->getAllWebTasksByPage($limit, $offset);
//        $activities = $webTask->getAllWebTasksByPageExcludeItem($limit, $offset,"'createPort', 'selectInterface', 'taggedNatParam'");
//        $allActivitiesCount = $webTask->getAllWebTasksCountExcludeItem("'createPort', 'selectInterface', 'taggedNatParam'");
//    $allActivitiesCount = $webTask->getAllWebTasksCount();
//        $models = $dev->getAllModels();
        $models = $webTask->getAllModelsFromWebTasks();
        if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
            $macsFromWebTask = $webTask->getAllMacsFromWebTasksByGroup($devices, $devCount);
        } else {
            $macsFromWebTask = $webTask->getAllMacsFromWebTasks();
        }
        if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
            $macsFromWebTask = $webTask->getAllMacsFromWebTasksByGroup($devices, $devCount);
        } else {
            $macsFromWebTask = $webTask->getAllMacsFromWebTasks();
        }
        $taskFromWebTask = $webTask->getALLTasksFromWebTasks("'create_port'");
        $statusCodesFromWebTasks = $webTask->getAllStatusCodesFromWebTasks();
        if (count($macsFromWebTask) == 0 ) {
            $mac = '0';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter = array('mac'=> $mac, 'model' => $model, 'task' => $task, 'status' => $status);
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }
        if (count($taskFromWebTask) == 0 ) {
            $task = '0';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter = array('mac'=> $mac, 'model' => $model, 'task' => $task, 'status' => $status);
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }
        if (count($statusCodesFromWebTasks) == 0) {
            $status = '-1';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter = array('mac'=> $mac, 'model' => $model, 'task' => $task, 'status' => $status);
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }
        if (count($models) == 0) {
            $models = '0';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter = array('mac'=> $mac, 'model' => $model, 'task' => $task, 'status' => $status);
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }

        if (count($macsFromWebTask) == 0 && count($taskFromWebTask) == 0 && count($macsFromWebTask) == 0 && count($statusCodesFromWebTasks) == 0){
            $mac = '0';
            $task = '0';
            $models = '0';
            $status = '-1';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter->mac = $mac;
            $userSettings->activityFilter->model = $model;
            $userSettings->activityFilter->task = $task;
            $userSettings->activityFilter->status = $status;
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }
        $macDel = true;
        if ($mac != '0' ) {
            for ($i = 0; $i < count($macsFromWebTask); $i++) {
                if ($macsFromWebTask[$i]->id == $mac){
                    $macDel = true;
                    break;
                } else {
                    $macDel = false;
                }
            }
        }
        if (!$macDel) {
            $mac = '0';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter->mac = $mac;
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }

        $taskDel = true;
        if ($task != '0' ) {
            for ($i = 0; $i < count($taskFromWebTask); $i++) {
                if ($taskFromWebTask[$i]->id == $task){
                    $taskDel = true;
                    break;
                } else {
                    $taskDel = false;
                }
            }
        }
        if (!$taskDel) {
            $task = '0';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter->task = $task;
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }

        $modelDel = true;
        if ($model != '0' ) {
            for ($i = 0; $i < count($models); $i++) {
                if ($models[$i]->id == $model){
                    $modelDel = true;
                    break;
                } else {
                    $modelDel = false;
                }
            }
        }
        if (!$modelDel) {
            $model = '0';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter->model = $model;
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }

        $statusDel = true;
        if ($status != '-1' ) {
            for ($i = 0; $i < count($statusCodesFromWebTasks); $i++) {
                if ($statusCodesFromWebTasks[$i]->operation_status == $status){
                    $statusDel = true;
                    break;
                } else {
                    $statusDel = false;
                }
            }
        }
        if (!$statusDel) {
            $status = '-1';
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->activityFilter->status = $status;
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }
        if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
//            $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
//            $countGroups=count($groupList);
//            $devices = $dev->getDevicesByGroups($groupList, $countGroups, $limit, $offset);
//            $devCount = $dev->getAllDevicesCountByGroups($groupList, $countGroups);
            $activities1 = $webTask->getAllFilteredWebTaskByStatusPageByGroups($devices, $devCount, $userID, $model, $mac, $task, $status, $createTime, $selectTime, '', '', "'createPort', 'selectInterface'");
            $activitiesCount = count($activities1);

            if ($activitiesCount > $limit) {
                for($i=0; $i<$limit; $i++) {
                    $activities[$i] = $activities1[$i];
                }
            } else {
                $activities = $activities1;
            }
        } else {
            $activities = $webTask->getAllFilteredWebTaskByStatusPage($model, $mac, $task, $status, $createTime, $selectTime, '', '', $limit, $offset, "'createPort', 'selectInterface'");
            $allActivitiesCount = $webTask->getAllFilteredWebTasksCount($model, $mac, $task, $status, $createTime, $selectTime, '', '', "'createPort', 'selectInterface'");
            $activitiesCount = $allActivitiesCount[0]->count;
        }

        foreach ($activities as  $activity){
            if(trim($activity->type_name)=='getSelectedParams'){
              $tabName=Utils::getTabnameINActivity($activity->xml);
                $tabN=array($activity->type_name,$tabName);
                $activity->type_name=$tabN;

            }
        }



        include $_SESSION['APPPATH'].'util/paging.php';

        $pagesCount=Paging::getPagesCount($activitiesCount,$limit);

        include $_SESSION['APPPATH'].'views/tiles/admin/activities_view.php';
    } catch (\Exception $e) {
      throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}
