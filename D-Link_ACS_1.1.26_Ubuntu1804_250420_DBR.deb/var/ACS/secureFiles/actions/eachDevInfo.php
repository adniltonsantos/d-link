<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
    //    define('BASEPATH', $_SESSION['BASEPATH']);
    //    $devID = $_GET['deviceID'];
    //    $serialNumber = $_GET['serialNumber'];

    //    if($devID==0){
    //        include  $_SESSION['APPPATH'].'actions/login.php';
    //    } else {
        require_once $_SESSION['APPPATH']."models/device.php";
        $device = new Device();
        $devInfo = $device->getClientNameModelByDevID($devID);

        if(!$devInfo) {
    //        include  $_SESSION['APPPATH'].'actions/login.php';
            $_SESSION['lastPage'] = 'forDevices';
            header('HTTP/1.1 404 Not Found');
            header("Status: 404 Not Found");
            require_once 'secureFiles/actions/error404.php';
        } else {

            if(!isset($_SESSION['activeTab'])){
               $_SESSION['activeTab'] = "info";
            }
            require_once $_SESSION['APPPATH'].'models/modelParams.php';
            $modParams = new ModelParams();
            $device = new Device();
            $vlanParams = $modParams->getVlans($devID);
            $voipParams = $modParams->getVoipParams($devInfo[0]->serial_number);
            $lteParams = $modParams->getLTE($devID);
            $statistics = $device->getStatistics($devID);

            require_once $_SESSION['APPPATH']."views/tiles/admin/each_dev_info_view.php";
        }
//    }
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}


