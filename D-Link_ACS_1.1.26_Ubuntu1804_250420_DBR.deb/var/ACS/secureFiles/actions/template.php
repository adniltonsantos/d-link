<?php
if (session_id() == '') {
    session_start();
}

if (isset($_SESSION['logged_in'])) {
    try{
        
        if($tmpAction == 'show'){
            getAllTemplates($tmpAction);
            
        }else if($tmpAction == 'create'){
            cretateTemplate($tmpAction);
            
        }else if($tmpAction == 'update'){
            editTemplate($tmpAction,$tmplId);
            
        }else if($tmpAction == 'descriptor'){
            showDescriptor($tmpAction);
            
        }else {
            $_SESSION['lastPage'] = 'forDevices';
            header('HTTP/1.1 404 Not Found');
            header("Status: 404 Not Found");
            header( 'Location: '.BASEPATH.'404' );
        }
        
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}

function getAllTemplates($tmpAction){
    include  $_SESSION['APPPATH'].'models/modelTemplates.php';
    $page = 1;
    $limit = 5;
    $offset = ($page - 1) * $limit;

    $mTemplates = new ModelTemplates();
    $templates = $mTemplates->getAllTemplatesList($limit,$offset);

    $allTemplatesCount = $mTemplates->getAllTemplatesCount();
    $templateCount = $allTemplatesCount[0]->count;

    require_once $_SESSION['APPPATH'].'util/paging.php';

    $pagesCount = Paging::getPagesCount($templateCount,$limit);

    require_once  $_SESSION['APPPATH'].'views/tiles/admin/templates_view.php';
}

function cretateTemplate($tmpAction){
    if(!defined('BASEPATH')){define('BASEPATH', $_SESSION['BASEPATH']);}
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $toAdd = 'true';
//    require_once $_SESSION['APPPATH'].'views/content/admin/addTemplate.php';
    require_once  $_SESSION['APPPATH'].'views/tiles/admin/templates_view.php';
}

function editTemplate($tmpAction,$tmplId){
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    
    require_once 'secureFiles/actions/ajaxActions/showTemplate.php';
}

function showDescriptor($tmpAction){
    $page = 1;
    if(isset($_POST['page'])){
        $page = $_POST['page']; 
    }

    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
    $limit = 5;
    $offset = ($page - 1) * $limit;

    $mTemplates = new ModelTemplates();
    $defaultDescriptor = $mTemplates->getDefaultDescriptor();
    $descriptors = $mTemplates->getAllDescriptorsList($limit,$offset);
    $allDescriptorsCount = $mTemplates->getAllDesctiptorsCount();
    $devCount = $allDescriptorsCount[0]->count;
    if ($devCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($devCount % $limit == 0) {
            $pagesCount = $devCount / $limit;
        } else {
            $pagesCount = ($devCount / $limit - ($devCount % $limit) * (1 / $limit)) + 1;
        }
    }

    require_once  $_SESSION['APPPATH'].'views/tiles/admin/templates_view.php';
}