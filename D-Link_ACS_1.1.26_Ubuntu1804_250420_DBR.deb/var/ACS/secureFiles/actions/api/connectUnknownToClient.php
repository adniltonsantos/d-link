<?php
//$_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";
//require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//require_once $_SESSION['APPPATH']."models/xor/xor.php";
//require_once $_SESSION['APPPATH']."actions/api/token.php";
//include $_SESSION['APPPATH'].'models/modelClient.php';
//include $_SESSION['APPPATH'] . 'sockets/createXML.php';
//include $_SESSION['APPPATH'] . 'sockets/connectTCP.php';
//include $_SESSION['APPPATH'] . 'util/actionNamesConstants.php';
//
//function checkToken($token) {
//    if($token != '') {
//        $login = token::check_token($token);
//        if($login!=false) {
//            $user = new ModelUser();
//            $userExist = $user->checkUserIdExist($login);
//            if(empty($userExist)) {
//                $result = array("result" => 'Invalid token');
//                echo json_encode($result);
//                return false;
//            } else {
//                $permissions = $user->getPermissionsByUserId($login);
//                if(count($permissions)==5) {
//                    $userID = $login;
//                    return $userID;
//                } else {
//                    $result = array("result" => 'User is not Administrator');
//                    echo json_encode($result);
//                    return false;
//                }
//            }
//        } else {
//            $result = array("result" => 'Invalid token');
//            echo json_encode($result);
//            return false;
//        }
//    } else {
//        $result = array("result" => 'Invalid token');
//        echo json_encode($result);
//        return false;
//    }
//}
//
//function checkElementIsUnsignedInt($var) {
//    $typeDevId = is_numeric($var);
//    if($typeDevId==true) {
//        if($var > 0) {
//            return true;
//        } else {
//            return false;
//        }
//    } else {
//        return false;
//    }
//}
//
//function isArrayElementEmpty($array) {
//    $error = 0;
//    $count = count($array);
//    foreach ($array as $key => $case ) {
//        if ( $case == '') {         //Check which value is empty
//            $error++  ;
//        }
//    }
//    if($error > 0 ){
//        return false;
//    } else {
//        return true;
//    }
//}
//
//function checkIsArrayElementUnsignedInt($array) {
//    for($i=0; $i<count($array); $i++) {
//        $typeDevId = is_numeric($array[$i]);
//        if ($typeDevId == true) {
//            if ($array[$i] > 0) {
//                return true;
//            } else {
//                return false;
//            }
//        } else {
//            return false;
//        }
//    }
//}
//
//try {
//    if (isset($_POST['method']) && !empty($_POST['method'])) {
//        $userID = '';
//        $action = trim($_POST['method']);
//        if (session_id() == '') {
//            session_start();
//        }
//        if (isset($_POST['token'])) {
//            $token = trim($_POST['token']);
//            $tokenExist = checkToken($token);
//            if ($tokenExist == false) {
//                return false;
//            } else {
//                $userID = $tokenExist;
//            }
//        } else {
//            $result = array("result" => "false");
//            echo json_encode($result);
//            return false;
//        }
//    }
//
//    switch ($action) {
//        case 'connectToClient':
//            $client = new ModelClient();
//            $clientID = trim($_POST['clientID']);
//            $clientIdType = checkElementIsUnsignedInt($clientID);
//            $userExist = $client->checkClientExist($clientID);
//            $devID = $_POST['devID'];
//            if(isset($_POST['templateID'])){
//                $tarifID = trim($_POST['templateID']);
//            } else {
//                $tarifID = 0;
//            }
//            if(isset($_POST['groupID'])){
//                $groupID = trim($_POST['groupID']);
//            } else {
//                $groupID = '';
//            }
//            if(empty($userExist) || $clientID=='' || $devID == '' || $clientIdType == false) {
//                $result = array("result" => 'false');
//                echo json_encode($result);
//                return false;
//            }
//            if(is_array($devID)) {
//                $devIDEmpty = isArrayElementEmpty($devID);
//                $devIDUnsignedInt = checkIsArrayElementUnsignedInt($devID);
//                $devExist = $client->checkUnknownDeviceExist($devID);
//
//                if($devIDEmpty == false || $devIDUnsignedInt == false || empty($devExist)) {
//                    $result = array("result" => 'false');
//                    echo json_encode($result);
//                    return false;
//                }
//                $update = $client->connectUnknownToClientByGroups($devID, $clientID, $tarifID, $groupID);
//            } else {
//                $deviceIdType = checkElementIsUnsignedInt(trim($devID));
//                $devExist = $client->checkUnknownDeviceExist(trim($devID));
//                if($deviceIdType == false || empty($devExist)) {
//                    $result = array("result" => "false");
//                    echo json_encode($result);
//                    return false;
//                }
//                $update = $client->connectUnknownToClient(trim($devID), $clientID, $tarifID, $groupID);
//            }
//            if ($update) {
//                $result = array("result" => 'true');
//            } else {
//                $result = array("result" => 'false');
//            }
//            echo json_encode($result);
//            break;
//
//        case 'resendDevice':
//            if(isset($_POST['ip'])) {
//                $ip = $_POST['ip'];
//            } else {
//                $ip = '';
//            }
//            if(isset($_POST['serial_number'])){
//                $serialNumber = $_POST['serial_number'];
//            } else {
//                $serialNumber = '';
//            }
//            if($ip == '' && $serialNumber == '') {
//                $result = array("result" => 'false');
//                echo json_encode($result);
//                return false;
//            }
//            $client = new ModelClient();
//            $devID = $client->checkUnknownDeviceExistBySerialIp($ip, $serialNumber);
//            if(empty($devID)) {
//                $result = array("result" => 'false');
//                echo json_encode($result);
//                return false;
//            }
//            $xml = CreateXML::createTheXML(ActionNamesConstants::$resend, $devID[0]->id, "", "NoName", $userID);
//            $result = ConnectTCP::connectToGetData($xml);
//            $result = array("result" => $devID[0]->id);
//            echo json_encode($result);
//            break;
//
//        default:
//            $result = array("result" => 'Undefined method');
//            echo json_encode($result);
//            break;
//    }
//
//} catch (\Exception $e){
//    error_log($e->getMessage());
//    header('HTTP/1.1 500 Internal Server Error');
//    header("Status: 500 Internal Server Error");
//    exit();
//}