<?php
$_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";
include $_SESSION['APPPATH'] . 'models/device.php';
include $_SESSION['APPPATH'] . 'models/modelParams.php';
include  $_SESSION['APPPATH'].'models/modelUser.php';
include  $_SESSION['APPPATH'].'models/modelClient.php';
include $_SESSION['APPPATH'] . 'sockets/createXML.php';
include $_SESSION['APPPATH'] . 'sockets/connectTCP.php';
include $_SESSION['APPPATH'] . 'util/actionNamesConstants.php';
require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
require_once $_SESSION['APPPATH']."models/xor/xor.php";
require_once $_SESSION['APPPATH']."actions/api/token.php";

function readVersionInfoSettings()
{
    $fileName = '/etc/acs/config/public-ipv4';
    $fileExist = file_exists($fileName);
    if ($fileExist && filesize($fileName)>7) {
        $handle = fopen($fileName, 'r');
        $data = fread($handle,filesize($fileName));
    } else {
        return false;
    }

    return $data;
}



function trimArray($array) {
    return(trim($array));
}

function isArrayElementEmpty($array) {
    $error = 0;
    $count = count($array);
    foreach ($array as $key => $case ) {
        if ( $case == '') {         //Check which value is empty
            $error++  ;
        }
    }
    if($error > 0 ){
        return false;
    } else {
        return true;
    }
}

function checkElementIsUnsignedInt($var) {
    $typeDevId = is_numeric($var);
    if($typeDevId==true) {
        if($var > 0) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function checkIsArrayElementUnsignedInt($array) {
    for($i=0; $i<count($array); $i++) {
        $typeDevId = is_numeric($array[$i]);
        if ($typeDevId == true) {
            if ($array[$i] > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}

function setDefaultConnection($modelParams,$conIndex, $index, $conn_type, $deviceId, $userID, $fwName) {
    $xml = CreateXML::createDefGatewayXML($conIndex, $index, $conn_type);
    $resForInsert = $modelParams->setParams($xml);
    if ($resForInsert != 0) {
        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$defConnection, $deviceId, $resForInsert, $userID, $fwName);
        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
        return $result;
    } else {
        return false;
    }
}

function selectInterface($modelParams, $deviceId, $bridgeIndex, $userID, $fwName) {
    $xml = CreateXML::createTheSETXMLForSelectInterface($bridgeIndex);
    $resForInsert = $modelParams->setLanWlanParams($xml);
    if ($resForInsert != 0) {
        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$selectInterface, $deviceId, $resForInsert, $userID, $fwName);
        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
        return $result;
    }
    return false;
}

function addOnlyClient($firstName, $surName, $address, $email, $patronymicName, $contractNumber){
    $client = new ModelClient();
    $result = $client->addOnlyClient($firstName, $surName, $address, $email, $patronymicName, $contractNumber);
    if (!$result) {
        $_SESSION['firstName'] = $firstName;
        $_SESSION['surName'] = $surName;
        $_SESSION['address'] = $address;
        $_SESSION['email'] = $email;
        $_SESSION['patronymicName'] = $patronymicName;
        $_SESSION['contractNumber'] = $contractNumber;
    } else {
        return $result;
    }
}

function createPort($modelParams, $deviceId, $bridgePort,$bridgeType,$availableIndex, $userID, $fwName) {
    if(!is_array($bridgePort)){
        $xml = CreateXML::createTheSETXMLForCreatePort($bridgePort,$bridgeType);
        $resForInsert = $modelParams->setLanWlanParams($xml);
    }else if (is_array($bridgePort) && !empty ($bridgePort)) {
        $xmlList = array();
        for ($i = 0; $i < count($bridgePort); $i++){
            $xmll = CreateXML::createTheSETXMLForCreatePort($bridgePort[$i],$bridgeType,$availableIndex[$i]);
            array_push($xmlList, $xmll);
        }
        $resForInsert = $modelParams->setLanWlanParams($xmlList);
    }

    if (!is_array($resForInsert) && $resForInsert != 0) {
        if($bridgeType == 'bridge'){
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$createPort, $deviceId, $resForInsert, $userID, $fwName);
        }elseif ($bridgeType == 'taggedNat') {
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$taggedNatParam, $deviceId, $resForInsert, $userID, $fwName);
        }elseif ($bridgeType == 'untaggedBridge'){
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$untaggedBridge, $deviceId, $resForInsert, $userID, $fwName);
        }

        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
        return $result;

    }elseif (is_array($resForInsert) && !empty($resForInsert)) {
        if($bridgeType == 'bridge'){
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$createPort, $deviceId, $resForInsert, $userID, $fwName);
        }elseif ($bridgeType == 'taggedNat') {
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$taggedNat, $deviceId, $resForInsert, $userID, $fwName);
        }elseif ($bridgeType == 'untaggedBridge'){
            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$untaggedBridge, $deviceId, $resForInsert, $userID, $fwName);
        }

        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
        return $result;
    }

    return false;
}

function checkVlanNameExist($modelParams,$bridgeName, $devId) {
    $ifExist = 'false';
    $vlansNames = $modelParams->getAllVlanNames($devId);
    foreach ($vlansNames as $vlanNames){
        if($vlanNames->vlan_name == $bridgeName){
            $ifExist = 'true';
            break;
        }
    }
    return $ifExist;
}

function checkVlanIDExist($modelParams, $vlanID, $devId) {
    $ifExist = 'false';
    $vlansIds = $modelParams->getAllVlanIds($devId);
    foreach ($vlansIds as $vlanid){
        if($vlanid->vlan_id == $vlanID){
            $ifExist = 'true';
            break;
        }
    }
    return $ifExist;
}

if (isset($_POST['method']) && !empty($_POST['method'])) {
    $dev = new Device();
    $userID = '';
    $action = trim($_POST['method']);
    if (session_id() == '') {
        session_start();
    }
    if(isset($_POST['token'])){
        $token = trim($_POST['token']);
        if($token != '') {
            $login = token::check_token($token);
            if($login!=false) {
                $user = new ModelUser();
                $userExist = $user->checkUserIdExist($login);
                if(empty($userExist)) {
                    $result = array("result" => 'Invalid token');
                    echo json_encode($result);
                    return false;
                } else {
                    $permissions = $user->getPermissionsByUserId($login);
                    if(count($permissions)==5) {
                        $userID = $login;
                    } else {
                        $result = array("result" => 'User is not Administrator');
                        echo json_encode($result);
                        return false;
                    }
                }
            } else {
                $result = array("result" => 'Invalid token');
                echo json_encode($result);
                return false;
            }
        } else {
            $result = array("result" => 'Invalid token');
            echo json_encode($result);
            return false;
        }
    } else {
        $result = array("result" => 'false');
        echo json_encode($result);
        return false;
    }

    /*-------Set fwName  for api----------------*/
    $fwName = '';
    if(isset($_POST['feedback'])) {
        $feedback = $_POST['feedback'];
        if($feedback == 0 || $feedback == 1) {
            if($feedback == 0) {
                $fwName = 2;
            } else {
                $fwName = 1;
            }
        } else {
            $result = array("result" => "Invalid feedback");
            echo json_encode($result);
            return false;
        }
    } else {
        $fwName = 2;
    }
    /*-------End set fwName  for api------------*/

    if(isset($_POST['deviceID'])) {
        $checkDev = $dev->checkDeviceIdExist($_POST['deviceID']);
        if($checkDev[0] == '') {
            $result = array("result" => 'Invalid Device ID');
            echo json_encode($result);
            return false;
        }
    }

    if(isset($_POST['device_id'])) {
        $checkDev = $dev->checkDeviceIdExist($_POST['device_id']);
        if($checkDev[0] == '') {
            $result = array("result" => 'Invalid Device ID');
            echo json_encode($result);
            return false;
        }
    }

    switch ($action) {
        case  'AddObject':
            if(isset($_POST['deviceID']) && $_POST['deviceID'] != '' && isset($_POST['object']) && $_POST['object'] != '') {
                $devID = $_POST['deviceID'];
                $object = $_POST['object'];
                $modelParams = new ModelParams();
                $xml = CreateXML::createTheSETXMLForNewObject($object);
                $resForInsert = $modelParams->setParams($xml);

                if ($resForInsert != 0) {
                    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $devID, $resForInsert, $userID, $fwName);
                    $resultTask = ConnectTCP::connectToGetDataForAPI($getAllXml);
                }
                $result = array("result" => $resultTask);
                echo json_encode($result);
            } else {
                $result = array("result" => 'false');
                echo json_encode($result);
                return false;
            }
            break;

        case 'addobject':
            if(isset($_POST['objtype']) && $_POST['objtype'] != ''){
                $objType = $_POST['objtype'];
                if(isset($_POST['deviceID'])){
                    $devId = $_POST['deviceID'];
                    if($objType = 'vlan') {
                        $modelParams = new ModelParams();
                        if(isset($_POST['vlanName']) && $_POST['vlanName'] != '') {
                            $bridgeName = $_POST['vlanName'];
                            $checkVlanName = checkVlanNameExist($modelParams, $bridgeName, $devId);
                            if($checkVlanName == 'true'){
                                $result = array("result" => 'Vlan Name is already used');
                                echo json_encode($result);
                                return false;
                            }
                        }
                        if(isset($_POST['vlanID']) && $_POST['vlanID'] != '') {
                            $vlanID = $_POST['vlanID'];
                            $checkVlanId = checkVlanIDExist($modelParams, $vlanID, $devId);
                            if($checkVlanId == 'true'){
                                $result = array("result" => 'Vlan ID is already used');
                                echo json_encode($result);
                                return false;
                            }
                        }
                        if(isset($_POST['vlanPort']) && $_POST['vlanPort'] != '') {
                            $bridgePortArray = $_POST['vlanPort'];
                            $bridgePort = array();
                            $availableIndex = array();
                        }
                        $bridgeType = $_POST['vlanType'];
                        if(isset($_POST['vlanName']) && isset($_POST['vlanID']) && isset($_POST['vlanPort']) && isset($_POST['vlanType']) && $_POST['vlanType'] == "bridge") {
                            $bridgeType = $_POST['vlanType'];
                        } elseif(isset($_POST['vlanName']) && isset($_POST['vlanID']) && isset($_POST['vlanType']) && $_POST['vlanType'] == "taggedNat") {
                            $bridgeType = $_POST['vlanType'];
                        } elseif(isset($_POST['vlanPort']) && isset($_POST['vlanType']) && $_POST['vlanType'] == "untaggedBridge") {
                            $bridgeType = $_POST['vlanType'];
                        } else {
                            $result = array("result" => 'false');
                            echo json_encode($result);
                            return false;
                        }
                        for($i = 0; $i < count($bridgePortArray); $i++) {
                            if(key($bridgePortArray[$i]) == "LAN") {
                                $index = $modelParams->setAvailableIndexLanForAPI($bridgePortArray[$i]['LAN'], $devId);
                                if(!empty($index)) {
                                    array_push($availableIndex, $index[0]->available_index);
                                    array_push($bridgePort, $bridgePortArray[$i]['LAN']);
                                } else {
                                    $result = array("result" => 'false');
                                    echo json_encode($result);
                                    return false;
                                }
                            } elseif (key($bridgePortArray[$i]) == "WAN") {
                                $index = $modelParams->setAvailableIndexWanForAPI($bridgePortArray[$i]['WAN'], $devId);
                                if(!empty($index)) {
                                    array_push($availableIndex, $index[0]->available_index);
                                    array_push($bridgePort, $bridgePortArray[$i]['WAN']);
                                } else {
                                    $result = array("result" => 'false');
                                    echo json_encode($result);
                                    return false;
                                }
                            } elseif(key($bridgePortArray[$i]) == "WLAN") {
                                $index = $modelParams->setAvailableIndexWlanForAPI($bridgePortArray[$i]['WLAN'], $devId);
                                if(!empty($index)) {
                                    array_push($availableIndex, $index[0]->available_index);
                                    array_push($bridgePort, $bridgePortArray[$i]['WLAN']);
                                } else {
                                    $result = array("result" => 'false');
                                    echo json_encode($result);
                                    return false;
                                }
                            } else {
                                $result = array("result" => 'false');
                                echo json_encode($result);
                                return false;
                            }
                        }

                        if($bridgeType == 'bridge'){
                            $xml = CreateXML::createTheSETXMLForCreateBridge($bridgeName, $vlanID);
                            $resForInsert = $modelParams->setLanWlanParams($xml);
                            if ($resForInsert != 0) {
                                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$createBridge, $devId, $resForInsert, $userID, $fwName);
                                $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                                if ($result) {
                                    $createPort = createPort($modelParams, $devId, $bridgePort,$bridgeType,$availableIndex,$userID, $fwName);
                                    $result = array("result" => $createPort);
                                    echo json_encode($result);
                                } else {
                                    $result = array("result" => 'false');
                                    echo json_encode($result);
                                    return false;
                                }
                            } else {
                                $result = array("result" => 'false');
                                echo json_encode($result);
                                return false;
                            }
                        }else if($bridgeType == 'taggedNat'){
                            $xml = CreateXML::createTheSETXMLForCreateBridge($bridgeName, $vlanID);
                            $resForInsert = $modelParams->setLanWlanParams($xml);
                            if ($resForInsert != 0) {
                                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$taggedNat, $devId, $resForInsert, $userID, $fwName);
                                $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                                if ($result) {
                                    $createPort = createPort($modelParams, $devId, $vlanID,$bridgeType,$availableIndex,$userID, $fwName);
                                    $result = array("result" => $createPort);
                                    echo json_encode($result);
                                } else {
                                    $result = array("result" => 'false');
                                    echo json_encode($result);
                                    return false;
                                }
                            } else {
                                $result = array("result" => 'false');
                                echo json_encode($result);
                                return false;
                            }
                        }else if($bridgeType == 'untaggedBridge'){
                            $createPort = createPort($modelParams, $devId, $bridgePort,$bridgeType,$availableIndex,$userID, $fwName);
                            $result = array("result" => $createPort);
                            echo json_encode($result);
                        }
                    }

                } else {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
            } else {
                $result = array("result" => 'false');
                echo json_encode($result);
                return false;
            }

            break;

        case 'changePPPWan':
            $_SESSION["Refresh"] = "true";
            if(isset($_POST['deviceID']) && isset($_POST['numIndex']) && isset($_POST['changedParamNames']) && isset($_POST['changedParamValues']) && isset($_POST['changedParamTypes']) /*&& isset($_POST["id"])*/) {
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $deviceID = $_POST['deviceID'];
                $numIndex = $_POST['numIndex'];
                $numIndexType = checkElementIsUnsignedInt($numIndex);
                $deviceIdType = checkElementIsUnsignedInt($deviceID);
                $checkNumIndexExist = $dev->checkNumIndexExist($deviceID, $numIndex);
//                $id = trim($_POST["id"]);
//                $idType = checkElementIsUnsignedInt($id);
                if($numIndexType == false || $deviceIdType == false || empty($checkNumIndexExist) /*$idType == false*/) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
//                $connect = $dev->getIndexConindexForPPPConnection($id, '');
                $connect = $dev->getConnIndexByID($deviceID);
                if(!empty($paramName) && !empty($paramVal) && !empty($paramType) /*&& !empty($connect[0]->id) && !empty($connect[0]->num_index)*/ && !empty($connect[0]->conn_index)) {
//                    $numIndex = $connect[0]->num_index;
                    $connIndex = $connect[0]->conn_index;
//                    $deviceID = $connect[0]->id;
                    $numIndexType = checkElementIsUnsignedInt($numIndex);
                    $connIndexType = checkElementIsUnsignedInt($connIndex);
                    $deviceIDType = checkElementIsUnsignedInt($deviceID);
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true && $numIndexType == true && $connIndexType == true && $deviceID == true) {
                        $xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$pppoeWanSet, $deviceID, $paramName, $paramVal, $paramType, $numIndex, $connIndex, 0);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceID, $resForInsert, $userID, $fwName);
                            $getConnect = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $getConnect);
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }

            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'changePPPIPv6Wan':
            $_SESSION["Refresh"] = "true";
            if(isset($_POST['changedParamNames']) && isset($_POST['changedParamValues']) && isset($_POST['changedParamTypes']) && isset($_POST["id"])) {
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $id = trim($_POST["id"]);
                $idType = checkElementIsUnsignedInt($id);
                if($idType == false) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
                $connect = $dev->getIndexConindexForPPPConnection($id, '');
                if(!empty($paramName) && !empty($paramVal) && !empty($paramType) && !empty($connect[0]->id) && !empty($connect[0]->num_index) && !empty($connect[0]->conn_index)) {
                    $numIndex = $connect[0]->num_index;
                    $connIndex = $connect[0]->conn_index;
                    $deviceID = $connect[0]->id;
                    $numIndexType = checkElementIsUnsignedInt($numIndex);
                    $connIndexType = checkElementIsUnsignedInt($connIndex);
                    $deviceIDType = checkElementIsUnsignedInt($deviceID);
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true && $numIndexType == true && $connIndexType == true && $deviceID == true) {
                        $xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$pppoeWanIPv6Set, $deviceID, $paramName, $paramVal, $paramType, $numIndex, $connIndex, 0);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceID, $resForInsert, $userID, $fwName);
                            $getConnect = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $getConnect);
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }

            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'addPPPWan':
            if (isset($_POST['deviceID']) && isset($_POST['changedParamNames']) && isset($_POST['changedParamValues'])
                && isset($_POST['changedParamTypes']) && isset($_POST['type'])) {
                $_SESSION["Refresh"] = "true";
                $deviceId = trim($_POST['deviceID']);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $index = '%d';
//                $connectIndex = trim($_POST['connectIndex']);
                $deviceIdType = checkElementIsUnsignedInt($deviceId);
//                $conIndexType = checkElementIsUnsignedInt($connectIndex);
                if($deviceIdType == false ) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
                $result = array("result" => 'false');
                $type = trim($_POST['type']);
                if($type != "pppoe" && $type != "l2tp" && $type != "pptp" && $type != 'pppoeIPv6') {
                    $result = array("result" => 'Undefined type');
                    echo json_encode($result);
                    return false;
                }
                if ($deviceId != '' && !empty($paramNames) && !empty($paramVal) && !empty($paramType) && !empty($type)) {
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true) {
                        $connectIndex = $dev->getConnIndexByID($deviceId);
                        $xml = CreateXML::createTheSETXMLForWanToAdd($type, $deviceId, $paramName, $paramVal, $paramType, $index, $connectIndex[0]->conn_index);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$addPPP, $deviceId, $resForInsert, $userID, $fwName);
                            $data = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            if ($data) {
//                                if ($isDefConn == true) {
//                                    $data = setDefaultConnection($modelParams, $connectIndex, 1, '', $deviceId, $userID);
//                                }
                                if (isset($_POST["interface_type"]) && $_POST["interface_type"] != '-1') {
                                    $interface_type = $_POST["interface_type"];
                                    $data = selectInterface($modelParams, $deviceId, $interface_type, $userID, $fwName);
                                }
                                $result = array("result" => $data);
                            } else {
                                $result = array("result" => 'false');
                            }
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'addPPPDualStackWan':
            if (isset($_POST['deviceID']) && isset($_POST['type'])) {
                $_SESSION["Refresh"] = "true";
                $deviceId = trim($_POST['deviceID']);
                $paramNamesPPP = $_POST['changedParamNamesPPP'];
                $paramValesPPP = $_POST['changedParamValuesPPP'];
                $paramTypesPPP = $_POST['changedParamTypesPPP'];
                $paramNamesIPv6 = $_POST['changedParamNamesIPv6'];
                $paramValesIPv6 = $_POST['changedParamValuesIPv6'];
                $paramTypesIPv6 = $_POST['changedParamTypesIPv6'];
                $paramValPPP = array_map("trimArray", $paramValesPPP);
                $paramNamePPP = array_map("trimArray", $paramNamesPPP);
                $paramTypePPP = array_map("trimArray", $paramTypesPPP);
                $paramValIPv6 = array_map("trimArray", $paramValesIPv6);
                $paramNameIPv6 = array_map("trimArray", $paramNamesIPv6);
                $paramTypeIPv6 = array_map("trimArray", $paramTypesIPv6);
                $index = '%d';
//                $connectIndex = trim($_POST['connectIndex']);
                $deviceIdType = checkElementIsUnsignedInt($deviceId);
//                $conIndexType = checkElementIsUnsignedInt($connectIndex);
                if($deviceIdType == false ) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
                $result = array("result" => 'false');
                $type = trim($_POST['type']);
                if($type != 'pppoeDualStack') {
                    $result = array("result" => 'Undefined type');
                    echo json_encode($result);
                    return false;
                }
                if ($deviceId != '' && !empty($type)) {
//                    $paramValuesEmpty = isArrayElementEmpty($paramVal);
//                    $paramNamesEmpty = isArrayElementEmpty($paramName);
//                    $paramTypesEmpty = isArrayElementEmpty($paramType);
//                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true) {
                        $connectIndex = $dev->getConnIndexByID($deviceId);
                        $xml1 = CreateXML::createTheSETXMLForWanToAdd("pppoe", $deviceId, $paramNamePPP, $paramValPPP, $paramTypePPP, $index, $connectIndex[0]->conn_index);
                        $modelParams = new ModelParams();
                        $resForInsert1 = $modelParams->setLanWlanParams($xml1);
                        $xml2 = CreateXML::createTheSETXMLForWanToAdd("dualStack", $deviceId, $paramNameIPv6, $paramValIPv6, $paramTypeIPv6, $index, $connectIndex[0]->conn_index);
                        $modelParams = new ModelParams();
                        $resForInsert2 = $modelParams->setLanWlanParams($xml2);
                        if ($resForInsert1 != 0 && $resForInsert2 != 0) {
                            $getAllXml1 = CreateXML::createTheXMLForSet(ActionNamesConstants::$addPPP, $deviceId, $resForInsert1, $userID, $fwName);
                            $getAllXml2 = CreateXML::createTheXMLForSet(ActionNamesConstants::$addDualStack, $deviceId, $resForInsert2, $userID, $fwName);
                            $data1 = ConnectTCP::connectToGetDataForAPI($getAllXml1);
                            $data2 = ConnectTCP::connectToGetDataForAPI($getAllXml2);
                            if ($data1 && $data2) {
                                if (isset($_POST["interface_type"]) && $_POST["interface_type"] != '-1') {
                                    $interface_type = $_POST["interface_type"];
                                    $data = selectInterface($modelParams, $deviceId, $interface_type, $userID, $fwName);
                                }
                                $result = array("result" => $data2);
                            } else {
                                $result = array("result" => 'false');
                            }
                        } else {
                            $result = array("result" => 'false');
                        }
//                    } else {
//                        $result = array("result" => 'false');
//                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'setStaticWan':
            if(isset($_POST['changedParamNames']) && isset($_POST['changedParamValues']) && isset($_POST['changedParamTypes'])
            && isset($_POST['numIndex']) && isset($_POST['deviceID'])&& /*isset($_POST['id']) &&*/ isset($_POST["having"])) {
                $_SESSION["Refresh"] = "true";
                $deviceId = trim($_POST['deviceID']);
                $index = trim($_POST["numIndex"]);
//                $id = trim($_POST["id"]);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $having = trim($_POST["having"]);
//                $idType = checkElementIsUnsignedInt($id);
//                $deviceId = '';
//                $index = '';
//                $conn_index = '';

//                if($idType == false) {
//                    $result = array("result" => 'false');
//                    echo json_encode($result);
//                    return false;
//                }

                if($having == 0) {
//                    $deviceId = $id;
                    $index = 1;
                    $connectIndex = $dev->getConnIndexByID($deviceId);
                    $conn_index = $connectIndex[0]->conn_index;
                } else {
                    $connectIndex = $dev->getConnIndexByID($deviceId);
                    $conn_index = $connectIndex[0]->conn_index;
//                    var_dump($deviceId);
//                    return false;
//                    $connect = $dev->getIndexConindexForIpoeConnection($id, '');
//                    $deviceId = $connect[0]->id;
//                    $index = $connect[0]->num_index;
//                    $conn_index = $connect[0]->conn_index;
                }

                if(!empty($paramName) && !empty($paramType) && !empty($paramVal) /*&& $id != ''*/ && $having != '' && !empty($index) && !empty($deviceId) && !empty($conn_index)) {
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    $numIndexType = checkElementIsUnsignedInt($index);
                    $connIndexType = checkElementIsUnsignedInt($conn_index);
                    $deviceIDType = checkElementIsUnsignedInt($deviceId);
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true && $numIndexType == true && $connIndexType == true && $deviceIDType == true) {
                        $xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$staticWanSet, $deviceId, $paramName, $paramVal, $paramType, $index, $conn_index, $having);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, $userID, $fwName);
                            $data = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $data);
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'setStaticIPv6Wan':
            if(isset($_POST['changedParamNames']) && isset($_POST['changedParamValues'])
                && isset($_POST['changedParamTypes']) && isset($_POST['id']) && isset($_POST["having"])) {
                $_SESSION["Refresh"] = "true";
//                $deviceId = trim($_POST['deviceID']);
                $id = trim($_POST["id"]);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $having = trim($_POST["having"]);
                $idType = checkElementIsUnsignedInt($id);
                $deviceId = '';
                $index = '';
                $conn_index = '';

                if($idType == false) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }

                if($having == 0) {
                    $deviceId = $id;
                    $index = 1;
                    $connectIndex = $dev->getConnIndexByID($deviceId);
                    $conn_index = $connectIndex[0]->conn_index;
                } else {
                    $connect = $dev->getIndexConindexForIpoeConnection($id, '');
                    $deviceId = $connect[0]->id;
                    $index = $connect[0]->num_index;
                    $conn_index = $connect[0]->conn_index;
                }

                if(!empty($paramName) && !empty($paramType) && !empty($paramVal) && $id != '' && $having != '' && !empty($index) && !empty($deviceId) && !empty($conn_index)) {
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    $numIndexType = checkElementIsUnsignedInt($index);
                    $connIndexType = checkElementIsUnsignedInt($conn_index);
                    $deviceIDType = checkElementIsUnsignedInt($deviceId);
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true && $numIndexType == true && $connIndexType == true && $deviceId == true) {
                        $xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$staticIPv6WanSet, $deviceId, $paramName, $paramVal, $paramType, $index, $conn_index, $having);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, $userID, $fwName);
                            $data = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $data);
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;


        case 'addStaticWan':
            if(isset($_POST['deviceID']) && isset($_POST['changedParamNames']) && isset($_POST['changedParamValues']) &&
                isset($_POST['changedParamTypes']) && isset($_POST['type'])) {
                $_SESSION["Refresh"] = "true";
                $deviceId = trim($_POST['deviceID']);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $index = '%d';
//                $connectIndex = trim($_POST['connectIndex']);
                $type = trim($_POST['type']);

                if($type != "static" && $type != "staticIPv6") {
                    $result = array("result" => 'Undefined type');
                    echo json_encode($result);
                    return false;
                }
                $deviceIdType = checkElementIsUnsignedInt($deviceId);
//                $conIndexType = checkElementIsUnsignedInt($connectIndex);
                if($deviceIdType == false) {
                    $result = array("result" => 'false1');
                    echo json_encode($result);
                    return false;
                }
                if($deviceId != '' && !empty($paramName) && !empty($paramVal) && !empty($paramType) && !empty($type) ) {
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true) {
                        $connectIndex = $dev->getConnIndexByID($deviceId);
                        $xml = CreateXML::createTheSETXMLForWanToAdd($type, $deviceId, $paramName, $paramVal, $paramType, $index, $connectIndex[0]->conn_index);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$addPPP, $deviceId, $resForInsert, $userID, $fwName);
                            $data = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            if ($data) {
//                                if ($isDefConn == true) {
//                                    $data = setDefaultConnection($modelParams, $connectIndex, $index, 'Static', $deviceId, $userID);
//                                }
                                if (isset($_POST["interface_type"]) && trim($_POST["interface_type"]) != '-1') {
                                    $interface_type = $_POST["interface_type"];
                                    $data = selectInterface($modelParams, $deviceId, $interface_type, $userID, $fwName);
                                }
                                $result = array("result" => $data);
                            } else {
                                $result = array("result" => 'false2');
                            }
                        } else {
                            $result = array("result" => 'false3');
                        }
                    } else {
                        $result = array("result" => 'false4');
                    }
                } else {
                    $result = array("result" => 'false5');
                }
            } else {
                $result = array("result" => 'false6');
            }
            echo json_encode($result);
            break;

        case 'setDynamicWan':
            if(isset($_POST['changedParamNames']) && isset($_POST['changedParamValues']) && isset($_POST['changedParamTypes'])
                && isset($_POST['numIndex']) && isset($_POST['deviceID']) /*&& isset($_POST['id'])*/ && isset($_POST["having"])) {
                $_SESSION["Refresh"] = "true";
                $deviceId = trim($_POST['deviceID']);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $index = trim($_POST["numIndex"]);
                $having = trim($_POST["having"]);
//                $id = trim($_POST['id']);
//                $idType = checkElementIsUnsignedInt($id);
//                if($idType == false) {
//                    $result = array("result" => 'false');
//                    echo json_encode($result);
//                    return false;
//                }
                if($having == 0) {
//                    $deviceId = $id;
                    $index = 1;
                    $connectIndex = $dev->getConnIndexByID($deviceId);
                    $conn_index = $connectIndex[0]->conn_index;
                } else {
                    $connectIndex = $dev->getConnIndexByID($deviceId);
                    $conn_index = $connectIndex[0]->conn_index;
//                    $connect = $dev->getIndexConindexForIpoeConnection($id, '');
//                    $deviceId = $connect[0]->id;
//                    $index = $connect[0]->num_index;
//                    $conn_index = $connect[0]->conn_index;
                }
                if(/*$id != '' && */ !empty($paramName) && !empty($paramVal) && !empty($paramType) && $having != '' && !empty($index) && !empty($deviceId) && !empty($conn_index)) {
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    $numIndexType = checkElementIsUnsignedInt($index);
                    $connIndexType = checkElementIsUnsignedInt($conn_index);
                    $deviceIDType = checkElementIsUnsignedInt($deviceId);
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true && $numIndexType == true && $connIndexType == true && $deviceId == true) {
                        $xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$dynamicWanSet, $deviceId, $paramName, $paramVal, $paramType, $index, $conn_index, $having);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, $userID, $fwName);
                            $data = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $data);
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'setDynamicWanIPv6':
            if(isset($_POST['changedParamNames']) && isset($_POST['changedParamValues'])
                && isset($_POST['changedParamTypes']) && isset($_POST['id']) && isset($_POST["having"])) {
                $_SESSION["Refresh"] = "true";
//                $deviceId = trim($_POST['deviceID']);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
//                $index = trim($_POST["index"]);
                $id = trim($_POST['id']);
                $having = trim($_POST["having"]);
//                $indexType = checkElementIsUnsignedInt($index);
//                $deviceIdType = checkElementIsUnsignedInt($deviceId);
                $idType = checkElementIsUnsignedInt($id);
                if($idType == false) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
                if($having == 0) {
                    $deviceId = $id;
                    $index = 1;
                    $connectIndex = $dev->getConnIndexByID($deviceId);
                    $conn_index = $connectIndex[0]->conn_index;
                } else {
                    $connect = $dev->getIndexConindexForIpoeConnection($id, '');
                    $deviceId = $connect[0]->id;
                    $index = $connect[0]->num_index;
                    $conn_index = $connect[0]->conn_index;
                }
                if($id != '' && !empty($paramName) && !empty($paramVal) && !empty($paramType) && $having != '' && !empty($index) && !empty($deviceId) && !empty($conn_index)) {
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    $numIndexType = checkElementIsUnsignedInt($index);
                    $connIndexType = checkElementIsUnsignedInt($conn_index);
                    $deviceIDType = checkElementIsUnsignedInt($deviceId);
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true && $numIndexType == true && $connIndexType == true && $deviceId == true) {
                        $xml = CreateXML::createTheSETXMLForWan(ActionNamesConstants::$dynamicIPv6WanSet, $deviceId, $paramName, $paramVal, $paramType, $index, $conn_index, $having);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, $userID, $fwName);
                            $data = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $data);
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'addDynamicWan':
            if(isset($_POST['deviceID']) && isset($_POST['changedParamNames']) && isset($_POST['changedParamValues']) &&
                isset($_POST['changedParamTypes']) && isset($_POST['type'])) {
                $_SESSION["Refresh"] = "true";
                $deviceId = trim($_POST['deviceID']);
//                $isDefConn = trim($_POST['defConnection']);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $index = '%d';
//                $connectIndex = ($_POST['connectIndex']);
                $type = ($_POST['type']);
                if($type != "dynamic" && $type != "dynamicIPv6") {
                    $result = array("result" => 'Undefined type');
                    echo json_encode($result);
                    return false;
                }
                $deviceIdType = checkElementIsUnsignedInt($deviceId);
//                $conIndexType = checkElementIsUnsignedInt($connectIndex);
                if($deviceIdType == false) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
                if($deviceId != '' && !empty($paramName) && !empty($paramType) && !empty($paramVal) && !empty($type)) {
                    if (isset($_POST['forWeb'])) {
                        $paramValuesEmpty = $paramVal;
                        $paramNamesEmpty = $paramName;
                        $paramTypesEmpty = $paramType;
                    } else {
                        $paramValuesEmpty = isArrayElementEmpty($paramVal);
                        $paramNamesEmpty = isArrayElementEmpty($paramName);
                        $paramTypesEmpty = isArrayElementEmpty($paramType);
                    }
                    if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true) {
                        $connectIndex = $dev->getConnIndexByID($deviceId);
                        $xml = CreateXML::createTheSETXMLForWanToAdd($type, $deviceId, $paramName, $paramVal, $paramType, $index, $connectIndex[0]->conn_index);
                        $modelParams = new ModelParams();
                        $resForInsert = $modelParams->setLanWlanParams($xml);
                        if ($resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$addPPP, $deviceId, $resForInsert, $userID, $fwName);
                            $data = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            if ($data) {
                                if (isset($_POST["interface_type"]) && $_POST["interface_type"] != '-1') {
                                    $interface_type = $_POST["interface_type"];
                                    $data = selectInterface($modelParams, $deviceId, $interface_type, $userID, $fwName);
                                }
                                $result = array("result" => $data);
                            } else {
                                $result = array("result" => 'false');
                            }
                        } else {
                            $result = array("result" => 'false');
                        }
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'setWLAN':
            if(/*isset($_POST['wlanID'])*/ isset($_POST['deviceID']) && isset($_POST['numIndex']) &&  isset($_POST['changedParamNames']) && isset($_POST['changedParamValues']) && isset($_POST['changedParamTypes'])) {
                $deviceId = trim($_POST['deviceID']);
                $numIndex = trim($_POST['numIndex']);
//                $wlanID = trim($_POST['wlanID']);
                $paramNames = $_POST['changedParamNames'];
                $paramVales = $_POST['changedParamValues'];
                $paramTypes = $_POST['changedParamTypes'];
                $paramVal = array_map("trimArray", $paramVales);
                $paramName = array_map("trimArray", $paramNames);
                $paramType = array_map("trimArray", $paramTypes);
                $deviceIdType = checkElementIsUnsignedInt($deviceId);
//                $wlanIDType = checkElementIsUnsignedInt($wlanID);
                $numIndexType = checkElementIsUnsignedInt($numIndex);
                if(/*$wlanIDType == false*/  $deviceIdType == false || $numIndexType == false) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
                $paramValuesEmpty = isArrayElementEmpty($paramVal);
                $paramNamesEmpty = isArrayElementEmpty($paramName);
                $paramTypesEmpty = isArrayElementEmpty($paramType);
                if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true) {
                    $modelParams = new ModelParams();
//                    $getWlan = $modelParams->getWirelessParam($wlanID);
//                    $index = $getWlan[0]->num_index;
//                    $indexType = checkElementIsUnsignedInt($index);
//                    if (!is_array($index) && !empty($index) && $indexType == true) {
                    if (!is_array($numIndex) && !empty($numIndex)) {
                        $xml = CreateXML::createTheSETXML1(ActionNamesConstants::$wlanSet, $deviceId, $paramNames, $paramVales, $paramTypes, $numIndex);
                    } else {
                        $result = array("result" => 'false');
                        echo json_encode($result);
                        return false;
                    }
                    $resForInsert = $modelParams->setLanWlanParams($xml);
                    if ($resForInsert != 0) {
                        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$setwLan, $deviceId, $resForInsert, $userID, $fwName);
                        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                        $result = array("result" => $result);
                    } else {
                        $result = array("result" => 'false');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;
        case 'setDefaultGateway':
            if(/*isset($_POST['connectType']) && isset($_POST["wanID"])*/ isset($_POST['numIndex']) && isset($_POST['deviceID'])) {
                $numIndex = trim($_POST['numIndex']);
                $deviceId = trim($_POST['deviceID']);
//                $conn_type = trim($_POST['connectType']);
//                $wanId = trim($_POST["wanID"]);
                if(/*$conn_type != '' && $wanId != ''*/ $numIndex != '' ) {
                    $deviceIdType = checkElementIsUnsignedInt($deviceId);
                    $numIndexType = checkElementIsUnsignedInt($numIndex);
                    $checkNumIndexExist = $dev->checkNumIndexExist($deviceId, $numIndex);
//                    $wanIdType = checkElementIsUnsignedInt($wanId);
                    if($deviceIdType == false || $numIndexType == false || empty($checkNumIndexExist)/*|| $wanIdType == false*/) {
                        $result = array("result" => 'false');
                        echo json_encode($result);
                        return false;
                    }
                    
                    $connect = $dev->getConnIndexByID($deviceId);
                    $getIpoeConnType = $dev->getIpoeConnectionTypeByID($deviceId, $numIndex);
                    $getpppConnType = $dev->getPPPConnectionTypeByID($deviceId, $numIndex);
                    if (!empty($getIpoeConnType)) {
                        $conn_type = $getIpoeConnType[0]->type_name;
                    } else if(!empty($getpppConnType)){
                        $conn_type = $getpppConnType[0]->type_name;
                    }
//                    if ($conn_type == "DHCP" || $conn_type == "Static" || $conn_type == "Static_v6" ||  $conn_type == "DHCP_v6") {
//                        $connect = $dev->getIndexConindexForIpoeConnection($wanId, $deviceId);
//                    } else {
//                        $connect = $dev->getIndexConindexForPPPConnection($wanId, $deviceId);
//                    }
                    if(!empty($connect[0]->conn_index) /*&& !empty($connect[0]->num_index)*/) {
                        $connIndex = $connect[0]->conn_index;
//                        $numIndex = $connect[0]->num_index;
                        $connIndexType = checkElementIsUnsignedInt($connIndex);
//                        $numIndexType = checkElementIsUnsignedInt($numIndex);
                        if ($connIndexType == true /*&& $numIndexType == true*/) {
                            $xml = CreateXML::createDefGatewayXML($connIndex, $numIndex, $conn_type);
                            $modelParams = new ModelParams();
                            $resForInsert = $modelParams->setParams($xml);
                            if ($resForInsert != 0) {
                                $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, $userID, $fwName);
                                $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                                $result = array("result" => $result);
                            } else {
                                $result = array("result" => 'false');
                            }
                        } else {
                            $result = array("result" => 'false1');
                        }
                    } else {
                        $result = array("result" => 'false2');
                    }

                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;
        case 'getpppParams':
            if(isset($_POST['deviceID'])) {
                $deviceId = trim($_POST['deviceID']);
                if($deviceId != '') {
                    $result = $dev->getPPPparams($deviceId);
                    if(empty($result)) {
                        $result = array("result" => 'There is no any connection');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;
        case 'getipoeParams':
            if(isset($_POST['deviceID'])) {
                $deviceId = trim($_POST['deviceID']);
                if($deviceId != '') {
                    $result = $dev->getipoearams($deviceId);
                    if(empty($result)) {
                        $result = array("result" => 'There is no any connection');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;
        case 'getWlanList':
            if(isset($_POST['deviceID'])) {
                $deviceId = trim($_POST['deviceID']);
                if($deviceId != '') {
                    $result = $dev->getWLanParams($deviceId);
                    if(empty($result)) {
                        $result = array("result" => 'There is no any connection');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;
        case 'getDeviceConnectionsList':
            if(isset($_POST['deviceID'])) {
                $deviceId = trim($_POST['deviceID']);
                if($deviceId != '') {
                    $result = $dev->getDeviceConnectionsList($deviceId);
                    if(empty($result)) {
                        $result = array("result" => 'There is no any connection');
                    }
                } else {
                    $result = array("result" => 'false');
                }
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;
        case 'refresh':
            if(isset($_POST['deviceID'])) {
                $deviceId = $_POST['deviceID'];
                $xml = CreateXML::createTheXML(ActionNamesConstants::$refresh, $deviceId, "", $fwName, $userID);
                $connRequest = ConnectTCP::connectToGetDataForAPI($xml);
                $result = array("result" => $connRequest);
                echo json_encode($result);
            } else {
                $result = array("result" => false);
                echo json_encode($result);
            }
            break;

        case 'reboot':
            if(isset($_POST['deviceID'])) {
                $deviceId = $_POST['deviceID'];
                $xml = CreateXML::createTheXML(ActionNamesConstants::$reboot, $deviceId, "", $fwName, $userID);
                $rebootDev = ConnectTCP::connectToGetDataForAPI($xml);
                $result = array("result" => $rebootDev);
                echo json_encode($result);
            } else {
                $result = array("result" => false);
                echo json_encode($result);
            }
            break;
        case 'reset':
            if(isset($_POST['deviceID'])) {
                $deviceId = $_POST['deviceID'];
                $xml = CreateXML::createTheXML(ActionNamesConstants::$reset, $deviceId, "", $fwName, $userID);
                $resetDev = ConnectTCP::connectToGetDataForAPI($xml);
                $result = array("result" => $resetDev);
                echo json_encode($result);
            } else {
                $result = array("result" => false);
                echo json_encode($result);
            }
            break;
        case 'setTemplate':
            if(isset($_POST['deviceID']) && isset($_POST['templateID'])) {
                $deviceId = $_POST['deviceID'];
                $templateId = $_POST['templateID'];
                $template = $dev->getTemplateByID($templateId);
                if(empty($template)) {
                    $result = array("result" => false);
                    echo json_encode($result);
                    return false;
                }
                $modelParams = new ModelParams();
                $resForUpdate = $modelParams->setTemplateId($deviceId, $templateId);
//                $result = array("result" => true);
                if ($resForUpdate) {
                    $xml = CreateXML::createTheXML(ActionNamesConstants::$setTemplate, $deviceId, '', $fwName, $userID);
                    $setTemplate = ConnectTCP::connectToGetDataForAPI($xml);
                    $result = array("result" => $setTemplate);
                    echo json_encode($result);
                }else {
                    $result = array("result" => false);
                    echo json_encode($result);
                }
            } else {
                $result = array("result" => false);
                echo json_encode($result);
            }
            break;
        case 'getTemplates':
            $template = $dev->getAllTemplates();
            echo json_encode($template);
            break;

        case 'setParamsDevice':
            if(isset($_POST['deviceID']) && isset($_POST['name']) && isset($_POST['value']) && isset($_POST['type'])) {
                $deviceId = $_POST['deviceID'];
                $name = $_POST["name"];
                $value = $_POST["value"];
                $type = $_POST["type"];
                $paramValuesEmpty = isArrayElementEmpty($value);
                $paramNamesEmpty = isArrayElementEmpty($name);
                $paramTypesEmpty = isArrayElementEmpty($type);
                if($paramValuesEmpty == true && $paramNamesEmpty == true && $paramTypesEmpty == true && count($name)==count($value) && count($name)==count($type) && count($value)==count($type)) {
                    $xml = CreateXML::setForDevParams($name, $value, $type);
                    $modelParams = new ModelParams();
                    $resForInsert = $modelParams->setLanWlanParams($xml);
                    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$set, $deviceId, $resForInsert, $userID, $fwName);
                    $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
//                    $xmlRefresh = CreateXML::createTheXML(ActionNamesConstants::$refresh, $deviceId, "", "NoName", $userID);
//                    $connRequest = ConnectTCP::connectToGetDataForAPI($xmlRefresh);
                    echo json_encode(array("result" => $result));
                } else {
                    $result = array("result" => false);
                    echo json_encode($result);
                }
            } else {
                $result = array("result" => false);
                echo json_encode($result);
            }
            break;

        case 'getSelectedParam':
            if(isset($_POST['deviceID']) && isset($_POST['name'])) {
                $devID = $_POST['deviceID'];
                $getSeriaNum = $dev->getSerialNumberByID($devID);
                $path = dirname(__FILE__) . "/../../../tmp/". $getSeriaNum[0]->serial_number ."_value.xml";
                $file = file_exists($path);
                if($file) {
                    if(filesize($path) == 0) {
                        $result = array("result" => false);
                        echo json_encode($result);
                        return false;
                    }
                    $fileContent = file_get_contents($path);
                    $searchStart = strpos($fileContent, "<ParameterList");
                    $xml = substr($fileContent, $searchStart);
                    $searchEnd = strpos($xml, "</cwmp:GetParameterValuesResponse>");
                    $xml = substr($xml, 0, $searchEnd);

                    $string = <<<XML
$xml
XML;
                    $xmlObject = new SimpleXMLElement($string);
                    $result = array();
                    $res = array();
                    if (!is_array($_POST['name'])) {
                        $searchValue = $_POST['name'] . ".";
                        foreach ($xmlObject->ParameterValueStruct as $value) {
                            if (strpos($value->Name, $_POST['name'].".") !== false || $value->Name==$_POST['name']) {
                                $names = "$value->Name";
                                $values = "$value->Value";
                                $array = array($names => $values);
                                array_push($res, $array);
                            }
                        }
                        $resul = array($_POST['name'] => $res);
                        array_push($result, $resul);
                        $res = array();
                    } else {
                        foreach ($_POST['name'] as $names) {
                            $searchValue = $names . ".";
                            foreach ($xmlObject->ParameterValueStruct as $value) {
                                if (strpos($value->Name, $searchValue) !== false || $value->Name == $names) {
                                    $array = array("$value->Name" => "$value->Value");
                                    array_push($res, $array);
                                }
                            }
                            $resul = array("$names" => $res);
                            array_push($result, $resul);
                            $res = array();
                        }
                    }
                    echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                } else {
                    $result = array("result" => false);
                    echo json_encode($result);
                }
            } else {
                $result = array("result" => false);
                echo json_encode($result);
            }
            break;

        case 'addClient':
            $firstName = "";
            $surName = "";
            $address = "";
            $email = "";
            $patronymicName = "";
            $contractNumber = "";
            if(isset($_POST['firstName'])){ $firstName = trim($_POST['firstName']);}
            if(isset($_POST['surName'])){ $surName = trim($_POST['surName']);}
            if(isset($_POST['address'])){ $address = trim($_POST['address']);}
            if(isset($_POST['email'])){ $email = trim($_POST['email']);}
            if(isset($_POST['patronymicName'])){ $patronymicName = trim($_POST['patronymicName']);}
            if(isset($_POST['contractNumber'])){ $contractNumber = trim($_POST['contractNumber']);}
            if($firstName == '' || $surName == '') {
                $result = array("result" => 'false');
                echo json_encode($result);
                return false;
            }
            if($email != '') {
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $client = new ModelClient();
                    $existsCount = $client->checkEmailExist($email);
                    if ($existsCount && $existsCount[0]->status == 1) {
                        $result = array("result" => 'false');
                        echo json_encode($result);
                        return false;
                    } elseif($existsCount && $existsCount[0]->status == 2) {
                        $result = array("result" => 'false');
                        echo json_encode($result);
                        return false;
                    } else {
                        $addClientID = addOnlyClient($firstName, $surName, $address, $email,$patronymicName, $contractNumber);
                        $result = array("result" => $addClientID);
                        echo json_encode($result);
                        return true;
                    }
                } else {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
            } else {
                $addClientID = addOnlyClient($firstName, $surName, $address, $email,$patronymicName, $contractNumber);
                $result = array("result" => $addClientID);
                echo json_encode($result);
                return true;
            }
            break;

        case 'getClientList':
            $client = new ModelClient();
            $clients = $client->getClients();
            echo json_encode($clients);
            break;

        case 'addDeviceFromSale':
            if(isset($_POST['serial_number']) && isset($_POST['model_name']) && isset($_POST['client_id'])) {
                $serial = $_POST['serial_number'];
                $modelName = $_POST['model_name'];
                $client_id = $_POST['client_id'];
                if($serial != '' && $modelName != '' && $client_id != '') {
                    $client = new ModelClient();

                    $clientExist = $client->checkClientExist($client_id);
                    if(empty($clientExist)) {
                        $result = array("result" => "Client does not exist");
                        echo json_encode($result);
                        return false;
                    }
                    $macExistsCount = $client->checkMacExist($serial);
                    $maxExistInDevices = $client->checkMacExistInDevices($serial);
                    if ($macExistsCount[0]->count != 0 || $maxExistInDevices[0]->count != 0) {
                        $result = array("result" => "Serial number already exist");
                        echo json_encode($result);
                        return false;
                    }
                    $modelExistsCount = $client->checkModelExist($modelName);
                    if ($modelExistsCount[0]->count == 0) {
                        $result = array("result" => "Model does not exist");
                        echo json_encode($result);
                        return false;
                    } else {
                        $model = $client->getModelNameByName($modelName);
                    }
                    $result = $client->addSaleChoosedClientWithouthConfig('-1','-1', $client_id, $serial, $model[0]->id, '', $model[0]->hw_version);
                    $result = array("result" => $result);
                } else {
                    $result = array("result" => "false11");
                }
            } else {
                $result = array("result" => "false1");
            }
            echo json_encode($result);
            break;

        case 'connectToClient':
            $client = new ModelClient();
            $clientID = trim($_POST['clientID']);
            $clientIdType = checkElementIsUnsignedInt($clientID);
            $userExist = $client->checkClientExist($clientID);
            $devID = $_POST['devID'];
            if(isset($_POST['templateID'])){
                $tarifID = trim($_POST['templateID']);
            } else {
                $tarifID = 0;
            }
            if(isset($_POST['groupID'])){
                $groupID = trim($_POST['groupID']);
            } else {
                $groupID = '';
            }
            if(empty($userExist) || $clientID=='' || $devID == '' || $clientIdType == false) {
                $result = array("result" => 'false');
                echo json_encode($result);
                return false;
            }
            if(is_array($devID)) {
                $devIDEmpty = isArrayElementEmpty($devID);
                $devIDUnsignedInt = checkIsArrayElementUnsignedInt($devID);
                $devExist = $client->checkUnknownDeviceExist($devID);

                if($devIDEmpty == false || $devIDUnsignedInt == false || empty($devExist)) {
                    $result = array("result" => 'false');
                    echo json_encode($result);
                    return false;
                }
                $update = $client->connectUnknownToClientByGroups($devID, $clientID, $tarifID, $groupID);
            } else {
                $deviceIdType = checkElementIsUnsignedInt(trim($devID));
                $devExist = $client->checkUnknownDeviceExist(trim($devID));
                if($deviceIdType == false || empty($devExist)) {
                    $result = array("result" => "false");
                    echo json_encode($result);
                    return false;
                }
                $update = $client->connectUnknownToClient(trim($devID), $clientID, $tarifID, $groupID);
            }
            if ($update) {
                $result = array("result" => 'true');
            } else {
                $result = array("result" => 'false');
            }
            echo json_encode($result);
            break;

        case 'resendDevice':
            if(isset($_POST['ip'])) {
                $ip = $_POST['ip'];
            } else {
                $ip = '';
            }
            if(isset($_POST['serial_number'])){
                $serialNumber = $_POST['serial_number'];
            } else {
                $serialNumber = '';
            }
            if($ip == '' && $serialNumber == '') {
                $result = array("result" => 'false');
                echo json_encode($result);
                return false;
            }
            $client = new ModelClient();
            $devID = $client->checkUnknownDeviceExistBySerialIp($ip, $serialNumber);
            if(empty($devID)) {
                $result = array("result" => 'false');
                echo json_encode($result);
                return false;
            }
            $xml = CreateXML::createTheXML(ActionNamesConstants::$resend, $devID[0]->id, "", $fwName, $userID);
            $result = ConnectTCP::connectToGetDataForAPI($xml);
            $result = array("result" => $devID[0]->id);
            echo json_encode($result);
            break;

        case 'getDevices':
            $dev = new Device();
            $devices = $dev->getAllDevices();
            echo json_encode($devices);
            return true;
            break;

        case 'getUnregisterDevices':
            $client = new ModelClient();
            if (isset($_POST["action"])) {
                $action = $_POST["action"];
                if($action=="getUnknowns") {
                    $result = $client->getAllUnknowns();
                } else if($action=="getPending") {
                    $result = $client->getAllPending();
                } else {
                    $result = array("result" => "Invalid action name");
                }
            } else {
                $result = $client->getAllUnregisterDevices();
            }
            echo json_encode($result);
            break;

        case 'getUnregisterDevicesByIpSerial':
            $client = new ModelClient();
            if(isset($_POST['ip']) && isset($_POST['serial_number'])) {
                $ip = $_POST['ip'];
                $serial = $_POST['serial_number'];
                $result = $client->getUnregisterDevicesByIpSerial($ip, $serial);
            } else if(isset($_POST['ip'])) {
                $ip = $_POST['ip'];
                $serial = '';
                $result = $client->getUnregisterDevicesByIpSerial($ip, $serial);
            } else if (isset($_POST['serial_number'])) {
                $ip = '';
                $serial = $_POST['serial_number'];
                $result = $client->getUnregisterDevicesByIpSerial($ip, $serial);
            } else {
                $result = array("result" => "false");
            }
            echo json_encode($result);
            break;

        case 'getModels':
            $dev = new Device();
            $models = $dev->getAllModels();
            echo json_encode($models);
            return true;
            break;

        case 'addModel':
            $dev = new Device();
            if(isset($_POST['modelName']) && isset($_POST['hardwareVersion'])) {
                $modelName = $_POST['modelName'];
                $modelHwVersion = $_POST['hardwareVersion'];
                if($modelName != '' && $modelHwVersion != '') {
                    $modelExistsCount = $dev->checkModelExist($modelName);
                    if ($modelExistsCount[0]->count == 0) {
                        $models = $dev->addNewModelAndHWVersion($modelName, $modelHwVersion);
                        $result = array("result" => $models);
                    } else {
                        $result = array("result" => "false");
                    }
                } else {
                    $result = array("result" => "false");
                }
            } else {
                $result = array("result" => "false");
            }
            echo json_encode($result);
            return true;
            break;
        case 'checkTaskStatus':
            $mod = new ModelUser();

            if (isset($_POST['taskId']) && $_POST['taskId'] != ''){
                $taskId = $_POST['taskId'];
                $operationStatus = $mod->getOperationStatusById($taskId);
                $result = array("Operation Status" => $operationStatus[0]->operation_status);
            }else{
                $result = array("result" => "false");
            }

            echo json_encode($result);
            break;

        case 'diagnostic':
            if (isset($_POST['device_id']) && isset($_POST['host']) && isset($_POST['type'])){
//                $connect = $dev->getIndexConindexForIpoeConnection($id, '');
//                $deviceId = $connect[0]->id;
//                $index = $connect[0]->num_index;
//                $connectIndex = $connect[0]->conn_index;
//                if($pingType != 'PPPoE' && $pingType != 'L2TP' && $pingType != 'LTE'){
//                    //get gateway and dnsservers
//                    $params = $modelParams->getDnsGateway($pingType, $deviceId);
//                    $dnsservers = $params[0]->dns_servers;
//                    if (($ind = strpos($dnsservers, ",")) !== false) {
//                        $dnsservers = substr($dnsservers, 0, $ind);
//                    }
//                }

                $deviceId = $_POST['device_id'];
                $host = $_POST['host'];
                $type = $_POST['type'];
                $modelParams = new ModelParams();

                $getDefaultGateway = $modelParams->getDefaultConnection($deviceId);
                if(empty($getDefaultGateway)) {
                    $result = array("result" => "No any WAN connection");
                    echo json_encode($result);
                    return false;
                } else {
                    $connectIndex = $getDefaultGateway[0]->conn_index;
                    $index = $getDefaultGateway[0]->num_index;
                    $pingType = $getDefaultGateway[0]->type;
                }
                if($type == "ping") {
                    $xmll = CreateXML::createDiagnosticFirstXML($connectIndex, $index, $host, $pingType, '4');
                    $resForInsert = $modelParams->setLanWlanParams($xmll);
                    if (!is_array($resForInsert) && $resForInsert != 0) {
                        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$diagnostic, $deviceId, $resForInsert, $userID, $fwName);
                        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                        $result = array("result" => $result);
                    } else if (is_array($resForInsert) && !empty ($resForInsert)) {
                        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$diagnostic, $deviceId, $resForInsert, $userID, $fwName);
                        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                        $result = array("result" => $result);
                    } else {
                        $result = array("result" => "false");
                    }
                } else if($type == "traceroute") {
                    if(isset($_POST['max_hop_count']) && isset($_POST['timeout'])) {
                        $maxHopCount = $_POST['max_hop_count'];
                        $timeOut = $_POST['timeout'];
                        $xmll = CreateXML::createDiagnosticFirstXMLForTracert($connectIndex, $index, $host, $pingType, $maxHopCount, $timeOut);
                        $resForInsert = $modelParams->setLanWlanParams($xmll);
                        if (!is_array($resForInsert) && $resForInsert != 0) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$tracert, $deviceId, $resForInsert, $userID, $fwName);
                            $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $result);
                        } else if (is_array($resForInsert) && !empty ($resForInsert)) {
                            $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$tracert, $deviceId, $resForInsert, $userID, $fwName);
                            $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                            $result = array("result" => $result);
                        } else {
                            $result = array("result" => "false");
                        }
                    } else {
                        $result = array("result" => "false");
                    }
                } else if($type == "upload"){
                    if(isset($_POST['file_size'])) {
                        $fileSize = $_POST['file_size'];
                        $xmll = CreateXML::createUploadDownloadDiagnosticXML($connectIndex, $index, $host, $pingType, 1, $fileSize);
                        $resForInsert = $modelParams->setLanWlanParams($xmll);
                        $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$uploadDiagnostics, $deviceId, $resForInsert, $userID, $fwName);
                        $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                        $result = array("result" => $result);
                    } else {
                        $result = array("result" => "false");
                    }
                } else if($type == "download") {
                    $xmll = CreateXML::createUploadDownloadDiagnosticXML($connectIndex, $index, $host, $pingType, 2, '');
                    $resForInsert = $modelParams->setLanWlanParams($xmll);
                    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$downloadDiagnostics, $deviceId, $resForInsert, $userID, $fwName);
                    $result = ConnectTCP::connectToGetDataForAPI($getAllXml);
                    $result = array("result" => $result);
                } else {
                    $result = array("result" => "false");
                }
            }else{
                $result = array("result" => "false");
            }
            echo json_encode($result);
            break;

        case 'ConfigUp':
            if(isset($_POST['deviceID']) && isset($_POST['fileID'])) {
                $deviceID = $_POST['deviceID'];
                $configId = $_POST['fileID'];
                //echo 'Device ID = ',$deviceID,"\n";
                //echo 'Config ID = ',$configId,"\n";

                $fileType = "3 Vendor Configuration File";
                $filePath  = "index.php";
                $config = $dev->getConfig($configId);
                if(empty($config)) {
                    $result = array("Error" => "Invalid fileID");
                    echo json_encode($result);
                    return false;

                } else {
                    $fName = $config[0]->config_path;
                    $fSize = $config[0]->file_size;
                    $tokenAndFileId = $token . "/" . $configId;
                    //echo 'File path = ',$fName,"\n";
                    //echo 'File size = ',$fSize,"\n";
                }

                $modelParams = new ModelParams();
                $tokenAndFileId = $token . "/" . $configId;
                $stunSettings = readVersionInfoSettings();
                if ($stunSettings != false){
                    $configUrl = $stunSettings . $filePath  . "?authorization=" . $tokenAndFileId;
                }else{
                    $ip = $user->getIp()[0];
                    $port = $user->getPort()[0];
                    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                    $configUrl = $protocol . $ip->settings_value . ":" . $port->settings_value . "?authorization=" . $tokenAndFileId;
                    $xml = CreateXML::createTheSetXmlForUpdateBackupedConfig($configUrl, $fSize, $fileType);
                }
                $resForInsert = $modelParams->setLanWlanParams($xml);

                if ($resForInsert != 0) {
                    $getAllXml = CreateXML::createTheXMLForSet(ActionNamesConstants::$configUpdate, $deviceID, $resForInsert, $userID, $fwName);
                    //
                    $uploadConf = ConnectTCP::connectToGetDataForAPI($getAllXml);
                    $uploadConf = array("Task ID" => $uploadConf);
                    echo json_encode($uploadConf);
                } else {
                    echo 'false';
                }} else {
                echo json_encode($result = array("Error" => "Invalid request"));
            }
            break;
        case 'ConfigDownload':
            if(isset($_POST['deviceID'])) {
                $deviceId = $_POST['deviceID'];
                //echo 'Device ID = ',$deviceId;
                $xml = CreateXML::createTheXML(ActionNamesConstants::$backup_config, $deviceId, "", $fwName, $userID);
                $configdown = ConnectTCP::connectToGetDataForAPI($xml);
                $configdown = array("Task ID" => $configdown);
                echo json_encode($configdown);
            } else {
                echo json_encode($result = array("Error" => "Invalid request"));
            }
            break;
        case 'cpeConfigs':
            if(isset($_POST['deviceID'])) {
                $deviceID = $_POST['deviceID'];
                $configs = $dev->getDeviceConfigs($deviceID);
                echo json_encode($configs);
            }
            break;

        case 'getFromDB':
            $modelParams = new ModelParams();

            if (isset($_POST['device_id'])){
                $deviceId = $_POST['device_id'];
                $getDiagnosticResults = $modelParams->getIpDiagnosticResults($deviceId);
                if (count($getDiagnosticResults) >0){
                    $result = array();
                    for ($i = 0; $i < count($getDiagnosticResults); $i++){
                        $diagnosticResults = array("create date" => $getDiagnosticResults[$i]->create_date,"average" => $getDiagnosticResults[$i]->average);
                        array_push($result, $diagnosticResults);
                    }
                }else{
                    $result = array("result" => "false");
                }
            }else{
                $result = array("result" => "false");
            }
            echo json_encode($result);
            break;

        default:
            $result = array("result" => 'Undefined method');
            echo json_encode($result);
            return true;
            break;
    }
} else {
    $result = array("result" => 'Undefined method');
    echo json_encode($result);
}