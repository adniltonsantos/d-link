<?php
//$_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";
//require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//require_once $_SESSION['APPPATH']."models/xor/xor.php";
//require_once $_SESSION['APPPATH']."actions/api/token.php";
//include  $_SESSION['APPPATH'].'models/modelClient.php';
//
//function addOnlyClient($firstName, $surName, $address, $email, $patronymicName, $contractNumber){
//    $client = new ModelClient();
//    $result = $client->addOnlyClient($firstName, $surName, $address, $email, $patronymicName, $contractNumber);
//    if (!$result) {
//        $_SESSION['firstName'] = $firstName;
//        $_SESSION['surName'] = $surName;
//        $_SESSION['address'] = $address;
//        $_SESSION['email'] = $email;
//        $_SESSION['patronymicName'] = $patronymicName;
//        $_SESSION['contractNumber'] = $contractNumber;
//    } else {
//        return $result;
//    }
//}
//
//function checkToken($token) {
//    if($token != '') {
//        $login = token::check_token($token);
//        if($login!=false) {
//            $user = new ModelUser();
//            $userExist = $user->checkUserIdExist($login);
//            if(empty($userExist)) {
//                $result = array("result" => 'Invalid token');
//                echo json_encode($result);
//                return false;
//            } else {
//                $permissions = $user->getPermissionsByUserId($login);
//                if(count($permissions)==5) {
//                    $userID = $login;
//                    return $userID;
//                } else {
//                    $result = array("result" => 'User is not Administrator');
//                    echo json_encode($result);
//                    return false;
//                }
//            }
//        } else {
//            $result = array("result" => 'Invalid token');
//            echo json_encode($result);
//            return false;
//        }
//    } else {
//        $result = array("result" => 'Invalid token');
//        echo json_encode($result);
//        return false;
//    }
//}
//
//try {
//    if (isset($_POST['method']) && !empty($_POST['method'])) {
//        $userID = '';
//        $action = trim($_POST['method']);
//        if (session_id() == '') {
//            session_start();
//        }
//        if (isset($_POST['token'])) {
//            $token = trim($_POST['token']);
//            $tokenExist = checkToken($token);
//            if ($tokenExist == false) {
//                return false;
//            } else {
//                $userID = $tokenExist;
//            }
//        } else {
//            $result = array("result" => "false");
//            echo json_encode($result);
//            return false;
//        }
//    }
//
//    switch ($action) {
//        case 'addClient':
//            $firstName = "";
//            $surName = "";
//            $address = "";
//            $email = "";
//            $patronymicName = "";
//            $contractNumber = "";
//            if(isset($_POST['firstName'])){ $firstName = trim($_POST['firstName']);}
//            if(isset($_POST['surName'])){ $surName = trim($_POST['surName']);}
//            if(isset($_POST['address'])){ $address = trim($_POST['address']);}
//            if(isset($_POST['email'])){ $email = trim($_POST['email']);}
//            if(isset($_POST['patronymicName'])){ $patronymicName = trim($_POST['patronymicName']);}
//            if(isset($_POST['contractNumber'])){ $contractNumber = trim($_POST['contractNumber']);}
//            if($firstName == '' || $surName == '') {
//                $result = array("result" => 'false');
//                echo json_encode($result);
//                return false;
//            }
//            if($email != '') {
//                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
//                    $client = new ModelClient();
//                    $existsCount = $client->checkEmailExist($email);
//                    if ($existsCount && $existsCount[0]->status == 1) {
//                        $result = array("result" => 'false');
//                        echo json_encode($result);
//                        return false;
//                    } elseif($existsCount && $existsCount[0]->status == 2) {
//                        $result = array("result" => 'false');
//                        echo json_encode($result);
//                        return false;
//                    } else {
//                        $addClientID = addOnlyClient($firstName, $surName, $address, $email,$patronymicName, $contractNumber);
//                        $result = array("result" => $addClientID);
//                        echo json_encode($result);
//                        return true;
//                    }
//                } else {
//                    $result = array("result" => 'false');
//                    echo json_encode($result);
//                    return false;
//                }
//            } else {
//                $addClientID = addOnlyClient($firstName, $surName, $address, $email,$patronymicName, $contractNumber);
//                $result = array("result" => $addClientID);
//                echo json_encode($result);
//                return true;
//            }
//            break;
//
//        case 'getClientList':
//            $client = new ModelClient();
//            $clients = $client->getClients();
//            echo json_encode($clients);
//            break;
//
//        default:
//            $result = array("result" => 'Undefined method');
//            echo json_encode($result);
//            break;
//    }
//
//} catch (\Exception $e){
//    error_log($e->getMessage());
//    header('HTTP/1.1 500 Internal Server Error');
//    header("Status: 500 Internal Server Error");
//    exit();
//}