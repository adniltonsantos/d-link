<?php
//$_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";
//require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//require_once $_SESSION['APPPATH']."models/xor/xor.php";
//require_once $_SESSION['APPPATH']."actions/api/token.php";
//include  $_SESSION['APPPATH'].'models/modelClient.php';
//
//
//function checkToken($token) {
//    if($token != '') {
//        $login = token::check_token($token);
//        if($login!=false) {
//            $user = new ModelUser();
//            $userExist = $user->checkUserIdExist($login);
//            if(empty($userExist)) {
//                $result = array("result" => 'Invalid token');
//                echo json_encode($result);
//                return false;
//            } else {
//                $permissions = $user->getPermissionsByUserId($login);
//                if(count($permissions)==5) {
//                    $userID = $login;
//                    return $userID;
//                } else {
//                    $result = array("result" => 'User is not Administrator');
//                    echo json_encode($result);
//                    return false;
//                }
//            }
//        } else {
//            $result = array("result" => 'Invalid token');
//            echo json_encode($result);
//            return false;
//        }
//    } else {
//        $result = array("result" => 'Invalid token');
//        echo json_encode($result);
//        return false;
//    }
//}
//
//try {
//    if (isset($_POST['method']) && !empty($_POST['method'])) {
//        $userID = '';
//        $action = trim($_POST['method']);
//        if (session_id() == '') {
//            session_start();
//        }
//        if (isset($_POST['token'])) {
//            $token = trim($_POST['token']);
//            $tokenExist = checkToken($token);
//            if ($tokenExist == false) {
//                return false;
//            } else {
//                $userID = $tokenExist;
//            }
//        } else {
//            $result = array("result" => "false");
//            echo json_encode($result);
//            return false;
//        }
//    }
//
//    switch ($action) {
//        case 'getUnregisterDevices':
//            $client = new ModelClient();
//            if (isset($_POST["action"])) {
//                $action = $_POST["action"];
//                if($action=="getUnknowns") {
//                    $result = $client->getAllUnknowns();
//                    } else if($action=="getPending") {
//                    $result = $client->getAllPending();
//                } else {
//                    $result = array("result" => "Invalid action name");
//                }
//            } else {
//                $result = $client->getAllUnregisterDevices();
//            }
//            echo json_encode($result);
//            break;
//
//        case 'getUnregisterDevicesByIpSerial':
//            $client = new ModelClient();
//            if(isset($_POST['ip']) && isset($_POST['serial_number'])) {
//                $ip = $_POST['ip'];
//                $serial = $_POST['serial_number'];
//                $result = $client->getUnregisterDevicesByIpSerial($ip, $serial);
//            } else if(isset($_POST['ip'])) {
//                $ip = $_POST['ip'];
//                $serial = '';
//                $result = $client->getUnregisterDevicesByIpSerial($ip, $serial);
//            } else if (isset($_POST['serial_number'])) {
//                $ip = '';
//                $serial = $_POST['serial_number'];
//                $result = $client->getUnregisterDevicesByIpSerial($ip, $serial);
//            } else {
//                $result = array("result" => "false");
//            }
//            echo json_encode($result);
//            break;
//
//        default:
//            $result = array("result" => 'Undefined method');
//            echo json_encode($result);
//            break;
//    }
//
//} catch (\Exception $e){
//    error_log($e->getMessage());
//    header('HTTP/1.1 500 Internal Server Error');
//    header("Status: 500 Internal Server Error");
//    exit();
//}